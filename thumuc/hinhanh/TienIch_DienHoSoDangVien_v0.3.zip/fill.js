// Bộ máy điền – tiêm vào trang Thêm mới hồ sơ đảng viên (sau fields.js).
(() => {
  if (window.__dienHoSo && window.__dienHoSoVer === 2) return;
  window.__dienHoSoVer = 2;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const chuan = (s) => (s == null ? "" : String(s)).normalize("NFC").replace(/\s+/g, " ").trim().toLowerCase();
  const q = (sel, root = document) => root.querySelector(sel);
  const qa = (sel, root = document) => [...root.querySelectorAll(sel)];
  const click = (el) => el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
  const host = (key) => q(`[formcontrolname="${key}"]`);

  async function cho(fn, ms = 6000, buoc = 150) {
    for (let t = 0; t < ms; t += buoc) {
      const v = fn();
      if (v) return v;
      await sleep(buoc);
    }
    return null;
  }

  function chonKhop(ds, gt) {
    const g = chuan(gt);
    let i = ds.findIndex((t) => chuan(t) === g);
    if (i < 0) i = ds.findIndex((t) => g && chuan(t).includes(g));
    return i;
  }

  function datGiaTri(el, v) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function dongPopup() {
    const bd = q(".cdk-overlay-backdrop");
    if (bd) click(bd);
    const close = q("vts-modal-container .vtsicon-Close\\:vts");
    if (close) click(close.closest("button") || close);
    const ll = host("profileNumber");
    if (ll) click(ll);
    await sleep(300);
  }

  // Danh sách lựa chọn đang mở (lớp phủ cuối cùng có mục chọn)
  function luaChonDangMo() {
    const panes = qa(".cdk-overlay-pane").filter((p) => p.querySelector("vts-option-item"));
    return panes.length ? qa("vts-option-item", panes[panes.length - 1]) : [];
  }

  // ---------- từng kiểu trường ----------
  async function dienRadio(key, val) {
    const labels = qa(`[formcontrolname="${key}"] label`);
    const i = chonKhop(labels.map((l) => l.innerText), val);
    if (i < 0) throw new Error(`không có lựa chọn "${val}"`);
    labels[i].click();
  }

  async function dienSelect(key, val) {
    const h = q(`vts-select[formcontrolname="${key}"]`);
    // Ô phụ thuộc (VD Xã/Phường chờ Tỉnh) – chờ được mở khóa
    const moKhoa = await cho(() => !h.className.includes("vts-select-disabled"), 6000);
    if (!moKhoa) {
      const hien = q("vts-select-top-control", h).innerText.trim();
      if (chuan(hien) === chuan(val)) return; // ô khóa nhưng đã đúng giá trị
      throw new Error("ô đang bị khóa trên trang");
    }
    const hienTai = q("vts-select-top-control", h).innerText.trim();
    if (chuan(hienTai) === chuan(val)) return; // đã đúng, khỏi chọn lại

    h.scrollIntoView({ block: "center" });
    click(q("vts-select-top-control", h));
    const coDs = await cho(() => luaChonDangMo().length > 0, 8000);
    if (!coDs) { await dongPopup(); throw new Error("danh sách không mở được"); }

    let opts = luaChonDangMo();
    let i = chonKhop(opts.map((o) => o.innerText), val);
    if (i < 0 || chuan(opts[i].innerText) !== chuan(val)) {
      // Danh sách dài (cuộn ảo): gõ vào ô tìm kiếm để lọc
      const tim = q("input.vts-select-selection-search-input", h);
      if (tim) {
        datGiaTri(tim, val);
        await sleep(700);
        await cho(() => luaChonDangMo().length > 0, 3000);
        opts = luaChonDangMo();
        const j = chonKhop(opts.map((o) => o.innerText), val);
        if (j >= 0) i = j;
      }
    }
    if (i < 0 || !opts[i] || !opts[i].isConnected) { await dongPopup(); throw new Error(`không tìm thấy lựa chọn "${val}"`); }
    opts[i].scrollIntoView({ block: "nearest" });
    opts[i].click();
    await sleep(400);
  }

  async function dienToChuc(key, val) {
    const h = q(`vts-select[formcontrolname="${key}"]`);
    h.scrollIntoView({ block: "center" });
    click(q("vts-select-top-control", h));
    const dlg = await cho(() => q("app-organization-dialog vts-tree-node") && q("app-organization-dialog"), 10000);
    if (!dlg) throw new Error("hộp thoại chọn tổ chức không mở được");
    const g = chuan(val);
    const tim = () => {
      const nodes = qa("vts-tree-node", dlg);
      const hit = nodes.filter((n) => chuan(n.getAttribute("title")).includes(g));
      const exact = hit.filter((n) => {
        const t = chuan(n.getAttribute("title"));
        return t === g || t.split(" - ").slice(1).join(" - ") === g || t.split(" - ")[0] === g;
      });
      return exact[0] || hit[hit.length - 1] || null;
    };
    let node = tim();
    for (let cap = 0; !node && cap < 4; cap++) {
      const dong = qa("vts-tree-node-switcher.vts-tree-switcher_close", dlg);
      if (!dong.length) break;
      dong.forEach((s) => click(s));
      await sleep(1500);
      node = tim();
    }
    if (!node) { await dongPopup(); throw new Error(`không tìm thấy tổ chức "${val}"`); }
    node.scrollIntoView({ block: "center" });
    click(q("vts-tree-node-title", node));
    await cho(() => !q("app-organization-dialog"), 5000);
  }

  async function dienText(key, val) {
    const el = q(`input[formcontrolname="${key}"], textarea[formcontrolname="${key}"]`);
    if (el.disabled || el.readOnly) throw new Error("ô đang bị khóa trên trang");
    el.scrollIntoView({ block: "center" });
    el.focus();
    datGiaTri(el, val);
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  async function dienNgay(key, val) {
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(val)) throw new Error(`ngày "${val}" phải có dạng dd/mm/yyyy`);
    await dienText(key, val);
  }

  async function dienCheck(key, val) {
    const h = host(key);
    const cb = q("input[type=checkbox]", h);
    const muon = ["có", "x", "1", "true", "yes", "đúng"].includes(chuan(val));
    if (cb && cb.checked !== muon) h.click();
  }

  function docLai(key, kieu) {
    const h = host(key);
    if (!h) return "";
    if (kieu === "text" || kieu === "date" || kieu === "area") return h.value;
    if (kieu === "check") return q("input[type=checkbox]", h)?.checked ? "Có" : "Không";
    if (kieu === "radio") {
      const l = q("label.vts-radio-wrapper-checked", h);
      return l ? l.innerText.trim() : "";
    }
    const t = q("vts-select-top-control", h).innerText.trim();
    return t.startsWith("--") ? "" : t;
  }

  const HAM = { radio: dienRadio, select: dienSelect, org: dienToChuc, text: dienText, area: dienText, date: dienNgay, check: dienCheck };

  // ---------- bảng tiến độ trên trang ----------
  function bang() {
    let b = q("#__dhs_panel");
    if (!b) {
      b = document.createElement("div");
      b.id = "__dhs_panel";
      b.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;width:340px;max-height:60vh;overflow:auto;background:#fff;border:1px solid #c8102e;border-radius:8px;box-shadow:0 6px 24px rgba(0,0,0,.2);font:13px/1.4 Segoe UI,Arial,sans-serif;color:#1f2328";
      document.body.appendChild(b);
    }
    return b;
  }
  function veBang(tieuDe, dong, xong) {
    const b = bang();
    b.innerHTML = "";
    const h = document.createElement("div");
    h.style.cssText = "background:#c8102e;color:#fff;padding:8px 12px;font-weight:600;display:flex;justify-content:space-between;align-items:center";
    h.textContent = tieuDe;
    if (xong) {
      const x = document.createElement("span");
      x.textContent = "✕";
      x.style.cssText = "cursor:pointer;padding:0 4px";
      x.onclick = () => b.remove();
      h.appendChild(x);
    }
    b.appendChild(h);
    const body = document.createElement("div");
    body.style.cssText = "padding:8px 12px";
    for (const d of dong) {
      const p = document.createElement("div");
      p.style.cssText = "padding:3px 0;border-bottom:1px solid #eee";
      p.textContent = (d.ok ? "✔ " : "✘ ") + d.nhan + (d.ok ? "" : " — " + d.loi);
      p.style.color = d.ok ? "#1a7f37" : "#c8102e";
      body.appendChild(p);
    }
    if (xong) {
      const n = document.createElement("div");
      n.style.cssText = "margin-top:6px;color:#555;font-size:12px";
      n.textContent = "Kiểm tra lại toàn bộ trang rồi tự bấm “Lưu & tiếp tục”.";
      body.appendChild(n);
    }
    b.appendChild(body);
  }

  window.__dienHoSo = async (duLieu) => {
    if (!host("currentFullName")) return { loiChung: "Trang hiện tại không phải trang Thêm mới hồ sơ đảng viên." };
    const ds = (window.TRUONG_HO_SO || []).filter(([k]) => String(duLieu[k] ?? "").trim() !== "");
    const kq = [];
    let n = 0;
    for (const [key, nhan, kieu] of ds) {
      n++;
      const val = String(duLieu[key]).trim();
      veBang(`Đang điền ${n}/${ds.length}: ${nhan}`, kq.filter((d) => !d.ok), false);
      if (!host(key)) {
        kq.push({ key, nhan, ok: false, loi: key === "cardNumber" ? "ô bị ẩn (đảng viên dự bị không có số thẻ)" : "ô không hiển thị trên trang" });
        continue;
      }
      try {
        await HAM[kieu](key, val);
        await sleep(200);
        kq.push({ key, nhan, ok: true, hien: docLai(key, kieu) });
      } catch (e) {
        kq.push({ key, nhan, ok: false, loi: e.message });
      }
    }
    const loi = kq.filter((d) => !d.ok);
    veBang(`Xong: ${kq.length - loi.length}/${kq.length} trường` + (loi.length ? `, ${loi.length} lỗi` : ""), loi, true);
    window.scrollTo({ top: 0, behavior: "smooth" });
    return { kq };
  };
})();
