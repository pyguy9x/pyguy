const $ = (id) => document.getElementById(id);
const KHOA = TRUONG_HO_SO.map((t) => t[0]);
const KIEU = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[2]]));
let hoSo = [];

const pad = (n) => String(n).padStart(2, "0");
const ngay = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;

function trangThai(s, loi) { $("tt").textContent = s; $("tt").className = "tt" + (loi ? " err" : ""); }

// ---------- Đọc Excel ----------
function docExcel(buf) {
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets["HoSo"] || wb.Sheets[wb.SheetNames.find((n) => n !== "HuongDan" && n !== "DanhMuc")];
  if (!ws) throw new Error("Không thấy trang tính HoSo.");
  const range = XLSX.utils.decode_range(ws["!ref"]);
  const giaTri = (r, c) => {
    const cell = ws[XLSX.utils.encode_cell({ r, c })];
    if (!cell || cell.v == null) return "";
    if (cell.v instanceof Date) return ngay(cell.v);
    return String(cell.w ?? cell.v).trim();
  };
  // Tìm dòng mã trường (dòng có nhiều mã trường nhất trong 10 dòng đầu)
  let dongMa = -1, cot = {};
  for (let r = range.s.r; r <= Math.min(range.e.r, range.s.r + 9); r++) {
    const m = {};
    for (let c = range.s.c; c <= range.e.c; c++) {
      const v = giaTri(r, c);
      if (KHOA.includes(v)) m[v] = c;
    }
    if (Object.keys(m).length > Object.keys(cot).length) { cot = m; dongMa = r; }
  }
  if (dongMa < 0 || Object.keys(cot).length < 5) throw new Error("Không nhận ra mẫu: thiếu dòng mã trường (dòng 3 của file mẫu).");
  const kq = [];
  for (let r = dongMa + 1; r <= range.e.r; r++) {
    const d = {};
    for (const [k, c] of Object.entries(cot)) {
      let v = giaTri(r, c);
      // Ô ngày nhập kiểu số/ngày của Excel
      if (KIEU[k] === "date") {
        const cell = ws[XLSX.utils.encode_cell({ r, c })];
        if (cell && typeof cell.v === "number" && cell.v > 1000 && cell.v < 80000) {
          const p = XLSX.SSF.parse_date_code(cell.v);
          v = `${pad(p.d)}/${pad(p.m)}/${p.y}`;
        }
      }
      if (v) d[k] = v;
    }
    if (Object.keys(d).length) { d.__dong = r + 1; kq.push(d); }
  }
  return { kq, soCot: Object.keys(cot).length };
}

function veDanhSach(chon = 0) {
  const ds = $("ds");
  ds.innerHTML = "";
  hoSo.forEach((d, i) => {
    const o = document.createElement("option");
    o.value = i;
    o.textContent = `${i + 1}. ${d.currentFullName || "(chưa có họ tên)"}${d.birthDate ? " – " + d.birthDate : ""} (dòng ${d.__dong})`;
    ds.append(o);
  });
  ds.disabled = !hoSo.length;
  $("dien").disabled = !hoSo.length;
  if (hoSo.length) { ds.value = Math.min(chon, hoSo.length - 1); xem(); }
}

function xem() {
  const d = hoSo[$("ds").value];
  const n = KHOA.filter((k) => d[k]).length;
  const el = $("xem");
  el.style.display = "block";
  el.innerHTML = "";
  const b = document.createElement("b");
  b.textContent = d.currentFullName || "(chưa có họ tên)";
  el.append(b, document.createTextNode(` · ${n}/76 trường có dữ liệu · ${d.activityOfficialOrgId || "chưa có tổ chức đảng"}`));
  $("tiep").disabled = Number($("ds").value) >= hoSo.length - 1;
}

$("nhap").onclick = () => $("tep").click();
async function napFile(f) {
  if (!f) return;
  try {
    const { kq, soCot } = docExcel(await f.arrayBuffer());
    hoSo = kq;
    await chrome.storage.session.set({ hoSo, ten: f.name, chon: 0 });
    trangThai(`Đã nhập ${kq.length} hồ sơ từ ${f.name} (${soCot}/76 cột nhận được).`, !kq.length);
    $("kq").innerHTML = "";
    veDanhSach(0);
  } catch (err) {
    trangThai("Lỗi đọc file: " + err.message, true);
  }
}
$("tep").onchange = async (e) => { await napFile(e.target.files[0]); e.target.value = ""; };
const tha = $("tha");
tha.ondragover = (e) => { e.preventDefault(); tha.classList.add("over"); };
tha.ondragleave = () => tha.classList.remove("over");
tha.ondrop = (e) => { e.preventDefault(); tha.classList.remove("over"); napFile(e.dataTransfer.files[0]); };

$("ds").onchange = () => { xem(); chrome.storage.session.set({ chon: Number($("ds").value) }); $("kq").innerHTML = ""; };
$("tiep").onclick = () => { $("ds").value = Number($("ds").value) + 1; $("ds").onchange(); };

function hienKq(dong, tieuDe) {
  const kq = $("kq");
  kq.innerHTML = "";
  if (tieuDe) { const t = document.createElement("div"); t.className = "tong"; t.textContent = tieuDe; kq.append(t); }
  // Lỗi lên đầu
  for (const d of [...dong.filter((x) => !x.ok), ...dong.filter((x) => x.ok)]) {
    const div = document.createElement("div");
    div.className = "d " + (d.ok ? "ok" : "err");
    const b = document.createElement("b");
    b.textContent = (d.ok ? "✔ " : "✘ ") + d.nhan;
    const s = document.createElement("small");
    s.textContent = d.ok ? d.hien : d.loi;
    div.append(b, s);
    kq.append(div);
  }
}

$("dien").onclick = async () => {
  const d = hoSo[$("ds").value];
  if (!d) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https:\/\/tcxdd\.dcs\.vn\//.test(tab.url || ""))
    return hienKq([{ ok: false, nhan: "Sai trang", loi: "Mở trang Thêm mới hồ sơ đảng viên trên tcxdd.dcs.vn rồi bấm lại." }]);
  $("dien").disabled = $("nhap").disabled = $("tiep").disabled = true;
  hienKq([], "Đang điền… (khoảng 1–2 phút; có thể thao tác xem trang, không cần giữ cửa sổ)");
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["fields.js", "fill.js"] });
    const duLieu = Object.fromEntries(KHOA.filter((k) => d[k]).map((k) => [k, d[k]]));
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: (x) => window.__dienHoSo(x), args: [duLieu] });
    const v = r.result || {};
    if (v.loiChung) hienKq([{ ok: false, nhan: "Không điền được", loi: v.loiChung }]);
    else {
      const loi = v.kq.filter((x) => !x.ok).length;
      hienKq(v.kq, `Đã dừng sau hồ sơ ${d.currentFullName || ""}: ${v.kq.length - loi}/${v.kq.length} trường đúng${loi ? `, ${loi} lỗi` : ""}. Kiểm tra trang rồi tự bấm Lưu.`);
    }
  } catch (e) {
    hienKq([{ ok: false, nhan: "Lỗi", loi: e.message }]);
  } finally {
    $("dien").disabled = $("nhap").disabled = false;
    xem();
  }
};

// Khôi phục dữ liệu đã nhập trong phiên (xóa khi đóng trình duyệt)
chrome.storage.session.get(["hoSo", "ten", "chon"], (s) => {
  if (s.hoSo && s.hoSo.length) {
    hoSo = s.hoSo;
    trangThai(`Đang dùng ${hoSo.length} hồ sơ từ ${s.ten} (dữ liệu tự xóa khi đóng trình duyệt).`);
    veDanhSach(s.chon || 0);
  }
});
