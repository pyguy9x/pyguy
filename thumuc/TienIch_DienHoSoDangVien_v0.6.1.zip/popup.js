const $ = (id) => document.getElementById(id);
const KHOA = TRUONG_HO_SO.map((t) => t[0]);
const KIEU = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[2]]));
const NHOM = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[3]]));

// Trường các bước dạng danh sách và bước 9 (khớp fill_ds.js, fill_kt.js, file Excel)
const DS_BUOC = {
  qtct: { ten: "Quá trình công tác", sheet: "QuaTrinhCongTac", don: "dòng công tác", truong: [
    ["fromDate", "Từ tháng/năm"], ["toDate", "Đến tháng/năm"], ["nationId", "Quốc gia"], ["companyName", "Tên tổ chức"],
    ["partyPositionIds", "Chức vụ đảng (cách nhau dấu ;)"], ["concurrentPartyPosition", "Chức vụ Đảng kiêm nhiệm"],
    ["companyPosition", "Chức danh, chức vụ, nghề nghiệp"], ["note", "Ghi chú"]],
    nhan: (x) => `${x.fromDate || "?"}${x.toDate ? " – " + x.toDate : ""}: ${x.companyName || x.companyPosition || ""}` },
  qh: { ten: "Quan hệ gia đình", sheet: "QuanHeGiaDinh", don: "người thân", truong: [
    ["type", "Phân loại"], ["familyMemberId", "Quan hệ"], ["isPartyMember", "Là đảng viên"], ["fullName", "Họ và tên"],
    ["identifyNo", "Số căn cước"], ["birthDate", "Năm sinh"], ["currentStatus", "Tình trạng (qua đời/ly hôn)"],
    ["finishedYear", "Năm qua đời/ly hôn"], ["currentJob", "Công việc"], ["nationalityId", "Quốc tịch"],
    ["nationId", "Nơi ở hiện nay"], ["residentPlace", "Chi tiết nơi ở"], ["hometown", "Quê quán"], ["note", "Ghi chú"]],
    nhan: (x) => `${x.familyMemberId || "?"}: ${x.fullName || ""}${x.birthDate ? " (" + x.birthDate + ")" : ""}` },
};
const KT_TRUONG = [
  ["householdAnnualIncome", "Tổng thu nhập hộ/năm (đồng)"], ["perCapitaAnnualIncome", "Thu nhập bình quân đầu người (đồng)"],
  ["economicActivity", "Hoạt động kinh tế"], ["countWorker", "Số lao động thuê mướn"],
  ["nhaCapLoai", "Nhà được cấp/thuê – loại"], ["nhaCapDienTich", "Nhà được cấp/thuê – m2"],
  ["nhaMuaLoai", "Nhà tự mua/xây – loại"], ["nhaMuaDienTich", "Nhà tự mua/xây – m2"],
  ["datCap", "Đất được cấp (m2)"], ["datMua", "Đất tự mua (m2)"], ["datTrangTrai", "Đất trang trại (ha)"],
  ["taiSan1Ten", "Tài sản 1 – tên"], ["taiSan1GiaTri", "Tài sản 1 – giá trị (đồng)"],
  ["taiSan2Ten", "Tài sản 2 – tên"], ["taiSan2GiaTri", "Tài sản 2 – giá trị (đồng)"],
  ["taiSan3Ten", "Tài sản 3 – tên"], ["taiSan3GiaTri", "Tài sản 3 – giá trị (đồng)"],
];

let hoSo = [], daLuu = {}, ssHienTai = null, tabDien = null, dangChay = false, choTrangMoi = false, buocDangChay = null;
let dsSS = { qtct: null, qh: null }, dsTT = { qtct: {}, qh: {} }, dsChayIdx = { qtct: [], qh: [] }, ktSS = null;

const pad = (n) => String(n).padStart(2, "0");
const el = (tag, props = {}, ...con) => { const e = Object.assign(document.createElement(tag), props); e.append(...con); return e; };
function trangThai(id, s, kieu) { $(id).textContent = s; $(id).className = "tt" + (kieu ? " " + kieu : ""); }
const luu = () => chrome.storage.session.set({ hoSo, daLuu, chon: Number($("ds").value) || 0 });
const chiSo = () => Number($("ds").value);
const hs = () => hoSo[chiSo()];

// ================= ĐỌC EXCEL =================
function docExcel(buf) {
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets["HoSo"] || wb.Sheets[wb.SheetNames.find((n) => !["HuongDan", "DanhMuc"].includes(n))];
  if (!ws) throw new Error("Không thấy trang tính HoSo.");
  const range = XLSX.utils.decode_range(ws["!ref"]);
  const giaTri = (r, c) => { const cell = ws[XLSX.utils.encode_cell({ r, c })]; return !cell || cell.v == null ? "" : String(cell.w ?? cell.v).trim(); };
  let dongMa = -1, cot = {};
  for (let r = range.s.r; r <= Math.min(range.e.r, range.s.r + 9); r++) {
    const m = {};
    for (let c = range.s.c; c <= range.e.c; c++) { const v = giaTri(r, c); if (KHOA.includes(v)) m[v] = c; }
    if (Object.keys(m).length > Object.keys(cot).length) { cot = m; dongMa = r; }
  }
  if (dongMa < 0 || Object.keys(cot).length < 5) throw new Error("Không nhận ra mẫu: thiếu dòng mã trường (dòng 3 của file mẫu).");
  const kq = [];
  for (let r = dongMa + 1; r <= range.e.r; r++) {
    const d = {};
    for (const [k, c] of Object.entries(cot)) {
      let v = giaTri(r, c);
      if (KIEU[k] === "date") {
        const cell = ws[XLSX.utils.encode_cell({ r, c })];
        if (cell && typeof cell.v === "number" && cell.v > 1000 && cell.v < 80000) { const p = XLSX.SSF.parse_date_code(cell.v); v = `${pad(p.d)}/${pad(p.m)}/${p.y}`; }
      }
      if (v) d[k] = v;
    }
    if (Object.keys(d).length) { d.__dong = r + 1; kq.push(d); }
  }
  // Trang phụ: gắn theo số căn cước đảng viên (cột dangVienCanCuoc)
  const docPhu = (ten) => {
    const out = {};
    const w = wb.Sheets[ten];
    if (!w || !w["!ref"]) return out;
    const rq = XLSX.utils.decode_range(w["!ref"]);
    const v = (r, c) => { const x = w[XLSX.utils.encode_cell({ r, c })]; return x && x.v != null ? String(x.w ?? x.v).trim() : ""; };
    let dongMaPhu = -1, cotP = {};
    for (let r = 0; r <= Math.min(rq.e.r, 9) && dongMaPhu < 0; r++) {
      const m = {};
      for (let c = rq.s.c; c <= rq.e.c; c++) { const t = v(r, c); if (/^[a-zA-Z0-9]+$/.test(t)) m[t] = c; }
      if (m.dangVienCanCuoc != null) { cotP = m; dongMaPhu = r; }
    }
    if (dongMaPhu < 0) return out;
    for (let r = dongMaPhu + 1; r <= rq.e.r; r++) {
      const k = v(r, cotP.dangVienCanCuoc);
      if (!k) continue;
      const x = { __dong: r + 1 };
      for (const [key, c] of Object.entries(cotP)) if (key !== "dangVienCanCuoc") { const t = v(r, c); if (t) x[key] = t; }
      if (Object.keys(x).length > 1) (out[k] = out[k] || []).push(x);
    }
    return out;
  };
  const qtct = docPhu("QuaTrinhCongTac"), qh = docPhu("QuanHeGiaDinh"), kt = docPhu("HoanCanhKinhTe");
  kq.forEach((d) => {
    d.__ds = { qtct: qtct[d.identifyNo] || [], qh: qh[d.identifyNo] || [] };
    d.__kt = (kt[d.identifyNo] || [])[0] || {};
  });
  return { kq, soCot: Object.keys(cot).length };
}

async function napFile(f) {
  if (!f) return;
  try {
    const { kq, soCot } = docExcel(await f.arrayBuffer());
    hoSo = kq; daLuu = {};
    veDanhSach(0);
    await luu();
    await chrome.storage.session.set({ ten: f.name });
    trangThai("tt", `Đã nhập ${kq.length} hồ sơ từ ${f.name} (${soCot}/76 cột B1). Xem và sửa ở mục "Tổng quan" bên dưới.`, kq.length ? "ok" : "err");
  } catch (err) { trangThai("tt", "Lỗi đọc file: " + err.message, "err"); }
}
$("nhap").onclick = () => $("tep").click();
$("tep").onchange = async (e) => { await napFile(e.target.files[0]); e.target.value = ""; };
const tha = $("tha");
tha.ondragover = (e) => { e.preventDefault(); tha.classList.add("over"); };
tha.ondragleave = () => tha.classList.remove("over");
tha.ondrop = (e) => { e.preventDefault(); tha.classList.remove("over"); napFile(e.dataTransfer.files[0]); };

// ================= DANH SÁCH HỒ SƠ =================
function veDanhSach(chon = 0) {
  const ds = $("ds");
  ds.innerHTML = "";
  hoSo.forEach((d, i) => ds.append(el("option", { value: i, textContent: `${daLuu[i] ? "✓ " : ""}${i + 1}. ${d.currentFullName || "(chưa có họ tên)"}${d.birthDate ? " – " + d.birthDate : ""}` })));
  ds.disabled = !hoSo.length;
  $("khuTongQuan").hidden = $("khuBuoc").hidden = !hoSo.length;
  if (hoSo.length) { ds.value = Math.min(chon, hoSo.length - 1); xem(); }
  capNhatNut();
}
function xem() {
  const d = hs();
  if (!d) return;
  const n = KHOA.filter((k) => d[k]).length;
  const x = $("xem");
  x.style.display = "block";
  x.innerHTML = "";
  x.append(el("b", { textContent: d.currentFullName || "(chưa có họ tên)" }),
    ` · dòng ${d.__dong} · B1: ${n}/76 trường · B2: ${d.__ds.qtct.length} dòng · B8: ${d.__ds.qh.length} người · B9: ${Object.keys(d.__kt).filter((k) => !k.startsWith("__")).length} ô` + (daLuu[chiSo()] ? " · đã bấm Lưu B1" : ""));
  xoaSoSanh();
  dsSS = { qtct: null, qh: null }; dsTT = { qtct: {}, qh: {} }; ktSS = null;
  veTongQuan();
  veDS("qtct"); veDS("qh"); veKT();
}
function capNhatNut() {
  const co = hoSo.length > 0;
  $("truoc").disabled = !co || dangChay || chiSo() <= 0;
  $("sau").disabled = !co || dangChay || chiSo() >= hoSo.length - 1;
  $("ds").disabled = !co || dangChay;
  $("soSanh").disabled = !co || dangChay;
  $("nhap").disabled = dangChay;
  $("dieuKhien").hidden = !dangChay;
  $("dien").disabled = dangChay || !ssHienTai || !dsChon().length || (ssHienTai.canhBao.length && !$("dungNguoi")?.checked);
  $("dien").textContent = `Điền ${dsChon().length} ô đã chọn`;
  for (const b of ["qtct", "qh"]) {
    if (!$(`${b}SoSanh`)) continue;
    $(`${b}SoSanh`).disabled = dangChay || !co;
    $(`${b}Dien`).disabled = dangChay || !dsSS[b] || !dsChonDS(b).length;
    $(`${b}Dien`).textContent = `Điền ${dsChonDS(b).length} ${DS_BUOC[b].don} đã chọn`;
  }
  $("ktSoSanh").disabled = dangChay || !co;
  const nKT = ktSS ? ktSS.ds.filter((x) => x.chon).length : 0;
  $("ktDien").disabled = dangChay || !nKT;
  $("ktDien").textContent = `Điền ${nKT} ô đã chọn`;
}
$("ds").onchange = () => { xem(); luu(); capNhatNut(); };
$("truoc").onclick = () => { $("ds").value = chiSo() - 1; $("ds").onchange(); };
$("sau").onclick = () => { $("ds").value = chiSo() + 1; $("ds").onchange(); };

// Thẻ chọn bước
document.querySelectorAll(".tab").forEach((t) => (t.onclick = () => {
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("on", x === t));
  document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.id !== "p_" + t.dataset.buoc));
}));

// ================= TỔNG QUAN – XEM & SỬA =================
let tqHienHet = false;
const oNhap = (nhan, gt, luuFn, daCo) => {
  const i = el("input", { value: gt || "", className: daCo ? "da-co" : "", title: daCo ? "Ô này đã có dữ liệu trên trang: " + daCo : "" });
  i.onchange = () => { luuFn(i.value.trim()); luu(); xoaKetQuaSoSanh(); };
  return el("div", { className: "tq-o" }, el("span", { textContent: nhan + (daCo ? " ⚠" : "") }), i);
};
function xoaKetQuaSoSanh() { xoaSoSanh(); dsSS = { qtct: null, qh: null }; ktSS = null; veDS("qtct"); veDS("qh"); veKT(); }
function veTongQuan() {
  const d = hs(), box = $("tqNoiDung");
  if (!d) return;
  box.innerHTML = "";
  const daCoB1 = ssHienTai ? Object.fromEntries(ssHienTai.ds.filter((x) => x.cu).map((x) => [x.key, x.cu])) : {};
  // B1
  const b1 = el("details", {}, el("summary", { textContent: `B1 – Thông tin cơ bản (${KHOA.filter((k) => d[k]).length}/76 trường có dữ liệu)` }));
  b1.append(el("div", {}, el("span", { className: "lienKet", textContent: tqHienHet ? "Chỉ hiện trường có dữ liệu" : "Hiện cả trường trống", onclick: () => { tqHienHet = !tqHienHet; veTongQuan(); $("tqNoiDung").firstChild.open = true; } })));
  for (const [k, nhan] of TRUONG_HO_SO) if (tqHienHet || d[k]) b1.append(oNhap(nhan, d[k], (v) => { if (v) d[k] = v; else delete d[k]; }, daCoB1[k]));
  box.append(b1);
  // B2, B8
  for (const b of ["qtct", "qh"]) {
    const cf = DS_BUOC[b], ds = d.__ds[b];
    const sec = el("details", {}, el("summary", { textContent: `${b === "qtct" ? "B2" : "B8"} – ${cf.ten} (${ds.length} ${cf.don})` }));
    ds.forEach((x, i) => {
      const daCo = dsSS[b] && dsSS[b][i];
      const the = el("div", { className: "tq-the" }, el("div", { className: "dau2" },
        el("span", { textContent: `${i + 1}. ${cf.nhan(x)}${daCo ? " ⚠ đã có trên trang" : ""}` }),
        el("span", { className: "xoa", textContent: "Xóa", onclick: () => { if (confirm("Xóa dòng này khỏi dữ liệu sẽ điền?")) { ds.splice(i, 1); luu(); xoaKetQuaSoSanh(); veTongQuan(); sec.open = true; } } })));
      for (const [k, nhan] of cf.truong) the.append(oNhap(nhan, x[k], (v) => { if (v) x[k] = v; else delete x[k]; }));
      sec.append(the);
    });
    sec.append(el("span", { className: "lienKet", textContent: `+ Thêm ${cf.don}`, onclick: () => { ds.push({}); luu(); veTongQuan(); [...$("tqNoiDung").children].find((s) => s.textContent.includes(cf.ten)).open = true; } }));
    box.append(sec);
  }
  // B9
  const kt = d.__kt;
  const daCoKT = ktSS ? Object.fromEntries(ktSS.ds.filter((x) => x.cu).map((x) => [x.key, x.cu])) : {};
  const b9 = el("details", {}, el("summary", { textContent: `B9 – Hoàn cảnh kinh tế (${KT_TRUONG.filter(([k]) => kt[k]).length} ô có dữ liệu)` }));
  for (const [k, nhan] of KT_TRUONG) b9.append(oNhap(nhan, kt[k], (v) => { if (v) kt[k] = v; else delete kt[k]; }, daCoKT[k]));
  box.append(b9);
  const dem = [ssHienTai && `B1: ${ssHienTai.ds.filter((x) => x.cu).length} trường đã có dữ liệu trên trang`,
    dsSS.qtct && `B2: ${dsSS.qtct.filter(Boolean).length} dòng đã có`, dsSS.qh && `B8: ${dsSS.qh.filter(Boolean).length} người đã có`,
    ktSS && `B9: ${ktSS.ds.filter((x) => x.cu).length} ô đã có`].filter(Boolean);
  trangThai("tqTomTat", dem.length ? "Đã so sánh – " + dem.join(" · ") + " (đánh dấu ⚠)" : "Chưa so sánh với trang. Mở từng mục trên trang và bấm So sánh để biết trường nào đã có.", dem.length ? "err" : "");
}

// ================= LÀM VIỆC VỚI TAB =================
async function layTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !/^https:\/\/tcxdd\.dcs\.vn\//.test(tab.url || "")) throw new Error("Hãy mở trang hồ sơ đảng viên trên tcxdd.dcs.vn.");
  return tab;
}
async function tiem(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["fields.js", "fill.js", "fill_ds.js", "fill_kt.js"] });
}
async function chay(tabId, func, args = []) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
  return r && r.result;
}
const sach = (o) => Object.fromEntries(Object.entries(o).filter(([k]) => !k.startsWith("__")));

// ================= B1: SO SÁNH & ĐIỀN =================
function xoaSoSanh() {
  ssHienTai = null;
  $("canhBao").innerHTML = ""; $("tomTat").innerHTML = ""; $("bangSS").innerHTML = "";
  $("khuDien").hidden = true; $("kq").innerHTML = ""; $("tienDo").textContent = "";
}
const NHAN_TT = { trong: ["Ô trống – sẽ điền", "t-trong"], khac: ["Đã có dữ liệu khác – cần xác nhận", "t-khac"], trung: ["Đã có, trùng – giữ nguyên", "t-trung"], khoa: ["Bị khóa – bỏ qua", "t-khoa"], an: ["Không hiển thị – bỏ qua", "t-khoa"] };

async function soSanh() {
  xoaSoSanh();
  const d = hs();
  if (!d) return;
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    const duLieu = Object.fromEntries(KHOA.filter((k) => d[k]).map((k) => [k, d[k]]));
    const r = await chay(tab.id, (x) => window.__dhsSoSanh(x), [duLieu]);
    if (!r || r.loiChung) { $("tomTat").append(el("div", { className: "tt err", textContent: r ? r.loiChung : "Không đọc được trang." })); return; }
    ssHienTai = r;
    veSoSanh();
    veTongQuan();
  } catch (e) { $("tomTat").append(el("div", { className: "tt err", textContent: e.message })); }
}
$("soSanh").onclick = soSanh;

let hienHet = false;
function veSoSanh() {
  const { ds, canhBao } = ssHienTai;
  const dem = (t) => ds.filter((x) => x.tt === t).length;
  if (canhBao.length) {
    const cb = el("div", { className: "cb" }, el("b", { textContent: "Cảnh báo: có thể không đúng người!" }));
    canhBao.forEach((c) => cb.append(el("div", { textContent: "• " + c })));
    cb.append(el("label", { className: "chk" }, el("input", { type: "checkbox", id: "dungNguoi", onchange: capNhatNut }), "Tôi đã kiểm tra, đúng đảng viên này"));
    $("canhBao").append(cb);
  }
  $("tomTat").append(
    el("span", { className: "tag t-trong", textContent: `${dem("trong")} ô trống` }),
    el("span", { className: "tag t-khac", textContent: `${dem("khac")} ô đã có, khác file` }),
    el("span", { className: "tag t-trung", textContent: `${dem("trung")} ô đã có, trùng` }),
    el("span", { className: "tag t-khoa", textContent: `${dem("khoa") + dem("an")} bỏ qua` }),
    el("div", {}, el("span", { className: "lienKet", textContent: "Hiện cả ô trùng/bỏ qua", onclick: () => { hienHet = !hienHet; veBang(); } }),
      el("span", { className: "lienKet", textContent: "Bỏ chọn tất cả", onclick: () => { ds.forEach((x) => (x.chon = false)); veBang(); } })));
  ds.forEach((x) => (x.chon = x.tt === "trong"));
  hienHet = false;
  veBang();
  $("khuDien").hidden = false;
}
function chonKem(x) {
  const m = x.key.match(/^(\w+?)(Nation|Province)Id$/);
  if (!m || !x.chon) return [];
  const kem = [];
  for (const sau of m[2] === "Nation" ? ["Province", "Commune"] : ["Commune"]) {
    const y = ssHienTai.ds.find((z) => z.key === m[1] + sau + "Id");
    if (y && !y.chon && (y.tt === "khac" || y.tt === "trong")) { y.chon = true; kem.push(y.nhan); }
  }
  return kem;
}
function veBang() {
  const b = $("bangSS");
  b.innerHTML = "";
  let nhomTruoc = "";
  for (const x of ssHienTai.ds) {
    if (!hienHet && (x.tt === "trung" || x.tt === "khoa" || x.tt === "an")) continue;
    if (NHOM[x.key] !== nhomTruoc) { nhomTruoc = NHOM[x.key]; b.append(el("div", { className: "nhom", textContent: nhomTruoc })); }
    const coThe = x.tt === "trong" || x.tt === "khac";
    const cb = el("input", { type: "checkbox", checked: !!x.chon, disabled: !coThe });
    cb.onchange = () => {
      x.chon = cb.checked;
      const kem = chonKem(x);
      if (kem.length) alert(`Đổi "${x.nhan}" thì hệ thống sẽ xóa ô phụ thuộc. Đã chọn kèm: ${kem.join(", ")}.`);
      veBang();
    };
    const [nhan, lop] = NHAN_TT[x.tt];
    const the = el("div", { className: "ss" + (x.tt === "khac" ? " khac" : "") },
      el("div", { className: "dau" }, cb, el("span", { textContent: x.nhan })),
      el("div", { className: "gt" }, el("span", { className: "tag " + lop, textContent: x.tt === "khac" ? (x.chon ? "Đã xác nhận thay" : "Giữ dữ liệu cũ") : nhan })));
    if (x.tt === "khac" || x.tt === "trung") the.append(el("div", { className: "gt" }, el("i", { textContent: "Trên trang:" }), x.tt === "khac" && x.chon ? el("s", { textContent: x.cu }) : x.cu));
    the.append(el("div", { className: "gt" }, el("i", { textContent: "File:" }), x.moi));
    b.append(the);
  }
  if (!b.children.length) b.append(el("div", { className: "tt", textContent: "Không có ô nào cần điền: dữ liệu trên trang đã trùng với file." }));
  capNhatNut();
}
const dsChon = () => (ssHienTai ? ssHienTai.ds.filter((x) => x.chon) : []);

$("dien").onclick = async () => {
  const chon = dsChon();
  if (!chon.length) return;
  const thay = chon.filter((x) => x.tt === "khac");
  if (thay.length && !confirm(`Xác nhận THAY ${thay.length} ô đang có dữ liệu cũ:\n\n` + thay.map((x) => `• ${x.nhan}: "${x.cu}" → "${x.moi}"`).join("\n"))) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    const r = await chay(tab.id, (m) => window.__dhsDien(m), [chon.map((x) => ({ key: x.key, moi: x.moi, cu: x.cu }))]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay("b1");
    $("kq").innerHTML = "";
    trangThai("tienDo", "Đang điền…");
  } catch (e) { trangThai("tienDo", e.message, "err"); }
};
function hienKq(kq, biDoi, dung) {
  const k = $("kq");
  k.innerHTML = "";
  const ok = kq.filter((x) => x.ok).length;
  trangThai("tienDo", (dung ? "Đã dừng hẳn. " : "Xong. ") + `${ok}/${kq.length} ô đã điền. Kiểm tra trang rồi tự bấm Lưu.`, kq.length - ok || biDoi.length ? "err" : "ok");
  for (const d of [...biDoi, ...kq.filter((x) => !x.ok), ...kq.filter((x) => x.ok)])
    k.append(el("div", { className: "d " + (d.ok ? "ok" : "err") }, el("b", { textContent: (d.ok ? "✔ " : "✘ ") + d.nhan }), el("small", { textContent: d.ok ? (d.cu ? `"${d.cu}" → "${d.hien}"` : d.hien) : d.loi })));
}

// ================= ĐIỀU KHIỂN CHUNG =================
let dangTamDung = false;
function batDauChay(buoc) { dangChay = true; buocDangChay = buoc; dangTamDung = false; $("tamDung").textContent = "❚❚ Tạm dừng"; trangThai("dkTT", "Đang điền…"); capNhatNut(); }
function ketThucChay() { dangChay = false; buocDangChay = null; dangTamDung = false; capNhatNut(); }
$("tamDung").onclick = async () => {
  dangTamDung = !dangTamDung;
  await chay(tabDien, (v) => window.__dhsPause(v), [dangTamDung]);
  $("tamDung").textContent = dangTamDung ? "▶ Tiếp tục" : "❚❚ Tạm dừng";
};
$("dungHan").onclick = async () => {
  if (!confirm("Dừng hẳn? Những gì đã điền vẫn ở trên trang (chưa lưu).")) return;
  await chay(tabDien, () => window.__dhsStop());
};

// ================= B2, B8: DANH SÁCH =================
const NHAN_DS = { moi: ["Mới – sẽ Thêm mới", "t-trong"], daCo: ["Đã có trên trang – chỉ điền ô trống", "t-khac"], luu: ["Đã lưu", "t-trong"], dong: ["Đã bỏ qua", "t-trung"], loi: ["Lỗi", "t-khoa"], cho: ["Đang chờ bấm Lưu", "t-khac"] };
const dsChonDS = (b) => { const d = hs(); return d ? d.__ds[b].filter((x, i) => x.__chon !== false && dsTT[b][i] !== "luu") : []; };
function veDS(b) {
  const p = $(`p_${b}`), d = hs(), cf = DS_BUOC[b];
  if (!p.childElementCount) {
    p.append(
      el("button", { id: `${b}SoSanh`, className: "full", textContent: `So sánh với bảng ${cf.ten} trên trang`, onclick: () => soSanhDS(b) }),
      el("div", { id: `${b}TT`, className: "tt" }),
      el("div", { id: `${b}Ds` }),
      el("button", { id: `${b}Dien`, className: "primary full", onclick: () => dienDS(b) }),
      el("div", { id: `${b}Kq` }));
  }
  const box = $(`${b}Ds`);
  box.innerHTML = "";
  if (!d) return;
  if (!d.__ds[b].length) box.append(el("div", { className: "tt", textContent: `File không có ${cf.don} nào cho đảng viên này (trang ${cf.sheet}, cột A = số căn cước đảng viên).` }));
  d.__ds[b].forEach((x, i) => {
    const cb = el("input", { type: "checkbox", checked: x.__chon !== false, disabled: dangChay });
    cb.onchange = () => { x.__chon = cb.checked; capNhatNut(); };
    const tt = dsTT[b][i] || (dsSS[b] ? (dsSS[b][i] ? "daCo" : "moi") : null);
    const the = el("div", { className: "ss" }, el("div", { className: "dau" }, cb, el("span", { textContent: cf.nhan(x) })));
    if (tt) the.append(el("div", { className: "gt" }, el("span", { className: "tag " + NHAN_DS[tt][1], textContent: NHAN_DS[tt][0] })));
    box.append(the);
  });
  capNhatNut();
}
async function soSanhDS(b) {
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    const r = await chay(tab.id, (bb, x) => window.__dhsDSSoSanh(bb, x), [b, hs().__ds[b].map(sach)]);
    if (!r || r.loiChung) return trangThai(`${b}TT`, r ? r.loiChung : "Không đọc được trang.", "err");
    dsSS[b] = r.ds.map((x) => x.daCo);
    dsTT[b] = {};
    trangThai(`${b}TT`, `Trên trang có ${r.soDong} dòng` + (r.trangSau ? " (bảng nhiều trang – tiện ích chỉ thấy trang đang mở)" : "") + `. File: ${dsSS[b].filter((x) => !x).length} mới, ${dsSS[b].filter(Boolean).length} đã có.`, r.trangSau ? "err" : "ok");
    veDS(b); veTongQuan();
  } catch (e) { trangThai(`${b}TT`, e.message, "err"); }
}
async function dienDS(b) {
  const ds = hs().__ds[b], cf = DS_BUOC[b];
  const idx = ds.map((x, i) => i).filter((i) => ds[i].__chon !== false && dsTT[b][i] !== "luu");
  if (!idx.length) return;
  if (!confirm(`Điền ${idx.length} ${cf.don} (${cf.ten}).\n\n• Dòng MỚI: bấm "Thêm mới" rồi điền.\n• Dòng ĐÃ CÓ: chỉ điền ô còn trống, không đổi dữ liệu cũ` + (b === "qh" ? ' (riêng "Là đảng viên": file ghi Có thì chọn Có)' : "") + `.\n• Sau mỗi dòng tiện ích DỪNG: anh/chị kiểm tra, bấm "Lưu thông tin" để sang dòng tiếp theo, hoặc "Đóng" để bỏ qua.`)) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    dsChayIdx[b] = idx;
    const r = await chay(tab.id, (bb, x) => window.__dhsDSDien(bb, x), [b, idx.map((i) => sach(ds[i]))]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay(b); veDS(b);
    $(`${b}Kq`).innerHTML = "";
    trangThai(`${b}TT`, "Đang điền…");
  } catch (e) { trangThai(`${b}TT`, e.message, "err"); }
}
function hienMot(id, kq) {
  const the = el("div", { className: "ss" }, el("div", { className: "dau", textContent: kq.ten }));
  for (const o of kq.o) the.append(el("div", { className: "gt" }, el("span", { textContent: (o.ok ? "✔ " : "✘ ") + o.nhan + ": " + (o.ok ? o.hien : o.loi) })));
  $(id).prepend(the);
}

// ================= B9: HOÀN CẢNH KINH TẾ =================
const NHAN_KT = { trong: ["Ô trống – sẽ điền", "t-trong"], themMoi: ["Thêm dòng tài sản – sẽ điền", "t-trong"], khac: ["Đã có dữ liệu khác – giữ nguyên", "t-khac"], trung: ["Đã có, trùng", "t-trung"], chiTrang: ["Chỉ có trên trang", "t-trung"], an: ["Không có ô trên trang", "t-khoa"] };
function veKT() {
  const box = $("ktBang");
  box.innerHTML = "";
  if (!ktSS) { const d = hs(); trangThai("ktTT", d && Object.keys(d.__kt).some((k) => !k.startsWith("__")) ? "Mở mục 9 Hoàn cảnh kinh tế trên trang rồi bấm So sánh." : "File không có dữ liệu Hoàn cảnh kinh tế cho đảng viên này."); capNhatNut(); return; }
  for (const x of ktSS.ds) {
    const coThe = x.tt === "trong" || x.tt === "themMoi";
    const cb = el("input", { type: "checkbox", checked: !!x.chon, disabled: !coThe || dangChay });
    cb.onchange = () => { x.chon = cb.checked; capNhatNut(); };
    const [nhan, lop] = NHAN_KT[x.tt];
    const the = el("div", { className: "ss" + (x.tt === "khac" ? " khac" : "") }, el("div", { className: "dau" }, cb, el("span", { textContent: x.nhan })),
      el("div", { className: "gt" }, el("span", { className: "tag " + lop, textContent: nhan })));
    if (x.cu) the.append(el("div", { className: "gt" }, el("i", { textContent: "Trên trang:" }), x.cu));
    if (x.moi) the.append(el("div", { className: "gt" }, el("i", { textContent: "File:" }), x.moi));
    box.append(the);
  }
  capNhatNut();
}
$("ktSoSanh").onclick = async () => {
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    trangThai("ktTT", "Đang đọc trang…");
    const r = await chay(tab.id, (x) => window.__dhsKTSoSanh(x), [sach(hs().__kt)]);
    if (!r || r.loiChung) { ktSS = null; veKT(); return trangThai("ktTT", r ? r.loiChung : "Không đọc được trang.", "err"); }
    r.ds.forEach((x) => (x.chon = x.tt === "trong" || x.tt === "themMoi"));
    ktSS = r;
    const n = (t) => r.ds.filter((x) => x.tt === t).length;
    trangThai("ktTT", `${n("trong") + n("themMoi")} ô trống sẽ điền · ${n("khac")} ô đã có dữ liệu khác (giữ nguyên) · ${n("trung")} ô trùng.`, n("khac") ? "err" : "ok");
    veKT(); veTongQuan();
  } catch (e) { trangThai("ktTT", e.message, "err"); }
};
$("ktDien").onclick = async () => {
  const chon = ktSS.ds.filter((x) => x.chon).map((x) => x.key);
  if (!chon.length) return;
  if (!confirm(`Điền ${chon.length} ô Hoàn cảnh kinh tế (chỉ ô còn trống).\nTiện ích sẽ bấm "Chỉnh sửa thông tin" nếu cần, điền rồi DỪNG để anh/chị kiểm tra và tự bấm "Lưu thông tin".`)) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    const r = await chay(tab.id, (x, c) => window.__dhsKTDien(x, c), [sach(hs().__kt), chon]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay("kt");
    $("ktKq").innerHTML = "";
    trangThai("ktTT", "Đang điền…");
  } catch (e) { trangThai("ktTT", e.message, "err"); }
};

// ================= TIN NHẮN TỪ TRANG =================
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!sender.tab) return;
  if (m.type === "dhs-progress") {
    trangThai("dkTT", `${m.paused ? "ĐANG TẠM DỪNG – " : ""}Đang điền ${m.n}/${m.tong}: ${m.nhan}`);
    if (buocDangChay === "b1") trangThai("tienDo", $("dkTT").textContent);
  } else if (m.type === "dhs-pause") {
    dangTamDung = m.paused;
    $("tamDung").textContent = dangTamDung ? "▶ Tiếp tục" : "❚❚ Tạm dừng";
  } else if (m.type === "dhs-done") {
    ketThucChay();
    hienKq(m.kq, m.biDoi, m.dung);
  } else if (m.type === "dhs-ds-cho") {
    const b = m.buoc;
    if (b === "kt") { trangThai("ktTT", 'Đã điền. Kiểm tra trên trang rồi bấm "Lưu thông tin" (hoặc "Đóng" để bỏ).', "ok"); $("ktKq").innerHTML = ""; hienMot("ktKq", m.kq); }
    else {
      dsTT[b][dsChayIdx[b][m.i]] = "cho"; veDS(b);
      trangThai(`${b}TT`, `Dòng ${m.i + 1}/${m.tong}: ${m.kq.ten} – đã điền. Kiểm tra rồi bấm "Lưu thông tin" trên trang (hoặc "Đóng" để bỏ qua).`, "ok");
      $(`${b}Kq`).innerHTML = ""; hienMot(`${b}Kq`, m.kq);
    }
    trangThai("dkTT", 'Đang chờ anh/chị kiểm tra và bấm "Lưu thông tin" trên trang…');
  } else if (m.type === "dhs-ds-loi") {
    trangThai("dkTT", "Trang báo lỗi khi lưu: " + m.loi.join("; ") + ". Sửa trên trang rồi bấm Lưu lại.", "err");
  } else if (m.type === "dhs-ds-mot") {
    const b = m.buoc;
    if (b === "kt") { if (m.kq.ketQua === "loi") hienMot("ktKq", { ...m.kq, o: [{ ok: false, nhan: "Lỗi", loi: m.kq.loi }] }); return; }
    const i = dsChayIdx[b][m.kq.i];
    if (i != null) dsTT[b][i] = m.kq.ketQua === "luu" ? "luu" : m.kq.ketQua === "loi" ? "loi" : "dong";
    if (m.kq.ketQua === "loi") hienMot(`${b}Kq`, { ...m.kq, o: [{ ok: false, nhan: "Lỗi", loi: m.kq.loi }] });
    veDS(b);
  } else if (m.type === "dhs-ds-xong") {
    ketThucChay();
    const b = m.buoc, luuN = m.tong.filter((k) => k.ketQua === "luu").length;
    if (b === "kt") trangThai("ktTT", m.tong[0].ketQua === "luu" ? "Đã bấm Lưu thông tin Hoàn cảnh kinh tế." : m.tong[0].ketQua === "dong" ? "Đã đóng, không lưu." : "Dừng: " + (m.tong[0].loi || m.tong[0].ketQua), m.tong[0].ketQua === "luu" ? "ok" : "err");
    else { trangThai(`${b}TT`, `Xong ${DS_BUOC[b].ten}: đã lưu ${luuN}/${m.tong.length} dòng` + (m.dung ? " (đã dừng hẳn)." : "."), "ok"); veDS(b); }
  } else if (m.type === "dhs-saved") {
    if (m.loi && m.loi.length) { trangThai("tienDo", "Trang báo lỗi sau khi bấm Lưu, chưa chuyển hồ sơ: " + m.loi.join("; "), "err"); return; }
    const i = chiSo();
    daLuu[i] = true;
    if ($("tuDong").checked && i < hoSo.length - 1) {
      veDanhSach(i + 1);
      choTrangMoi = true;
      trangThai("tt", `Đã lưu B1 hồ sơ ${i + 1}. Chuyển sang hồ sơ ${i + 2}: mở trang của đảng viên này (hoặc trang Thêm mới), tiện ích sẽ tự so sánh B1.`, "ok");
    } else {
      veDanhSach(i);
      trangThai("tt", `Đã lưu B1 hồ sơ ${i + 1}.` + (i >= hoSo.length - 1 ? " Đây là hồ sơ cuối cùng." : ""), "ok");
    }
    luu();
  }
});

// Sau khi Lưu B1: khi trang hồ sơ mới tải xong thì tự so sánh (không tự điền)
let henGio = null;
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (!choTrangMoi || dangChay || !(info.status === "complete" || info.url)) return;
  if (!/^https:\/\/tcxdd\.dcs\.vn\/dangvien\/pages\/profile-manage\/party-member\/(create|view\/\d+)/.test(tab.url || "")) return;
  clearTimeout(henGio);
  henGio = setTimeout(async () => {
    for (let i = 0; i < 10; i++) {
      const co = await chay(tabId, () => !!document.querySelector('[formcontrolname="currentFullName"]')).catch(() => false);
      if (co) { choTrangMoi = false; soSanh(); return; }
      await new Promise((r) => setTimeout(r, 1000));
    }
  }, 1200);
});

// ================= KHÔI PHỤC PHIÊN =================
chrome.storage.session.get(["hoSo", "ten", "chon", "daLuu"], (s) => {
  if (s.hoSo && s.hoSo.length) {
    hoSo = s.hoSo; daLuu = s.daLuu || {};
    hoSo.forEach((d) => { d.__ds = d.__ds || { qtct: [], qh: d.__nguoiThan || [] }; d.__kt = d.__kt || {}; });
    trangThai("tt", `Đang dùng ${hoSo.length} hồ sơ từ ${s.ten || "file đã nhập"} (tự xóa khi đóng trình duyệt).`);
    veDanhSach(s.chon || 0);
  }
});
veDS("qtct"); veDS("qh");
