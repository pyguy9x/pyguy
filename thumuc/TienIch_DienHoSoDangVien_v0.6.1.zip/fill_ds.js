// Các bước dạng DANH SÁCH: 2 – Quá trình công tác, 8 – Quan hệ gia đình. Tiêm sau fields.js và fill.js.
// Nguyên tắc: dòng ĐÃ CÓ trên trang chỉ được điền ô còn trống, không đổi ô đã có dữ liệu
// (riêng "Là đảng viên" của người thân: file ghi Có thì chọn Có). Dòng CHƯA CÓ: bấm "Thêm mới" rồi điền.
// Mỗi dòng: điền xong thì DỪNG, chờ người dùng tự bấm "Lưu thông tin" (hoặc "Đóng" để bỏ qua) rồi mới sang dòng kế tiếp.
(() => {
  if (window.__dhsDSVer === 1) return;
  window.__dhsDSVer = 1;
  const L = window.__dhsLib;
  const { sleep, chuan, q, qa, click, cho, dienSelect, dienText, diemDung, ctl, gui, laCo } = L;

  const DONG_NGHIA_QH = {
    "em gái": "Em ruột", "em trai": "Em ruột", "em": "Em ruột",
    "anh trai": "Anh ruột", "anh": "Anh ruột", "chị gái": "Chị ruột", "chị": "Chị ruột",
    "bố": "Bố đẻ", "cha": "Bố đẻ", "cha đẻ": "Bố đẻ", "mẹ": "Mẹ đẻ",
    "con trai": "Con đẻ", "con gái": "Con đẻ", "con": "Con đẻ",
    "cha vợ": "Bố vợ", "cha chồng": "Bố chồng",
  };
  // "4/2003" -> "04/2003"
  const thangChuan = (v) => { const m = String(v).trim().match(/^(\d{1,2})[\/.\-](\d{4})$/); return m ? `${m[1].padStart(2, "0")}/${m[2]}` : String(v).trim(); };

  const CAU_HINH = {
    qh: {
      ten: "Quan hệ gia đình",
      formKey: "familyMemberId",
      bang: ["quan hệ", "họ và tên"],
      truong: [
        ["type", "Phân loại", "select"], ["familyMemberId", "Quan hệ", "select"], ["isPartyMember", "Là đảng viên", "select"],
        ["fullName", "Họ và tên", "text"], ["identifyNo", "Số căn cước", "text"], ["birthDate", "Năm sinh", "year"],
        ["currentStatus", "Tình trạng (đã qua đời/ly hôn)", "select"], ["finishedYear", "Đã qua đời/ly hôn năm", "year"],
        ["currentJob", "Công việc", "text"], ["nationalityId", "Quốc tịch", "select"], ["nationId", "Nơi ở hiện nay", "select"],
        ["residentPlace", "Chi tiết nơi ở", "text"], ["hometown", "Quê quán", "text"], ["note", "Ghi chú", "text"],
      ],
      macDinh: { type: "Bản thân", isPartyMember: "Không", nationalityId: "Việt Nam", nationId: "Việt Nam" },
      chuanHoa: (x) => ({ ...x, familyMemberId: x.familyMemberId ? DONG_NGHIA_QH[chuan(x.familyMemberId)] || x.familyMemberId : x.familyMemberId }),
      nhan: (x) => `${x.familyMemberId || "?"}: ${x.fullName}`,
      dong: (o) => ({ ten: o["họ và tên"], quanHe: o["quan hệ"] }),
      khop: (r, x) => chuan(r.ten) === chuan(x.fullName) && (!x.familyMemberId || chuan(r.quanHe) === chuan(x.familyMemberId)),
      khop2: (r, x) => chuan(r.ten) === chuan(x.fullName),
    },
    qtct: {
      ten: "Quá trình công tác",
      formKey: "companyName",
      bang: ["thời gian", "tên tổ chức"],
      truong: [
        ["nationId", "Quốc gia", "select"], ["fromDate", "Từ tháng/năm", "thang"], ["toDate", "Đến tháng/năm", "thang"],
        ["companyName", "Tên tổ chức", "text"], ["partyPositionIds", "Chức vụ đảng", "multi"],
        ["concurrentPartyPosition", "Chức vụ Đảng kiêm nhiệm", "text"], ["companyPosition", "Chức danh, chức vụ, nghề nghiệp", "text"],
        ["note", "Ghi chú", "text"],
      ],
      macDinh: { nationId: "Việt Nam" },
      chuanHoa: (x) => ({ ...x, fromDate: x.fromDate ? thangChuan(x.fromDate) : x.fromDate, toDate: x.toDate ? thangChuan(x.toDate) : x.toDate }),
      nhan: (x) => `${x.fromDate || "?"}${x.toDate ? " – " + x.toDate : ""}: ${x.companyName || x.companyPosition || ""}`,
      dong: (o) => ({ thoiGian: o["thời gian"], toChuc: o["tên tổ chức"] }),
      khop: (r, x) => !!x.fromDate && chuan(r.thoiGian).startsWith(chuan(x.fromDate)) && chuan(r.toChuc) === chuan(x.companyName),
      khop2: (r, x) => !!x.fromDate && !!x.toDate && chuan(r.thoiGian).replace(/\s/g, "") === chuan(`${x.fromDate}-${x.toDate}`),
    },
  };
  window.CAU_HINH_DS = Object.fromEntries(Object.entries(CAU_HINH).map(([k, v]) => [k, { ten: v.ten, truong: v.truong }]));

  const nut = (re) => qa("button").find((b) => re.test(chuan(b.innerText)));

  function docO(key, kieu) {
    const h = q(`[formcontrolname="${key}"]`);
    if (!h) return null;
    if (kieu === "year") return q("input", h)?.value || "";
    if (kieu === "multi") return qa("vts-select-item, .vts-select-selection-item", h).map((x) => x.innerText.trim()).filter((t) => t && !/^\+\s*\d/.test(t)).join("; ");
    if (h.tagName === "VTS-SELECT") { const t = q("vts-select-top-control", h).innerText.trim(); return t.startsWith("--") ? "" : t; }
    return h.value || "";
  }
  const biKhoa = (key) => { const h = q(`[formcontrolname="${key}"]`); return !h || h.disabled || h.className.includes("disabled") || !!q("input:disabled", h); };

  async function dienNam(key, val) {
    if (!/^\d{4}$/.test(val)) throw new Error(`năm "${val}" phải có dạng yyyy, VD 1958`);
    const h = q(`vts-date-picker[formcontrolname="${key}"]`);
    if (!(await cho(() => !h.className.includes("disabled") && !q("input:disabled", h), 4000))) throw new Error("ô đang bị khóa trên trang");
    const inp = q("input", h);
    h.scrollIntoView({ block: "center" });
    click(inp); inp.focus();
    await sleep(300);
    L.datGiaTri(inp, val);
    await sleep(300);
    inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
    await sleep(400);
    inp.dispatchEvent(new Event("blur", { bubbles: true }));
    const khac = q('[formcontrolname="fullName"], [formcontrolname="companyName"]');
    if (khac) click(khac); // bấm ra ngoài để đóng bảng chọn năm (không dùng Esc vì Esc xóa giá trị vừa gõ)
    await sleep(400);
    if (inp.value !== val) throw new Error(`trang không nhận năm "${val}"`);
  }
  async function dienThang(key, val) {
    if (!/^(\d{2}\/)?\d{4}$/.test(val)) throw new Error(`"${val}" phải có dạng mm/yyyy hoặc yyyy, VD 04/2003`);
    await dienText(key, val);
    const ok = await cho(() => q(`[formcontrolname="${key}"]`).value === val, 1500);
    if (!ok) throw new Error(`trang không nhận "${val}" (đang hiện "${q(`[formcontrolname="${key}"]`).value}")`);
  }
  // Ô chọn nhiều (Chức vụ đảng): các giá trị cách nhau bằng dấu ";"
  async function dienNhieu(key, val) {
    const h = q(`vts-select[formcontrolname="${key}"]`);
    const ds = val.split(";").map((x) => x.trim()).filter(Boolean);
    const thieu = [];
    h.scrollIntoView({ block: "center" });
    for (const v of ds) {
      if (!h.className.includes("vts-select-open")) { click(q("vts-select-top-control", h)); await sleep(700); }
      const pane = qa(".cdk-overlay-pane").filter((p) => p.querySelector("vts-option-item")).pop();
      if (!pane) { thieu.push(v); continue; }
      let o = qa("vts-option-item", pane).find((x) => chuan(x.innerText) === chuan(v));
      const vp = q("cdk-virtual-scroll-viewport", pane);
      if (!o && vp) {
        for (let y = 0; y <= vp.scrollHeight && !o; y += Math.max(100, vp.clientHeight * 0.8)) {
          vp.scrollTop = y; vp.dispatchEvent(new Event("scroll")); await sleep(80);
          o = qa("vts-option-item", pane).find((x) => chuan(x.innerText) === chuan(v));
        }
      }
      if (!o) { thieu.push(v); continue; }
      if (!o.className.includes("selected")) { o.click(); await sleep(300); }
    }
    const inp = q("input", h);
    if (inp) inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true }));
    await sleep(300);
    if (thieu.length) throw new Error(`không tìm thấy lựa chọn: ${thieu.join("; ")}`);
  }
  const HAM = { select: dienSelect, text: dienText, year: dienNam, thang: dienThang, multi: dienNhieu };

  function docBang(ch) {
    const t = qa("table").find((x) => ch.bang.every((b) => qa("thead th", x).some((th) => chuan(th.innerText) === b)));
    if (!t) return { rows: [], coBang: false };
    const th = qa("thead th", t).map((x) => chuan(x.innerText));
    const rows = qa("tbody tr", t).filter((tr) => tr.children.length > 3).map((tr) => {
      const o = {};
      th.forEach((h, i) => { o[h] = tr.children[i]?.innerText.trim() || ""; });
      return { tr, ...ch.dong(o) };
    });
    const trangSau = qa("vts-pagination li, .vts-pagination li").some((li) => /next/.test(li.className) && !/disabled/.test(li.className));
    return { rows, coBang: true, trangSau };
  }
  const timDong = (ch, bang, x) => bang.rows.find((r) => ch.khop(r, x)) || bang.rows.find((r) => ch.khop2(r, x));

  window.__dhsDSSoSanh = (buoc, ds) => {
    const ch = CAU_HINH[buoc];
    ds = ds.map(ch.chuanHoa);
    if (q(`[formcontrolname="${ch.formKey}"]`)) return { loiChung: `Đang mở biểu mẫu ${ch.ten}. Bấm Đóng hoặc Lưu trước rồi so sánh lại.` };
    const bang = docBang(ch);
    if (!bang.coBang) return { loiChung: `Chưa thấy bảng ${ch.ten}. Mở mục "${ch.ten}" của hồ sơ.` };
    return { soDong: bang.rows.length, trangSau: bang.trangSau, ds: ds.map((x) => ({ ten: ch.nhan(x), daCo: !!timDong(ch, bang, x) })) };
  };

  function choNguoiDung(ch) {
    return new Promise((xong) => {
      let ketQua = null;
      const coForm = () => !!q(`[formcontrolname="${ch.formKey}"]`);
      const nghe = (e) => {
        const b = e.target.closest && e.target.closest("button");
        if (!b) return;
        const t = chuan(b.innerText);
        if (/^lưu/.test(t)) ketQua = "luu";
        else if (["đóng", "hủy", "huỷ", "thoát"].includes(t)) ketQua = ketQua === "luu" ? "luu" : "dong";
      };
      document.addEventListener("click", nghe, true);
      const tick = setInterval(() => {
        if (ctl.stopped) { fin("dung"); return; }
        if (!coForm()) fin(ketQua === "luu" ? "luu" : ketQua || "dong");
        else if (ketQua === "luu") {
          const loi = qa(".form-control-error-general").map((x) => x.innerText.trim()).filter(Boolean);
          if (loi.length) { ketQua = null; gui({ type: "dhs-ds-loi", loi: [...new Set(loi)].slice(0, 4) }); }
        }
      }, 400);
      function fin(v) { clearInterval(tick); document.removeEventListener("click", nghe, true); xong(v); }
    });
  }
  async function dongForm(ch) {
    if (!q(`[formcontrolname="${ch.formKey}"]`)) return;
    const d = nut(/^đóng$/);
    if (d) d.click();
    const thoat = await cho(() => nut(/^thoát$/), 2000);
    if (thoat) thoat.click();
    await cho(() => !q(`[formcontrolname="${ch.formKey}"]`), 3000);
  }

  window.__dhsDSDien = (buoc, ds) => {
    const ch = CAU_HINH[buoc];
    ds = ds.map(ch.chuanHoa);
    if (ctl.running) return { loiChung: "Đang chạy một việc khác." };
    if (q(`[formcontrolname="${ch.formKey}"]`)) return { loiChung: `Đang mở biểu mẫu ${ch.ten}. Bấm Đóng hoặc Lưu trước.` };
    ctl.running = true; ctl.paused = false; ctl.stopped = false;
    const coForm = () => !!q(`[formcontrolname="${ch.formKey}"]`);
    (async () => {
      const tong = [];
      for (let i = 0; i < ds.length; i++) {
        const x = ds[i];
        const kq = { buoc, i, ten: ch.nhan(x), o: [], ketQua: "" };
        try {
          await diemDung();
          const bang = docBang(ch);
          const dong = timDong(ch, bang, x);
          kq.loai = dong ? "sua" : "them";
          L.veBang(`${ch.ten} ${i + 1}/${ds.length}: ${kq.ten} – đang mở biểu mẫu`, [], false);
          if (dong) {
            const nutSua = qa("button", dong.tr.lastElementChild).find((b) => q(".vtsicon-FilePen\\:custom", b)) || q("button", dong.tr.lastElementChild);
            click(nutSua);
          } else {
            const b = nut(/^thêm mới$/);
            if (!b) throw new Error('không thấy nút "Thêm mới"');
            b.click();
          }
          if (!(await cho(coForm, 8000))) throw new Error("biểu mẫu không mở được");
          await sleep(900);
          for (const [key, nhan, kieu] of ch.truong) {
            const moi = String(x[key] ?? "").trim();
            if (!moi) continue;
            await diemDung();
            gui({ type: "dhs-progress", n: i + 1, tong: ds.length, nhan: `${kq.ten}: ${nhan}`, paused: ctl.paused });
            const cu = docO(key, kieu);
            const laDV = buoc === "qh" && key === "isPartyMember";
            const trung = chuan(cu) === chuan(moi) || (laDV && laCo(moi) === (chuan(cu) === "có"));
            if (trung) { kq.o.push({ nhan, ok: true, hien: cu, tt: "trung" }); continue; }
            const trong = !chuan(cu) || (!dong && ch.macDinh[key] && chuan(cu) === chuan(ch.macDinh[key]));
            if (!trong && !laDV) { kq.o.push({ nhan, ok: false, tt: "khac", loi: `đã có "${cu}" – giữ nguyên (file: "${moi}")` }); continue; }
            if (biKhoa(key) && kieu !== "year") { kq.o.push({ nhan, ok: false, loi: "ô đang bị khóa" }); continue; }
            try {
              await HAM[kieu](key, laDV ? (laCo(moi) ? "Có" : "Không") : moi);
              await sleep(150);
              kq.o.push({ nhan, ok: true, hien: docO(key, kieu), cu, tt: "dien" });
            } catch (e) { kq.o.push({ nhan, ok: false, loi: e.message }); }
          }
          const loi = kq.o.filter((o) => !o.ok);
          L.veBang(`${kq.ten}: điền ${kq.o.filter((o) => o.tt === "dien").length} ô` + (loi.length ? `, ${loi.length} cần xem` : "") + ' – KIỂM TRA rồi bấm "Lưu thông tin" để sang dòng tiếp theo, hoặc "Đóng" để bỏ qua', loi, false);
          gui({ type: "dhs-ds-cho", buoc, i, tong: ds.length, kq });
          const tl = await choNguoiDung(ch);
          kq.ketQua = tl;
          if (tl === "dung") { tong.push(kq); break; }
          await sleep(1200);
        } catch (e) {
          if (e.message === "__STOP__") { kq.ketQua = "dung"; tong.push(kq); break; }
          kq.ketQua = "loi"; kq.loi = e.message;
          await dongForm(ch);
        }
        tong.push(kq);
        gui({ type: "dhs-ds-mot", buoc, kq });
      }
      const luu = tong.filter((k) => k.ketQua === "luu").length;
      L.veBang(`${ch.ten}: đã lưu ${luu}/${ds.length} dòng` + (ctl.stopped ? " (đã dừng hẳn)" : ""), tong.filter((k) => k.ketQua !== "luu").map((k) => ({ ok: false, nhan: k.ten, loi: k.ketQua === "dong" ? "đã bỏ qua (Đóng)" : k.loi || k.ketQua })), true);
      ctl.running = false;
      gui({ type: "dhs-ds-xong", buoc, tong, dung: ctl.stopped });
    })();
    return { batDau: true };
  };
})();
