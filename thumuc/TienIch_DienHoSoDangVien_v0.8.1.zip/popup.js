const $ = (id) => document.getElementById(id);
const KHOA = TRUONG_HO_SO.map((t) => t[0]);
const KIEU = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[2]]));
const NHOM = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[3]]));

// Trường các bước dạng danh sách và bước 9 (khớp fill_ds.js, fill_kt.js, file Excel)
const DS_BUOC = {
  qtct: { ten: "Quá trình công tác", sheet: "QuaTrinhCongTac", don: "dòng công tác", truong: [
    ["fromDate", "Từ tháng/năm"], ["toDate", "Đến tháng/năm"], ["nationId", "Quốc gia"], ["companyName", "Tên tổ chức"],
    ["partyPositionIds", "Chức vụ đảng (cách nhau dấu ;)"], ["concurrentPartyPosition", "Chức vụ Đảng kiêm nhiệm"],
    ["companyPosition", "Chức danh, chức vụ, nghề nghiệp"], ["note", "Ghi chú"]],
    nhan: (x) => `${x.fromDate || "?"}${x.toDate ? " – " + x.toDate : ""}: ${x.companyName || x.companyPosition || ""}` },
  qh: { ten: "Quan hệ gia đình", sheet: "QuanHeGiaDinh", don: "người thân", truong: [
    ["type", "Phân loại"], ["familyMemberId", "Quan hệ"], ["isPartyMember", "Là đảng viên"], ["fullName", "Họ và tên"],
    ["identifyNo", "Số căn cước"], ["birthDate", "Năm sinh"], ["currentStatus", "Tình trạng (qua đời/ly hôn)"],
    ["finishedYear", "Năm qua đời/ly hôn"], ["currentJob", "Công việc"], ["nationalityId", "Quốc tịch"],
    ["nationId", "Nơi ở hiện nay"], ["residentPlace", "Chi tiết nơi ở"], ["hometown", "Quê quán"], ["note", "Ghi chú"]],
    nhan: (x) => `${x.familyMemberId || "?"}: ${x.fullName || ""}${x.birthDate ? " (" + x.birthDate + ")" : ""}` },
};
DS_BUOC.qtct.so = "B2"; DS_BUOC.qh.so = "B8";
for (const [b, c] of Object.entries(DS_THEM)) DS_BUOC[b] = { so: c.so, ten: c.ten, sheet: c.sheet, don: c.don, truong: c.truong.map((t) => [t[0], t[1]]), bb: c.truong.filter((t) => t[3]).map((t) => t[0]), nhan: c.nhan };
const DS_KEYS = Object.keys(DS_BUOC);
const theoDS = (f) => Object.fromEntries(DS_KEYS.map((k) => [k, f()]));
const KT_TRUONG = [
  ["householdAnnualIncome", "Tổng thu nhập hộ/năm (đồng)"], ["perCapitaAnnualIncome", "Thu nhập bình quân đầu người (đồng)"],
  ["economicActivity", "Hoạt động kinh tế"], ["countWorker", "Số lao động thuê mướn"],
  ["nhaCapLoai", "Nhà được cấp/thuê – loại"], ["nhaCapDienTich", "Nhà được cấp/thuê – m2"],
  ["nhaMuaLoai", "Nhà tự mua/xây – loại"], ["nhaMuaDienTich", "Nhà tự mua/xây – m2"],
  ["datCap", "Đất được cấp (m2)"], ["datMua", "Đất tự mua (m2)"], ["datTrangTrai", "Đất trang trại (ha)"],
  ["taiSan1Ten", "Tài sản 1 – tên"], ["taiSan1GiaTri", "Tài sản 1 – giá trị (đồng)"],
  ["taiSan2Ten", "Tài sản 2 – tên"], ["taiSan2GiaTri", "Tài sản 2 – giá trị (đồng)"],
  ["taiSan3Ten", "Tài sản 3 – tên"], ["taiSan3GiaTri", "Tài sản 3 – giá trị (đồng)"],
];

let hoSo = [], daLuu = {}, ssHienTai = null, tabDien = null, dangChay = false, choTrangMoi = false, buocDangChay = null;
let dsSS = theoDS(() => null), dsTT = theoDS(() => ({})), dsChayIdx = theoDS(() => []), ktSS = null, ddSS = null;

const pad = (n) => String(n).padStart(2, "0");
const el = (tag, props = {}, ...con) => { const e = Object.assign(document.createElement(tag), props); e.append(...con); return e; };
function trangThai(id, s, kieu) { $(id).textContent = s; $(id).className = "tt" + (kieu ? " " + kieu : ""); }
const luu = () => chrome.storage.session.set({ hoSo, daLuu, chon: Number($("ds").value) || 0 });
const chiSo = () => Number($("ds").value);
const hs = () => hoSo[chiSo()];

// ================= ĐỌC EXCEL =================
function docExcel(buf) {
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets["HoSo"] || wb.Sheets[wb.SheetNames.find((n) => !["HuongDan", "DanhMuc"].includes(n))];
  if (!ws) throw new Error("Không thấy trang tính HoSo.");
  const range = XLSX.utils.decode_range(ws["!ref"]);
  const giaTri = (r, c) => { const cell = ws[XLSX.utils.encode_cell({ r, c })]; return !cell || cell.v == null ? "" : String(cell.w ?? cell.v).trim(); };
  let dongMa = -1, cot = {};
  for (let r = range.s.r; r <= Math.min(range.e.r, range.s.r + 9); r++) {
    const m = {};
    for (let c = range.s.c; c <= range.e.c; c++) { const v = giaTri(r, c); if (KHOA.includes(v)) m[v] = c; }
    if (Object.keys(m).length > Object.keys(cot).length) { cot = m; dongMa = r; }
  }
  if (dongMa < 0 || Object.keys(cot).length < 5) throw new Error("Không nhận ra mẫu: thiếu dòng mã trường (dòng 3 của file mẫu).");
  const kq = [];
  for (let r = dongMa + 1; r <= range.e.r; r++) {
    const d = {};
    for (const [k, c] of Object.entries(cot)) {
      let v = giaTri(r, c);
      if (KIEU[k] === "date") {
        const cell = ws[XLSX.utils.encode_cell({ r, c })];
        if (cell && typeof cell.v === "number" && cell.v > 1000 && cell.v < 80000) { const p = XLSX.SSF.parse_date_code(cell.v); v = `${pad(p.d)}/${pad(p.m)}/${p.y}`; }
      }
      if (v) d[k] = v;
    }
    if (Object.keys(d).length) { d.__dong = r + 1; kq.push(d); }
  }
  // Trang phụ: gắn theo số căn cước đảng viên (cột dangVienCanCuoc)
  const docPhu = (ten) => {
    const out = {};
    const w = wb.Sheets[ten];
    if (!w || !w["!ref"]) return out;
    const rq = XLSX.utils.decode_range(w["!ref"]);
    const v = (r, c) => { const x = w[XLSX.utils.encode_cell({ r, c })]; return x && x.v != null ? String(x.w ?? x.v).trim() : ""; };
    let dongMaPhu = -1, cotP = {};
    for (let r = 0; r <= Math.min(rq.e.r, 9) && dongMaPhu < 0; r++) {
      const m = {};
      for (let c = rq.s.c; c <= rq.e.c; c++) { const t = v(r, c); if (/^[a-zA-Z0-9]+$/.test(t)) m[t] = c; }
      if (m.dangVienCanCuoc != null) { cotP = m; dongMaPhu = r; }
    }
    if (dongMaPhu < 0) return out;
    for (let r = dongMaPhu + 1; r <= rq.e.r; r++) {
      const k = v(r, cotP.dangVienCanCuoc);
      if (!k) continue;
      const x = { __dong: r + 1 };
      for (const [key, c] of Object.entries(cotP)) if (key !== "dangVienCanCuoc") { const t = v(r, c); if (t) x[key] = t; }
      if (Object.keys(x).length > 1) (out[k] = out[k] || []).push(x);
    }
    return out;
  };
  const phu = Object.fromEntries(DS_KEYS.map((b) => [b, docPhu(DS_BUOC[b].sheet)])), kt = docPhu("HoanCanhKinhTe"), dd = docPhu("DacDiemLichSu");
  kq.forEach((d) => {
    d.__ds = Object.fromEntries(DS_KEYS.map((b) => [b, phu[b][d.identifyNo] || []]));
    d.__dd = (dd[d.identifyNo] || [])[0] || {};
    d.__kt = (kt[d.identifyNo] || [])[0] || {};
  });
  return { kq, soCot: Object.keys(cot).length };
}

async function napFile(f) {
  if (!f) return;
  try {
    const { kq, soCot } = docExcel(await f.arrayBuffer());
    hoSo = kq; daLuu = {};
    veDanhSach(0);
    await luu();
    await chrome.storage.session.set({ ten: f.name });
    trangThai("tt", `Đã nhập ${kq.length} hồ sơ từ ${f.name} (${soCot}/76 cột B1). Xem và sửa ở mục "Tổng quan" bên dưới.`, kq.length ? "ok" : "err");
  } catch (err) { trangThai("tt", "Lỗi đọc file: " + err.message, "err"); }
}
$("nhap").onclick = () => $("tep").click();
$("tep").onchange = async (e) => { await napFile(e.target.files[0]); e.target.value = ""; };
const tha = $("tha");
tha.ondragover = (e) => { e.preventDefault(); tha.classList.add("over"); };
tha.ondragleave = () => tha.classList.remove("over");
tha.ondrop = (e) => { e.preventDefault(); tha.classList.remove("over"); napFile(e.dataTransfer.files[0]); };

// ================= DANH SÁCH HỒ SƠ =================
function veDanhSach(chon = 0) {
  const ds = $("ds");
  ds.innerHTML = "";
  hoSo.forEach((d, i) => ds.append(el("option", { value: i, textContent: `${daLuu[i] ? "✓ " : ""}${i + 1}. ${d.currentFullName || "(chưa có họ tên)"}${d.birthDate ? " – " + d.birthDate : ""}` })));
  ds.disabled = !hoSo.length;
  $("khuTongQuan").hidden = $("khuBuoc").hidden = $("khuTD").hidden = !hoSo.length;
  if (hoSo.length) { ds.value = Math.min(chon, hoSo.length - 1); xem(); }
  capNhatNut();
}
function xem() {
  const d = hs();
  if (!d) return;
  const n = KHOA.filter((k) => d[k]).length;
  const x = $("xem");
  x.style.display = "block";
  x.innerHTML = "";
  x.append(el("b", { textContent: d.currentFullName || "(chưa có họ tên)" }),
    ` · ${d.__idMay ? "☁ ID " + d.__idMay : "dòng " + d.__dong} · B1: ${n}/76 trường · B2: ${d.__ds.qtct.length} dòng · B8: ${d.__ds.qh.length} người · B9: ${Object.keys(d.__kt).filter((k) => !k.startsWith("__")).length} ô · mục khác: ${Object.keys(DS_THEM).reduce((s, b) => s + d.__ds[b].length, 0)} dòng, B6 ${TRUONG_DD.filter(([k]) => d.__dd[k]).length} ô` + (daLuu[chiSo()] ? " · đã bấm Lưu B1" : ""));
  xoaSoSanh();
  dsSS = theoDS(() => null); dsTT = theoDS(() => ({})); ktSS = null; ddSS = null;
  veTongQuan();
  DS_KEYS.forEach(veDS); veKT(); veDD();
}
function capNhatNut() {
  const co = hoSo.length > 0;
  $("truoc").disabled = !co || dangChay || chiSo() <= 0;
  $("sau").disabled = !co || dangChay || chiSo() >= hoSo.length - 1;
  $("ds").disabled = !co || dangChay;
  $("soSanh").disabled = !co || dangChay;
  $("nhap").disabled = dangChay;
  $("taiMay").disabled = dangChay;
  $("dieuKhien").hidden = !dangChay;
  if ($("chayTD")) $("chayTD").disabled = !co || dangChay;
  $("dien").disabled = dangChay || !ssHienTai || !dsChon().length || (ssHienTai.canhBao.length && !$("dungNguoi")?.checked);
  $("dien").textContent = `Điền ${dsChon().length} ô đã chọn`;
  if ($("ddSoSanh")) { $("ddSoSanh").disabled = dangChay || !co; const nDD = ddSS ? ddSS.ds.filter((x) => x.chon).length : 0; $("ddDien").disabled = dangChay || !nDD; $("ddDien").textContent = `Điền ${nDD} ô đã chọn`; }
  for (const b of DS_KEYS) {
    if (!$(`${b}SoSanh`)) continue;
    $(`${b}SoSanh`).disabled = dangChay || !co;
    $(`${b}Dien`).disabled = dangChay || !dsSS[b] || !dsChonDS(b).length;
    $(`${b}Dien`).textContent = `Điền ${dsChonDS(b).length} ${DS_BUOC[b].don} đã chọn`;
  }
  $("ktSoSanh").disabled = dangChay || !co;
  const nKT = ktSS ? ktSS.ds.filter((x) => x.chon).length : 0;
  $("ktDien").disabled = dangChay || !nKT;
  $("ktDien").textContent = `Điền ${nKT} ô đã chọn`;
}
$("ds").onchange = () => { xem(); luu(); capNhatNut(); };
$("truoc").onclick = () => { $("ds").value = chiSo() - 1; $("ds").onchange(); };
$("sau").onclick = () => { $("ds").value = chiSo() + 1; $("ds").onchange(); };

// Thẻ chọn bước
document.querySelectorAll(".tab").forEach((t) => (t.onclick = () => {
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("on", x === t));
  document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.id !== "p_" + t.dataset.buoc));
}));

// ================= TỔNG QUAN – XEM & SỬA =================
let tqHienHet = false;
// nghi: [lý do AI chưa chắc, hàm bỏ đánh dấu] – sửa ô hoặc bấm "Đúng" thì bỏ đánh dấu
const oNhap = (nhan, gt, luuFn, daCo, nghi) => {
  const lyDo = nghi && nghi[0];
  const i = el("input", { value: gt || "", className: lyDo ? "nghi" : daCo ? "da-co" : "", title: daCo ? "Ô này đã có dữ liệu trên trang: " + daCo : "" });
  i.onchange = () => { luuFn(i.value.trim()); if (lyDo) nghi[1](); luu(); xoaKetQuaSoSanh(); veThieu(); if (lyDo) veTongQuan(); };
  const o = el("div", { className: "tq-o" + (lyDo ? " tq-nghi" : "") }, el("span", { textContent: nhan + (daCo ? " ⚠" : "") }), i);
  if (lyDo) o.append(el("small", { className: "ly-do" }, "⚠ AI chưa chắc: " + lyDo + " ",
    el("span", { className: "lienKet", textContent: "✓ Đúng", title: "Đã đối chiếu hồ sơ gốc, giữ nguyên", onclick: () => { nghi[1](); luu(); veTongQuan(); veThieu(); } })));
  return o;
};
const nghiCua = (bang, k) => (bang && bang[k] ? [bang[k], () => delete bang[k]] : null);
function xoaKetQuaSoSanh() { xoaSoSanh(); dsSS = theoDS(() => null); ktSS = null; ddSS = null; DS_KEYS.forEach(veDS); veKT(); veDD(); }
function veTongQuan() {
  const d = hs(), box = $("tqNoiDung");
  if (!d) return;
  box.innerHTML = "";
  const daCoB1 = ssHienTai ? Object.fromEntries(ssHienTai.ds.filter((x) => x.cu).map((x) => [x.key, x.cu])) : {};
  // B1
  const soNghiB1 = Object.keys(d.__nghi || {}).length;
  const b1 = el("details", {}, el("summary", { textContent: `B1 – Thông tin cơ bản (${KHOA.filter((k) => d[k]).length}/76 trường có dữ liệu)` + (soNghiB1 ? ` · ⚠ ${soNghiB1} ô AI chưa chắc` : "") }));
  b1.append(el("div", {}, el("span", { className: "lienKet", textContent: tqHienHet ? "Chỉ hiện trường có dữ liệu" : "Hiện cả trường trống", onclick: () => { tqHienHet = !tqHienHet; veTongQuan(); $("tqNoiDung").firstChild.open = true; } })));
  for (const [k, nhan] of TRUONG_HO_SO) if (tqHienHet || d[k]) b1.append(oNhap(nhan, d[k], (v) => { if (v) d[k] = v; else delete d[k]; }, daCoB1[k], nghiCua(d.__nghi, k)));
  box.append(b1);
  // B2, B8
  for (const b of DS_KEYS) {
    const cf = DS_BUOC[b], ds = d.__ds[b];
    const soNghi = ds.reduce((t, x) => t + Object.keys(x.__nghi || {}).length, 0);
    const sec = el("details", {}, el("summary", { textContent: `${cf.so} – ${cf.ten} (${ds.length} ${cf.don})` + (soNghi ? ` · ⚠ ${soNghi} ô AI chưa chắc` : "") }));
    ds.forEach((x, i) => {
      const daCo = dsSS[b] && dsSS[b][i];
      const the = el("div", { className: "tq-the" }, el("div", { className: "dau2" },
        el("span", { textContent: `${i + 1}. ${cf.nhan(x)}${daCo ? " ⚠ đã có trên trang" : ""}` }),
        el("span", { className: "xoa", textContent: "Xóa", onclick: () => { if (confirm("Xóa dòng này khỏi dữ liệu sẽ điền?")) { ds.splice(i, 1); luu(); xoaKetQuaSoSanh(); veTongQuan(); sec.open = true; } } })));
      for (const [k, nhan] of cf.truong) the.append(oNhap(nhan, x[k], (v) => { if (v) x[k] = v; else delete x[k]; }, null, nghiCua(x.__nghi, k)));
      sec.append(the);
    });
    sec.append(el("span", { className: "lienKet", textContent: `+ Thêm ${cf.don}`, onclick: () => { ds.push({}); luu(); veTongQuan(); [...$("tqNoiDung").children].find((s) => s.textContent.includes(cf.ten)).open = true; } }));
    box.append(sec);
  }
  // B6
  const b6 = el("details", {}, el("summary", { textContent: `B6 – Đặc điểm lịch sử (${TRUONG_DD.filter(([k]) => d.__dd[k]).length} ô có dữ liệu)` }));
  for (const [k, nhan] of TRUONG_DD) b6.append(oNhap(nhan, d.__dd[k], (v) => { if (v) d.__dd[k] = v; else delete d.__dd[k]; }, null, nghiCua(d.__dd.__nghi, k)));
  box.append(b6);
  // B9
  const kt = d.__kt;
  const daCoKT = ktSS ? Object.fromEntries(ktSS.ds.filter((x) => x.cu).map((x) => [x.key, x.cu])) : {};
  const b9 = el("details", {}, el("summary", { textContent: `B9 – Hoàn cảnh kinh tế (${KT_TRUONG.filter(([k]) => kt[k]).length} ô có dữ liệu)` }));
  for (const [k, nhan] of KT_TRUONG) b9.append(oNhap(nhan, kt[k], (v) => { if (v) kt[k] = v; else delete kt[k]; }, daCoKT[k], nghiCua(kt.__nghi, k)));
  box.append(b9);
  const dem = [ssHienTai && `B1: ${ssHienTai.ds.filter((x) => x.cu).length} trường đã có dữ liệu trên trang`,
    dsSS.qtct && `B2: ${dsSS.qtct.filter(Boolean).length} dòng đã có`, dsSS.qh && `B8: ${dsSS.qh.filter(Boolean).length} người đã có`,
    ktSS && `B9: ${ktSS.ds.filter((x) => x.cu).length} ô đã có`].filter(Boolean);
  trangThai("tqTomTat", dem.length ? "Đã so sánh – " + dem.join(" · ") + " (đánh dấu ⚠)" : "Chưa so sánh với trang. Mở từng mục trên trang và bấm So sánh để biết trường nào đã có.", dem.length ? "err" : "");
  veThieu();
}

// ================= LÀM VIỆC VỚI TAB =================
async function layTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !/^https:\/\/tcxdd\.dcs\.vn\//.test(tab.url || "")) throw new Error("Hãy mở trang hồ sơ đảng viên trên tcxdd.dcs.vn.");
  return tab;
}
async function tiem(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["fields.js", "fill.js", "fill_ds.js", "fill_kt.js", "auto.js"] });
}
async function chay(tabId, func, args = []) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
  return r && r.result;
}
const sach = (o) => Object.fromEntries(Object.entries(o).filter(([k]) => !k.startsWith("__")));

// ================= B1: SO SÁNH & ĐIỀN =================
function xoaSoSanh() {
  ssHienTai = null;
  $("canhBao").innerHTML = ""; $("tomTat").innerHTML = ""; $("bangSS").innerHTML = "";
  $("khuDien").hidden = true; $("kq").innerHTML = ""; $("tienDo").textContent = "";
}
const NHAN_TT = { trong: ["Ô trống – sẽ điền", "t-trong"], khac: ["Đã có dữ liệu khác – cần xác nhận", "t-khac"], trung: ["Đã có, trùng – giữ nguyên", "t-trung"], khoa: ["Bị khóa – bỏ qua", "t-khoa"], an: ["Không hiển thị – bỏ qua", "t-khoa"] };

async function soSanh() {
  xoaSoSanh();
  const d = hs();
  if (!d) return;
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    const duLieu = Object.fromEntries(KHOA.filter((k) => d[k]).map((k) => [k, d[k]]));
    const r = await chay(tab.id, (x) => window.__dhsSoSanh(x), [duLieu]);
    if (!r || r.loiChung) { $("tomTat").append(el("div", { className: "tt err", textContent: r ? r.loiChung : "Không đọc được trang." })); return; }
    ssHienTai = r;
    d.__thieuB1 = (r.thieu || []).map((x) => ({ k: x.key, bb: !!x.bb })); luu();
    veSoSanh();
    veTongQuan();
  } catch (e) { $("tomTat").append(el("div", { className: "tt err", textContent: e.message })); }
}
$("soSanh").onclick = soSanh;

let hienHet = false;
function veSoSanh() {
  const { ds, canhBao } = ssHienTai;
  const dem = (t) => ds.filter((x) => x.tt === t).length;
  if (canhBao.length) {
    const cb = el("div", { className: "cb" }, el("b", { textContent: "Cảnh báo: có thể không đúng người!" }));
    canhBao.forEach((c) => cb.append(el("div", { textContent: "• " + c })));
    cb.append(el("label", { className: "chk" }, el("input", { type: "checkbox", id: "dungNguoi", onchange: capNhatNut }), "Tôi đã kiểm tra, đúng đảng viên này"));
    $("canhBao").append(cb);
  }
  $("tomTat").append(
    el("span", { className: "tag t-trong", textContent: `${dem("trong")} ô trống` }),
    el("span", { className: "tag t-khac", textContent: `${dem("khac")} ô đã có, khác file` }),
    el("span", { className: "tag t-trung", textContent: `${dem("trung")} ô đã có, trùng` }),
    el("span", { className: "tag t-khoa", textContent: `${dem("khoa") + dem("an")} bỏ qua` }),
    el("div", {}, el("span", { className: "lienKet", textContent: "Hiện cả ô trùng/bỏ qua", onclick: () => { hienHet = !hienHet; veBang(); } }),
      el("span", { className: "lienKet", textContent: "Bỏ chọn tất cả", onclick: () => { ds.forEach((x) => (x.chon = false)); veBang(); } })));
  ds.forEach((x) => (x.chon = x.tt === "trong"));
  hienHet = false;
  veBang();
  $("khuDien").hidden = false;
}
function chonKem(x) {
  const m = x.key.match(/^(\w+?)(Nation|Province)Id$/);
  if (!m || !x.chon) return [];
  const kem = [];
  for (const sau of m[2] === "Nation" ? ["Province", "Commune"] : ["Commune"]) {
    const y = ssHienTai.ds.find((z) => z.key === m[1] + sau + "Id");
    if (y && !y.chon && (y.tt === "khac" || y.tt === "trong")) { y.chon = true; kem.push(y.nhan); }
  }
  return kem;
}
function veBang() {
  const b = $("bangSS");
  b.innerHTML = "";
  let nhomTruoc = "";
  for (const x of ssHienTai.ds) {
    if (!hienHet && (x.tt === "trung" || x.tt === "khoa" || x.tt === "an")) continue;
    if (NHOM[x.key] !== nhomTruoc) { nhomTruoc = NHOM[x.key]; b.append(el("div", { className: "nhom", textContent: nhomTruoc })); }
    const coThe = x.tt === "trong" || x.tt === "khac";
    const cb = el("input", { type: "checkbox", checked: !!x.chon, disabled: !coThe });
    cb.onchange = () => {
      x.chon = cb.checked;
      const kem = chonKem(x);
      if (kem.length) alert(`Đổi "${x.nhan}" thì hệ thống sẽ xóa ô phụ thuộc. Đã chọn kèm: ${kem.join(", ")}.`);
      veBang();
    };
    const [nhan, lop] = NHAN_TT[x.tt];
    const the = el("div", { className: "ss" + (x.tt === "khac" ? " khac" : "") },
      el("div", { className: "dau" }, cb, el("span", { textContent: x.nhan })),
      el("div", { className: "gt" }, el("span", { className: "tag " + lop, textContent: x.tt === "khac" ? (x.chon ? "Đã xác nhận thay" : "Giữ dữ liệu cũ") : nhan })));
    if (x.tt === "khac" || x.tt === "trung") the.append(el("div", { className: "gt" }, el("i", { textContent: "Trên trang:" }), x.tt === "khac" && x.chon ? el("s", { textContent: x.cu }) : x.cu));
    the.append(el("div", { className: "gt" }, el("i", { textContent: "File:" }), x.moi));
    b.append(the);
  }
  if (!b.children.length) b.append(el("div", { className: "tt", textContent: "Không có ô nào cần điền: dữ liệu trên trang đã trùng với file." }));
  capNhatNut();
}
const dsChon = () => (ssHienTai ? ssHienTai.ds.filter((x) => x.chon) : []);

$("dien").onclick = async () => {
  const chon = dsChon();
  if (!chon.length) return;
  const thay = chon.filter((x) => x.tt === "khac");
  if (thay.length && !confirm(`Xác nhận THAY ${thay.length} ô đang có dữ liệu cũ:\n\n` + thay.map((x) => `• ${x.nhan}: "${x.cu}" → "${x.moi}"`).join("\n"))) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    const r = await chay(tab.id, (m) => { window.__dhsTRUONG = null; return window.__dhsDien(m); }, [chon.map((x) => ({ key: x.key, moi: x.moi, cu: x.cu }))]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay("b1");
    $("kq").innerHTML = "";
    trangThai("tienDo", "Đang điền…");
  } catch (e) { trangThai("tienDo", e.message, "err"); }
};
function hienKq(kq, biDoi, dung) {
  const k = $("kq");
  k.innerHTML = "";
  const ok = kq.filter((x) => x.ok).length;
  trangThai("tienDo", (dung ? "Đã dừng hẳn. " : "Xong. ") + `${ok}/${kq.length} ô đã điền. Kiểm tra trang rồi tự bấm Lưu.`, kq.length - ok || biDoi.length ? "err" : "ok");
  for (const d of [...biDoi, ...kq.filter((x) => !x.ok), ...kq.filter((x) => x.ok)])
    k.append(el("div", { className: "d " + (d.ok ? "ok" : "err") }, el("b", { textContent: (d.ok ? "✔ " : "✘ ") + d.nhan }), el("small", { textContent: d.ok ? (d.cu ? `"${d.cu}" → "${d.hien}"` : d.hien) : d.loi })));
}

// ================= ĐIỀU KHIỂN CHUNG =================
let dangTamDung = false;
function batDauChay(buoc) { dangChay = true; buocDangChay = buoc; dangTamDung = false; $("tamDung").textContent = "❚❚ Tạm dừng"; trangThai("dkTT", "Đang điền…"); capNhatNut(); }
function ketThucChay() { dangChay = false; buocDangChay = null; dangTamDung = false; capNhatNut(); }
$("tamDung").onclick = async () => {
  dangTamDung = !dangTamDung;
  await chay(tabDien, (v) => window.__dhsPause(v), [dangTamDung]);
  $("tamDung").textContent = dangTamDung ? "▶ Tiếp tục" : "❚❚ Tạm dừng";
};
$("dungHan").onclick = async () => {
  if (!confirm(tdDangChay ? "Dừng hẳn chạy tự động? Các mục đã lưu vẫn giữ trên hệ thống; mục đang điền dở chưa được lưu." : "Dừng hẳn? Những gì đã điền vẫn ở trên trang (chưa lưu).")) return;
  if (td) td.dung = true;
  await chay(tabDien, () => window.__dhsStop());
};

// ================= B2, B8: DANH SÁCH =================
const NHAN_DS = { moi: ["Mới – sẽ Thêm mới", "t-trong"], daCo: ["Đã có trên trang – chỉ điền ô trống", "t-khac"], luu: ["Đã lưu", "t-trong"], dong: ["Đã bỏ qua", "t-trung"], loi: ["Lỗi", "t-khoa"], cho: ["Đang chờ bấm Lưu", "t-khac"] };
const dsChonDS = (b) => { const d = hs(); return d ? d.__ds[b].filter((x, i) => x.__chon !== false && dsTT[b][i] !== "luu") : []; };
function veDS(b) {
  const p = $(`p_${b}`), d = hs(), cf = DS_BUOC[b];
  if (!p.childElementCount) {
    p.append(
      el("button", { id: `${b}SoSanh`, className: "full", textContent: `So sánh với bảng ${cf.ten} trên trang`, onclick: () => soSanhDS(b) }),
      el("div", { id: `${b}TT`, className: "tt" }),
      el("div", { id: `${b}Ds` }),
      el("button", { id: `${b}Dien`, className: "primary full", onclick: () => dienDS(b) }),
      el("div", { id: `${b}Kq` }));
  }
  const box = $(`${b}Ds`);
  box.innerHTML = "";
  if (!d) return;
  if (!d.__ds[b].length) box.append(el("div", { className: "tt", textContent: `File không có ${cf.don} nào cho đảng viên này (trang ${cf.sheet}, cột A = số căn cước đảng viên).` }));
  d.__ds[b].forEach((x, i) => {
    const cb = el("input", { type: "checkbox", checked: x.__chon !== false, disabled: dangChay });
    cb.onchange = () => { x.__chon = cb.checked; capNhatNut(); };
    const tt = dsTT[b][i] || (dsSS[b] ? (dsSS[b][i] ? "daCo" : "moi") : null);
    const the = el("div", { className: "ss" }, el("div", { className: "dau" }, cb, el("span", { textContent: cf.nhan(x) })));
    if (tt) the.append(el("div", { className: "gt" }, el("span", { className: "tag " + NHAN_DS[tt][1], textContent: NHAN_DS[tt][0] })));
    box.append(the);
  });
  capNhatNut();
}
async function soSanhDS(b) {
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    const r = await chay(tab.id, (bb, x) => window.__dhsDSSoSanh(bb, x), [b, hs().__ds[b].map(sach)]);
    if (!r || r.loiChung) return trangThai(`${b}TT`, r ? r.loiChung : "Không đọc được trang.", "err");
    dsSS[b] = r.ds.map((x) => x.daCo);
    dsTT[b] = {};
    trangThai(`${b}TT`, `Trên trang có ${r.soDong} dòng` + (r.trangSau ? " (bảng nhiều trang – tiện ích chỉ thấy trang đang mở)" : "") + `. File: ${dsSS[b].filter((x) => !x).length} mới, ${dsSS[b].filter(Boolean).length} đã có.`, r.trangSau ? "err" : "ok");
    veDS(b); veTongQuan();
  } catch (e) { trangThai(`${b}TT`, e.message, "err"); }
}
async function dienDS(b) {
  const ds = hs().__ds[b], cf = DS_BUOC[b];
  const idx = ds.map((x, i) => i).filter((i) => ds[i].__chon !== false && dsTT[b][i] !== "luu");
  if (!idx.length) return;
  if (!confirm(`Điền ${idx.length} ${cf.don} (${cf.ten}).\n\n• Dòng MỚI: bấm "Thêm mới" rồi điền.\n• Dòng ĐÃ CÓ: chỉ điền ô còn trống, không đổi dữ liệu cũ` + (b === "qh" ? ' (riêng "Là đảng viên": file ghi Có thì chọn Có)' : "") + `.\n• Sau mỗi dòng tiện ích DỪNG: anh/chị kiểm tra, bấm "Lưu thông tin" để sang dòng tiếp theo, hoặc "Đóng" để bỏ qua.`)) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    dsChayIdx[b] = idx;
    const r = await chay(tab.id, (bb, x) => window.__dhsDSDien(bb, x), [b, idx.map((i) => sach(ds[i]))]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay(b); veDS(b);
    $(`${b}Kq`).innerHTML = "";
    trangThai(`${b}TT`, "Đang điền…");
  } catch (e) { trangThai(`${b}TT`, e.message, "err"); }
}
function hienMot(id, kq) {
  const the = el("div", { className: "ss" }, el("div", { className: "dau", textContent: kq.ten }));
  for (const o of kq.o) the.append(el("div", { className: "gt" }, el("span", { textContent: (o.ok ? "✔ " : "✘ ") + o.nhan + ": " + (o.ok ? o.hien : o.loi) })));
  $(id).prepend(the);
}

// ================= B9: HOÀN CẢNH KINH TẾ =================
const NHAN_KT = { trong: ["Ô trống – sẽ điền", "t-trong"], themMoi: ["Thêm dòng tài sản – sẽ điền", "t-trong"], khac: ["Đã có dữ liệu khác – giữ nguyên", "t-khac"], trung: ["Đã có, trùng", "t-trung"], chiTrang: ["Chỉ có trên trang", "t-trung"], an: ["Không có ô trên trang", "t-khoa"] };
function veKT() {
  const box = $("ktBang");
  box.innerHTML = "";
  if (!ktSS) { const d = hs(); trangThai("ktTT", d && Object.keys(d.__kt).some((k) => !k.startsWith("__")) ? "Mở mục 9 Hoàn cảnh kinh tế trên trang rồi bấm So sánh." : "File không có dữ liệu Hoàn cảnh kinh tế cho đảng viên này."); capNhatNut(); return; }
  for (const x of ktSS.ds) {
    const coThe = x.tt === "trong" || x.tt === "themMoi";
    const cb = el("input", { type: "checkbox", checked: !!x.chon, disabled: !coThe || dangChay });
    cb.onchange = () => { x.chon = cb.checked; capNhatNut(); };
    const [nhan, lop] = NHAN_KT[x.tt];
    const the = el("div", { className: "ss" + (x.tt === "khac" ? " khac" : "") }, el("div", { className: "dau" }, cb, el("span", { textContent: x.nhan })),
      el("div", { className: "gt" }, el("span", { className: "tag " + lop, textContent: nhan })));
    if (x.cu) the.append(el("div", { className: "gt" }, el("i", { textContent: "Trên trang:" }), x.cu));
    if (x.moi) the.append(el("div", { className: "gt" }, el("i", { textContent: "File:" }), x.moi));
    box.append(the);
  }
  capNhatNut();
}
$("ktSoSanh").onclick = async () => {
  try {
    const tab = await layTab();
    tabDien = tab.id;
    await tiem(tab.id);
    trangThai("ktTT", "Đang đọc trang…");
    const r = await chay(tab.id, (x) => window.__dhsKTSoSanh(x), [sach(hs().__kt)]);
    if (!r || r.loiChung) { ktSS = null; veKT(); return trangThai("ktTT", r ? r.loiChung : "Không đọc được trang.", "err"); }
    r.ds.forEach((x) => (x.chon = x.tt === "trong" || x.tt === "themMoi"));
    ktSS = r;
    { const d = hs(); if (d) { d.__thieuB9 = r.ds.filter((x) => !x.moi && !String(x.cu || '').trim()).map((x) => x.key); luu(); } }
    const n = (t) => r.ds.filter((x) => x.tt === t).length;
    trangThai("ktTT", `${n("trong") + n("themMoi")} ô trống sẽ điền · ${n("khac")} ô đã có dữ liệu khác (giữ nguyên) · ${n("trung")} ô trùng.`, n("khac") ? "err" : "ok");
    veKT(); veTongQuan();
  } catch (e) { trangThai("ktTT", e.message, "err"); }
};
$("ktDien").onclick = async () => {
  const chon = ktSS.ds.filter((x) => x.chon).map((x) => x.key);
  if (!chon.length) return;
  if (!confirm(`Điền ${chon.length} ô Hoàn cảnh kinh tế (chỉ ô còn trống).\nTiện ích sẽ bấm "Chỉnh sửa thông tin" nếu cần, điền rồi DỪNG để anh/chị kiểm tra và tự bấm "Lưu thông tin".`)) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    const r = await chay(tab.id, (x, c) => window.__dhsKTDien(x, c), [sach(hs().__kt), chon]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay("kt");
    $("ktKq").innerHTML = "";
    trangThai("ktTT", "Đang điền…");
  } catch (e) { trangThai("ktTT", e.message, "err"); }
};

// ================= TIN NHẮN TỪ TRANG =================
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!sender.tab) return;
  if (m.type === "dhs-progress") {
    trangThai("dkTT", `${m.paused ? "ĐANG TẠM DỪNG – " : ""}Đang điền ${m.n}/${m.tong}: ${m.nhan}`);
    if (buocDangChay === "b1") trangThai("tienDo", $("dkTT").textContent);
  } else if (m.type === "dhs-pause") {
    dangTamDung = m.paused;
    $("tamDung").textContent = dangTamDung ? "▶ Tiếp tục" : "❚❚ Tạm dừng";
  } else if (m.type === "dhs-done") {
    const b = buocDangChay;
    ketThucChay();
    if (b === "dd") hienKqDD(m); else hienKq(m.kq, m.biDoi, m.dung);
  } else if (m.type === "dhs-ds-cho") {
    const b = m.buoc;
    if (b === "kt") { trangThai("ktTT", 'Đã điền. Kiểm tra trên trang rồi bấm "Lưu thông tin" (hoặc "Đóng" để bỏ).', "ok"); $("ktKq").innerHTML = ""; hienMot("ktKq", m.kq); }
    else {
      dsTT[b][dsChayIdx[b][m.i]] = "cho"; veDS(b);
      trangThai(`${b}TT`, `Dòng ${m.i + 1}/${m.tong}: ${m.kq.ten} – đã điền. Kiểm tra rồi bấm "Lưu thông tin" trên trang (hoặc "Đóng" để bỏ qua).`, "ok");
      $(`${b}Kq`).innerHTML = ""; hienMot(`${b}Kq`, m.kq);
    }
    trangThai("dkTT", 'Đang chờ anh/chị kiểm tra và bấm "Lưu thông tin" trên trang…');
  } else if (m.type === "dhs-ds-loi") {
    trangThai("dkTT", "Trang báo lỗi khi lưu: " + m.loi.join("; ") + ". Sửa trên trang rồi bấm Lưu lại.", "err");
  } else if (m.type === "dhs-ds-mot") {
    const b = m.buoc;
    if (b === "kt") { if (m.kq.ketQua === "loi") hienMot("ktKq", { ...m.kq, o: [{ ok: false, nhan: "Lỗi", loi: m.kq.loi }] }); return; }
    const i = dsChayIdx[b][m.kq.i];
    if (i != null) dsTT[b][i] = m.kq.ketQua === "luu" ? "luu" : m.kq.ketQua === "loi" ? "loi" : "dong";
    if (m.kq.ketQua === "loi") hienMot(`${b}Kq`, { ...m.kq, o: [{ ok: false, nhan: "Lỗi", loi: m.kq.loi }] });
    veDS(b);
  } else if (m.type === "dhs-ds-xong") {
    ketThucChay();
    const b = m.buoc, luuN = m.tong.filter((k) => k.ketQua === "luu").length;
    if (b === "kt") trangThai("ktTT", m.tong[0].ketQua === "luu" ? "Đã bấm Lưu thông tin Hoàn cảnh kinh tế." : m.tong[0].ketQua === "dong" ? "Đã đóng, không lưu." : "Dừng: " + (m.tong[0].loi || m.tong[0].ketQua), m.tong[0].ketQua === "luu" ? "ok" : "err");
    else { trangThai(`${b}TT`, `Xong ${DS_BUOC[b].ten}: đã lưu ${luuN}/${m.tong.length} dòng` + (m.dung ? " (đã dừng hẳn)." : "."), "ok"); veDS(b); }
  } else if (m.type === "dhs-auto-cho") {
    trangThai("tdTT", `${TEN_MUC[m.muc] || m.muc} – ${m.ten}: trang báo lỗi khi lưu (${m.loi}). Sửa trên trang rồi bấm "Lưu thông tin" – tiện ích sẽ chạy tiếp; hoặc bấm "Đóng" trên biểu mẫu để bỏ qua dòng này.`, "err");
  } else if (m.type === "dhs-saved") {
    if (tdDangChay) return;
    if (m.loi && m.loi.length) { trangThai("tienDo", "Trang báo lỗi sau khi bấm Lưu, chưa chuyển hồ sơ: " + m.loi.join("; "), "err"); return; }
    const i = chiSo();
    daLuu[i] = true;
    if ($("tuDong").checked && i < hoSo.length - 1) {
      veDanhSach(i + 1);
      choTrangMoi = true;
      trangThai("tt", `Đã lưu B1 hồ sơ ${i + 1}. Chuyển sang hồ sơ ${i + 2}: mở trang của đảng viên này (hoặc trang Thêm mới), tiện ích sẽ tự so sánh B1.`, "ok");
    } else {
      veDanhSach(i);
      trangThai("tt", `Đã lưu B1 hồ sơ ${i + 1}.` + (i >= hoSo.length - 1 ? " Đây là hồ sơ cuối cùng." : ""), "ok");
    }
    luu();
  }
});

// Sau khi Lưu B1: khi trang hồ sơ mới tải xong thì tự so sánh (không tự điền)
let henGio = null;
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (!choTrangMoi || dangChay || !(info.status === "complete" || info.url)) return;
  if (!/^https:\/\/tcxdd\.dcs\.vn\/dangvien\/pages\/profile-manage\/party-member\/(create|view\/\d+)/.test(tab.url || "")) return;
  clearTimeout(henGio);
  henGio = setTimeout(async () => {
    for (let i = 0; i < 10; i++) {
      const co = await chay(tabId, () => !!document.querySelector('[formcontrolname="currentFullName"]')).catch(() => false);
      if (co) { choTrangMoi = false; if ($("tdTuChay").checked && hs()) chayTuDong("b1"); else soSanh(); return; }
      await new Promise((r) => setTimeout(r, 1000));
    }
  }, 1200);
});

// ================= KHÔI PHỤC PHIÊN =================
chrome.storage.session.get(["hoSo", "ten", "chon", "daLuu"], (s) => {
  if (s.hoSo && s.hoSo.length) {
    hoSo = s.hoSo; daLuu = s.daLuu || {};
    hoSo.forEach((d) => { d.__ds = d.__ds || { qtct: [], qh: d.__nguoiThan || [] }; DS_KEYS.forEach((b) => (d.__ds[b] = d.__ds[b] || [])); d.__kt = d.__kt || {}; d.__dd = d.__dd || {}; });
    trangThai("tt", `Đang dùng ${hoSo.length} hồ sơ từ ${s.ten || "file đã nhập"} (tự xóa khi đóng trình duyệt).`);
    veDanhSach(s.chon || 0);
  }
});
DS_KEYS.forEach(veDS); veDD();


// ================= TẢI DỮ LIỆU ĐÃ LƯU TRÊN ĐÁM MÂY (Firebase) =================
const FB_URL = "https://hung-da4c1-default-rtdb.asia-southeast1.firebasedatabase.app";
let dsMay = [];
chrome.storage.local.get(["fbSecret"], (s) => { if (s.fbSecret) $("fbSecret").value = s.fbSecret; else $("caiMay").open = true; });
$("fbSecret").onchange = () => chrome.storage.local.set({ fbSecret: $("fbSecret").value.trim() });
async function fbDoc(path) {
  const secret = $("fbSecret").value.trim();
  if (!secret) { $("caiMay").open = true; throw new Error("Chưa nhập mã bí mật trong mục Cài đặt đám mây."); }
  const r = await fetch(`${FB_URL}/${path}.json?auth=${encodeURIComponent(secret)}`);
  const t = await r.text();
  if (!r.ok) {
    let m = t; try { m = JSON.parse(t).error || t; } catch (e) {}
    throw new Error(r.status === 401 || /permission|auth/i.test(m) ? "Sai mã bí mật hoặc không có quyền đọc." : `Lỗi máy chủ ${r.status}: ${m}`);
  }
  return t ? JSON.parse(t) : null;
}
const khongDau = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[đĐ]/g, "d").toLowerCase();
function veDsMay() {
  const q = khongDau($("locMay").value.trim());
  const box = $("dsMay"); box.innerHTML = "";
  const hien = dsMay.filter((x) => !q || khongDau(`${x.ten} ${x.cccd} ${x.id} ${x.nguoiNhap}`).includes(q));
  hien.forEach((x) => {
    const cb = el("input", { type: "checkbox", checked: !!x.chon });
    cb.onchange = () => { x.chon = cb.checked; demChon(); };
    box.append(el("label", {}, cb, el("div", {}, el("b", { textContent: x.ten || "(chưa có họ tên)" }),
      el("small", { textContent: `ID ${x.id}${x.ngaySinh ? " · sinh " + x.ngaySinh : ""} · ${x.soCongTac || 0} dòng công tác · ${x.soNguoiThan || 0} người thân` }),
      el("small", { textContent: `Lưu bởi ${x.nguoiNhap || "?"} lúc ${x.capNhat || "?"}` }))));
  });
  if (!hien.length) box.append(el("div", { className: "note", style: "padding:6px 8px", textContent: "Không có hồ sơ phù hợp." }));
  $("chonHetMay").checked = hien.length > 0 && hien.every((x) => x.chon);
  demChon();
}
function demChon() { const n = dsMay.filter((x) => x.chon).length; $("napMay").disabled = !n || dangChay; $("napMay").textContent = `Nạp ${n} hồ sơ đã chọn`; }
$("locMay").oninput = veDsMay;
$("chonHetMay").onchange = () => {
  const q = khongDau($("locMay").value.trim());
  dsMay.filter((x) => !q || khongDau(`${x.ten} ${x.cccd} ${x.id} ${x.nguoiNhap}`).includes(q)).forEach((x) => (x.chon = $("chonHetMay").checked));
  veDsMay();
};
$("taiMay").onclick = async () => {
  $("taiMay").disabled = true; trangThai("ttMay", "Đang tải danh sách hồ sơ…");
  try {
    const ds = (await fbDoc("dsHoSo")) || {};
    dsMay = Object.entries(ds).map(([id, x]) => ({ id, ...x, chon: false })).sort((a, b) => String(a.ten).localeCompare(String(b.ten), "vi"));
    $("khuMay").hidden = !dsMay.length;
    veDsMay();
    trangThai("ttMay", dsMay.length ? `Có ${dsMay.length} hồ sơ trên đám mây. Chọn hồ sơ cần điền rồi bấm Nạp.` : "Chưa có hồ sơ nào trên đám mây.", dsMay.length ? "ok" : "");
  } catch (e) { trangThai("ttMay", "Lỗi: " + e.message, "err"); }
  finally { $("taiMay").disabled = false; }
};
$("napMay").onclick = async () => {
  if (dangChay) return;
  const chon = dsMay.filter((x) => x.chon);
  if (hoSo.length && !confirm(`Nạp ${chon.length} hồ sơ từ đám mây sẽ THAY danh sách đang dùng (${hoSo.length} hồ sơ). Tiếp tục?`)) return;
  $("napMay").disabled = true;
  const kq = [], loi = [];
  for (const [i, x] of chon.entries()) {
    trangThai("ttMay", `Đang nạp ${i + 1}/${chon.length}: ${x.ten}…`);
    try {
      const r = await fbDoc("hoso/" + encodeURIComponent(x.id));
      if (!r) throw new Error("không còn trên đám mây");
      const d = {};
      for (const [k, v] of Object.entries(r.hoSo || {})) if (KHOA.includes(k) && v != null && v !== "") d[k] = String(v);
      const mang = (a) => (Array.isArray(a) ? a : Object.values(a || {})).filter((o) => o && typeof o === "object");
      d.__idMay = x.id; d.__dong = "☁";
      d.__ds = { qtct: mang(r.quaTrinhCongTac), qh: mang(r.quanHeGiaDinh) };
      for (const b of Object.keys(DS_THEM)) d.__ds[b] = mang(r[b]);
      d.__dd = { ...(r.dacDiemLichSu || {}) };
      d.__kt = { ...(r.hoanCanhKinhTe || {}) };
      ganNghi(d, r);
      kq.push(d);
    } catch (e) { loi.push(`${x.ten}: ${e.message}`); }
  }
  if (kq.length) {
    hoSo = kq; daLuu = {};
    veDanhSach(0);
    await luu();
    await chrome.storage.session.set({ ten: "đám mây" });
    trangThai("tt", `Đã nạp ${kq.length} hồ sơ từ đám mây. Xem và sửa ở mục "Tổng quan" bên dưới.`, "ok");
    batDauTuDongSauNap();
  }
  trangThai("ttMay", `Đã nạp ${kq.length}/${chon.length} hồ sơ.` + (loi.length ? " Lỗi: " + loi.join("; ") : ""), loi.length ? "err" : "ok");
  demChon();
};


// Ô AI chưa chắc (app quét v5/v6 lưu trong "nghi" và "lyDo"): gắn vào từng ô để tô đỏ và báo lại
// Nhóm trong app quét: b1, ct (= qtct), qh, kt, dd và các mục bổ sung cùng tên
function ganNghi(d, r) {
  const nghi = r.nghi || {}, lyDo = r.lyDo || {};
  const ds = (a) => (Array.isArray(a) ? a : Object.values(a || {})).map(String);
  const ld = (nhom, ma) => (lyDo[nhom] || {})[ma] || "cần đối chiếu hồ sơ gốc";
  const mot = (nhom, dich, coKhoa) => { for (const k of ds(nghi[nhom])) if (coKhoa(k)) (dich.__nghi = dich.__nghi || {})[k] = ld(nhom, k); };
  const goc = { __nghi: {} };
  mot("b1", goc, (k) => !!d[k]);
  if (Object.keys(goc.__nghi).length) d.__nghi = goc.__nghi;
  mot("dd", d.__dd, (k) => !!d.__dd[k]);
  mot("kt", d.__kt, (k) => !!d.__kt[k]);
  for (const [nhom, b] of [["ct", "qtct"], ["qh", "qh"], ...Object.keys(DS_THEM).map((k) => [k, k])]) {
    for (const ma of ds(nghi[nhom])) {
      const m = ma.match(/^(\d+)\.(\w+)$/);
      const x = m && d.__ds[b][Number(m[1])];
      if (x && x[m[2]]) (x.__nghi = x.__nghi || {})[m[2]] = ld(nhom, ma);
    }
  }
}
// Danh sách ô AI chưa chắc của một hồ sơ: [{muc, nhan, gt, lyDo, quanTrong}]
const QUAN_TRONG = ["currentFullName", "birthDate", "identifyNo", "gender", "officialJoinPartyDate", "officialRecognitionDate", "cardNumber", "profileNumber", "activityOfficialOrgId"];
function dsNghi(d) {
  const kq = [];
  const NB1 = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[1]])), NDD = Object.fromEntries(TRUONG_DD.map((t) => [t[0], t[1]])), NKT = Object.fromEntries(KT_TRUONG);
  for (const [k, l] of Object.entries(d.__nghi || {})) kq.push({ muc: "b1", nhan: NB1[k] || k, gt: d[k], lyDo: l, quanTrong: QUAN_TRONG.includes(k) });
  for (const b of DS_KEYS) {
    const cf = DS_BUOC[b], nh = Object.fromEntries(cf.truong);
    d.__ds[b].forEach((x) => { for (const [k, l] of Object.entries(x.__nghi || {})) kq.push({ muc: b, nhan: `${cf.nhan(x)} – ${nh[k] || k}`, gt: x[k], lyDo: l, quanTrong: k === "fullName" || k === "identifyNo" }); });
  }
  for (const [k, l] of Object.entries(d.__dd.__nghi || {})) kq.push({ muc: "dd", nhan: NDD[k] || k, gt: d.__dd[k], lyDo: l });
  for (const [k, l] of Object.entries(d.__kt.__nghi || {})) kq.push({ muc: "kt", nhan: NKT[k] || k, gt: d.__kt[k], lyDo: l });
  return kq;
}

// ================= CÒN THIẾU – CẦN BỔ SUNG =================
// Trường B1 hệ thống đánh dấu * (quan sát trên trang Chỉnh sửa thông tin cơ bản, 10/2026)
const BAT_BUOC_B1 = ["activityOfficialOrgId", "currentFullName", "gender", "birthDate", "abroadStatus", "birthNationId", "birthProvinceId", "birthCommuneId",
  "hometownNationId", "hometownProvinceId", "hometownCommuneId", "residentNationId", "residentProvinceId", "residentCommuneId", "ethnicityId", "religionId",
  "currentOccupationId", "officialJoinPartyDate", "officialRecognitionDate", "educationLevelId", "identifyNo"];
// Các mục tiện ích chưa điền tự động – trường bắt buộc (*) quan sát trên trang, để nhắc nhập tay
const MUC_NHAP_TAY = [
  ["11 Quá trình sinh hoạt Đảng", "hệ thống tự ghi khi chuyển sinh hoạt, không có nút Thêm mới – không cần nhập"],
  ["Thông tin cơ bản (chỉ có khi sửa)", "Trạng thái hoạt động; Chức vụ đảng, chính quyền, đoàn thể, doanh nghiệp hiện nay – nhập tay"],
  ["B3 Đào tạo", "Ngoại ngữ bắt buộc khi đào tạo ngoại ngữ; Trình độ bắt buộc với một số loại khác"],
];

// Trường chính của từng dòng B2, B8 (dùng để nhắc thiếu; các trường phụ như ghi chú không nhắc)
const CHINH_DS = { qtct: ["fromDate", "companyName", "companyPosition"], qh: ["type", "familyMemberId", "fullName", "birthDate"] };
function dsThieu(d) {
  const kq = [];
  // B1
  const NHAN_B1 = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[1]])), NHAN_B9 = Object.fromEntries(KT_TRUONG);
  const c1 = d.__thieuB1 && d.__thieuB1.map((x) => (typeof x === "string" ? { k: x, bb: false } : x)).filter((x) => !d[x.k]);
  const t1 = c1 && c1.filter((x) => x.bb).map((x) => NHAN_B1[x.k] || x.k);
  const t1p = c1 && c1.filter((x) => !x.bb).map((x) => NHAN_B1[x.k] || x.k);
  const t9 = d.__thieuB9 && d.__thieuB9.filter((k) => !d.__kt[k]).map((k) => NHAN_B9[k] || k);
  if (t1) {
    kq.push(["B1 – trường BẮT BUỘC (*)", t1.length ? t1 : null, "hệ thống đánh dấu *, phải bổ sung mới lưu được"]);
    kq.push(["B1 – trường không bắt buộc", t1p.length ? t1p : null, "còn trống, bổ sung nếu hồ sơ gốc có", true]);
  }
  else {
    const bb = BAT_BUOC_B1.filter((k) => KHOA.includes(k) && !d[k]).map((k) => NHAN_B1[k] || k);
    kq.push(["B1 – trường BẮT BUỘC (*)", bb.length ? bb : null, "theo dữ liệu, chưa đối chiếu trang – bấm So sánh để loại trường trang đã có"]);
    kq.push(["B1 – trường không bắt buộc", undefined, `dữ liệu đang trống ${KHOA.filter((k) => !d[k] && !BAT_BUOC_B1.includes(k)).length} trường – bấm So sánh để xem chi tiết.`]);
  }
  // B2, B8
  for (const b of DS_KEYS) {
    const cf = DS_BUOC[b], ds = d.__ds[b] || [], ten = cf.so + " " + cf.ten, them = !!DS_THEM[b];
    if (!ds.length) { if (them) continue; kq.push([ten, [`Chưa có ${cf.don} nào`]]); continue; }
    const nhanCua = Object.fromEntries(cf.truong);
    const ls = [];
    ds.forEach((x, i) => { const t = (CHINH_DS[b] || cf.bb).filter((k) => !String(x[k] || "").trim()).map((k) => nhanCua[k]); if (t.length) ls.push(`Dòng ${i + 1} (${cf.nhan(x)}): ${t.join(", ")}`); });
    kq.push([ten, ls.length ? ls : null]);
  }
  // B9
  if (t9) kq.push(["B9 Hoàn cảnh kinh tế", t9.length ? t9 : null, "trống cả trong dữ liệu lẫn trên trang"]);
  else if (!KT_TRUONG.some(([k]) => d.__kt[k])) kq.push(["B9 Hoàn cảnh kinh tế", ["Chưa có dữ liệu hoàn cảnh kinh tế"]]);
  else kq.push(["B9 Hoàn cảnh kinh tế", undefined, `chưa so sánh – dữ liệu đang trống ${KT_TRUONG.filter(([k]) => !d.__kt[k]).length}/${KT_TRUONG.length} ô.`]);
  return kq;
}
function vanBanThieu(d) {
  const dong = [`Hồ sơ: ${d.currentFullName || "(chưa có họ tên)"} – CCCD: ${d.identifyNo || "chưa có"}${d.__idMay ? " – ID " + d.__idMay : ""}`];
  const ng = dsNghi(d);
  if (ng.length) dong.push("AI chưa chắc – cần rà soát:", ...ng.map((x) => `  - ${TEN_MUC[x.muc] || x.muc} · ${x.nhan}: "${x.gt}" (${x.lyDo})`));
  for (const [ten, ls, ghi] of dsThieu(d)) {
    if (ls === null) continue;
    if (ls === undefined) { dong.push(`${ten}: ${ghi}`); continue; }
    dong.push(`${ten}${ghi ? " (" + ghi + ")" : ""}:`, ...ls.map((x) => "  - " + x));
  }
  dong.push("Lưu ý:", ...MUC_NHAP_TAY.map(([m, t]) => `  - ${m}: ${t}`));
  return dong.join("\n");
}
function veThieu() {
  const box = $("thieu"), d = hs();
  if (!box) return;
  box.innerHTML = "";
  if (!d) return;
  const ds = dsThieu(d);
  const soMuc = ds.reduce((s, [, ls, , phu]) => s + (Array.isArray(ls) && !phu ? ls.length : 0), 0);
  const ng = dsNghi(d);
  if (ng.length) {
    const kn = el("details", { className: "muc nghi-ds", open: ng.length <= 8 }, el("summary", { textContent: `⚠ AI chưa chắc – cần rà soát (${ng.length} ô${ng.some((x) => x.quanTrong) ? ", có trường quan trọng" : ""})` }));
    ng.sort((a, b) => b.quanTrong - a.quanTrong).forEach((x) => kn.append(el("div", {}, el("i", { textContent: `${TEN_MUC[x.muc] || x.muc} · ${x.nhan}${x.quanTrong ? " (quan trọng)" : ""}: ` }), `"${x.gt}" – ${x.lyDo}`)));
    box.append(kn);
  }
  box.append(el("b", { textContent: soMuc ? `Còn thiếu – cần bổ sung (${soMuc} mục chính)` : "Còn thiếu – cần bổ sung" }));
  for (const [ten, ls, ghi, phu] of ds) {
    const m = el("div", { className: "muc" }, el("i", { textContent: ten + ": " }));
    if (phu && Array.isArray(ls)) {
      const ct = el("details", {}, el("summary", { textContent: `${ls.length} trường – bấm để xem` }), el("div", { textContent: ls.join("; ") }));
      m.append(ct); box.append(m); continue;
    }
    if (ls === null) m.append("✓ đủ" + (ghi ? "" : " các trường chính"));
    else if (ls === undefined) m.append(el("span", { className: "hd", textContent: ghi }));
    else { if (ghi) m.append(el("span", { className: "hd", textContent: `(${ghi}) ` })); m.append(ls.join("; ")); }
    box.append(m);
  }
  const tay = el("details", { className: "muc" }, el("summary", { textContent: "Lưu ý các mục nhập tay / điều kiện" }));
  MUC_NHAP_TAY.forEach(([m, t]) => tay.append(el("div", {}, el("i", { textContent: m + ": " }), t)));
  box.append(tay);
  const nut = el("span", { className: "lienKet", textContent: "📋 Sao chép danh sách thiếu", onclick: async () => {
    const t = vanBanThieu(d);
    try { await navigator.clipboard.writeText(t); nut.textContent = "✓ Đã sao chép"; }
    catch (e) { prompt("Sao chép nội dung sau:", t); }
    setTimeout(() => (nut.textContent = "📋 Sao chép danh sách thiếu"), 2000);
  } });
  box.append(el("div", { className: "muc" }, nut));
}


// ================= B6: ĐẶC ĐIỂM LỊCH SỬ (một biểu mẫu, dùng chung cơ chế so sánh/điền của B1) =================
const OPT_DD = { truong: TRUONG_DD, khoa: "leaveDate", ten: "6 Đặc điểm lịch sử" };
function veDD() {
  const p = $("p_dd"), d = hs();
  if (!p) return;
  if (!p.childElementCount) {
    p.append(
      el("p", { className: "note", textContent: 'Trên trang: mở mục 6 Đặc điểm lịch sử, bấm "Chỉnh sửa thông tin" rồi mới bấm So sánh.' }),
      el("button", { id: "ddSoSanh", className: "full", textContent: "So sánh B6 với dữ liệu trên trang", onclick: soSanhDD }),
      el("div", { id: "ddTT", className: "tt" }), el("div", { id: "ddBang" }),
      el("button", { id: "ddDien", className: "primary full", disabled: true, onclick: dienDD }), el("div", { id: "ddKq" }));
  }
  const box = $("ddBang"); box.innerHTML = "";
  if (!d) return;
  const coDL = TRUONG_DD.filter(([k]) => d.__dd[k]).length;
  if (!ddSS) { trangThai("ddTT", coDL ? `Dữ liệu có ${coDL} ô B6.` : "Dữ liệu không có thông tin Đặc điểm lịch sử cho đảng viên này (đa số đảng viên để trống mục này)."); capNhatNut(); return; }
  for (const x of ddSS.ds) {
    const coThe = x.tt === "trong" || x.tt === "khac";
    const cb = el("input", { type: "checkbox", checked: !!x.chon, disabled: !coThe || dangChay });
    cb.onchange = () => { x.chon = cb.checked; capNhatNut(); };
    const [nhan, lop] = NHAN_TT[x.tt];
    const the = el("div", { className: "ss" + (x.tt === "khac" ? " khac" : "") }, el("div", { className: "dau" }, cb, el("span", { textContent: x.nhan })),
      el("div", { className: "gt" }, el("span", { className: "tag " + lop, textContent: nhan })));
    if (x.cu) the.append(el("div", { className: "gt" }, el("i", { textContent: "Trên trang:" }), x.cu));
    the.append(el("div", { className: "gt" }, el("i", { textContent: "File:" }), x.moi));
    box.append(the);
  }
  capNhatNut();
}
async function soSanhDD() {
  const d = hs(); if (!d) return;
  ddSS = null; $("ddKq").innerHTML = "";
  try {
    const tab = await layTab(); tabDien = tab.id;
    await tiem(tab.id);
    const duLieu = Object.fromEntries(TRUONG_DD.filter(([k]) => d.__dd[k]).map(([k]) => [k, d.__dd[k]]));
    const r = await chay(tab.id, (x, o) => window.__dhsSoSanh(x, o), [duLieu, OPT_DD]);
    if (!r || r.loiChung) { veDD(); return trangThai("ddTT", r ? r.loiChung : "Không đọc được trang.", "err"); }
    r.ds.forEach((x) => (x.chon = x.tt === "trong"));
    ddSS = r;
    const khoa = r.ds.filter((x) => x.tt === "khoa").length;
    veDD();
    trangThai("ddTT", (r.ds.length ? `${r.ds.filter((x) => x.tt === "trong").length} ô trống sẽ điền, ${r.ds.filter((x) => x.tt === "khac").length} ô khác dữ liệu (giữ nguyên nếu không tích).` : "Dữ liệu không có ô B6 nào để điền.") +
      (khoa ? ` ${khoa} ô đang khóa – bấm "Chỉnh sửa thông tin" trên trang rồi So sánh lại.` : ""), khoa ? "err" : "ok");
  } catch (e) { trangThai("ddTT", e.message, "err"); }
}
async function dienDD() {
  const chon = ddSS ? ddSS.ds.filter((x) => x.chon) : [];
  if (!chon.length) return;
  const thay = chon.filter((x) => x.tt === "khac");
  if (thay.length && !confirm(`Xác nhận THAY ${thay.length} ô đang có dữ liệu cũ:\n\n` + thay.map((x) => `• ${x.nhan}: "${x.cu}" → "${x.moi}"`).join("\n"))) return;
  try {
    const tab = await layTab();
    if (tab.id !== tabDien) throw new Error("Tab đã đổi sau khi so sánh. Bấm So sánh lại.");
    await tiem(tab.id);
    const r = await chay(tab.id, (m, t) => { window.__dhsTRUONG = t; return window.__dhsDien(m); }, [chon.map((x) => ({ key: x.key, moi: x.moi, cu: x.cu })), TRUONG_DD]);
    if (r && r.loiChung) throw new Error(r.loiChung);
    batDauChay("dd");
    trangThai("ddTT", "Đang điền…");
  } catch (e) { trangThai("ddTT", e.message, "err"); }
}
function hienKqDD(m) {
  const ok = m.kq.filter((x) => x.ok).length;
  trangThai("ddTT", (m.dung ? "Đã dừng hẳn. " : "Xong. ") + `${ok}/${m.kq.length} ô đã điền. Kiểm tra trang rồi tự bấm Lưu.`, ok === m.kq.length ? "ok" : "err");
  const k = $("ddKq"); k.innerHTML = "";
  for (const d of [...(m.biDoi || []), ...m.kq]) k.append(el("div", { className: "ss" }, el("span", { textContent: (d.ok ? "✔ " : "✘ ") + d.nhan + (d.ok ? "" : " — " + d.loi) })));
  ddSS = null;
}


// ================= CHẠY TỰ ĐỘNG B1 → B10 =================
// Dữ liệu trong file/đám mây là dữ liệu chuẩn: điền ô trống và THAY ô khác dữ liệu, tự bấm "Lưu thông tin" từng mục.
// Dừng hỏi khi: có thể không đúng người (họ tên/CCCD/ngày sinh khác) và – nếu bật – khi ghi đè trường quan trọng.
// Bước cuối "Đóng hồ sơ" do người dùng xác nhận.
const THU_TU = ["b1", "qtct", "daotao", "huyhieu", "khenthuong", "danhgia", "kyluat", "dd", "nuocngoai", "qh", "kt", "mxh"];
const TEN_MUC = { b1: "B1 Thông tin cơ bản", dd: "B6 Đặc điểm lịch sử", kt: "B9 Hoàn cảnh kinh tế" };
for (const b of DS_KEYS) TEN_MUC[b] = `${DS_BUOC[b].so} ${DS_BUOC[b].ten}`;
let td = null, tdDangChay = false;

(function veKhuTuDong() {
  const sel = $("tuMuc");
  THU_TU.forEach((m) => sel.append(el("option", { value: m, textContent: TEN_MUC[m] })));
  try { const v = JSON.parse(localStorage.getItem("dhs_td") || "{}"); if (v.hoiQT === false) $("tdHoiQT").checked = false; if (v.tuChay === false) $("tdTuChay").checked = false; } catch (e) {}
  const ghi = () => { try { localStorage.setItem("dhs_td", JSON.stringify({ hoiQT: $("tdHoiQT").checked, tuChay: $("tdTuChay").checked })); } catch (e) {} };
  $("tdHoiQT").onchange = ghi; $("tdTuChay").onchange = ghi;
  $("chayTD").onclick = () => chayTuDong($("tuMuc").value);
  $("tdBoQua").onclick = () => tabDien && chay(tabDien, () => { window.__dhsBoQua = true; }).catch(() => {});
})();

const coDuLieuMuc = (d, m) => m === "b1" ? KHOA.some((k) => d[k]) : m === "dd" ? TRUONG_DD.some(([k]) => d.__dd[k]) : m === "kt" ? KT_TRUONG.some(([k]) => d.__kt[k]) : d.__ds[m].some((x) => x.__chon !== false);
async function choTamDung() { while (dangTamDung && td && !td.dung) await new Promise((r) => setTimeout(r, 300)); }
const goi = async (tabId, func, args) => { await tiem(tabId); return chay(tabId, func, args); };

// Mở hồ sơ trên trang: chọn đúng hồ sơ trong danh sách theo số căn cước (hoặc họ tên) đang hiện trên trang
async function chonHoSoTheoTrang(tabId) {
  const t = await chay(tabId, () => {
    const v = (k) => { const h = document.querySelector(`[formcontrolname="${k}"]`); return h ? (h.value ?? h.querySelector("input")?.value ?? "") : ""; };
    return { cc: String(v("identifyNo")).trim(), ten: String(v("currentFullName")).trim() };
  }).catch(() => null);
  if (!t || (!t.cc && !t.ten)) return;
  const tenC = (s) => khongDau(s).replace(/\s+/g, " ").trim();
  let i = t.cc ? hoSo.findIndex((d) => d.identifyNo === t.cc) : -1;
  if (i < 0 && t.ten) { const ds = hoSo.map((d, j) => [d, j]).filter(([d]) => tenC(d.currentFullName) === tenC(t.ten)); if (ds.length === 1) i = ds[0][1]; }
  if (i >= 0 && i !== chiSo()) { $("ds").value = i; xem(); luu(); }
}

async function chayTuDong(tuMuc = "b1") {
  if (dangChay || !hs()) return;
  let tab;
  try { tab = await layTab(); } catch (e) { $("khuTuDong").open = true; return trangThai("tdTT", e.message, "err"); }
  tabDien = tab.id;
  if (tuMuc === "b1") await chonHoSoTheoTrang(tab.id);
  const d = hs();
  td = { dung: false, bc: {}, idx: chiSo(), tab: tab.id, ten: d.currentFullName || "(chưa có họ tên)" };
  tdDangChay = true;
  batDauChay("auto");
  $("khuTuDong").open = true;
  $("tdBC").innerHTML = ""; $("tdCuoi").hidden = true;
  trangThai("tdTT", `Đang chạy tự động hồ sơ ${td.ten}…`);
  try {
    for (const m of THU_TU.slice(Math.max(0, THU_TU.indexOf(tuMuc)))) {
      if (td.dung) break;
      await choTamDung();
      if (td.dung) break;
      if (!coDuLieuMuc(d, m)) { td.bc[m] = { tt: "khongCo" }; veBaoCao(); continue; }
      trangThai("tdTT", `${TEN_MUC[m]}: đang mở mục…`);
      let r;
      try { r = await chayMuc(tab.id, m, d); }
      catch (e) { r = { tt: "loi", loi: [/Frame|closed|No tab|Cannot access/i.test(e.message) ? "Trang đã tải lại hoặc đóng giữa chừng: " + e.message : e.message] }; }
      td.bc[m] = r; veBaoCao();
      if (r.dungHan) { td.dung = true; break; }
    }
  } finally {
    tdDangChay = false;
    ketThucChay();
  }
  ketThucTuDong();
}

async function chayMuc(tabId, m, d) {
  const mo = await goi(tabId, (b) => window.__dhsAutoLib.moMuc(b), [m]);
  if (!mo || !mo.ok) return { tt: "loi", loi: [mo ? mo.loi : "Không chạy được trên trang."], dungHan: !!(mo && /danh sách các mục|hộp thoại/.test(mo.loi)) };
  trangThai("tdTT", `${TEN_MUC[m]}: đang so sánh và điền…`);
  if (m === "b1" || m === "dd") return chayForm(tabId, m, d);
  if (m === "kt") return chayKT(tabId, d);
  return chayDSMuc(tabId, m, d);
}

const NHAN_B1 = Object.fromEntries(TRUONG_HO_SO.map((t) => [t[0], t[1]]));
async function chayForm(tabId, m, d) {
  const laB1 = m === "b1", src = laB1 ? d : d.__dd, khoa = laB1 ? "currentFullName" : "leaveDate";
  const keys = laB1 ? KHOA : TRUONG_DD.map((t) => t[0]);
  const duLieu = Object.fromEntries(keys.filter((k) => src[k]).map((k) => [k, src[k]]));
  const nghi = (laB1 ? d.__nghi : d.__dd.__nghi) || {};
  const opt = laB1 ? null : OPT_DD;
  const bc = { tt: "xong", dien: [], ghiDe: [], loi: [], giuCu: [], nghi: Object.entries(nghi).map(([k, l]) => ({ nhan: (laB1 ? NHAN_B1[k] : (TRUONG_DD.find((t) => t[0] === k) || [])[1]) || k, gt: src[k], lyDo: l, quanTrong: laB1 && QUAN_TRONG.includes(k) })) };
  const danhDauForm = () => chay(tabId, (n) => window.__dhsAutoLib.danhDau({ form: n }), [nghi]).catch(() => {});
  await danhDauForm();
  // 1. So sánh sơ bộ (chưa mở chế độ sửa) để biết có gì cần đổi
  let ss = await goi(tabId, (x, o) => window.__dhsSoSanh(x, o), [duLieu, { ...(opt || {}), boQuaKhoa: true }]);
  if (!ss || ss.loiChung) return { ...bc, tt: "loi", loi: [ss ? ss.loiChung : "Không đọc được trang."] };
  let daXacNhanNguoi = false;
  if (laB1 && ss.canhBao.length) {
    if (!confirm(`CẢNH BÁO – có thể KHÔNG ĐÚNG NGƯỜI (hồ sơ "${d.currentFullName}"):\n\n${ss.canhBao.join("\n")}\n\nOK: chắc chắn đúng người, thay bằng dữ liệu file.\nHủy: dừng chạy tự động.`))
      return { ...bc, tt: "loi", loi: ["Đã dừng vì nghi không đúng người: " + ss.canhBao.join("; ")], dungHan: true };
    daXacNhanNguoi = true;
  }
  if (laB1) d.__thieuB1 = (ss.thieu || []).map((x) => ({ k: x.key, bb: !!x.bb }));
  if (!ss.ds.some((x) => x.tt === "trong" || x.tt === "khac")) return { ...bc, tt: "trung" };
  // 2. Mở chế độ sửa rồi so sánh lại với giá trị thật
  const ms = await chay(tabId, (k) => window.__dhsAutoLib.moSua(k), [khoa]);
  if (!ms.ok) return { ...bc, tt: "loi", loi: [ms.loi] };
  ss = await chay(tabId, (x, o) => window.__dhsSoSanh(x, o), [duLieu, opt || undefined]);
  if (!ss || ss.loiChung) return { ...bc, tt: "loi", loi: [ss ? ss.loiChung : "Không đọc được trang."] };
  let chon = ss.ds.filter((x) => x.tt === "trong" || x.tt === "khac");
  bc.loi.push(...ss.ds.filter((x) => x.tt === "khoa").map((x) => `${x.nhan}: ô bị khóa, không điền được (file: "${x.moi}")`));
  // Trường quan trọng đang có dữ liệu khác
  const qt = laB1 ? chon.filter((x) => x.tt === "khac" && QUAN_TRONG.includes(x.key)) : [];
  if (qt.length && $("tdHoiQT").checked && !daXacNhanNguoi) {
    const ok = confirm(`Ghi đè ${qt.length} trường QUAN TRỌNG đang có dữ liệu khác trên trang (${d.currentFullName}):\n\n` +
      qt.map((x) => `• ${x.nhan}: "${x.cu}" → "${x.moi}"` + (nghi[x.key] ? `   ⚠ AI chưa chắc: ${nghi[x.key]}` : "")).join("\n") +
      "\n\nOK: thay bằng dữ liệu file.\nHủy: giữ dữ liệu trên trang cho các trường này, vẫn điền các trường khác.");
    if (!ok) { bc.giuCu.push(...qt.map((x) => ({ nhan: x.nhan, cu: x.cu, moi: x.moi }))); chon = chon.filter((x) => !qt.includes(x)); }
  }
  // Đổi Quốc gia/Tỉnh thì trang xóa ô phụ thuộc: chọn kèm Tỉnh/Xã có trong file để điền lại
  const chonSet = new Set(chon.map((x) => x.key));
  for (const x of [...chon]) {
    const mm = x.key.match(/^(\w+?)(Nation|Province)Id$/);
    if (!mm) continue;
    for (const sau of mm[2] === "Nation" ? ["Province", "Commune"] : ["Commune"]) {
      const y = ss.ds.find((z) => z.key === mm[1] + sau + "Id");
      if (y && !chonSet.has(y.key) && y.tt !== "khoa" && y.tt !== "an") chonSet.add(y.key);
    }
  }
  chon = ss.ds.filter((x) => chonSet.has(x.key));
  if (!chon.length) { await chay(tabId, () => window.__dhsAutoLib.huySua(), []); return { ...bc, tt: "trung" }; }
  await danhDauForm();
  const r = await chay(tabId, (mm, t) => window.__dhsDienCho(mm, t), [chon.map((x) => ({ key: x.key, moi: x.moi, cu: x.cu })), laB1 ? null : TRUONG_DD]);
  if (!r || r.loiChung) return { ...bc, tt: "loi", loi: [r ? r.loiChung : "Không điền được."] };
  for (const o of r.kq) {
    if (!o.ok) bc.loi.push(`${o.nhan}: ${o.loi}`);
    else if (o.cu && o.cu !== o.hien) bc.ghiDe.push({ nhan: o.nhan, cu: o.cu, moi: o.hien });
    else if (!o.cu) bc.dien.push(o.nhan);
  }
  bc.loi.push(...r.biDoi.map((o) => `${o.nhan}: ${o.loi}`));
  if (r.dung) return { ...bc, tt: "dung", dungHan: true };
  // 3. Lưu
  trangThai("tdTT", `${TEN_MUC[m]}: đang bấm "Lưu thông tin"…`);
  const lu = await chay(tabId, (k) => window.__dhsAutoLib.luuVaCho({ khoaKey: k }), [khoa]);
  if (!lu.ok) {
    bc.loiLuu = lu.loi;
    trangThai("tdTT", `${TEN_MUC[m]}: trang báo lỗi khi lưu – ${lu.loi}. Sửa trên trang rồi bấm "Lưu thông tin", tiện ích sẽ chạy tiếp; hoặc bấm "Bỏ qua mục này".`, "err");
    $("tdBoQua").hidden = false;
    const kq = await chay(tabId, (k) => window.__dhsAutoLib.choNguoiLuu(k), [khoa]).finally(() => ($("tdBoQua").hidden = true));
    if (kq === "dung") return { ...bc, tt: "dung", dungHan: true };
    bc.tt = kq === "luu" ? "xong" : "boQua";
    if (kq === "luu") bc.ghiChu = "Đã lưu sau khi anh/chị sửa lỗi trên trang.";
  }
  if (laB1 && lu.chuyenTrang) bc.ghiChu = "Đã lưu và trang chuyển sang bước tiếp theo.";
  await danhDauForm();
  return bc;
}

async function chayDSMuc(tabId, m, d) {
  const cf = DS_BUOC[m], rows = d.__ds[m].filter((x) => x.__chon !== false);
  const nh = Object.fromEntries(cf.truong);
  const bc = { tt: "xong", dien: [], ghiDe: [], loi: [], giuCu: [], dong: { luu: 0, trung: 0, khac: 0 },
    nghi: rows.flatMap((x) => Object.entries(x.__nghi || {}).map(([k, l]) => ({ nhan: `${cf.nhan(x)} – ${nh[k] || k}`, gt: x[k], lyDo: l }))) };
  const r = await chay(tabId, (b, x, o) => window.__dhsDSDienCho(b, x, o), [m, rows.map(sach), { nghi: rows.map((x) => x.__nghi || {}) }]);
  if (!r || r.loiChung) return { ...bc, tt: "loi", loi: [r ? r.loiChung : "Không điền được."] };
  for (const k of r.tong) {
    if (k.ketQua === "luu") bc.dong.luu++; else if (k.ketQua === "trung") bc.dong.trung++; else bc.dong.khac++;
    if (k.ketQua === "loi") bc.loi.push(`${k.ten}: ${k.loi}`);
    else if (k.ketQua === "dong") bc.loi.push(`${k.ten}: đã bỏ qua (Đóng), chưa lưu`);
    for (const o of k.o) {
      if (!o.ok && o.tt !== "khac") bc.loi.push(`${k.ten} – ${o.nhan}: ${o.loi}`);
      if (o.ok && o.tt === "ghiDe") bc.ghiDe.push({ nhan: `${k.ten} – ${o.nhan}`, cu: o.cu, moi: o.hien });
      if (o.ok && o.tt === "dien" && k.loai === "sua") bc.dien.push(`${k.ten} – ${o.nhan}`);
    }
  }
  if (r.dung) { bc.tt = "dung"; bc.dungHan = true; }
  const dongNghi = rows.filter((x) => x.__nghi && Object.keys(x.__nghi).length).map((x) => ({ x: sach(x), lyDo: Object.entries(x.__nghi).map(([k, l]) => `${nh[k] || k}: ${l}`).join("; ") }));
  if (dongNghi.length) await chay(tabId, (b, rr) => window.__dhsAutoLib.danhDau({ bang: { buoc: b, rows: rr } }), [m, dongNghi]).catch(() => {});
  return bc;
}

async function chayKT(tabId, d) {
  const kt = sach(d.__kt), nghi = d.__kt.__nghi || {};
  const NKT = Object.fromEntries(KT_TRUONG);
  const bc = { tt: "xong", dien: [], ghiDe: [], loi: [], giuCu: [], nghi: Object.entries(nghi).map(([k, l]) => ({ nhan: NKT[k] || k, gt: kt[k], lyDo: l })) };
  const ss = await chay(tabId, (x) => window.__dhsKTSoSanh(x), [kt]);
  if (!ss || ss.loiChung) return { ...bc, tt: "loi", loi: [ss ? ss.loiChung : "Không đọc được trang."] };
  d.__thieuB9 = ss.ds.filter((x) => !x.moi && !String(x.cu || "").trim()).map((x) => x.key);
  const chon = ss.ds.filter((x) => ["trong", "themMoi", "khac"].includes(x.tt)).map((x) => x.key);
  if (!chon.length) { await chay(tabId, (n) => window.__dhsAutoLib.danhDau({ form: n }), [nghi]).catch(() => {}); return { ...bc, tt: "trung" }; }
  const k = await chay(tabId, (x, c, o) => window.__dhsKTDienCho(x, c, o), [kt, chon, { nghi }]);
  if (!k || k.loiChung) return { ...bc, tt: "loi", loi: [k ? k.loiChung : "Không điền được."] };
  for (const o of k.o) {
    if (!o.ok && o.tt !== "khac") bc.loi.push(`${o.nhan}: ${o.loi}`);
    if (o.ok && o.tt === "ghiDe") bc.ghiDe.push({ nhan: o.nhan, cu: o.cu, moi: o.hien });
    if (o.ok && o.tt === "dien") bc.dien.push(o.nhan);
  }
  if (k.ketQua === "dung") return { ...bc, tt: "dung", dungHan: true };
  if (k.ketQua === "loi") { bc.tt = "loi"; bc.loi.unshift(k.loi); }
  else if (k.ketQua === "dong") { bc.tt = "boQua"; bc.loi.push("Đã đóng, chưa lưu Hoàn cảnh kinh tế."); }
  else if (k.ketQua === "trung") bc.tt = "trung";
  return bc;
}

// ---------- Báo cáo kết quả ----------
const NHAN_TD = { xong: ["✔ Đã lưu", "ok"], trung: ["= Không có gì thay đổi", "trung"], khongCo: ["– Không có dữ liệu", "trung"], boQua: ["↷ Bỏ qua", "err"], loi: ["✘ Lỗi", "err"], dung: ["■ Đã dừng", "err"] };
function veBaoCao() {
  const box = $("tdBC");
  box.innerHTML = "";
  if (!td) return;
  for (const [m, r] of Object.entries(td.bc)) {
    if (r.tt === "khongCo") continue;
    const [nhan, lop] = NHAN_TD[r.tt] || [r.tt, ""];
    const soNghi = (r.nghi || []).length;
    const tom = [r.dong && `${r.dong.luu} dòng lưu, ${r.dong.trung} dòng giữ nguyên` + (r.dong.khac ? `, ${r.dong.khac} dòng chưa lưu` : ""),
      r.dien && r.dien.length && `${r.dien.length} ô điền mới`, r.ghiDe && r.ghiDe.length && `${r.ghiDe.length} ô thay dữ liệu cũ`,
      r.loi && r.loi.length && `${r.loi.length} lỗi`, soNghi && `⚠ ${soNghi} ô AI chưa chắc`].filter(Boolean).join(" · ");
    const muc = el("details", { className: "td-muc " + lop, open: !!((r.loi && r.loi.length) || soNghi || (r.giuCu && r.giuCu.length)) },
      el("summary", {}, el("b", { textContent: TEN_MUC[m] + ": " }), nhan + (tom ? " · " + tom : "")));
    if (r.ghiChu) muc.append(el("div", { className: "gt", textContent: r.ghiChu }));
    if (soNghi) {
      const k = el("div", { className: "td-nghi" }, el("b", { textContent: "Cần rà soát (AI chưa chắc):" }));
      r.nghi.forEach((x) => k.append(el("div", { textContent: `• ${x.nhan}${x.quanTrong ? " (QUAN TRỌNG)" : ""}: "${x.gt}" – ${x.lyDo}` })));
      k.append(el("span", { className: "lienKet", textContent: "Mở mục này trên trang và tô đỏ", onclick: () => xemLaiMuc(m) }));
      muc.append(k);
    }
    for (const x of r.giuCu || []) muc.append(el("div", { className: "gt", textContent: `Giữ dữ liệu trên trang: ${x.nhan} "${x.cu}" (file: "${x.moi}")` }));
    for (const x of r.ghiDe || []) muc.append(el("div", { className: "gt", textContent: `Đã thay: ${x.nhan}: "${x.cu}" → "${x.moi}"` }));
    for (const x of r.loi || []) muc.append(el("div", { className: "gt loi", textContent: "✘ " + x }));
    box.append(muc);
  }
}
async function xemLaiMuc(m) {
  if (dangChay || !td) return;
  const d = hoSo[td.idx];
  try {
    const mo = await goi(td.tab, (b) => window.__dhsAutoLib.moMuc(b), [m]);
    if (!mo.ok) return trangThai("tdTT", mo.loi, "err");
    let cfg;
    if (m === "b1") cfg = { form: d.__nghi || {} };
    else if (m === "dd") cfg = { form: d.__dd.__nghi || {} };
    else if (m === "kt") cfg = { form: d.__kt.__nghi || {} };
    else { const nh = Object.fromEntries(DS_BUOC[m].truong); cfg = { bang: { buoc: m, rows: d.__ds[m].filter((x) => x.__nghi && Object.keys(x.__nghi).length).map((x) => ({ x: sach(x), lyDo: Object.entries(x.__nghi).map(([k, l]) => `${nh[k] || k}: ${l}`).join("; ") })) } }; }
    await chay(td.tab, (c) => window.__dhsAutoLib.danhDau(c), [cfg]);
    trangThai("tdTT", `Đã mở ${TEN_MUC[m]} và tô đỏ các ô/dòng AI chưa chắc.`, "ok");
  } catch (e) { trangThai("tdTT", e.message, "err"); }
}
function ketThucTuDong() {
  if (!td) return;
  const ds = Object.values(td.bc);
  const loi = ds.filter((r) => r.tt === "loi" || r.tt === "boQua" || r.tt === "dung").length;
  const nghi = ds.reduce((t, r) => t + (r.nghi || []).length, 0);
  const dungGiua = td.dung;
  trangThai("tdTT", (dungGiua ? "Đã dừng giữa chừng. " : "Đã chạy xong B1 → B10. ") +
    `${ds.filter((r) => r.tt === "xong").length} mục đã lưu` + (loi ? `, ${loi} mục có lỗi/bỏ qua` : "") + (nghi ? `, ⚠ ${nghi} ô AI chưa chắc cần rà soát` : "") +
    ". Rà soát trên trang (các ô tô đỏ) rồi bấm xác nhận bên dưới để đóng hồ sơ.", loi || dungGiua ? "err" : "ok");
  $("tdCuoi").hidden = false;
  $("tdDong").textContent = `✔ Xác nhận hoàn tất – Đóng hồ sơ ${td.ten}`;
  veBaoCao();
}
$("tdDong").onclick = async () => {
  if (!td || dangChay) return;
  const coLoi = Object.values(td.bc).some((r) => ["loi", "boQua", "dung"].includes(r.tt));
  if (coLoi && !confirm("Còn mục bị lỗi hoặc bỏ qua (xem báo cáo). Vẫn đóng hồ sơ?")) return;
  try {
    const r = await goi(td.tab, () => window.__dhsAutoLib.dongHoSo(), []);
    if (!r.ok) return trangThai("tdTT", r.loi, "err");
  } catch (e) { return trangThai("tdTT", e.message, "err"); }
  const i = td.idx;
  daLuu[i] = true;
  $("tdCuoi").hidden = true;
  if (i < hoSo.length - 1) {
    veDanhSach(i + 1);
    choTrangMoi = $("tdTuChay").checked;
    trangThai("tdTT", `Đã đóng hồ sơ ${td.ten}. Tiếp theo: ${hoSo[i + 1].currentFullName || "(chưa có họ tên)"} – mở trang hồ sơ của người này (hoặc trang Thêm mới)` + (choTrangMoi ? ", tiện ích sẽ tự chạy." : ", rồi bấm Chạy tự động."), "ok");
  } else {
    veDanhSach(i);
    trangThai("tdTT", `Đã đóng hồ sơ ${td.ten}. Đây là hồ sơ cuối cùng trong danh sách.`, "ok");
  }
  td = null;
  luu();
};

async function batDauTuDongSauNap() {
  if (!$("tdTuChay").checked || !hoSo.length) return;
  $("khuTuDong").open = true;
  let tab = null;
  try { tab = await layTab(); } catch (e) {}
  if (tab && /\/party-member\/(create|view\/\d+)/.test(tab.url || "")) return chayTuDong("b1");
  choTrangMoi = true;
  trangThai("tdTT", `Mở trang hồ sơ của ${hs().currentFullName || "đảng viên"} (Xem thông tin đảng viên, hoặc Thêm mới) – tiện ích sẽ tự chạy từ B1 đến B10.`, "ok");
}
