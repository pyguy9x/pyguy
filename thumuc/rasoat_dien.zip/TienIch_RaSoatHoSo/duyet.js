(() => {
  'use strict';
  var $ = function(id) { return document.getElementById(id); };
  function txt(el, s) { el.textContent = (s == null ? '' : s); return el; }
  function div(cls) { var d = document.createElement('div'); if (cls) d.className = cls; return d; }

  var FB_URL = 'https://hung-da4c1-default-rtdb.asia-southeast1.firebasedatabase.app';
  var MA_MAC_DINH = 'uPjRMZvtogiFls0X2n71sd5o098RcsPdVfxjPUBm';
  var CO_CHROME = (typeof chrome !== 'undefined') && !!(chrome.storage && chrome.storage.local);

  var DS = [];
  var SECTIONS = [];
  try { if (typeof SECTIONS_DATA !== 'undefined' && SECTIONS_DATA) SECTIONS = SECTIONS_DATA; } catch (e) {}
  var TOTAL_FIELDS = 0;
  try { SECTIONS.forEach(function(s) { TOTAL_FIELDS += s.truong.length; }); } catch (e) {}

  function getSecret() { return $('secret').value.trim(); }
  function getNguoi() { return $('nguoi').value.trim(); }
  function getDonVi() { return $('donVi').value.trim(); }

  async function napLuu() {
    try {
      if (CO_CHROME) {
        var o = await chrome.storage.local.get(['rsSecret', 'rsNguoi', 'rsDonVi']);
        $('secret').value = o.rsSecret || MA_MAC_DINH;
        $('nguoi').value = o.rsNguoi || '';
        $('donVi').value = o.rsDonVi || '';
      } else {
        $('secret').value = localStorage.getItem('rsSecret') || MA_MAC_DINH;
        $('nguoi').value = localStorage.getItem('rsNguoi') || '';
        $('donVi').value = localStorage.getItem('rsDonVi') || '';
      }
    } catch (e) { $('secret').value = MA_MAC_DINH; }
  }
  async function ghiLuu() {
    try {
      if (CO_CHROME) await chrome.storage.local.set({ rsSecret: getSecret(), rsNguoi: getNguoi(), rsDonVi: getDonVi() });
      else { localStorage.setItem('rsSecret', getSecret()); localStorage.setItem('rsNguoi', getNguoi()); localStorage.setItem('rsDonVi', getDonVi()); }
    } catch (e) {}
  }

  function sachChuoiFb(s) {
    var r = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c === 65534 || c === 65535 || c === 127) continue;
      if (c < 32 && c !== 9 && c !== 10 && c !== 13) continue;
      if (c >= 55296 && c <= 57343) {
        var hi = c <= 56319;
        var nx = i + 1 < s.length ? s.charCodeAt(i + 1) : 0;
        var pv = i > 0 ? s.charCodeAt(i - 1) : 0;
        if ((hi && nx >= 56320 && nx <= 57343) || (!hi && pv >= 55296 && pv <= 56319)) { r += s[i]; } // Unicode surrogates
        continue;
      }
      r += s[i];
    }
    return r;
  }
  function sachKhoaFb(k) { return sachChuoiFb(String(k)).split('.').join('_').split('$').join('_').split('#').join('_').split('[').join('_').split(']').join('_').split('/').join('_') || '_'; }
  function sachFb(v) {
    if (v === undefined || v === null) return null;
    if (typeof v === 'string') return sachChuoiFb(v);
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    if (typeof v === 'boolean') return v;
    if (Array.isArray(v)) return v.map(sachFb);
    if (typeof v === 'object') {
      var o = {};
      for (var k in v) {
        if (!Object.prototype.hasOwnProperty.call(v, k)) continue;
        var x = v[k];
        if (x === undefined) continue;
        o[sachKhoaFb(k)] = sachFb(x);
      }
      return o;
    }
    return String(v);
  }
  function sachFbRoot(o) {
    if (o === undefined || o === null || typeof o !== 'object' || Array.isArray(o)) return sachFb(o);
    var r = {};
    for (var k in o) {
      if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
      r[k] = sachFb(o[k]);
    }
    return r;
  }
  async function fb(method, path, body) {
    var secret = getSecret();
    if (!secret) throw new Error('Chưa nhập mã bí mật.');
    var url = FB_URL + '/' + path + '.json?auth=' + encodeURIComponent(secret);
    var r = await fetch(url, { method: method, headers: body === undefined ? {} : { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(sachFbRoot(body)) });
    var t = await r.text();
    if (!r.ok) { var m = t; try { m = JSON.parse(t).error || t; } catch (e) {} throw new Error('Lỗi máy chủ: ' + m); }
    return t ? JSON.parse(t) : null;
  }

  function ru(s) { return String(s == null ? '' : s).toLowerCase().split(' ').filter(function(x) { return x; }).join(' '); }

  async function taiDS() {
    $('tai').disabled = true;
    $('loading').hidden = false;
    $('empty').hidden = true;
    $('hsList').innerHTML = '';
    try {
      var dy = await fb('GET', 'duyet');
      DS = Object.entries(dy || {}).filter(function(p) { return p[1] && typeof p[1] === 'object'; }).map(function(p) {
        var x = p[1];
        return { id: p[0], ten: x.ten || '', cccd: x.cccd || '', ngaySinh: x.ngaySinh || '', tt: x.trangThai || '', xongN: Object.keys(x.xong || {}).length, totalFields: x.totalFields || 0 };
      });
      DS.sort(function(a, b) { return String(a.ten).localeCompare(String(b.ten), 'vi'); });
      veDs();
    } catch (e) {
      $('hsList').innerHTML = '';
      $('empty').hidden = false;
      txt($('empty'), 'Lỗi tải danh sách: ' + e.message);
    }
    $('tai').disabled = false;
    $('loading').hidden = true;
  }

  function veDs() {
    var q = ru($('search').value);
    var box = $('hsList');
    box.innerHTML = '';
    var list = DS.filter(function(d) {
      return !q || ru(d.ten).indexOf(q) >= 0 || ru(d.cccd).indexOf(q) >= 0 || ru(d.id).indexOf(q) >= 0;
    });
    if (!list.length) {
      $('empty').hidden = false;
      txt($('empty'), q ? 'Không tìm thấy hồ sơ nào.' : 'Chưa có hồ sơ nào được rà soát.');
      return;
    }
    $('empty').hidden = true;
    list.forEach(function(d) {
      var o = div('hs-item');
      var b = document.createElement('b');
      txt(b, d.ten || '(chưa có họ tên)');
      var s = document.createElement('small');
      txt(s, 'CCCD: ' + (d.cccd || '—') + (d.ngaySinh ? ' · sinh ' + d.ngaySinh : '') + ' · ' + d.xongN + '/' + TOTAL_FIELDS + (d.tt ? ' · ' + d.tt : ''));
      var acts = div('actions');

      var nutSua = document.createElement('button');
      txt(nutSua, 'Sửa');
      nutSua.onclick = function() { suaHoSo(d.id); };
      acts.append(nutSua);

      var nutXoa = document.createElement('button');
      txt(nutXoa, 'Xóa');
      nutXoa.className = 'nho do';
      nutXoa.onclick = function() { xoaHoSo(d.id); };
      acts.append(nutXoa);
      var nutHienLai = document.createElement('button');
      txt(nutHienLai, d.tt === 'đã lưu' ? 'Hiện lại' : 'Tiếp tục rà soát');
      nutHienLai.onclick = function() { hienLai(d.id); };
      acts.append(nutHienLai);
      o.append(b, s, acts);
      box.append(o);
    });
  }

  async function hienLai(id) {
    if (!CO_CHROME || !chrome.runtime || !chrome.runtime.sendMessage) {
      alert('Tính năng này chỉ hoạt động trong extension Chrome.');
      return;
    }
    try {
      await chrome.runtime.sendMessage({ type: 'open_review_panel', id: id });
      window.close(); // Close this management panel after opening the review panel
    } catch (e) {
      alert('Lỗi mở hồ sơ rà soát: ' + e.message);
    }
  }

  async function xoaHoSo(id) {
    if (!confirm('Bạn có chắc chắn muốn xóa hồ sơ \'' + id + '\' không? Hành động này không thể hoàn tác.')) return;
    try {
      await fb('DELETE', 'duyet/' + encodeURIComponent(id));
      alert('Đã xóa hồ sơ: ' + id);
      taiDS(); // Tải lại danh sách sau khi xóa
    } catch (e) {
      alert('Lỗi xóa hồ sơ: ' + e.message);
    }
  }

  async function suaHoSo(id) {
    var hoSo = DS.find(h => h.id === id);
    if (!hoSo) return;

    var newTen = prompt('Nhập tên mới:', hoSo.ten);
    if (newTen === null) return; // Người dùng bấm Hủy

    var newCccd = prompt('Nhập CCCD mới:', hoSo.cccd);
    if (newCccd === null) return;

    var newNgaySinh = prompt('Nhập Ngày sinh mới:', hoSo.ngaySinh);
    if (newNgaySinh === null) return;

    try {
      await fb('PATCH', 'duyet/' + encodeURIComponent(id), {
        ten: newTen,
        cccd: newCccd,
        ngaySinh: newNgaySinh
      });
      alert('Đã cập nhật hồ sơ: ' + id);
      taiDS(); // Tải lại danh sách sau khi sửa
    } catch (e) {
      alert('Lỗi cập nhật hồ sơ: ' + e.message);
    }
  }

  $('search').oninput = veDs;
  $('tai').onclick = taiDS;
  $('secret').onchange = ghiLuu;
  $('nguoi').onchange = ghiLuu;
  $('donVi').onchange = ghiLuu;

  napLuu();
  taiDS();
})();