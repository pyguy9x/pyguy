// Rà soát B1-B10 không dùng dữ liệu mây: tạo hồ sơ từ trang, đọc/tự điền giá trị, tick từng trường.
(() => {
'use strict';
var $ = function(id) { return document.getElementById(id); };
function txt(el, s) { el.textContent = (s == null ? '' : s); return el; }
function div(cls) { var d = document.createElement('div'); if (cls) d.className = cls; return d; }

var FB_URL = 'https://hung-da4c1-default-rtdb.asia-southeast1.firebasedatabase.app';
var MA_MAC_DINH = 'uPjRMZvtogiFls0X2n71sd5o098RcsPdVfxjPUBm';
var CO_CHROME = (typeof chrome !== 'undefined') && !!(chrome.storage && chrome.storage.local);
function getSecret() { return $('secret').value.trim(); }
function getNguoi() { return $('nguoi').value.trim(); }
function getDonVi() { return $('donVi').value.trim(); }
async function napLuu() {
  try {
    if (CO_CHROME) {
      var o = await chrome.storage.local.get(['rsSecret', 'rsNguoi']);
      $('secret').value = o.rsSecret || MA_MAC_DINH;
      $('nguoi').value = o.rsNguoi || '';
      $('donVi').value = o.rsDonVi || '';
    } else {
      $('secret').value = localStorage.getItem('rsSecret') || MA_MAC_DINH;
      $('nguoi').value = localStorage.getItem('rsNguoi') || '';
      $('donVi').value = localStorage.getItem('rsDonVi') || '';
    }
  } catch (e) { $('secret').value = MA_MAC_DINH; }
}
async function ghiLuu() {
  try {
    if (CO_CHROME) await chrome.storage.local.set({ rsSecret: getSecret(), rsNguoi: getNguoi(), rsDonVi: getDonVi() });
    else { localStorage.setItem('rsSecret', getSecret()); localStorage.setItem('rsNguoi', getNguoi()); localStorage.setItem('rsDonVi', getDonVi()); }
  } catch (e) {}
}

function sachChuoiFb(s) {
  var r = '';
  for (var i = 0; i < s.length; i++) {
    var c = s.charCodeAt(i);
    if (c === 65534 || c === 65535 || c === 127) continue;
    if (c < 32 && c !== 9 && c !== 10 && c !== 13) continue;
    if (c >= 55296 && c <= 57343) {
      var hi = c <= 56319;
      var nx = i + 1 < s.length ? s.charCodeAt(i + 1) : 0;
      var pv = i > 0 ? s.charCodeAt(i - 1) : 0;
      if ((hi && nx >= 56320 && nx <= 57343) || (!hi && pv >= 55296 && pv <= 56319)) { r += s[i]; }
      continue;
    }
    r += s[i];
  }
  return r;
}
function sachKhoaFb(k) { return sachChuoiFb(String(k)).split('.').join('_').split('$').join('_').split('#').join('_').split('[').join('_').split(']').join('_').split('/').join('_') || '_'; }
function sachFb(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'string') return sachChuoiFb(v);
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'boolean') return v;
  if (Array.isArray(v)) return v.map(sachFb);
  if (typeof v === 'object') {
    var o = {};
    for (var k in v) {
      if (!Object.prototype.hasOwnProperty.call(v, k)) continue;
      var x = v[k];
      if (x === undefined) continue;
      o[sachKhoaFb(k)] = sachFb(x);
    }
    return o;
  }
  return String(v);
}
function sachFbRoot(o) {
  if (o === undefined || o === null || typeof o !== 'object' || Array.isArray(o)) return sachFb(o);
  var r = {};
  for (var k in o) {
    if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
    r[k] = sachFb(o[k]);
  }
  return r;
}
async function fb(method, path, body) {
  var secret = getSecret();
  if (!secret) throw new Error('Chưa nhập mã bí mật.');
  var url = FB_URL + '/' + path + '.json?auth=' + encodeURIComponent(secret);
  var r = await fetch(url, { method: method, headers: body === undefined ? {} : { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(sachFbRoot(body)) });
  var t = await r.text();
  if (!r.ok) { var m = t; try { m = JSON.parse(t).error || t; } catch (e) {} throw new Error('Lỗi máy chủ: ' + m); }
  return t ? JSON.parse(t) : null;
}

var DS = [];
var VD = {};
try { if (typeof VI_DU !== 'undefined' && VI_DU) VD = VI_DU; } catch (e) {}
var TOTAL_FIELDS = 0;
try { SECTIONS.forEach(function(s) { TOTAL_FIELDS += s.truong.length; }); } catch (e) {}
var CUR = null;
var henLuu = 0;
function thongBao(t, lop) {
  var tb = $('tb');
  tb.innerHTML = '';
  if (!t) return;
  var d = div('thongbao ' + (lop || 'ok'));
  txt(d, t);
  tb.append(d);
}
function ru(s) { return String(s == null ? '' : s).toLowerCase().split(' ').filter(function(x) { return x; }).join(' '); }

// ---------- Đọc trang tcxdd (hàm tự chứa, chạy trong tab đích) ----------
function docTrangJob() {
  var out = { forms: {}, tables: [], ten: '', cccd: '', ngaySinh: '', firstFormControlName: '' }; // Đã sửa
  function gv(h) { return h ? ((h.value !== undefined && h.value !== '') ? h.value : (h.innerText || '')) : ''; }
  out.cccd = String(gv(document.querySelector('[formcontrolname="identifyNo"]'))).trim();
  out.ten = String(gv(document.querySelector('[formcontrolname="currentFullName"]'))).trim();
  out.ngaySinh = String(gv(document.querySelector('[formcontrolname="birthDate"]'))).trim();
  
  // Lấy formcontrolname của phần tử đầu tiên đang hiển thị
  var allFormControlElements = Array.from(document.querySelectorAll('[formcontrolname]'));
  for (var i = 0; i < allFormControlElements.length; i++) {
    var el = allFormControlElements[i];
    if (el.offsetParent !== null) { // Kiểm tra nếu phần tử hiển thị
      out.firstFormControlName = el.getAttribute('formcontrolname');
      break;
    }
  }

  document.querySelectorAll('[formcontrolname]').forEach(function(h) {
    var k = h.getAttribute('formcontrolname');
    if (!k || out.forms[k] !== undefined) return;
    var v = '';
    var tag = h.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') v = h.value || '';
    else if (tag === 'VTS-SELECT' || h.querySelector('vts-select-top-control')) {
      var t = h.querySelector('vts-select-top-control');
      v = t ? t.innerText.trim() : h.innerText.trim();
      if (v.slice(0, 2) === '--') v = '';
    } else if (h.querySelector('input[type=checkbox]')) {
      v = h.querySelector('input[type=checkbox]').checked ? 'Có' : '';
    } else {
      var lab = h.querySelector('label.vts-radio-wrapper-checked');
      v = lab ? lab.innerText.trim() : h.innerText.trim();
    }
    out.forms[k] = v;
  });
  document.querySelectorAll('table').forEach(function(tb) {
    if (tb.offsetParent === null) return;
    var rows = [];
    tb.querySelectorAll('tr').forEach(function(tr, ri) {
      if (ri > 60) return;
      var cells = [];
      tr.querySelectorAll('th,td').forEach(function(td, ci) {
        if (ci > 12) return;
        var s = td.innerText.trim();
        if (s) cells.push(s);
      });
      if (cells.length) rows.push(cells.join(' | '));
    });
    if (rows.length) out.tables.push(rows);
  });
  return out;
}
async function tabTcxdd() {
  if (!CO_CHROME || !chrome.tabs || !chrome.tabs.query || !chrome.scripting || !chrome.scripting.executeScript) throw new Error('Trang này đang mở ngoài extension. Hãy mở bằng chrome-extension://ID/panel.html');
  var tabs = await chrome.tabs.query({ url: 'https://tcxdd.dcs.vn/*' });
  if (!tabs.length) throw new Error('Chưa mở trang tcxdd.dcs.vn. Hãy mở hồ sơ bên trái.');
  var act = tabs.filter(function(t) { return t.active; })[0] || tabs[0];
  return act.id;
}

// ---------- Danh sách hồ sơ rà soát ----------
async function taiDS() {
  $('tai').disabled = true;
  thongBao('Đang tải danh sách…', 'ok');
  try {
    await ghiLuu();
    var dy = await fb('GET', 'duyet');
    DS = Object.entries(dy || {}).filter(function(p) { return p[1] && typeof p[1] === 'object'; }).map(function(p) {
      var x = p[1];
      return { id: p[0], ten: x.ten || '', cccd: x.cccd || '', ngaySinh: x.ngaySinh || '', tt: x.trangThai || '', xongN: Object.keys(x.xong || {}).length };
    });
    DS.sort(function(a, b) { return String(a.ten).localeCompare(String(b.ten), 'vi'); });
    $('lanTai').textContent = 'Đã tải ' + DS.length + ' hồ sơ lúc ' + new Date().toLocaleTimeString('vi-VN');
    thongBao('Đã tải ' + DS.length + ' hồ sơ.', 'ok');
    veDs();
    try {
      var last = localStorage.getItem('rsLast') || '';
      if (last && DS.filter(function(x) { return x.id === last; }).length) chon(last);
    } catch (e2) {}
  } catch (e) { thongBao('Lỗi: ' + e.message, 'loi'); }
  $('tai').disabled = false;
}
function veDs() {
  var q = ru($('tim').value);
  var box = $('ds');
  box.innerHTML = '';
  var list = DS.filter(function(d) {
    return !q || ru(d.ten).indexOf(q) >= 0 || ru(d.cccd).indexOf(q) >= 0 || ru(d.id).indexOf(q) >= 0;
  });
  if (!list.length) {
    var m = div('mo');
    txt(m, 'Chưa có hồ sơ nào. Mở hồ sơ trên tcxdd rồi bấm Tạo mới từ trang đang mở.');
    box.append(m);
    return;
  }
  list.forEach(function(d) {
    var o = div('hs' + (CUR && CUR.id === d.id ? ' on' : ''));
    var b = document.createElement('b');
    txt(b, d.ten || '(chưa có họ tên)');
    var s = document.createElement('small');
    txt(s, 'CCCD: ' + (d.cccd || '—') + (d.ngaySinh ? ' · sinh ' + d.ngaySinh : '') + ' · ' + d.xongN + '/' + TOTAL_FIELDS + (d.tt ? ' · ' + d.tt : ''));
    o.append(b, s);
    o.onclick = function() { chon(d.id); };
    box.append(o);
  });
}
async function taoMoi() {
  try {
    var tabId = await tabTcxdd();
    var inj = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: docTrangJob });
    var kq = inj && inj[0] && inj[0].result;
    if (!kq || (!kq.ten && !kq.cccd)) throw new Error('Không đọc được họ tên/CCCD trên trang.');
    var cc = String(kq.cccd || '').replace(/[^0-9]/g, '');
    var id = (/^[0-9]{12}$/.test(cc)) ? cc : ('TAM' + Date.now().toString(36).toUpperCase());
    var cu = await fb('GET', 'duyet/' + encodeURIComponent(id)).catch(function() { return null; });
    if (!cu) {
      await fb('PATCH', 'duyet/' + encodeURIComponent(id), { ten: kq.ten, cccd: kq.cccd, ngaySinh: kq.ngaySinh || '', nguoiDuyet: getNguoi() || '', donVi: getDonVi(), trangThai: 'chờ duyệt' });
      thongBao('Đã tạo hồ sơ: ' + (kq.ten || id) + '.', 'ok');
    } else {
      thongBao('Hồ sơ đã có, mở luôn: ' + (kq.ten || id) + '.', 'ok');
    }
    await taiDS();
    chon(id);
  } catch (e) { thongBao('Lỗi: ' + e.message, 'loi'); }
}

// ---------- Mở hồ sơ ----------
async function chon(id) {
  thongBao('Đang tải hồ sơ ' + id + '…', 'ok');
  try {
    var rec = await fb('GET', 'duyet/' + encodeURIComponent(id)).catch(function() { return null; }) || {};
    CUR = { id: id, ten: rec.ten || '', cccd: rec.cccd || '', ngaySinh: rec.ngaySinh || '',
      vals: rec.vals || {}, rows: rec.rows || {}, tick: rec.xong || {}, tt: rec.trangThai || '',
      note: rec.ghiChu || {}, sua: rec.sua || {}, suaHang: rec.suaHang || {}, khoa: !!rec.khoa,
      // Lưu bản gốc để so sánh khi sửa thủ công
      valsGoc: JSON.parse(JSON.stringify(rec.vals || {})),
      rowsGoc: JSON.parse(JSON.stringify(rec.rows || {}))
    };
    $('khuHs').hidden = false;
    txt($('tenHs'), (CUR.ten || '(chưa có họ tên)') + ' · mã ' + id);
    txt($('ttHs'), 'CCCD ' + (CUR.cccd || '—') + (CUR.ngaySinh ? ' · sinh ' + CUR.ngaySinh : '') + (CUR.tt ? ' · ' + CUR.tt : ''));
    thongBao('', '');
    veDs();
    try { localStorage.setItem('rsLast', id); } catch (e) {}
    capKhoa();
    var maMucHienTai = await getMaMucHienTaiTuTrang(); // Đã sửa
    veMucs(maMucHienTai); // Đã sửa
  } catch (e) { thongBao('Lỗi: ' + e.message, 'loi'); }
}

async function getMaMucHienTaiTuTrang() { // Hàm mới
  try {
    var tabId = await tabTcxdd();
    var inj = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: docTrangJob });
    var kq = inj && inj[0] && inj[0].result;
    var firstFormControlName = kq && kq.firstFormControlName;
    if (firstFormControlName) {
      // Tìm xem formcontrolname này thuộc section nào
      for (var i = 0; i < SECTIONS.length; i++) {
        for (var j = 0; j < SECTIONS[i].truong.length; j++) {
          if (SECTIONS[i].truong[j][0] === firstFormControlName) {
            return SECTIONS[i].ma;
          }
        }
      }
    }
  } catch (e) {
    console.error("Lỗi khi lấy mã mục hiện tại từ trang: ", e);
  }
  return null;
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'open_review_panel') {
    chon(msg.id);
  }
});

function khoaTick(ma, k) { return ma + '.' + k; }
var MAU_MUC = { b1: '#b91c1c', qtct: '#1d4ed8', daotao: '#0e7490', huyhieu: '#a16207', khenthuong: '#c026d3', danhgia: '#7c3aed', kyluat: '#be123c', dd: '#4d7c0f', nuocngoai: '#0f766e', qh: '#ea580c', kt: '#15803d', mxh: '#334155', b11: '#64748b' };
function veMucs(maMucHienTai) { // Đã sửa
  var box = $('mucs');
  var moTruoc = {};
  var cuon = 0;
  try {
    box.querySelectorAll('details.muc').forEach(function(d) { if (d.open && d.dataset.ma) moTruoc[d.dataset.ma] = true; });
    cuon = (document.scrollingElement || document.documentElement).scrollTop || 0;
  } catch (e) {}
  box.innerHTML = '';
  if (!CUR) return;
  SECTIONS.forEach(function(sec) {
    var lam = sec.truong.filter(function(t) { return CUR.tick[khoaTick(sec.ma, t[0])]; }).length;
    var det = document.createElement('details');
    det.className = 'muc';
    // Nếu có mã mục hiện tại, chỉ mở mục đó, các mục khác thu gọn
    if (maMucHienTai) { // Đã sửa
      det.open = (sec.ma === maMucHienTai); // Đã sửa
    } else { // Giữ nguyên hành vi cũ nếu không có mã mục hiện tại từ trang
      if (moTruoc[sec.ma] || lam < sec.truong.length) det.open = true;
    }
    var sm = document.createElement('summary');
    txt(sm, sec.so + ' ' + sec.ten + ' (' + lam + '/' + sec.truong.length + ')');
    sm.style.borderLeft = '6px solid ' + (MAU_MUC[sec.ma] || '#b91c1c');
    sm.style.paddingLeft = '6px';
    det.append(sm);
    var bDoc = document.createElement('button');
    bDoc.className = 'doc-trang';
    txt(bDoc, sec.kieu === 'form' ? 'ĐỌC MỤC NÀY TỪ TRANG (chỉ điền ô trống)' : 'ĐỌC BẢNG NÀY TỪ TRANG (thêm dòng mới)');
    bDoc.onclick = function() { docMuc(sec.ma); };
    if (!CUR.khoa) det.append(bDoc);
    if (sec.kieu === 'ds') {
      var rows = CUR.rows[sec.ma] || [];
      rows.forEach(function(txtRow, i) {
        var d = div('dong');
        var nk = sec.ma + '.hang.' + i;
        // Nếu là qtct và đã parse, hiển thị các trường riêng biệt
        if ((sec.ma === 'qtct' && typeof txtRow === 'object' && txtRow.fromDate) || (sec.ma === 'qh' && typeof txtRow === 'object' && txtRow.fullName)) {
          var fields = sec.ma === 'qh' ? [
            { key: 'type', label: 'Ph\u00e2n lo\u1ea1i' },
            { key: 'familyMemberId', label: 'Quan h\u1ec7' },
            { key: 'fullName', label: 'H\u1ecd t\u00ean' },
            { key: 'birthDate', label: 'N\u0103m sinh' },
            { key: 'identifyNo', label: 'CCCD' },
            { key: 'residentPlace', label: 'N\u01a1i \u1edf' },
            { key: 'hometown', label: 'Qu\u00ea qu\u00e1n' }
          ] : [
            { key: 'fromDate', label: 'Từ' },
            { key: 'toDate', label: 'Đến' },
            { key: 'nationId', label: 'Quốc gia' },
            { key: 'companyName', label: 'Tổ chức' },
            { key: 'companyPosition', label: 'Ch\u1ee9c danh' }
          ];
          fields.forEach(function(f) {
            var rowDiv = div('dong');
            var lbl = document.createElement('span');
            lbl.style.cssText = 'font-weight:bold;margin-right:4px;min-width:50px';
            txt(lbl, f.label + ':');
            var val = document.createElement('span');
            val.textContent = txtRow[f.key] || '';
            rowDiv.append(lbl, val);
            d.append(rowDiv);
          });
          // B2: chỉ hiện data parse, không hiện textbox sửa
        } else {
          // Hiển thị cũ cho các bảng khác hoặc chưa parse
          var inp = document.createElement('input');
          inp.style.width = '100%';
          inp.value = typeof txtRow === 'string' ? txtRow : JSON.stringify(txtRow);
          inp.placeholder = 'Dòng ' + (i + 1) + ' — sửa trực tiếp';
          inp.disabled = !!CUR.khoa;
          inp.onchange = function() {
            CUR.rows[sec.ma][i] = inp.value;
            CUR.suaHang[sec.ma] = CUR.suaHang[sec.ma] || {};
            CUR.suaHang[sec.ma][i] = 1;
            luuTick();
          };
          d.append(inp);
        }
        if ((CUR.suaHang[sec.ma] || {})[i]) {
          var ch = document.createElement('span');
          ch.style.cssText = 'display:inline-block;background:#ede9fe;color:#5b21b6;font-size:11px;border-radius:8px;padding:0 6px;margin-left:6px';
          txt(ch, 'Đã sửa thủ công');
          d.append(ch);
        }
        var gn = document.createElement('input');
        gn.style.width = '100%';
        gn.style.marginTop = '3px';
        gn.value = (CUR.note || {})[nk] || '';
        gn.placeholder = 'Ghi chú dòng này…';
        gn.disabled = !!CUR.khoa;
        gn.onchange = function() {
          var v = gn.value.trim();
          if (v) CUR.note[nk] = v; else delete CUR.note[nk];
          luuTick();
        };
        d.append(gn);
        det.append(d);
      });
      // Da bo nut Them/Xoa dong theo yeu cau
    }
    sec.truong.forEach(function(t) {
      var k = t[0], kk = khoaTick(sec.ma, k);
      var da = !!CUR.tick[kk];
      var f = div('f' + (da ? ' da' : ''));
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.checked = da; cb.disabled = !!CUR.khoa; cb.dataset.kk = kk;
      cb.onchange = function() { datTick(kk, cb.checked); f.className = 'f' + (cb.checked ? ' da' : ''); capDem(); };
      var nh = div('nhan');
      var lb = document.createElement('b');
      var bb = (sec.bb || []).indexOf(k) >= 0;
      txt(lb, t[1] + (bb ? ' *' : ''));
      if (bb) lb.className = 'bb';
      nh.append(lb);
      if (VD[k]) {
        var vd = document.createElement('div');
        vd.style.cssText = 'background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;font-size:11px;border-radius:8px;padding:3px 8px;margin:3px 0';
        txt(vd, VD[k]);
        nh.append(vd);
      }
      if (CUR.sua[kk]) {
        var chip = document.createElement('span');
        chip.style.cssText = 'display:inline-block;background:#ede9fe;color:#5b21b6;font-size:11px;border-radius:8px;padding:0 6px;margin-left:6px';
        txt(chip, 'Đã sửa thủ công');
        nh.append(chip);
      }
      if (sec.kieu === 'form') {
        var valGoc = CUR.valsGoc[kk] || '';
        if (valGoc) { // Đã sửa
          var divGoc = document.createElement('div');
          divGoc.style.cssText = 'background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;font-size:11px;border-radius:8px;padding:3px 8px;margin:3px 0';
          txt(divGoc, 'Gốc trên trang: ' + valGoc);
          nh.append(divGoc);
        }
        var inp = document.createElement('input');
        inp.style.width = '100%';
        inp.style.marginTop = '3px';
        inp.value = CUR.vals[kk] || '';
        inp.placeholder = (valGoc && CUR.vals[kk] && (valGoc !== CUR.vals[kk])) ? 'Dữ liệu mà bạn đã sửa khác với dữ liệu gốc' : 'Tự điền giá trị…';
        inp.disabled = !!CUR.khoa;
        inp.onchange = function() {
          CUR.vals[kk] = inp.value;
          CUR.sua[kk] = { nguoi: getNguoi() || '?', donVi: getDonVi(), luc: new Date().toLocaleString('vi-VN') };
          luuTick();
          if (!nh.querySelector('.chip-sua')) {
            var c2 = document.createElement('span');
            c2.className = 'chip-sua';
            c2.style.cssText = 'display:inline-block;background:#ede9fe;color:#5b21b6;font-size:11px;border-radius:8px;padding:0 6px;margin-left:6px';
            txt(c2, 'Đã sửa thủ công');
            nh.append(c2);
          }
          inp.placeholder = (valGoc && CUR.vals[kk] && (valGoc !== CUR.vals[kk])) ? 'Dữ liệu mà bạn đã sửa khác với dữ liệu gốc' : 'Tự điền giá trị…';
        };
        nh.append(inp);
      }
      var ghi = document.createElement('input');
      ghi.style.width = '100%';
      ghi.style.marginTop = '3px';
      ghi.value = (CUR.note || {})[kk] || '';
      ghi.placeholder = 'Ghi chú rà soát… (VD: đã sửa ngày sinh từ AAA sang BBB)';
      ghi.disabled = !!CUR.khoa;
      ghi.onchange = function() {
        var v = ghi.value.trim();
        if (v) CUR.note[kk] = v; else delete CUR.note[kk];
        luuTick();
      };
      nh.append(ghi);
      f.dataset.kk = kk;
      f.append(cb, nh);
      det.append(f);
    });
    var nutChonTatCa = document.createElement('button');
    nutChonTatCa.className = 'chinh nho';
    nutChonTatCa.style.marginTop = '10px';
    txt(nutChonTatCa, 'Chọn tất cả các trường trong ' + sec.so);
    nutChonTatCa.onclick = function() {
      if (CUR.khoa) return;
      if (!confirm('Bạn chịu trách nhiệm với những gì đã rà soát trong ' + sec.so + ' rồi chứ? (Tất cả các trường trong mục này sẽ được đánh dấu đã rà soát và mục sẽ được thu gọn.)')) return;
      det.querySelectorAll('.f input[type=checkbox]').forEach(function(c) {
        if (!c.disabled && !c.checked) {
          c.checked = true;
          datTick(c.dataset.kk, true);
          c.closest('.f').className = 'f da';
        }
      });
      capDem();
      det.open = false; // Thu gọn mục sau khi chọn tất cả
    };
    if (!CUR.khoa) det.append(nutChonTatCa);
    det.dataset.ma = sec.ma;
    box.append(det);
  });
  var b11 = document.createElement('details');
  b11.className = 'muc';
  b11.dataset.ma = 'b11';
  if (moTruoc.b11) b11.open = true;
  var s11 = document.createElement('summary');
  txt(s11, 'B11 Quá trình sinh hoạt Đảng (hệ thống tự ghi — không cần duyệt)');
  s11.style.borderLeft = '6px solid ' + MAU_MUC.b11;
  s11.style.paddingLeft = '6px';
  b11.append(s11);
  box.append(b11);
  capDem();
  try { (document.scrollingElement || document.documentElement).scrollTop = cuon; } catch (e) {}
}
function veMucDong(ma) {
  veMucs();
  var box = $('mucs');
  for (var i = 0; i < box.children.length; i++) {
    var d = box.children[i];
    if (d.dataset && d.dataset.ma === ma) { d.open = true; if (d.scrollIntoView) d.scrollIntoView({ block: 'start' }); break; }
  }
}
function secCua(ma) { return SECTIONS.filter(function(s) { return s.ma === ma; })[0]; }
function tickHopLe(kk) {
  var p = String(kk || '').split('.');
  if (p.length < 2) return false;
  var sec = secCua(p[0]);
  if (!sec) return false;
  var field = p.slice(1).join('.');
  if (p[1] === 'hang') return false;
  return sec.truong.some(function(t) { return t[0] === field; });
}
function phanLoaiTick() {
  var hopLe = [], la = [];
  Object.keys((CUR && CUR.tick) || {}).forEach(function(kk) { (tickHopLe(kk) ? hopLe : la).push(kk); });
  return { hopLe: hopLe, la: la };
}

// ---------- Đọc mục từ trang ----------
function parseQtctRow(rowStr) {
  var parts = String(rowStr).split('|').map(function(x) { return x.trim(); });
  if (parts.length < 4) return null;
  if (!/^\d+$/.test(parts[0])) return null;
  var tg = parts[1] || '';
  if (!/\d/.test(tg)) return null;
  var tt = tg.split('-');
  var fromDate = (tt[0] || '').trim();
  var toDate = tt.length > 1 ? tt.slice(1).join('-').trim() : '';
  if (!fromDate) return null;
  var companyPosition = parts[2] || '';
  var companyName = parts[3] || '';
  var nationId = parts.length >= 5 ? (parts[4] || '') : '';
  if (!companyPosition && !companyName) return null;
  return {
    fromDate: fromDate,
    toDate: toDate,
    nationId: nationId || 'Vi\u1ec7t Nam',
    companyName: companyName,
    partyPositionIds: '',
    concurrentPartyPosition: '',
    companyPosition: companyPosition,
    note: ''
  };
}function parseQhRow(rowStr) {
  var parts = String(rowStr).split('|').map(function(x) { return x.trim(); });
  if (parts.length < 4) return null;
  if (!/^\d+$/.test(parts[0])) return null;
  var fullName = parts[3] || '';
  if (!fullName) return null;
  var birthDate = parts[4] || '';
  if (birthDate && !/\d/.test(birthDate)) return null;
  var residentPlace = parts.slice(5).join(' | ');
  if (!parts[1] && !parts[2] && !residentPlace) return null;
  return {
    type: parts[1] || '',
    familyMemberId: parts[2] || '',
    isPartyMember: '',
    fullName: fullName,
    identifyNo: '',
    birthDate: birthDate,
    currentStatus: '',
    finishedYear: '',
    currentJob: '',
    nationalityId: '',
    nationId: '',
    residentPlace: residentPlace,
    hometown: '',
    note: ''
  };
}
async function docQhChiTietJob() {
  function chuan(x) { return String(x == null ? '' : x).toLowerCase().trim(); }
  function sleep(ms) { return new Promise(function(rs) { setTimeout(rs, ms); }); }
  function q(s2, r) { return (r || document).querySelector(s2); }
  function qa(s2, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s2)); }
  function formMo() { return !!q('[formcontrolname="familyMemberId"]'); }
  function docForm() {
    var out = {};
    qa('[formcontrolname]').forEach(function(h) {
      var k = h.getAttribute('formcontrolname');
      if (!k || out[k] !== undefined) return;
      var v = '';
      var tag = h.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') v = h.value || '';
      else if (tag === 'VTS-SELECT' || h.querySelector('vts-select-top-control')) {
        var t = h.querySelector('vts-select-top-control');
        v = t ? t.innerText.trim() : h.innerText.trim();
        if (v.slice(0, 2) === '--') v = '';
      } else if (h.querySelector('input[type=checkbox]')) {
        v = h.querySelector('input[type=checkbox]').checked ? 'Có' : '';
      } else {
        var lab = h.querySelector('label.vts-radio-wrapper-checked');
        v = lab ? lab.innerText.trim() : h.innerText.trim();
      }
      out[k] = v;
    });
    return out;
  }
  function nut(re) {
    var bs = qa('button').filter(function(b) { return b.offsetParent !== null; });
    for (var i = 0; i < bs.length; i++) { if (re.test(chuan(bs[i].innerText))) return bs[i]; }
    return null;
  }
  async function cho(fn, ms) {
    var t0 = Date.now();
    while (Date.now() - t0 < ms) {
      var v = null;
      try { v = fn(); } catch (e) {}
      if (v) return v;
      await sleep(250);
    }
    return null;
  }
  async function dongForm() {
    var d = nut(/^đóng$/);
    if (d) d.click();
    await sleep(600);
    var th = nut(/^thoát$/);
    if (th) th.click();
    await cho(function() { return !formMo(); }, 3000);
  }
  if (formMo()) return { loi: 'FORM_OPEN' };
  var tables = qa('table').filter(function(tb) {
    if (!tb.offsetParent) return false;
    var hs = qa('thead th', tb).map(function(x) { return chuan(x.innerText); });
    return hs.some(function(h) { return h.indexOf('quan hệ') >= 0; }) && hs.some(function(h) { return h.indexOf('họ và tên') >= 0; });
  });
  if (!tables.length) return { loi: 'NO_TABLE' };
  var trs = qa('tbody tr', tables[0]).filter(function(tr) { return tr.children.length > 3; }).slice(0, 60);
  var out = [];
  for (var i = 0; i < trs.length; i++) {
    var tr = trs[i];
    var label = '';
    try { label = tr.innerText.replace(/\s+/g, ' ').trim().slice(0, 120); } catch (e2) {}
    var last = tr.lastElementChild;
    var btns = last ? qa('button', last) : [];
    if (!btns.length) { out.push({ label: label, vals: null }); continue; }
    btns[0].click();
    var mo = await cho(formMo, 8000);
    if (!mo) { out.push({ label: label, vals: null }); continue; }
    await sleep(700);
    var vals = docForm();
    await dongForm();
    out.push({ label: label, vals: vals });
  }
  return { rows: out };
}
async function docMucQh(sec) {
  if (!CUR || CUR.khoa) return;
  try {
    thongBao('Đang đọc chi tiết từng dòng B8 từ trang (chỉ đọc, không sửa gì trên trang)...', 'ok');
    var tabId = await tabTcxdd();
    var inj = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: docQhChiTietJob });
    var kq = inj && inj[0] && inj[0].result;
    if (!kq) throw new Error('Không đọc được nội dung trang.');
    if (kq.loi === 'FORM_OPEN') throw new Error('Đang mở 1 biểu mẫu trên trang. Bấm Đóng/Lưu trên trang rồi đọc lại.');
    if (kq.loi === 'NO_TABLE') throw new Error('Chưa thấy bảng Quan hệ gia đình. Mở mục B8 trên trang.');
    CUR.rows.qh = (CUR.rows.qh || []).filter(function(r) { return r && typeof r === 'object' && !!r.fullName; });
    var them = 0, hong = 0;
    (kq.rows || []).forEach(function(o) {
      var v = (o && o.vals) || {};
      function g(k) { return String(v[k] == null ? '' : v[k]).trim(); }
      var ten = g('fullName');
      if (!ten) { hong++; return; }
      var parsed = { type: g('type'), familyMemberId: g('familyMemberId'), isPartyMember: g('isPartyMember'), fullName: ten, identifyNo: g('identifyNo'), birthDate: g('birthDate'), currentStatus: g('currentStatus'), finishedYear: g('finishedYear'), currentJob: g('currentJob'), nationalityId: g('nationalityId'), nationId: g('nationId'), residentPlace: g('residentPlace'), hometown: g('hometown'), note: g('note') };
      var ei = -1;
      CUR.rows.qh.forEach(function(row, i) {
        if (row && row.fullName === parsed.fullName && String(row.birthDate || '') === String(parsed.birthDate || '')) ei = i;
      });
      if (ei >= 0) CUR.rows.qh[ei] = parsed; else CUR.rows.qh.push(parsed);
      them++;
    });
    luuTick();
    veMucDong('qh');
    thongBao('Đã đọc B8: ' + them + ' dòng đủ 14 trường' + (hong ? ', ' + hong + ' dòng lỗi/bỏ qua' : '') + ' (trang hiện tại).', 'ok');
  } catch (e) { thongBao('Lỗi đọc B8: ' + e.message, 'loi'); }
}
async function docMuc(ma) {
  var sec = secCua(ma);
  if (!sec || !CUR || CUR.khoa) return;
  if (ma === 'qh') { docMucQh(sec); return; }
  try {
    thongBao('Đang đọc ' + sec.so + ' ' + sec.ten + ' từ trang…', 'ok');
    var tabId = await tabTcxdd();
    var inj = await chrome.scripting.executeScript({ target: { tabId: tabId }, func: docTrangJob });
    var dump = inj && inj[0] && inj[0].result;
    if (!dump) throw new Error('Không đọc được nội dung trang.');
    var them = 0;
    if (sec.kieu === 'form') {
      sec.truong.forEach(function(t) {
        var kk = khoaTick(sec.ma, t[0]);
        var v = String((dump.forms || {})[t[0]] || '').trim();
        if (v && !String(CUR.vals[kk] || '').trim()) { CUR.vals[kk] = v; them++; }
      });
    } else {
      CUR.rows[sec.ma] = CUR.rows[sec.ma] || [];
      if (sec.ma === 'qtct' || sec.ma === 'qh') { CUR.rows[sec.ma] = (CUR.rows[sec.ma] || []).filter(function(r) { return r && typeof r === 'object' && (sec.ma === 'qh' ? !!r.fullName : (/\d/.test(String(r.fromDate || '')) && (r.companyName || r.companyPosition))); }); }
      (dump.tables || []).forEach(function(rows) {
        rows.forEach(function(r) {
          var rowStr = String(r).trim();
          if (!rowStr) return;
          var parsed = null;
          if (sec.ma === 'qtct' && rowStr.indexOf('|') >= 0) {
            parsed = parseQtctRow(rowStr);
          } else if (sec.ma === 'qh' && rowStr.indexOf('|') >= 0) {
            parsed = parseQhRow(rowStr);
          }
          if (parsed) {
            var existingIdx = -1;
            CUR.rows[sec.ma].forEach(function(row, i) {
              if (sec.ma === 'qh' ? (row.fullName && row.fullName === parsed.fullName && String(row.birthDate || '') === String(parsed.birthDate || '')) : (row.fromDate === parsed.fromDate && row.companyName === parsed.companyName)) existingIdx = i;
            });
            if (existingIdx >= 0) {
              CUR.rows[sec.ma][existingIdx] = parsed;
            } else {
              CUR.rows[sec.ma].push(parsed);
            }
            them++;
          } else if (sec.ma !== 'qtct' && sec.ma !== 'qh' && r && CUR.rows[sec.ma].indexOf(r) < 0) {
            CUR.rows[sec.ma].push(r);
            them++;
          }
        });
      });
    }
    luuTick();
    veMucDong(ma);
    thongBao('Đã đọc ' + sec.so + ': thêm ' + them + ' giá trị/dòng mới (không ghi đè). Mở mục "' + sec.ten + '" rồi Đọc mục này từ trang.', 'ok');
  } catch (e) { thongBao('Lỗi đọc trang: ' + e.message, 'loi'); }
}

// ---------- Tick + lưu ----------
function capDem() {
  if (!CUR) return;
  var tong = 0, xong = 0;
  SECTIONS.forEach(function(sec) {
    sec.truong.forEach(function(t) {
      tong++;
      if (CUR.tick[khoaTick(sec.ma, t[0])]) xong++;
    });
  });
  txt($('demTick'), 'Đã tick ' + xong + '/' + tong + ' trường');
  $('tienDo').style.width = (tong ? Math.round(xong / tong * 100) : 0) + '%';
  var sums = $('mucs').querySelectorAll('details.muc > summary');
  SECTIONS.forEach(function(sec, i) {
    if (!sums[i]) return;
    var lam = sec.truong.filter(function(t) { return CUR.tick[khoaTick(sec.ma, t[0])]; }).length;
    txt(sums[i], sec.so + ' ' + sec.ten + ' (' + lam + '/' + sec.truong.length + ')');
  });
}
function datTick(kk, v) {
  if (!CUR || CUR.khoa) return;
  if (v) CUR.tick[kk] = { nguoi: getNguoi() || '?', donVi: getDonVi(), luc: new Date().toLocaleString('vi-VN') };
  else delete CUR.tick[kk];
  capDem();
  if (henLuu) clearTimeout(henLuu);
  henLuu = setTimeout(luuTick, 800);
}
async function luuTick() {
  if (!CUR) return;
  try {
    await fb('PATCH', 'duyet/' + encodeURIComponent(CUR.id), {
      ten: CUR.ten, cccd: CUR.cccd, ngaySinh: CUR.ngaySinh || '', capNhat: new Date().toISOString(),
      nguoiDuyet: getNguoi() || '', vals: CUR.vals, rows: CUR.rows, xong: CUR.tick,
      donVi: getDonVi(), ghiChu: CUR.note, sua: CUR.sua, suaHang: CUR.suaHang, totalFields: TOTAL_FIELDS,
      trangThai: CUR.tt || 'đang duyệt'
    });
    if (!CUR.tt) { CUR.tt = 'đang duyệt'; }
    var ds = DS.filter(function(x) { return x.id === CUR.id; })[0];
    if (ds) { try { ds.xongN = Object.keys(CUR.tick || {}).filter(tickHopLe).length; } catch (e2) { ds.xongN = Object.keys(CUR.tick || {}).length; } }
    veDs();
  } catch (e) { thongBao('Chưa lưu được: ' + e.message, 'loi'); }
}
async function datTrangThai(tt) {
  if (!CUR) return;
  try {
    await fb('PATCH', 'duyet/' + encodeURIComponent(CUR.id), {
      ten: CUR.ten, cccd: CUR.cccd, ngaySinh: CUR.ngaySinh || '', trangThai: tt,
      nguoiDuyet: getNguoi() || '', donVi: getDonVi(), duyetLuc: new Date().toLocaleString('vi-VN')
    });
    CUR.tt = tt;
    var ds = DS.filter(function(x) { return x.id === CUR.id; })[0];
    if (ds) ds.tt = tt;
    txt($('ttHs'), 'CCCD ' + (CUR.cccd || '—') + (CUR.ngaySinh ? ' · sinh ' + CUR.ngaySinh : '') + ' · ' + tt);
    veDs();
    thongBao(tt === 'đã duyệt' ? 'Đã đánh dấu duyệt xong hồ sơ này.' : 'Đã mở lại hồ sơ để duyệt tiếp.', 'ok');
  } catch (e) { thongBao('Lỗi: ' + e.message, 'loi'); }
}

$('tai').onclick = taiDS;
$('tim').oninput = veDs;
$('taoMoi').onclick = taoMoi;
$('secret').onchange = ghiLuu;
$('nguoi').onchange = ghiLuu;
$('donVi').onchange = ghiLuu;
$('xong').onclick = function() { datTrangThai('đã duyệt'); };
$('moLai').onclick = function() { datTrangThai('chờ duyệt'); };
$('nhanh').onclick = raSoatNhanh;
function raSoatNhanh() {
  if (!CUR) return;
  var box = $('mucs');
  Array.prototype.forEach.call(box.querySelectorAll('.f.thieu'), function(e) { e.classList.remove('thieu'); });
  Array.prototype.forEach.call(box.querySelectorAll('details.thieu-muc'), function(e) { e.classList.remove('thieu-muc'); });
  var dem = 0, dau = null;
  SECTIONS.forEach(function(sec) {
    var rows = sec.kieu === 'ds' ? (CUR.rows[sec.ma] || []) : [];
    var loiMuc = false;
    sec.truong.forEach(function(t) {
      var bb = (sec.bb || []).indexOf(t[0]) >= 0;
      var trong = sec.kieu === 'form' ? !String(CUR.vals[khoaTick(sec.ma, t[0])] || '').trim() : !rows.length;
      if (bb || trong) {
        dem++;
        loiMuc = true;
        var el = box.querySelector('.f[data-kk="' + sec.ma + '.' + t[0] + '"]');
        if (el) { el.classList.add('thieu'); if (!dau) dau = el; }
      }
    });
    if (loiMuc) {
      var det = null;
      Array.prototype.forEach.call(box.children, function(d) { if (d.dataset && d.dataset.ma === sec.ma) det = d; });
      if (det) { det.classList.add('thieu-muc'); det.open = true; }
    }
  });
  thongBao(dem ? ('Còn ' + dem + ' trường bắt buộc/thiếu thông tin (đánh dấu đỏ).') : 'Xong: không còn trường bắt buộc/thiếu.', dem ? 'loi' : 'ok');
  if (dau && dau.scrollIntoView) dau.scrollIntoView({ block: 'center' });
}
$('luuKhoa').onclick = luuKhoa;
function capKhoa() {
  var k = !!(CUR && CUR.khoa);
  $('khoaBao').hidden = !k;
  $('luuKhoa').style.display = k ? 'none' : '';
  $('xong').style.display = k ? 'none' : '';
  $('moLai').style.display = k ? 'none' : '';
}
async function luuKhoa() {
  if (!CUR || CUR.khoa) return;
  moPopupLuu();
}
function nhanDong(kk) {
  var p = kk.split('.');
  var sec = secCua(p[0]);
  if (!sec) return kk;
  if (p.length > 2 && p[1] === 'hang') return sec.so + ' – Dòng ' + (Number(p[2]) + 1);
  var t = sec.truong.filter(function(x) { return x[0] === p.slice(1).join('.'); })[0];
  return sec.so + ' – ' + (t ? t[1] : p.slice(1).join('.'));
}
function moPopupLuu() {
  dongPopupLuu();
  var ov = document.createElement('div');
  ov.id = 'popupLuu';
  ov.style.cssText = 'position:fixed;inset:0;z-index:2147483002;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:12px';
  var hop = document.createElement('div');
  hop.style.cssText = 'background:#fff;border-radius:10px;max-width:520px;width:100%;max-height:85vh;display:flex;flex-direction:column';
  var td = document.createElement('div');
  td.style.cssText = 'padding:10px 14px;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:15px';
  txt(td, 'Xác nhận lưu hồ sơ rà soát');
  var nd = document.createElement('div');
  nd.style.cssText = 'padding:10px 14px;overflow:auto';
  var pl = phanLoaiTick();
  var ticks = pl.hopLe;
  var ticksLa = pl.la;
  var h1 = document.createElement('b');
  txt(h1, 'Đã tick (' + ticks.length + '/' + TOTAL_FIELDS + ')');
  if (ticksLa.length) { var hLa = document.createElement('div'); hLa.style.cssText = 'color:#b91c1c;font-size:12px;margin:4px 0'; txt(hLa, 'Tick lạ/bỏ qua (' + ticksLa.length + '): ' + ticksLa.slice(0, 12).join(', ') + (ticksLa.length > 12 ? '…' : '') + ' — sẽ xóa khi lưu.'); nd.append(hLa); }
  nd.append(h1);
  if (!ticks.length) { var em1 = div('mo'); txt(em1, 'Chưa tick trường nào.'); nd.append(em1); }
  ticks.forEach(function(kk) {
    var d = div('dong');
    var sec = secCua(kk.split('.')[0]);
    var gt = (sec && sec.kieu === 'form') ? String(CUR.vals[kk] || '') : '';
    txt(d, '✓ ' + nhanDong(kk) + (gt ? ': ' + gt : ''));
    nd.append(d);
  });
  var suaKeys = Object.keys(CUR.sua || {});
  var suaHangN = 0;
  Object.keys(CUR.suaHang || {}).forEach(function(m) { suaHangN += Object.keys(CUR.suaHang[m] || {}).length; });
  var h2 = document.createElement('b');
  txt(h2, 'Sửa thủ công (' + (suaKeys.length + suaHangN) + ')');
  nd.append(h2);
  if (!suaKeys.length && !suaHangN) { var em2 = div('mo'); txt(em2, 'Không có.'); nd.append(em2); }
  suaKeys.forEach(function(kk) {
    var d = div('dong');
    var valGoc = CUR.valsGoc[kk] || '';
    var valSua = CUR.vals[kk] || '';
    if (valGoc !== valSua) {
      txt(d, '✎ ' + nhanDong(kk) + ': Gốc: "' + valGoc + '" → Sửa: "' + valSua + '"');
    } else {
      txt(d, '✎ ' + nhanDong(kk) + ': ' + valSua);
    }
    nd.append(d);
  });
  Object.keys(CUR.suaHang || {}).forEach(function(m) {
    Object.keys(CUR.suaHang[m] || {}).forEach(function(i) {
      var d = div('dong');
      var sec = secCua(m);
      var valGoc = (CUR.rowsGoc[m] || [])[i] || '';
      var valSua = (CUR.rows[m] || [])[i] || '';
      if (valGoc !== valSua) {
        txt(d, '✎ ' + (sec ? sec.so + ' – Dòng ' + (Number(i) + 1) : m + ' dòng ' + i) + ': Gốc: "' + valGoc + '" → Sửa: "' + valSua + '"');
      } else {
        txt(d, '✎ ' + (sec ? sec.so + ' – Dòng ' + (Number(i) + 1) : m + ' dòng ' + i) + ': ' + valSua);
      }
      nd.append(d);
    });
  });
  var hg = div('mo');
  txt(hg, 'Ghi chú: ' + Object.keys(CUR.note || {}).length + ' mục. Sau khi lưu sẽ KHÓA, không sửa được nữa.');
  nd.append(hg);
  var nut = document.createElement('div');
  nut.style.cssText = 'padding:10px 14px;border-top:1px solid #e5e7eb;display:flex;gap:8px;justify-content:flex-end';
  var bHuy = document.createElement('button');
  txt(bHuy, 'Hủy');
  bHuy.onclick = dongPopupLuu;
  var bOk = document.createElement('button');
  bOk.className = 'chinh';
  txt(bOk, 'Xác nhận lưu (khóa)');
  bOk.onclick = xacNhanLuu;
  nut.append(bHuy, bOk);
  hop.append(td, nd, nut);
  ov.append(hop);
  ov.onclick = function(e) { if (e.target === ov) dongPopupLuu(); };
  document.body.append(ov);
}
function dongPopupLuu() {
  var ov = document.getElementById('popupLuu');
  if (ov) ov.remove();
}
async function xacNhanLuu() {
  if (!CUR || CUR.khoa) { dongPopupLuu(); return; }
  try {
    Object.keys(CUR.tick || {}).forEach(function(kk) { if (!tickHopLe(kk)) delete CUR.tick[kk]; });
    await fb('PATCH', 'duyet/' + encodeURIComponent(CUR.id), {
      ten: CUR.ten, cccd: CUR.cccd, ngaySinh: CUR.ngaySinh || '', capNhat: new Date().toISOString(),
      nguoiDuyet: getNguoi() || '', donVi: getDonVi(), vals: CUR.vals, rows: CUR.rows, xong: CUR.tick,
      ghiChu: CUR.note, sua: CUR.sua, suaHang: CUR.suaHang, totalFields: TOTAL_FIELDS,
      trangThai: 'đã lưu', khoa: true
    });
    CUR.khoa = true;
    CUR.tt = 'đã lưu';
    dongPopupLuu();
    capKhoa();
    veMucs();
    thongBao('Đã lưu và khóa hồ sơ rà soát. Không sửa được nữa.', 'ok');
  } catch (e) { thongBao('Lỗi: ' + e.message, 'loi'); }
}
napLuu();
taiDS();
var lastTuanTu = null;
function nutTuanTu(dir) {
  if (!CUR || CUR.khoa) return;
  var all = Array.prototype.slice.call(document.querySelectorAll('#mucs .f input[type=checkbox]')).filter(function(c) { return !c.disabled; });
  if (!all.length) return;
  function vis(c) { return c.offsetParent !== null; }
  function bam(cb, v) {
    var kk = cb.dataset.kk;
    if (!kk) return;
    cb.checked = v;
    datTick(kk, v);
    var f = cb.closest('.f');
    if (f) f.className = 'f' + (v ? ' da' : '');
    capDem();
  }
  function toiBox(b) {
    var f = b ? b.closest('.f') : null;
    if (!f) return;
    var det = f.closest('details.muc');
    if (det && !det.open) det.open = true;
    try { f.setAttribute('tabindex', '-1'); } catch (e0) {}
    f.focus();
    if (f.scrollIntoView) f.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function onScr(el) {
    if (!el || !vis(el)) return false;
    var r = null;
    try { r = el.getBoundingClientRect(); } catch (e3) { return false; }
    var h = window.innerHeight || 800;
    return !!r && r.top >= 0 && r.top <= h;
  }
  var idx = -1, neo = false, k0 = -1;
  (function () {
    var ae = document.activeElement;
    if (!ae || ae.tagName !== 'INPUT' || ae.type !== 'checkbox') return;
    var ai = all.indexOf(ae);
    if (ai >= 0 && onScr(ae)) idx = ai;
  })();
  var kk, rk;
  for (kk = 0; kk < all.length; kk++) {
    if (!vis(all[kk])) continue;
    rk = null;
    try { rk = all[kk].getBoundingClientRect(); } catch (e4) { continue; }
    if (rk && rk.top >= 120) { k0 = kk; break; }
  }
  if (idx < 0 && lastTuanTu) {
    var li = all.indexOf(lastTuanTu);
    if (li >= 0 && onScr(all[li])) idx = li;
  }
  if (idx < 0 && k0 >= 0) { idx = k0 - 1; neo = true; }
  var target = -1, k;
  if (dir > 0) {
    var s = idx < 0 ? 0 : idx + 1;
    for (k = s; k < all.length; k++) { if (vis(all[k]) && !all[k].checked) { target = k; break; } }
    if (target < 0) { for (k = s; k < all.length; k++) { if (!vis(all[k]) && !all[k].checked) { target = k; break; } } }
  } else {
    var s2 = idx < 0 ? (neo ? -1 : all.length - 1) : Math.min(idx, all.length - 1);
    for (k = s2; k >= 0; k--) { if (vis(all[k]) && all[k].checked) { target = k; break; } }
    if (target < 0) { for (k = s2; k >= 0; k--) { if (!vis(all[k]) && all[k].checked) { target = k; break; } } }
  }
  if (target >= 0) { bam(all[target], dir > 0); lastTuanTu = all[target]; toiBox(all[target]); }
}
document.addEventListener('keydown', function(e) {
  var plus = (e.code === 'NumpadAdd' || e.key === '+');
  var minus = (e.code === 'NumpadSubtract' || e.key === '-');
  if (!plus && !minus) return;
  var t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
  e.preventDefault();
  nutTuanTu(plus ? 1 : -1);
});
})();