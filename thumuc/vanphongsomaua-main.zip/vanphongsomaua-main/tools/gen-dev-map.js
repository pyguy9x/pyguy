/* tools/gen-dev-map.js — regen js/dev-map.js (auto, khong sua tay).
 * Chay: node tools/gen-dev-map.js
 * Quet: js/legacy.js (SECTION_MAP) + js/store.js + js/modules/*.js + js/main.js (MODULE_MAP),
 *       QUICK_GREP tro file/dong moi cho ham da tach.
 * Line chinh xac bang scan brace-balance (xu ly string/comment/regex), tuong duong ast-bro digest
 * (ast-bro CLI khong co binary win32).
 */
const fs = require('fs');
const vm = require('vm');

const FILES = {
  legacy: 'js/legacy.js',
  store: 'js/store.js',
  utils: 'js/modules/utils.js',
  auth: 'js/modules/auth.js',
  ttbtv: 'js/modules/ttbtv.js',
  provbch: 'js/modules/prov-bch.js',
  ppmttq: 'js/modules/pp-mttq.js',
  main: 'js/main.js',
  config: 'js/config.js',
};
const QUICK_KEYS = ['saveEditTask', 'mergeDepartmentAndOffice', 'renderOfficeDrillRows', 'homeFilteredTasks', 'renderBCHTable', 'renderBCHDrill', 'uploadBCHTaskFile', 'resetBCHFilters', 'renderTTBTVTable', 'renderPROVDrill', 'renderPROVTable', 'loadMTTQKPIData', 'provincePlanLoad', 'applyTokenMultiScope', 'userCan', '_obfToken', 'initAuth', 'loadData'];

function isWord(c) { return /[A-Za-z0-9_$]/.test(c || ''); }
function skipRe(l, j) {
  let k = j + 1, inCls = false;
  for (; k < l.length; k++) {
    const c = l[k];
    if (c === '\\') { k++; continue; }
    if (c === '[') inCls = true;
    else if (c === ']') inCls = false;
    else if (c === '/' && !inCls) return k;
  }
  return j;
}
// end body cua ham bat dau tai startIdx (0-based), tra {line, col} cua '}' dong
function endOf(lines, startIdx, fromCol) {
  let i = startIdx, j = fromCol, inSL = false, inML = false, q = null;
  let paren = 0, seenParen = false, bodyFound = false, depth = 0;
  let prevSig = null, lastWord = '';
  for (; i < lines.length; i++) {
    const l = lines[i];
    for (; j < l.length; j++) {
      const c = l[j], n = l[j + 1];
      if (inSL) break;
      if (inML) { if (c === '*' && n === '/') { inML = false; j++; } continue; }
      if (q) { if (c === '\\') { j++; continue; } if (c === q) q = null; continue; }
      if (c === '/' && n === '/') { inSL = true; break; }
      if (c === '/' && n === '*') { inML = true; j++; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; prevSig = c; lastWord = ''; continue; }
      if (c === '/' && /^(return|typeof|instanceof|in|of|new|delete|void|throw|case|do|else)$/.test(lastWord)) { j = skipRe(l, j); prevSig = '/'; lastWord = ''; continue; }
      if (c === '/' && (prevSig === null || '=(:,[!&|?{};+~^%'.includes(prevSig))) { j = skipRe(l, j); prevSig = '/'; lastWord = ''; continue; }
      if (isWord(c)) lastWord += c; else if (!/\s/.test(c)) { prevSig = c; lastWord = ''; }
      if (!bodyFound) {
        if (c === '(') { paren++; seenParen = true; }
        else if (c === ')') paren--;
        else if (c === '{' && seenParen && paren === 0) { bodyFound = true; depth = 1; }
      } else {
        if (c === '{') depth++;
        if (c === '}') { depth--; if (depth === 0) return { line: i + 1, col: j }; }
      }
    }
    inSL = false; j = 0;
  }
  return null;
}

// digest 1 file: [{name, start, end, top}]
function digest(path) {
  const src = fs.readFileSync(path, 'utf8');
  const lines = src.split('\n');
  const re = /(async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/g;
  const out = [];
  lines.forEach((l, i) => {
    let m; re.lastIndex = 0;
    while ((m = re.exec(l))) {
      const top = /^\s*$/.test(l.slice(0, m.index));
      const e = endOf(lines, i, m.index);
      out.push({ name: m[2], start: i + 1, end: e ? e.line : null, top });
    }
  });
  return { path, totalLines: lines.length, funcs: out };
}

const dig = {};
for (const [k, p] of Object.entries(FILES)) {
  if (!fs.existsSync(p)) { console.log('skip missing ' + p); continue; }
  dig[k] = digest(p);
  console.log(p + ': ' + dig[k].totalLines + ' lines, ' + dig[k].funcs.length + ' funcs');
}

// SECTION_MAP cho legacy: cum cum theo khoang cach (gap > 150 dong => section moi)
function sections(funcs) {
  const tops = funcs.filter(f => f.top && f.end).sort((a, b) => a.start - b.start);
  const secs = []; let cur = null;
  for (const f of tops) {
    if (!cur || f.start - cur.lastStart > 150) {
      if (cur) secs.push(cur);
      cur = { start: f.start, lastStart: f.start, end: f.end, keys: [] };
    }
    cur.lastStart = f.start; cur.end = Math.max(cur.end, f.end || f.start);
    if (cur.keys.length < 5) cur.keys.push(f.name + ' ' + f.start);
  }
  if (cur) secs.push(cur);
  return secs.map((s, i) => ({ id: 'L' + (i + 1), range: s.start + '-' + s.end, key: s.keys.join(', ') }));
}

// index name -> {file, line} (uu tien module, sau do legacy)
const index = new Map();
for (const k of ['utils', 'auth', 'ttbtv', 'provbch', 'ppmttq', 'store', 'legacy', 'main', 'config']) {
  if (!dig[k]) continue;
  for (const f of dig[k].funcs) if (!index.has(f.name)) index.set(f.name, { file: dig[k].path, line: f.start });
}

const today = new Date().toISOString().slice(0, 10);
let out = '// js/dev-map.js - Ban do nhanh (AUTO-GEN boi tools/gen-dev-map.js ' + today + '), khong import vao prod, chi tra cuu IDE\n';
out += '// Dung: Grep tu khoa → Read file + offset theo ban do này. MODULE_MAP: ham da tach khoi legacy.js\n';
out += '// legacy.js hien tai: ' + dig.legacy.totalLines + ' dong (goc 12359); modules: utils/auth/ttbtv/prov-bch/pp-mttq + store.js\n';
out += 'export const SECTION_MAP = [\n';
for (const s of sections(dig.legacy.funcs)) out += '  { id: "' + s.id + '", range: "' + s.range + '", key: "' + s.key + '" },\n';
out += '];\n';
out += 'export const MODULE_MAP = [\n';
for (const k of ['store', 'utils', 'auth', 'ttbtv', 'provbch', 'ppmttq']) {
  if (!dig[k]) continue;
  const f0 = dig[k].funcs[0], f1 = dig[k].funcs[dig[k].funcs.length - 1];
  out += '  { file: "' + dig[k].path + '", lines: ' + dig[k].totalLines + ', funcs: ' + dig[k].funcs.length
    + (f0 ? ', range: "' + f0.start + '-' + (f1.end || f1.start) + '"' : '') + ' },\n';
}
out += '];\n';
out += 'export const SUPABASE_TABLES = ["officers","tt_btv_officers","province_officers","action_100_days_officers","office_officers","tasks","tt_btv_tasks","province_tasks","province_plan_blocks","action_100_days_tasks","vpub_tasks","office_tasks","department_tasks","mttq_kpi_people","mttq_kpi_catalog","mttq_kpi_tasks","activity_logs"];\n';
out += 'export const CACHE_KEYS = ["vp_tasks_cache","bch_officers_cache","bch_tasks_cache","ttbtv_officers_cache","ttbtv_tasks_cache","province_officers_cache","province_tasks_cache","vpub_tasks_cache","action100_tasks_cache"];\n';
out += 'export const QUICK_GREP = {\n';
for (const n of QUICK_KEYS) {
  const hit = index.get(n);
  out += '  ' + n + ': "Grep ' + n + ' → Read ' + (hit ? hit.file + ' ' + hit.line + '/30' : 'NOT-FOUND') + '",\n';
}
out += '};\n';
// dev-map.js dung `export` (ESM, giong ban goc) nen vm.Script (CJS) khong parse duoc;
// validate cu phap bang cach strip export (node --check cung khong ap dung cho ESM).
try { new vm.Script(out.replace(/^export const /gm, 'const ')); } catch (e) { console.error('FAIL dev-map vm: ' + e.message); process.exit(1); }
fs.writeFileSync('js/dev-map.js', out);
console.log('wrote js/dev-map.js bytes=' + out.length);
