-- Migration: Thêm trường chỉ tiêu vào nq_tw
-- Date: 2026-09-29
-- Mô tả: Thêm so_chi_tieu (tổng số chỉ tiêu) và so_chi_tieu_dan_da (số đã đạt)
--          Tiến độ tự tính = so_chi_tieu_dan_da / so_chi_tieu * 100

ALTER TABLE public.nq_tw ADD COLUMN IF NOT EXISTS so_chi_tieu INTEGER DEFAULT 0;
ALTER TABLE public.nq_tw ADD COLUMN IF NOT EXISTS so_chi_tieu_dan_da INTEGER DEFAULT 0;

-- Update existing rows (tất cả đang có so_chi_tieu = 0)
UPDATE public.nq_tw SET so_chi_tieu = 0, so_chi_tieu_dan_da = 0 WHERE so_chi_tieu IS NULL;
