// ==========================================================================
// Supabase Edge Function: Secure Write Proxy
// Thay thế direct Supabase REST API calls cho INSERT/UPDATE/DELETE
// Deploy: supabase functions deploy secure-write
// ==========================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

serve(async (req) => {
  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-user-token, content-type",
    "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers });
  }

  try {
    // ==========================================
    // BƯỚC 1: XÁC THỰC TOKEN
    // ==========================================
    const userToken = req.headers.get("x-user-token");
    if (!userToken || !userToken.startsWith("CB-MAUA-") && !userToken.startsWith("CQ-MAUA-")) {
      return new Response(JSON.stringify({ error: "Thiếu hoặc sai token" }), {
        status: 401,
        headers: { ...headers, "Content-Type": "application/json" },
      });
    }

    // ==========================================
    // BƯỚC 2: PARSE REQUEST
    // ==========================================
    const { table, method, data, id } = await req.json();

    if (!table || !method) {
      return new Response(JSON.stringify({ error: "Thiếu table hoặc method" }), {
        status: 400,
        headers: { ...headers, "Content-Type": "application/json" },
      });
    }

    // ==========================================
    // BƯỚC 3: EXECUTE VIA SERVICE_ROLE (bypass RLS)
    // ==========================================
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    let result;

    switch (method.toUpperCase()) {
      case "GET": {
        let query = supabase.from(table).select("*");
        if (id) query = query.eq("id", id);
        const { data: rows, error } = await query;
        if (error) throw error;
        result = { ok: true, data: rows };
        break;
      }

      case "POST": {
        const { data: inserted, error } = await supabase
          .from(table)
          .insert(data)
          .select()
          .single();
        if (error) throw error;
        result = { ok: true, data: inserted };
        break;
      }

      case "PATCH": {
        if (!id) throw new Error("Thiếu id cho PATCH");
        const { data: updated, error } = await supabase
          .from(table)
          .update(data)
          .eq("id", id)
          .select()
          .single();
        if (error) throw error;
        result = { ok: true, data: updated };
        break;
      }

      case "DELETE": {
        if (!id) throw new Error("Thiếu id cho DELETE");
        const { error } = await supabase.from(table).delete().eq("id", id);
        if (error) throw error;
        result = { ok: true, data: null };
        break;
      }

      default:
        throw new Error(`Method không hỗ trợ: ${method}`);
    }

    // ==========================================
    // BƯỚC 4: LOG ACTIVITY
    // ==========================================
    await supabase.from("activity_logs").insert({
      action: method.toUpperCase(),
      table_name: table,
      row_id: id || "bulk",
      token_hash: userToken.substring(0, 8) + "...",
      created_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { ...headers, "Content-Type": "application/json" },
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});