import { Resend } from "npm:resend@4.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const allowedOrigin = (origin: string | null) => {
  if (!origin) return "";
  try {
    return new URL(origin).hostname.endsWith(".vercel.app") ? origin : "";
  } catch {
    return "";
  }
};
const corsHeaders = (origin: string | null): Record<string, string> => ({
  "Access-Control-Allow-Origin": allowedOrigin(origin),
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
});
const escapeHtml = (value: unknown) => String(value ?? "")
  .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;").replaceAll("'", "&#39;");

Deno.serve(async (request) => {
  const origin = request.headers.get("origin");
  const headers = { ...corsHeaders(origin), "Content-Type": "application/json" };
  if (request.method === "OPTIONS") return new Response("ok", { headers });
  if (request.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  if (origin && !allowedOrigin(origin)) return new Response(JSON.stringify({ error: "Origin not allowed" }), { status: 403, headers });

  try {
    const body = await request.json();
    const { to_email, task_name, owner, deadline, attachment_link, admin_note } = body;
    if (!to_email || !task_name) return new Response(JSON.stringify({ error: "to_email and task_name are required" }), { status: 400, headers });
    const html = `<h2>Thông báo nhiệm vụ sắp đến hạn</h2><p><b>Nhiệm vụ:</b> ${escapeHtml(task_name)}</p><p><b>Người phụ trách:</b> ${escapeHtml(owner)}</p><p><b>Hạn hoàn thành:</b> ${escapeHtml(deadline)}</p>${admin_note ? `<p><b>Ghi chú Admin:</b> ${escapeHtml(admin_note)}</p>` : ""}${attachment_link ? `<p><a href="${escapeHtml(attachment_link)}">Xem tệp đính kèm</a></p>` : ""}`;
    const result = await resend.emails.send({ from: "Văn phòng số Mậu A <lyminhtl@gmail.com>", to: [to_email], subject: `Nhiệm vụ sắp đến hạn: ${task_name}`, html });
    if (result.error) throw new Error(result.error.message);
    return new Response(JSON.stringify({ ok: true, id: result.data?.id }), { headers });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Email send failed" }), { status: 500, headers });
  }
});