-- ==========================================================================
-- RLS SETUP - Văn phòng số Mậu A
-- Chạy trong Supabase Dashboard → SQL Editor
-- ==========================================
-- PHASE 1: RLS bật, web KHÔNG lỗi ( policies cho phép anon read + write )
-- PHASE 2: Edge Functions + migrate app sang X-User-Token header (xem file rls-phase2.sql)
-- ==========================================================================

-- ==========================================
-- BƯỚC 1: TẠO HÀM HỖ TRỢ
-- ==========================================

-- Hàm lấy token từ header X-User-Token của request
CREATE OR REPLACE FUNCTION public.get_request_token()
RETURNS text
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  h json;
BEGIN
  BEGIN
    h := current_setting('request.headers', true)::json;
  EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
  END;
  RETURN COALESCE(h->>'x-user-token', h->>'X-User-Token', NULL);
END;
$$;

-- Hàm kiểm tra token có hợp lệ không
CREATE OR REPLACE FUNCTION public.is_valid_token(p_token text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM (
      SELECT token FROM public.officers WHERE token = p_token
      UNION ALL
      SELECT token FROM public.tt_btv_officers WHERE token = p_token
      UNION ALL
      SELECT token FROM public.province_officers WHERE token = p_token
      UNION ALL
      SELECT token FROM public.office_officers WHERE token = p_token
      UNION ALL
      SELECT token FROM public.action_100_days_officers WHERE token = p_token
    ) t
  );
$$;

-- Hàm lấy scope của token
CREATE OR REPLACE FUNCTION public.get_token_scope(p_token text)
RETURNS text
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  v_unit text;
BEGIN
  SELECT unit INTO v_unit FROM public.officers WHERE token = p_token LIMIT 1;
  IF FOUND THEN
    RETURN CASE v_unit WHEN 'BCH' THEN 'bch' ELSE 'office' END;
  END IF;
  SELECT 'ttbtv' INTO v_unit FROM public.tt_btv_officers WHERE token = p_token LIMIT 1;
  IF FOUND THEN RETURN 'ttbtv'; END IF;
  SELECT 'province' INTO v_unit FROM public.province_officers WHERE token = p_token LIMIT 1;
  IF FOUND THEN RETURN 'province'; END IF;
  SELECT 'office' INTO v_unit FROM public.office_officers WHERE token = p_token LIMIT 1;
  IF FOUND THEN RETURN 'office'; END IF;
  SELECT CASE WHEN unit = 'VPDU' THEN 'vpub' ELSE 'action100' END INTO v_unit
    FROM public.action_100_days_officers WHERE token = p_token LIMIT 1;
  IF FOUND THEN RETURN v_unit; END IF;
  RETURN NULL;
END;
$$;

-- ==========================================
-- BƯỚC 2: BẬT RLS TRÊN 17 BẢNG
-- ==========================================

ALTER TABLE public.officers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tt_btv_officers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.province_officers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.office_officers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.action_100_days_officers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tt_btv_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.province_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.province_plan_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.action_100_days_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vpub_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.office_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.department_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mttq_kpi_people ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mttq_kpi_catalog ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mttq_kpi_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- ==========================================
-- BƯỚC 3: POLICIES - READ (cho phép anon đọc → web hoạt động)
-- ==========================================

CREATE POLICY "rls_officers_select" ON public.officers FOR SELECT USING (true);
CREATE POLICY "rls_ttbtv_officers_select" ON public.tt_btv_officers FOR SELECT USING (true);
CREATE POLICY "rls_province_officers_select" ON public.province_officers FOR SELECT USING (true);
CREATE POLICY "rls_office_officers_select" ON public.office_officers FOR SELECT USING (true);
CREATE POLICY "rls_action100_officers_select" ON public.action_100_days_officers FOR SELECT USING (true);
CREATE POLICY "rls_tasks_select" ON public.tasks FOR SELECT USING (true);
CREATE POLICY "rls_ttbtv_tasks_select" ON public.tt_btv_tasks FOR SELECT USING (true);
CREATE POLICY "rls_province_tasks_select" ON public.province_tasks FOR SELECT USING (true);
CREATE POLICY "rls_province_plan_blocks_select" ON public.province_plan_blocks FOR SELECT USING (true);
CREATE POLICY "rls_action100_tasks_select" ON public.action_100_days_tasks FOR SELECT USING (true);
CREATE POLICY "rls_vpub_tasks_select" ON public.vpub_tasks FOR SELECT USING (true);
CREATE POLICY "rls_office_tasks_select" ON public.office_tasks FOR SELECT USING (true);
CREATE POLICY "rls_department_tasks_select" ON public.department_tasks FOR SELECT USING (true);
CREATE POLICY "rls_mttq_people_select" ON public.mttq_kpi_people FOR SELECT USING (true);
CREATE POLICY "rls_mttq_catalog_select" ON public.mttq_kpi_catalog FOR SELECT USING (true);
CREATE POLICY "rls_mttq_tasks_select" ON public.mttq_kpi_tasks FOR SELECT USING (true);
CREATE POLICY "rls_activity_select" ON public.activity_logs FOR SELECT USING (true);

-- ==========================================
-- BƯỚC 4: POLICIES - WRITE (P1: cho phép anon write → web hoạt động)
-- PHASE 1: Anon được write (giữ nguyên hành vi hiện tại)
-- PHASE 2: Chuyển sang Edge Functions (file rls-phase2.sql)
-- ==========================================

-- P1: Cho phép anon write trên tất cả bảng (web không lỗi)
-- Sau khi migrate sang Edge Functions, xóa các policy này và thay bằng policy kiểm token

-- officers
CREATE POLICY "rls_officers_anon_write" ON public.officers FOR ALL USING (auth.role() = 'anon');
-- tt_btv_officers
CREATE POLICY "rls_ttbtv_officers_anon_write" ON public.tt_btv_officers FOR ALL USING (auth.role() = 'anon');
-- province_officers
CREATE POLICY "rls_province_officers_anon_write" ON public.province_officers FOR ALL USING (auth.role() = 'anon');
-- office_officers
CREATE POLICY "rls_office_officers_anon_write" ON public.office_officers FOR ALL USING (auth.role() = 'anon');
-- action_100_days_officers
CREATE POLICY "rls_action100_officers_anon_write" ON public.action_100_days_officers FOR ALL USING (auth.role() = 'anon');

-- tasks
CREATE POLICY "rls_tasks_anon_write" ON public.tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_ttbtv_tasks_anon_write" ON public.tt_btv_tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_province_tasks_anon_write" ON public.province_tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_province_plan_blocks_anon_write" ON public.province_plan_blocks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_action100_tasks_anon_write" ON public.action_100_days_tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_vpub_tasks_anon_write" ON public.vpub_tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_office_tasks_anon_write" ON public.office_tasks FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_department_tasks_anon_write" ON public.department_tasks FOR ALL USING (auth.role() = 'anon');

-- mttq
CREATE POLICY "rls_mttq_people_anon_write" ON public.mttq_kpi_people FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_mttq_catalog_anon_write" ON public.mttq_kpi_catalog FOR ALL USING (auth.role() = 'anon');
CREATE POLICY "rls_mttq_tasks_anon_write" ON public.mttq_kpi_tasks FOR ALL USING (auth.role() = 'anon');

-- activity_logs
CREATE POLICY "rls_activity_anon_write" ON public.activity_logs FOR ALL USING (auth.role() = 'anon');

-- ==========================================
-- BƯỚC 5: GRANT
-- ==========================================

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;
GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO anon;
GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;

-- ==========================================
-- BƯỚC 6: VERIFY
-- ==========================================

SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname='public' AND tablename IN (
  'officers','tt_btv_officers','province_officers','office_officers','action_100_days_officers',
  'tasks','tt_btv_tasks','province_tasks','province_plan_blocks','action_100_days_tasks',
  'vpub_tasks','office_tasks','department_tasks',
  'mttq_kpi_people','mttq_kpi_catalog','mttq_kpi_tasks','activity_logs'
) ORDER BY tablename;
