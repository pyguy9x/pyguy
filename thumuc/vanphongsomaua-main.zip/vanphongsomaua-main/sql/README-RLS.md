# ==========================================================================
# HƯỚNG DẪN MIGRATE APP SANG RLS + EDGE FUNCTION
# Thực hiện SAU khi chạy SQL Phase 1 (rls-setup.sql)
# ==========================================================================

## 1. TRẠNG THÁI HIỆN TẠI
- App gửi tất cả requests (GET/POST/PATCH/DELETE) trực tiếp đến Supabase REST API
- Headers chỉ có: apikey + Authorization (anon key)
- Không gửi token người dùng → RLS Phase 2 sẽ chặn writes

## 2. CÁI CẦM

### 2a. Deploy Phase 1 SQL (RLS cho reads, anon writes allowed)
```bash
# Trong Supabase Dashboard → SQL Editor
# Paste nội dung sql/rls-setup.sql và chạy
```

### 2b. Deploy Edge Function
```bash
supabase functions deploy secure-write --no-verify-jwt
```

### 2c. Set SERVICE_ROLE_KEY trong Edge Function env
```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"
```
(Lấy key từ Supabase Dashboard → Settings → API → service_role key)

## 3. SỬA APP - THÊM X-User-Token HEADER

Trong `js/legacy.js`, tìm tất cả `fetch(` calls và thêm header:

### Trước:
```javascript
const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks`, {
  method: "PATCH",
  headers: {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ ... })
});
```

### Sau:
```javascript
const userToken = localStorage.getItem("_vp_t") || "";
const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks`, {
  method: "PATCH",
  headers: {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    "Content-Type": "application/json",
    "X-User-Token": userToken,  // ← THÊM DÒNG NÀY
  },
  body: JSON.stringify({ ... })
});
```

### Hàm helper thêm vào `js/legacy.js`:
```javascript
function getAuthHeaders() {
  const token = localStorage.getItem("_vp_t") || "";
  return {
    "apikey": SUPABASE_KEY,
    "Authorization": `Bearer ${SUPABASE_KEY}`,
    "Content-Type": "application/json",
    "X-User-Token": token,
  };
}
```

## 4. MIGRATE WRITE OPERATIONS SANG EDGE FUNCTION

Các hàm write trong `js/legacy.js` cần chuyển sang dùng Edge Function:

### 4a. Tạo hàm wrapper trong `js/legacy.js`:
```javascript
async function secureWrite(table, method, data, id) {
  const token = localStorage.getItem("_vp_t") || "";
  const response = await fetch(
    `${SUPABASE_URL}/functions/v1/secure-write`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-User-Token": token,
        "Authorization": `Bearer ${SUPABASE_KEY}`,
      },
      body: JSON.stringify({ table, method, data, id }),
    }
  );
  return response.json();
}
```

### 4b. Thay thế các call trực tiếp:

**Ví dụ: deleteOfficeTask()**
- Trước: `fetch(URL, { method: "DELETE", headers: {...} })`
- Sau: `secureWrite("office_tasks", "DELETE", null, x.id)`

**Ví dụ: lưu nhiệm vụ**
- Trước: `fetch(URL, { method: "PATCH", body: JSON.stringify({...}) })`
- Sau: `secureWrite("office_tasks", "PATCH", {...}, x.id)`

## 5. THỨ TỰ KIỂM TRA SAU KHI DEPLOY

1. ✅ Trang chủ load được (reads vẫn hoạt động)
2. ✅ Login bằng token vẫn được
3. ✅ Thêm nhiệm vụ mới vẫn lưu được
4. ✅ Sửa nhiệm vụ vẫn cập nhật được
5. ✅ Xóa nhiệm vụ vẫn xóa được
6. ✅ Toast thông báo vẫn hiện đúng
7. ✅ Filter/search vẫn hoạt động
8. ✅ Charts vẫn render

## 6. ROLLBACK NẾU LỖI

Nếu web lỗi sau khi bật RLS:
```sql
-- Tắt RLS tạm thời
ALTER TABLE public.officers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks DISABLE ROW LEVEL SECURITY;
-- ... tương tự các bảng khác
```

Hoặc xóa tất cả policies:
```sql
DROP POLICY IF EXISTS "rls_officers_select" ON public.officers;
DROP POLICY IF EXISTS "rls_officers_anon_write" ON public.officers;
-- ... tương tự
```

## 7. FILE ĐÃ TẠO

| File | Mục đích |
|------|----------|
| `sql/rls-setup.sql` | Phase 1 - RLS cho reads + anon writes |
| `sql/rls-phase2.sql` | Phase 2 - Siết chặt viết (yêu cầu token) |
| `supabase/functions/secure-write/index.ts` | Edge Function proxy cho writes |
| `supabase/functions/secure-write/deno.json` | Cấu hình Edge Function |

## 8. LƯU Ý QUAN TRỌNG

1. **Không xóa Phase 1 policies trước khi Phase 2 hoạt động**
2. **Test trên môi trường dev trước** (có thể dùng `?demo=1`)
3. **Backup database trước khi chạy RLS**: `npm run backup`
4. **F5 cứng Ctrl+Shift+R** sau khi deploy để bỏ cache
5. **Kiểm tra browser console** xem có error RLS không
