-- ==========================================================================
-- RLS PHASE 2 - Văn phòng số Mậu A
-- Chạy SAU khi đã migrate app sang Edge Functions (xem edge-function.js)
-- ==========================================
-- GIA HẠN: Xóa các policy anon_write ở Phase 1, thay bằng policy kiểm token
-- ==========================================================================

-- ==========================================
-- XÓA CÁC POLICY PHASE 1 (anon write)
-- ==========================================

DROP POLICY IF EXISTS "rls_officers_anon_write" ON public.officers;
DROP POLICY IF EXISTS "rls_ttbtv_officers_anon_write" ON public.tt_btv_officers;
DROP POLICY IF EXISTS "rls_province_officers_anon_write" ON public.province_officers;
DROP POLICY IF EXISTS "rls_office_officers_anon_write" ON public.office_officers;
DROP POLICY IF EXISTS "rls_action100_officers_anon_write" ON public.action_100_days_officers;

DROP POLICY IF EXISTS "rls_tasks_anon_write" ON public.tasks;
DROP POLICY IF EXISTS "rls_ttbtv_tasks_anon_write" ON public.tt_btv_tasks;
DROP POLICY IF EXISTS "rls_province_tasks_anon_write" ON public.province_tasks;
DROP POLICY IF EXISTS "rls_province_plan_blocks_anon_write" ON public.province_plan_blocks;
DROP POLICY IF EXISTS "rls_action100_tasks_anon_write" ON public.action_100_days_tasks;
DROP POLICY IF EXISTS "rls_vpub_tasks_anon_write" ON public.vpub_tasks;
DROP POLICY IF EXISTS "rls_office_tasks_anon_write" ON public.office_tasks;
DROP POLICY IF EXISTS "rls_department_tasks_anon_write" ON public.department_tasks;

DROP POLICY IF EXISTS "rls_mttq_people_anon_write" ON public.mttq_kpi_people;
DROP POLICY IF EXISTS "rls_mttq_catalog_anon_write" ON public.mttq_kpi_catalog;
DROP POLICY IF EXISTS "rls_mttq_tasks_anon_write" ON public.mttq_kpi_tasks;

DROP POLICY IF EXISTS "rls_activity_anon_write" ON public.activity_logs;

-- ==========================================
-- TẠO POLICIES PHASE 2: YÊU CẦU X-User-Token HỢP LỆ
-- ==========================================

-- officers: chỉ token BCH mới được ghi
CREATE POLICY "rls_officers_write" ON public.officers
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) = 'bch'
  );

-- tt_btv_officers
CREATE POLICY "rls_ttbtv_officers_write" ON public.tt_btv_officers
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('ttbtv', 'bch')
  );

-- province_officers
CREATE POLICY "rls_province_officers_write" ON public.province_officers
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('province', 'bch')
  );

-- office_officers
CREATE POLICY "rls_office_officers_write" ON public.office_officers
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('office', 'bch')
  );

-- action_100_days_officers
CREATE POLICY "rls_action100_officers_write" ON public.action_100_days_officers
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('action100', 'vpub', 'bch')
  );

-- tasks
CREATE POLICY "rls_tasks_write" ON public.tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('office', 'bch')
  );

-- tt_btv_tasks
CREATE POLICY "rls_ttbtv_tasks_write" ON public.tt_btv_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('ttbtv', 'bch')
  );

-- province_tasks
CREATE POLICY "rls_province_tasks_write" ON public.province_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('province', 'bch')
  );

-- province_plan_blocks
CREATE POLICY "rls_province_plan_blocks_write" ON public.province_plan_blocks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('province', 'bch')
  );

-- action_100_days_tasks
CREATE POLICY "rls_action100_tasks_write" ON public.action_100_days_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('action100', 'vpub', 'bch')
  );

-- vpub_tasks
CREATE POLICY "rls_vpub_tasks_write" ON public.vpub_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('vpub', 'bch')
  );

-- office_tasks
CREATE POLICY "rls_office_tasks_write" ON public.office_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('office', 'bch')
  );

-- department_tasks
CREATE POLICY "rls_department_tasks_write" ON public.department_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) = 'admin'
  );

-- mttq_kpi_people
CREATE POLICY "rls_mttq_people_write" ON public.mttq_kpi_people
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('bch', 'admin')
  );

-- mttq_kpi_catalog
CREATE POLICY "rls_mttq_catalog_write" ON public.mttq_kpi_catalog
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('bch', 'admin')
  );

-- mttq_kpi_tasks
CREATE POLICY "rls_mttq_tasks_write" ON public.mttq_kpi_tasks
  FOR ALL USING (
    is_valid_token(get_request_token())
    AND get_token_scope(get_request_token()) IN ('mttq', 'bch')
  );

-- activity_logs: chỉ insert (delete vẫn admin)
CREATE POLICY "rls_activity_insert" ON public.activity_logs
  FOR INSERT WITH CHECK (is_valid_token(get_request_token()));

CREATE POLICY "rls_activity_delete" ON public.activity_logs
  FOR DELETE USING (get_token_scope(get_request_token()) = 'admin');
