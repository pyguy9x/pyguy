# ==========================================================================
# BÁO CÁO KIỂM TRA UI/UX - Văn phòng số Mậu A
# Kiểm tra bằng mắt + phân tích code (không can thiệp dự án)
# ==========================================================================

## 1. TRẮNG TRỌNG & TỐI (Contrast)

| Vấn đề | Vị trí | Mức độ |
|--------|--------|--------|
| Sidebar text trắng `rgba(255,255,255,0.84)` trên nền gradient vàng-nâu | `css/style.css:272` | ⚠️ Contrast thấp trên sáng |
| Sidebar text trắng `rgba(255,255,255,0.92)` trên nền tối | `css/style.css:400` | ✅ OK |
| `.auth-card p` màu `#64748b` trên nền trắng | `css/style.css:295` | ⚠️ Contrast thấp (4.2:1, chuẩn WCAG cần 4.5:1) |
| `.text-muted` `#64748b` trên nền sáng | `css/style.css:485` | ⚠️ Contrast thấp |

**Khuyến nghị:** Tăng contrast cho sidebar text sáng, dùng `#94a3b8` thay vì `rgba(white,0.84)`.

---

## 2. ACCESSIBILITY

### Thiếu label cho form
| Phần tử | Vấn đề |
|---------|--------|
| `<input id="tokenInput">` (auth) | Không có `<label for="tokenInput">` — screen reader không biết đây là gì |
| `<input id="searchInput">` | Có `placeholder` nhưng không có label — placeholder không thay thế label |
| `<input id="editTaskText">` | Có label trong HTML nhưng thiếu `for` |

### SVG không có tiêu đề
```html
<svg viewBox="0 0 120 104" role="img">
  <!-- Thiếu <title> inside SVG -->
```
→ Screen reader đọc là "image" không có mô tả.

### Thiếu aria-label trên nhiều nút
- `#refreshBtn` — không có `aria-label="Cập nhật dữ liệu"`
- `#logoutBtn` — không có `aria-label="Đăng xuất"`
- `#sbToggle` — có `title` nhưng thiếu `aria-label`

### Focus indicator
```css
.auth-input:focus { outline: none; }  /* BỎ focus indicator! */
```
→ Người dùng bàn phím không thấy đang nhập ở đâu. Nên thêm `outline: 2px solid #8b1e35` thay vì `none`.

---

## 3. RESPONSIVE & MOBILE

| Vấn đề | Vị trí | Mô tả |
|--------|--------|-------|
| `.drill-table` `min-width: 1380px` | `css:1298` | Trên mobile phải scroll ngang — OK nhưng cần báo hiệu scroll |
| `.sidebar` fixed `left:280px` | `css:69` | Trên mobile (<768px) sidebar có thể vượt khỏi màn hình |
| `.chart-container` height cố định `280px` | `css:748` | Trên mobile chart bị cắt hoặc chiếm quá nhiều không gian |
| `@media (max-width: 650px)` chỉ có 1 breakpoint | `css:1007` | Nên thêm 2-3 breakpoint cho tablet |
| `index2.html` thiếu NQ 57 IDs | diff | Bản cũ hơn — không sync với index.html |

---

## 4. TOAST SYSTEM — LỖI Nghiêm trọng

**Hai hệ thống toast xung đột:**

| Toast | CSS | JS | Vị trí |
|-------|-----|----|--------|
| `toast-container` | `css/toast.css` | `js/email.js` `showToast(message, type)` | bottom-right |
| `appToastWrap` | `css/style.css` `.app-toast` | `js/legacy.js` `showToast(type, title, message)` | top-right (wrap) |

**Bug:** `email.js` define `showToast(message, type)` với 2 params, nhưng gọi ở dòng 89 với 3 params `showToast("error", "Không có quyền", "Chỉ Admin...")`:
- Nếu email.js load trước → "error" là message, "Không có quyền" là type → toast xanh (success) thay vì đỏ
- Nếu legacy.js load trước → đúng signature nhưng toast HTML khác cấu trúc

**Khuyến nghị:** Gộp lại 1 hàm `showToast(type, title, message)` duy nhất.

---

## 5. HIỂN THỊ & HÌNH ẢNH

| Vấn đề | Vị trí |
|--------|--------|
| Logo sidebar `transform: scale(1.18)` + `border-radius: 50%` — có thể bị crop | `index.html:46-48` |
| Favicon dùng external URL (`i.ibb.co`) — load chậm nếu mạng yếu | `index.html:16` |
| `demoBanner` `display:none` hardcoded — dù DEMO_MODE=false thì banner vẫn ẩn (đúng) nhưng CSS không có `.demo-visible` class | `index.html:23` |

---

## 6. HIỆN NĂNG (Performance)

| Vấn đề | Ảnh hưởng |
|--------|-----------|
| `legacy.js` 6696 dòng / 506KB | Tải chậm trên mạng yếu, parse lâu |
| `css/style.css` 1.16MB | CSS quá lớn, nhiều rule không dùng |
| Chart.js load từ CDN | Nếu CDN chậm → app chờ |
| 17 `@media` queries trong CSS | Nhiều responsive rule, dễ conflict |
| `setTimeout` rải rác (800ms, 900ms, 1200ms) | Timing không chắc chắn, race condition |

---

## 7. BỘ LỌC & SẮP XẾP

| Vấn đề | Mô tả |
|--------|-------|
| `dateRange` filter không rõ ràng | Label "Khoảng thời gian" + 2 date picker — thừa, gây nhầm lẫn |
| `officeOfficerNameFilter` dùng `bchFold` | `bchFold` bỏ dấu tiếng Việt → tìm "Nguyen Van A" khớp "Nguyễn Văn A" — OK nhưng không document |
| BCH filter `BCH_MONTH`/`BCH_QUARTER` dùng `typeof` check | Global variables có thể undefined → filter không hoạt động im lặng |

---

## 8. TÓM TẮT ƯU TIÊN UI FIX

| Ưu tiên | Lỗi | Fix |
|---------|-----|-----|
| **P1** | Hai toast system xung đột | Gộp thành 1 hàm `showToast(type, title, message)` |
| **P1** | Thiếu label auth input | Thêm `<label for="tokenInput">Token</label>` |
| **P1** | Bỏ focus outline | Thay `outline:none` bằng `outline: 2px solid #8b1e35` |
| **P2** | Sidebar text contrast thấp | Tăng opacity hoặc đổi màu |
| **P2** | `.auth-card p` contrast thấp | Đổi `#64748b` → `#475569` |
| **P2** | Mobile chart container | Thêm `@media (max-width: 480px)` cho chart |
| **P2** | SVG thiếu `<title>` | Thêm `<title>Logo Văn phòng số</title>` |
| **P3** | `index2.html` stale | Xóa hoặc đồng bộ |
| **P3** | CSS 1.16MB | Tách file, bỏ unused CSS |
| **P3** | Demo banner hardcoded | Thêm CSS class `.demo-active #demoBanner { display: block }` |

---

## 9. SO SÁNH index.html vs index2.html

| | index.html | index2.html |
|--|-----------|------------|
| Dòng | 2973 | 2818 |
| CSS version | `v=20260940` | `v=20260924` |
| NQ 57 IDs | ✅ Có (29 IDs) | ❌ Thiếu hết |
| BCH vinh danh | ✅ Có | ❌ Không rõ |
| Date Picker | ✅ Thống nhất | ❌ Có thể chưa |

→ **index2.html là bản cũ**, không nên để trong repo hoặc cần sync.

---

## 10. KẾT LUẬN TỔNG

| Hạng | Đánh giá |
|------|----------|
| Visual design | ✅ Đẹp, nhất quán, logo thương hiệu rõ |
| Accessibility | ⚠️ Trung bình — thiếu label, focus, aria |
| Mobile responsive | ⚠️ Cơ bản hoạt động, nhưng nhiều breakpoint thiếu |
| Toast/notification | ❌ Hai hệ thống xung đột |
| Performance | ⚠️ JS 506KB, CSS 1.16MB — cần tối ưu |
| Stale files | ❌ index2.html cần xóa |
