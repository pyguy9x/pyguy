# n8n Backup - Link tải toàn bộ data

## 1. Token & Folder
- `BACKUP_TOKEN` (đã gen): `vpbu_469fd4c377acfa7cf76c8a69110b39de`
- Google Drive Folder ID: `1yu4WFxfaWeZGU7DIsGWFzwgrhIYsMddj` (https://drive.google.com/drive/folders/1yu4WFxfaWeZGU7DIsGWFzwgrhIYsMddj)

## 2. Cài trên VPS (n8n self-hosted Docker)

### B1. Đặt biến môi trường cho n8n
Vào `docker-compose.yml` của n8n, thêm env:
```yaml
environment:
  - BACKUP_TOKEN=vpbu_469fd4c377acfa7cf76c8a69110b39de
```
Rồi `docker compose up -d` (hoặc `docker restart n8n`).

> Nếu không muốn sửa compose, vào n8n → Settings → Environment Variables → Add `BACKUP_TOKEN`.

### B2. Import workflow
n8n → Workflows → Import from File → chọn `n8n/vp-backup-workflow.json`.

### B3. Gán Credentials
Mở workflow vừa import:
- Node `Supabase - Get All Rows` → chọn credential Supabase self-hosted đã có (thay `REPLACE_WITH_YOUR_SUPABASE_CREDENTIAL_ID`)
- Nodes `Google Drive - Upload/List/Delete` → chọn credential `Google Drive OAuth2` (tạo mới nếu chưa có: Credentials → Google Drive OAuth2 → Sign in, cần bật Drive API trong Google Cloud). Thay `REPLACE_WITH_YOUR_GDRIVE_CREDENTIAL_ID`. Folder ID đã điền sẵn.

> Nếu Supabase node không hỗ trợ `{{ $json.table }}` động, đổi sang node `Postgres` → Query: `SELECT * FROM {{$json.table}} ORDER BY id ASC`.

### B4. Active
Bật `Active` workflow. Webhook URL sẽ hiện ở node `Webhook - Backup Link`, dạng:
```
http://<VPS_IP>:5678/webhook/vp-backup?token=vpbu_469fd4c377acfa7cf76c8a69110b39de
```
(Nếu n8n đặt sau reverse proxy, host sẽ là domain của bạn).

## 3. Sử dụng

### Tải thủ công (link)
```bash
curl "http://<VPS_IP>:5678/webhook/vp-backup?token=vpbu_469fd4c377acfa7cf76c8a69110b39de" -o backup-$(date +%F).json
# Sai token → {"error":"invalid token"} (403)
```

### Sao lưu tự động
Workflow tự chạy `Schedule - Daily 02:00` mỗi ngày:
- Gom 17 bảng `BACKUP_TABLES` (giống `js/legacy.js:223` - backupData paginate 1000)
- Upload lên Drive folder trên → List → xóa bản cũ, chỉ giữ 5 file mới nhất.

Test ngay: bấm `Execute Workflow` thủ công trong n8n, kiểm tra Drive có file mới.

## 4. Lưu ý bảo mật (chưa có HTTPS)
- Token truyền plain-text trên http → chỉ dùng trong mạng nội bộ / VPN. Nên thêm HTTPS (Let's Encrypt via Traefik/Caddy) sớm.
- Không commit token vào git. Token chỉ nằm trong env n8n.
- Rate limit webhook nếu mở ra internet: n8n → Settings → Rate limiting hoặc firewall `ufw allow from <IP>`.

## 5. Khắc phục sự cố
- Supabase lỗi bảng: workflow vẫn tạo file, bảng lỗi để trống (như `skipped` trong backupData).
- Drive quota: kiểm tra credential hết hạn → Re-authenticate trong n8n Credentials.
- Webhook 404: kiểm tra workflow đã Active và path `vp-backup` không trùng workflow khác.
