-- supabase_seed_tokens.sql
-- Đẩy token thật lên 4 bảng chính (giữ nguyên giá trị, không xóa data cũ)
-- Chạy trong Supabase Dashboard > SQL Editor > Run
-- Chỉ INSERT khi token chưa tồn tại (an toàn, không ghi đè)
-- 4 bảng chính: officers (BCH), tt_btv_officers (TT/BTV), province_officers (Tỉnh), office_officers (Văn phòng)
-- Thêm action_100_days_officers cho CQ-* (KH 100 ngày / VPUB) - nếu chưa có bảng thì bỏ qua

-- ===== 1. BCH - officers (29 token) =====
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Chu Chính Sơn','CB-MAUA-HDA-62F311','TUV','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-HDA-62F311');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Phạm Xuân Sơn','CB-MAUA-PXS-BBD61F','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-PXS-BBD61F');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Chu Chính Sơn','CB-MAUA-CCS-D13D0C','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-CCS-D13D0C');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Quốc Tuấn','CB-MAUA-TQT-2B13B6','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TQT-2B13B6');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Lê Văn Tuấn','CB-MAUA-LVT-E1906F','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-LVT-E1906F');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Nguyễn Thị Kim','CB-MAUA-NTK-CBB13F','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-NTK-CBB13F');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Đặng Ngọc Cường','CB-MAUA-DNC-832D52','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-DNC-832D52');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Đình Thắng','CB-MAUA-TDT-FA2CCC','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TDT-FA2CCC');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Đinh Mạnh Cường','CB-MAUA-DMC-724CD3','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-DMC-724CD3');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Lê Quang Long','CB-MAUA-LQL-CCB54F','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-LQL-CCB54F');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Văn Hùng','CB-MAUA-TVH-850D07','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TVH-850D07');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Thanh Long','CB-MAUA-TTL-7092CD','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TTL-7092CD');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Hoàng Minh Cường','CB-MAUA-HMC-B31E6F','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-HMC-B31E6F');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Thị Hương','CB-MAUA-TTH-4116B2','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TTH-4116B2');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Ngọc Cường','CB-MAUA-TNC-E94A7D','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TNC-E94A7D');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Nguyễn Thị Thu','CB-MAUA-NTT-36EE60','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-NTT-36EE60');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Văn Hùng','CB-MAUA-TVH-5B194D','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TVH-5B194D');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Phạm Thị Oanh','CB-MAUA-PTO-B60D0B','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-PTO-B60D0B');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Đào Kim Vân','CB-MAUA-DKV-D6DB6A','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-DKV-D6DB6A');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Phạm Văn Mạnh','CB-MAUA-PVM-17DE3B','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-PVM-17DE3B');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Trần Xuân Phú','CB-MAUA-TXP-178AF7','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-TXP-178AF7');
INSERT INTO public.officers (name, token, title, unit)
SELECT 'Lê Chí Cường','CB-MAUA-LCC-7396FB','','BCH' WHERE NOT EXISTS (SELECT 1 FROM public.officers WHERE token='CB-MAUA-LCC-7396FB');

-- ===== 2. Văn phòng - office_officers (7 token) =====
-- Lưu ý: bảng office_officers có UNIQUE(name) và KHÔNG có cột unit, chỉ INSERT 3 cột
-- Nếu name đã tồn tại (ví dụ Phạm Văn Mạnh với token cũ pvm_ecb76f) thì UPDATE token/title thay vì báo lỗi, không xóa dòng
INSERT INTO public.office_officers (name, token, title) VALUES ('Phạm Văn Mạnh','CB-MAUA-PVM-7KQ2A1','Chánh Văn phòng') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Nguyễn Thị Minh Trang','CB-MAUA-NMT-4XR8B2','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Vũ Thị Kim Thoa','CB-MAUA-VTK-8LM3C4','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Vũ Thị Lượng','CB-MAUA-VTL-2PD5D6','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Lê Anh Minh','CB-MAUA-LAM-6QZ7E8','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Nguyễn Thị Thúy','CB-MAUA-NTT-9HC1F2','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;
INSERT INTO public.office_officers (name, token, title) VALUES ('Lý Thế Minh','CB-MAUA-LTM-3VK4G5','') ON CONFLICT (name) DO UPDATE SET token = EXCLUDED.token, title = EXCLUDED.title;

-- ===== 3. KH 100 ngày / VPUB - action_100_days_officers (22 token CQ- + 4 staff) =====
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'VPDU','CQ-MAUA-VPDU','VPDU','VPDU' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-VPDU');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'UBND','CQ-MAUA-UBND','UBND','UBND' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-UBND');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'UBND xã','CQ-MAUA-UBNDXA','UBND xã','UBND xã' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-UBNDXA');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Ban Xây dựng Đảng','CQ-MAUA-BANXDD','','Ban Xây dựng Đảng' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-BANXDD');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'MTTQ','CQ-MAUA-MTTQ','','MTTQ' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-MTTQ');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'HDND','CQ-MAUA-HDND','','HDND' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-HDND');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Công an xã','CQ-MAUA-CBCONGAN','','Công an xã' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-CBCONGAN');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Quân sự xã','CQ-MAUA-CBQUANSU','','Quân sự xã' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-CBQUANSU');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'UBKT','CQ-MAUA-UBKT','','UBKT' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-UBKT');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trung tâm Chính trị','CQ-MAUA-TTCT','','Trung tâm Chính trị' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-TTCT');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Phòng Kinh Tế hạ tầng','CQ-MAUA-KTHT','','Phòng Kinh Tế hạ tầng' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-KTHT');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Phòng văn hóa','CQ-MAUA-PVH','','Phòng văn hóa' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-PVH');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trung tâm PV HCC','CQ-MAUA-HCC','','Trung tâm PV HCC' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-HCC');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trung tâm Dịch vụ tổng hợp','CQ-MAUA-DVTH-CVE61','','Trung tâm Dịch vụ tổng hợp' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-DVTH-CVE61');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'BQL dự án đầu tư xây dựng','CQ-MAUA-DTXD-8LX74F','','BQL dự án đầu tư xây dựng' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-DTXD-8LX74F');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Phòng NN và MT','CQ-MAUA-NNMT-CV','','Phòng NN và MT' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-NNMT-CV');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trạm Y tế','CQ-MAUA-TYTLD','','Trạm Y tế' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-TYTLD');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trạm Y tế','CQ-MAUA-TYTCV','','Trạm Y tế' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-TYTCV');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'UBND xã','CQ-MAUA-UBNDXA2','UBND xã','UBND xã' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-UBNDXA2');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'VPUB','CQ-VPUB-MAUA','VPUB','VPUB' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-VPUB-MAUA');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'CV nhập liệu','CQ-MAUA-CV','CV nhập liệu','CV' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CQ-MAUA-CV');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Lê Trường Thịnh','CB-MAUA-LTT-8DH46R','','LTT' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CB-MAUA-LTT-8DH46R');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Trần Anh Tráng','CB-MAUA-TAT-3F8CH1','','TAT' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CB-MAUA-TAT-3F8CH1');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Phòng NN và MT','CB-MAUA-DNC-5OP3FG','','DNC' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CB-MAUA-DNC-5OP3FG');
INSERT INTO public.action_100_days_officers (name, token, title, unit)
SELECT 'Nguyễn Giang Nam','CB-MAUA-NGN-88KQBY','','NGN' WHERE NOT EXISTS (SELECT 1 FROM public.action_100_days_officers WHERE token='CB-MAUA-NGN-88KQBY');

-- ===== 4. Set role overrides - role_overrides (lưu perms cho mỗi token, áp dụng mọi trình duyệt) =====
create table if not exists public.role_overrides (
  token text primary key,
  perms jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now(),
  updated_by text
);
alter table public.role_overrides disable row level security;

-- ===== 5. Kiểm tra sau khi chạy =====
-- SELECT 'officers' as tbl, count(*) FROM public.officers
-- UNION ALL SELECT 'office_officers', count(*) FROM public.office_officers
-- UNION ALL SELECT 'action_100_days_officers', count(*) FROM public.action_100_days_officers;
-- SELECT token, name FROM public.action_100_days_officers WHERE token LIKE 'CQ-%' ORDER BY token;
-- SELECT * FROM public.role_overrides;
