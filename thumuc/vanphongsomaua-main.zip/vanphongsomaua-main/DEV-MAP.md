# DEV-MAP.md - Bản đồ dự án vanphongsomaua (auto-gen 2026-09-28)

> File này chỉ để tra cứu IDE, không import vào prod.

## 1. Tổng quan refactor
- **Gốc:** `legacy.js` 12359 dòng
- **Hiện tại:** `legacy.js` 6733 dòng (đã tách)
- **Thứ tự load BẮT BUỘC trong main.js:**
  ```
  store.js -> utils(60) -> auth(79) -> ttbtv(141) -> prov-bch(73) -> pp-mttq(82) -> legacy(6462)
  ```
  > DỪNG TÁCH legacy.js nữa. Tính năng mới tạo file mới `js/modules/<ten>.js` dạng classic script window globals.

## 2. MODULE_MAP

| File | Dòng | Số hàm | Range |
|------|------|--------|-------|
| `js/store.js` | 18 | 0 | - |
| `js/modules/utils.js` | 863 | 60 | 6-862 |
| `js/modules/auth.js` | 1336 | 79 | 7-1335 |
| `js/modules/ttbtv.js` | 2192 | 142 | 5-2191 |
| `js/modules/prov-bch.js` | 1864 | 75 | 9-1863 |
| `js/modules/pp-mttq.js` | 1178 | 85 | 5-1177 |

## 3. SECTION_MAP (legacy.js còn lại)

| ID | Range | Từ khóa chính |
|----|-------|---------------|
| L1 | 8-1173 | safeLSSet, safeLSGet, readCache, writeCache, _obfOfficers |
| L2 | 1179-4532 | foldHonorText, isLeadershipPosition, updateGlobalHonors, openHonorBestTasks |
| L3 | 4553-5266 | resetPROVDrillFilters, renderPROVAddTaskRow, renderPROVDrill |
| L4 | 5267-5876 | exportWorkspaceExcel, focusFirstEditable, fillSelect |
| L5 | 6127-6716 | ppNormalizeDateInputs, vpubWrapDateInput, setupTTBTVDateFields, bchWrapDateInput |

> Cách dùng: `Grep <keyword> -> Read js/legacy.js <offset>/30` để không phải load cả file.

## 4. SUPABASE_TABLES (17 bảng)

```
officers, tt_btv_officers, province_officers, action_100_days_officers, office_officers,
tasks, tt_btv_tasks, province_tasks, province_plan_blocks, action_100_days_tasks,
vpub_tasks, office_tasks, department_tasks,
mttq_kpi_people, mttq_kpi_catalog, mttq_kpi_tasks,
activity_logs
```

## 5. CACHE_KEYS (9 key localStorage)

```
vp_tasks_cache, bch_officers_cache, bch_tasks_cache, ttbtv_officers_cache,
ttbtv_tasks_cache, province_officers_cache, province_tasks_cache,
vpub_tasks_cache, action100_tasks_cache
```

## 6. QUICK_GREP - tra nhanh 18 hàm hay dùng

- `saveEditTask` -> `js/legacy.js:868`
- `mergeDepartmentAndOffice` -> `js/legacy.js:1957`
- `renderOfficeDrillRows` -> `js/legacy.js:3080`
- `homeFilteredTasks` -> `js/legacy.js:1442`
- `renderBCHTable` -> `js/legacy.js:3711`
- `renderBCHDrill` -> `js/legacy.js:3538`
- `uploadBCHTaskFile` -> `js/modules/prov-bch.js:449`
- `resetBCHFilters` -> `js/modules/prov-bch.js:703`
- `renderTTBTVTable` -> `js/legacy.js:4127`
- `renderPROVDrill` -> `js/legacy.js:4592`
- `renderPROVTable` -> `js/legacy.js:4683`
- `loadMTTQKPIData` -> `js/modules/pp-mttq.js:299`
- `provincePlanLoad` -> `js/modules/pp-mttq.js:888`
- `applyTokenMultiScope` -> `js/modules/auth.js:1097`
- `userCan` -> `js/modules/auth.js:1136`
- `_obfToken` -> `js/modules/auth.js:7`
- `initAuth` -> `js/modules/auth.js:314`
- `loadData` -> `js/legacy.js:2025`

## 7. Quy tắc cho LLM (từ opencode.json rules)

1. File >500 dòng LUÔN dùng ast-bro map/digest + Read offset/limit
2. Sau sửa chạy `node --check` 8 file phải pass
3. Luôn dùng model rẻ nhất (chutes free 0đ / deepseek 10đ), chỉ dùng claude-sonnet-4-6 50đ khi user ghi `dung pro`
4. Tính năng mới: tạo `js/modules/<ten>.js` dạng classic script window globals, thêm vào `main.js` trước `legacy`

---
*Gen bởi `tools/gen-dev-map.js` - nếu sửa thủ công nhớ chạy lại gen.*
