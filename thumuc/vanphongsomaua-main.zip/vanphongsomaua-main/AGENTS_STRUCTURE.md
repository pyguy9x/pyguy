# Cấu trúc mới sau refactor (STOP - Không tách legacy nữa)

## Tổng quan
- Ban đầu: legacy.js 12.359 dòng (Grade F)
- Hiện tại: 6.462 dòng + 6 modules, đã tách 435/644 hàm (67.5%)
- Trạng thái: node --check pass 8 file, web chạy mượt

## Thứ tự load BẮT BUỘC trong index.html / js/main.js
1. js/store.js (globals, CURRENT_USER, store)
2. js/modules/utils.js (60 hàm core)
3. js/modules/auth.js (79 hàm, chừa isOwnedByToken trong legacy)
4. js/modules/ttbtv.js (141 hàm)
5. js/modules/prov-bch.js (73 hàm)
6. js/modules/pp-mttq.js (82 hàm)
7. js/legacy.js (6462 dòng còn lại - CORE: task-core, render, home, dashboard)

-> Tất cả modules là classic script (gắn window), KHÔNG dùng import/export ESM để không vỡ 237 onclick.

## Quy tắc cho Agent từ giờ
1. KHÔNG được tách tiếp legacy.js nữa. Đóng băng ở 6462 dòng.
2. Tính năng MỚI viết vào js/modules/<ten-tinh-nang>.js mới, rồi thêm vào main.js load trước legacy.
3. Khi sửa file >500 dòng, LUÔN dùng ast-bro map/digest hoặc tree-sitter-analyzer để partial-read, không đọc cả file.
4. Nếu phải sửa legacy.js: chỉ extract đúng hàm cần sửa qua Read offset/limit, không được xóa hàm hàng loạt.
5. Sau mỗi lần sửa: chạy `node --check js/*.js js/modules/*.js` phải pass hết.
6. Giữ lại các hàm lồng/closure trong legacy (ví dụ isOwnedByToken) - không cố lôi ra ngoài.
7. Giữ nguyên 237 onclick trong legacy, không đổi thành addEventListener.

## Các nhóm đã tách xong (không đụng lại)
- utils core, auth, ttbtv-vpub-action-office, prov-bch, pp-mttq

## Các nhóm còn lại trong legacy (để nguyên)
- task chung, home, dashboard, filter, notif, render