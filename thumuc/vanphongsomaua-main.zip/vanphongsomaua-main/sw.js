// Killer SW: gỡ bỏ hoàn toàn offline cache vps-maua-v1 cũ.
// Browser luôn fetch sw.js mới nhất khi F5, nên file này sẽ thay thế SW cũ,
// xóa cache vps-maua-* rồi tự unregister.
self.addEventListener("install", () => { self.skipWaiting(); });
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.indexOf("vps-maua") === 0).map((k) => caches.delete(k))))
      .then(() => self.registration.unregister())
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", () => { /* không chặn request, để về mạng trực tiếp */ });
