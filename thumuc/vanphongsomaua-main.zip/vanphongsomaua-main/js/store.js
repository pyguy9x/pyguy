/* js/store.js — globals dung chung (tach tu js/legacy.js).
 * Classic script, load DAU TIEN (truoc modules/utils.js va legacy.js).
 * Dung window.* (khong var/let/const) de tranh clash voi khai bao goc trong legacy.js.
 * Phase 2 moi chuyen const/let goc sang day.
 */
window.SUPABASE_URL = window.SUPABASE_URL || (window.SUPABASE_CONFIG && window.SUPABASE_CONFIG.url) || "https://zipvocbtmilyeuhqqrur.supabase.co";
window.SUPABASE_KEY = window.SUPABASE_KEY || (window.SUPABASE_CONFIG && window.SUPABASE_CONFIG.anonKey) || "";
window.STORAGE_BUCKET = window.STORAGE_BUCKET || "task-files";
window.STAFF_TOKENS = window.STAFF_TOKENS || {};
window.MTTQ_TOKENS = window.MTTQ_TOKENS || {};
window.MTTQ_ADMIN_TOKEN = window.MTTQ_ADMIN_TOKEN || "YOUR_MTTQ_ADMIN_TOKEN";
window.DEPARTMENT_TOKENS = window.DEPARTMENT_TOKENS || {};
window.STAFF_ACTION100_TOKENS = window.STAFF_ACTION100_TOKENS || {};
window.BCH_FULL_TOKENS = window.BCH_FULL_TOKENS || new Set();
window.BCH_BROAD_TOKENS = window.BCH_BROAD_TOKENS || new Set();
window.TTBTV_ALLOWED_TOKENS = window.TTBTV_ALLOWED_TOKENS || new Set();
// CURRENT_USER / editingDataIndex / ACTIVITY_LOG_ROWS / BACKUP_TABLES / DEMO_*: giu trong legacy.js (let/const), phase 2 moi chuyen.
