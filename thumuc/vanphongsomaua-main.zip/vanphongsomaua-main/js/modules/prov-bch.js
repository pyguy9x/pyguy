﻿/* js/modules/prov-bch.js — tach tu js/legacy.js (nhom 5 PROV + BCH).
 * Classic script (window globals), load SAU ttbtv, TRUOC legacy.js.
 */
if(typeof provinceFold!=="function") window.provinceFold=function(s){return String(s??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d").replace(/Đ/g,"D").toLowerCase().trim();};
if(typeof provinceStatusLabel!=="function") window.provinceStatusLabel=function(k){const m={done:"Hoàn thành",overdue:"Quá hạn",processing:"Đang thực hiện"};return m[String(k||"").toLowerCase()]||String(k||"—");};
if(typeof provinceStatusFor!=="function") window.provinceStatusFor=function(x){const k=String(x?.statusKey||x?.status||"processing").toLowerCase();return k==="done"?"done":k==="overdue"?"overdue":"processing";};
if(typeof provinceTaskLeader!=="function") window.provinceTaskLeader=function(x){if(!x) return ""; const off=String(x.officer_name??"").trim(); return off||String(x.role||"—").trim();};

function normalizeBCHOfficer(x) {
    return {
        id: x.id, name: String(x.name ?? "").trim(), token: String(x.token ?? "").trim(),
        title: String(x.title ?? "").trim(), unit: String(x.unit ?? "").trim(), note: String(x.note ?? "").trim()
    };
}

function normalizeBCHTask(x) {
    const obj = {
        id: x.id, officer_name: String(x.officer_name ?? "").trim(),
        task_name: String(x.task_name ?? "").trim(), product: String(x.product ?? "").trim(),
        amount: String(x.amount ?? "").trim(), deadline: String(x.deadline ?? "").trim(),
        result: String(x.result ?? "").trim(), updated_at: x.updated_at || "",
        note: String(x.note ?? "").trim(), phat_sinh: !!x.phat_sinh,
        role: String(x.role ?? "").trim(),
        completed_date: String(x.completed_date ?? "").trim(),
        status: String(x.status ?? "").trim(),
        staff_note: String(x.staff_note ?? "").trim(),
        admin_note: String(x.admin_note ?? "").trim(),
        attachment_path: String(x.attachment_path ?? "").trim(),
        attachment_name: String(x.attachment_name ?? "").trim(),
        attachment_type: String(x.attachment_type ?? "").trim(),
        attachment_size: Number(x.attachment_size ?? 0) || 0,
        attachment_approved: x.attachment_approved === true,
        attachment_approved_at: String(x.attachment_approved_at ?? "").trim(),
        attachment_approved_by: String(x.attachment_approved_by ?? "").trim()
    };
    obj.statusKey = bchStatusFor(obj);
    obj._search = bchFold([obj.officer_name, obj.task_name, obj.product, obj.amount, obj.deadline, obj.result, obj.status, obj.note].join(" "));
    return obj;
}

async function loadBCHData(force = false) {
    if(DEMO_MODE){
        const snap = await getDemoSnapshot();
        const offRaw = Array.isArray(snap.officers) ? snap.officers : [];
        const taskRaw = Array.isArray(snap.tasks) ? snap.tasks : [];
        BCH_OFFICERS = offRaw.map(normalizeBCHOfficer); BCH_TASKS = taskRaw.map(normalizeBCHTask); BCH_LOADED = true;
        try{ writeOfficersCache("bch_officers_cache", BCH_OFFICERS); localStorage.setItem("bch_tasks_cache", JSON.stringify(BCH_TASKS)); }catch(e){}
        rebuildBCHOfficerFilter(); applyBCHFilters(); renderBCHCharts(); if(typeof renderCharts==="function") renderCharts(); if(typeof updateGlobalHonors==="function") updateGlobalHonors();
        const syncD=document.getElementById("bchSyncText"); if(syncD) syncD.textContent=`✅ [DEMO] ${BCH_OFFICERS.length} cán bộ / ${BCH_TASKS.length} nhiệm vụ mẫu`;
        const btnD=document.getElementById("bchRefreshBtn"); if(btnD) btnD.disabled=false;
        return;
    }
    if (BCH_LOADED && !force) { applyBCHFilters(); return; }
    const btn = document.getElementById("bchRefreshBtn");
    const sync = document.getElementById("bchSyncText");
    try {
        if (btn) btn.disabled = true;
        if (sync) sync.textContent = "⏳ Đang đồng bộ public.officers và public.tasks...";
        showTableSkeleton("bchTableBody");
        let offRaw = [], taskRaw = [];
        try { offRaw = await bchFetch(BCH_OFFICERS_API); }
        catch (offErr) {
            console.warn("BCH officers select chi tiết lỗi, thử select=*", offErr);
            offRaw = await bchFetch(`${SUPABASE_URL}/rest/v1/officers?select=*&order=id.asc`);
        }
        try { taskRaw = await bchFetch(BCH_TASKS_API); }
        catch (taskErr) {
            console.warn("BCH tasks select chi tiết lỗi, thử select=*", taskErr);
            taskRaw = await bchFetch(`${SUPABASE_URL}/rest/v1/tasks?select=*&order=id.asc`);
        }
        BCH_OFFICERS = offRaw.map(normalizeBCHOfficer);
        BCH_TASKS = taskRaw.map(normalizeBCHTask);
        BCH_LOADED = true;
        console.info(`[V37 BCH] Supabase: ${BCH_OFFICERS.length} officers / ${BCH_TASKS.length} tasks`);
        writeOfficersCache("bch_officers_cache", BCH_OFFICERS);
        localStorage.setItem("bch_tasks_cache", JSON.stringify(BCH_TASKS));
        writeCache("bch_tasks_cache", BCH_TASKS);
        rebuildBCHOfficerFilter();
        applyBCHFilters();
        renderBCHCharts();
        if (typeof renderCharts === "function") renderCharts();
        if (typeof updateGlobalHonors === "function") updateGlobalHonors();
        if (sync) sync.textContent = `✅ Đã tải ${BCH_OFFICERS.length} cán bộ và ${BCH_TASKS.length} nhiệm vụ BCH lúc ${new Date().toLocaleTimeString("vi-VN")}${(BCH_OFFICERS.length === 29 && BCH_TASKS.length === 426) ? " · Khớp JSON nguồn" : ""}`;
    } catch (e) {
        console.error("Lỗi tải BCH:", e);
        try {
            const oc = readOfficersCache("bch_officers_cache") || readCache("bch_officers_cache") || [];
            const tc = readCache("bch_tasks_cache") || [];
            if (oc.length || tc.length) {
                BCH_OFFICERS = oc.map(normalizeBCHOfficer);
                BCH_TASKS = tc.map(normalizeBCHTask);
                BCH_LOADED = true; rebuildBCHOfficerFilter(); applyBCHFilters(); renderBCHCharts();
                if (typeof renderCharts === "function") renderCharts();
                if (typeof updateGlobalHonors === "function") updateGlobalHonors();
                if (sync) sync.textContent = `⚠️ Mất kết nối · đang dùng cache ${BCH_TASKS.length} nhiệm vụ gần nhất`;
            } else throw e;
        } catch (_) {
            if (sync) sync.textContent = "❌ Không tải được dữ liệu BCH: " + (e.message || e);
            renderBCHTable([]);
        }
    } finally { if (btn) btn.disabled = false; }
}

function rebuildBCHOfficerFilter() {
    const sel = document.getElementById("bchOfficerFilter"); if (!sel) return;
    const current = sel.value;
    const names = [...new Set(BCH_TASKS.map(x => x.officer_name).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
    sel.innerHTML = '<option value="">Tất cả cán bộ</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
    if (names.includes(current)) sel.value = current;
}

function applyBCHFilters() {
    if (!document.getElementById("bchWorkspace")) return;
    const q = bchFold(document.getElementById("bchSearch")?.value || "");
    const officer = document.getElementById("bchOfficerFilter")?.value || "";
    const officerQ = bchFold(document.getElementById("bchOfficerNameFilter")?.value || "");
    const status = document.getElementById("bchStatusFilter")?.value || "all";
    const timeMode = document.getElementById("bchTimeFilter")?.value || "all";
    BCH_TASKS.forEach(x => x.statusKey = bchStatusFor(x));
    BCH_FILTERED = BCH_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (officer && x.officer_name !== officer) return false;
        if (officerQ && !bchFold(x.officer_name || "").includes(officerQ)) return false;
        if (status !== "all" && bchStatusGroup(x.statusKey) !== status) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof BCH_MONTH !== "undefined" && BCH_MONTH) { const d = bchDeadlineDate(x.deadline); if (!d || (d.getMonth() + 1) !== BCH_MONTH) return false; }
        if (typeof BCH_QUARTER !== "undefined" && BCH_QUARTER) { const d = bchDeadlineDate(x.deadline); if (!d || Math.ceil((d.getMonth() + 1) / 3) !== BCH_QUARTER) return false; }
        if (typeof BCH_NODL !== "undefined" && BCH_NODL) { if (bchDeadlineDate(x.deadline)) return false; }
        if (typeof BCH_DL_DATE !== "undefined" && BCH_DL_DATE) { const dd = bchDeadlineDate(x.deadline); if (!dd || new Date(dd.getFullYear(), dd.getMonth(), dd.getDate()).getTime() !== BCH_DL_DATE) return false; }
        else if (typeof BCH_DL_Q !== "undefined" && BCH_DL_Q && !bchFold(x.deadline || "").includes(BCH_DL_Q)) return false;
        return true;
    });
    if (typeof BCH_PAGE !== "undefined") BCH_PAGE = 1;
    renderBCHKPIs();
    renderBCHTable(BCH_FILTERED);
    renderBCHCharts();
}

function openBCHTaskDetail(id) {
    const x = BCH_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    const o = bchOfficerMap().get(bchFold(x.officer_name)) || {};
    const val = v => esc(String(v || "—"));
    const status = bchStatusFor(x);
    document.getElementById("bchDetailSubtitle").textContent = `${x.officer_name || "Chưa phân công"} · ${bchStatusLabel(status)}`;
    document.getElementById("bchDetailBody").innerHTML = `<div class="bch-detail-grid">
                <div class="bch-detail-field"><div class="bch-detail-label">Cán bộ phụ trách</div><div class="bch-detail-value">${val(x.officer_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Chức vụ</div><div class="bch-detail-value">${val(o.title)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Nhiệm vụ cụ thể</div><div class="bch-detail-value">${val(x.task_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Cơ quan chủ trì</div><div class="bch-detail-value">${val(x.role || x.unit_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Chuyên viên phụ trách</div><div class="bch-detail-value">${val(x.specialist_name)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Nguồn giao</div><div class="bch-detail-value">${val(x.source_doc || x.amount)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Văn bản Tỉnh giao</div><div class="bch-detail-value">${val(x.source_doc || x.amount)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Hạn hoàn thành</div><div class="bch-detail-value">${val(x.deadline)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Trạng thái</div><div class="bch-detail-value"><span class="bch-badge ${status}">${bchStatusLabel(status)}</span></div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Phát sinh</div><div class="bch-detail-value">${x.phat_sinh ? "Có" : "Không"}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Kết quả</div><div class="bch-detail-value">${val(x.result || "Chưa điền")}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Ghi chú</div><div class="bch-detail-value">${val(x.note)}</div></div>
            </div>`;
    smoothOpenModal("bchDetailModal");
}

function closeBCHTaskDetail() { smoothCloseModal("bchDetailModal"); }

function getBCHRowsByMode(mode) {
    BCH_TASKS.forEach(x => x.statusKey = bchStatusFor(x));
    const base = (typeof bchScopeRows === "function") ? bchScopeRows() : [...BCH_TASKS];
    if (mode === "processing") return base.filter(x => bchStatusGroup(x.statusKey) === "processing");
    if (mode === "done") return base.filter(x => bchStatusGroup(x.statusKey) === "done");
    if (mode === "overdue") return base.filter(x => bchStatusGroup(x.statusKey) === "overdue");
    return [...base];
}

function openBCHStatusPopup(mode = "all", el = null) {
    BCH_DRILL_MODE = mode;
    document.getElementById("bchWorkspace")?.classList.add("open");
    document.querySelectorAll("#bchSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");

    const labels = {
        all: ["Tất cả nhiệm vụ BCH Đảng bộ", "📋"],
        processing: ["Nhiệm vụ BCH — Đang xử lý", "📌"],
        done: ["Nhiệm vụ BCH — Hoàn thành", "✅"],
        overdue: ["Nhiệm vụ BCH — Quá hạn", "⏰"]
    };
    const meta = labels[mode] || labels.all;
    const officer = document.getElementById("bchOfficerFilter")?.value || "";
    renderBCHDrill(getBCHRowsByMode(mode), meta[0] + (officer ? ` — ${officer}` : ""), meta[1]);
}

function openBCHFilePopup() {
    BCH_TASKS.forEach(x => x.statusKey = bchStatusFor(x));
    const base = (typeof bchScopeRows === "function") ? bchScopeRows() : [...BCH_TASKS];
    const rows = base.filter(x => String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim());
    const officer = document.getElementById("bchOfficerFilter")?.value || "";
    renderBCHDrill(rows, `Nhiệm vụ BCH — Có file đính kèm${officer ? ` — ${officer}` : ""}`, "📎");
}

function applyBCHDrillOrder(rows) {
    const mode = document.getElementById("bchDrillOrder")?.value || "newest"; let out = [...rows];
    if (mode === "with_file") out = out.filter(x => !!x.attachment_path || !!x.attachment_name);
    const due = x => { const d = bchDeadlineDate(x?.deadline); return d ? d.getTime() : null };
    if (mode === "oldest") out.sort((a, b) => bchDrillTimestamp(a) - bchDrillTimestamp(b));
    else if (mode === "due_far") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return B - A });
    else if (mode === "due_near") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return A - B });
    else out = sortNewestFirst(out); return out;
}

function onBCHDrillFilterChange() { let rows = BCH_DRILL_STATE.ids.map(id => BCH_TASKS.find(x => String(x.id) === String(id))).filter(Boolean); const _isPerf = String(BCH_DRILL_STATE.title || "").includes("Hiệu suất nhiệm vụ -"); const status = document.getElementById("bchDrillStatusFilter")?.value || "all"; if(!_isPerf && status!=="all") rows = rows.filter(x => bchStatusGroup(bchStatusFor(x))===status); const selOfficer = document.getElementById("bchDrillOfficerSelect")?.value || ""; if(!_isPerf && selOfficer) rows = rows.filter(x => bchFold(x.officer_name||"")===bchFold(selOfficer)); const q = bchFold(document.getElementById("bchDrillOfficerFilter")?.value || ""); if(q) rows = rows.filter(x => bchFold([x.task_name, x.product, x.result, x.staff_note, x.admin_note, x.note, x.officer_name].join(" ")).includes(q)); renderBCHDrill(rows, BCH_DRILL_STATE.title, BCH_DRILL_STATE.icon, false) }

function appendBCHAddTaskRow() {
    const body = document.getElementById("bchDrillBody");
    if (!body || document.getElementById("bchAddTaskRow")) return;
    body.insertAdjacentHTML("beforeend", renderBCHAddTaskRow());
    if (typeof setupBCHDateFields === 'function') setupBCHDateFields();
}

function openBCHAddTaskPanel() { if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.scope === "bch"))) return; openBCHWorkspace(); openBCHAddModal(); }

function openBCHAddModal() {
    if (!CURRENT_USER) return;
    const isAdmin = CURRENT_USER.role === "admin";
    const names = [...new Set(BCH_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))];
    const wrap = document.getElementById("bchNewOfficerWrap");
    if (wrap) {
        wrap.innerHTML = isAdmin
            ? `<select id="bchNewOfficer">${names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("")}</select>`
            : `<input id="bchNewOfficer" value="${esc(CURRENT_USER.name || "")}" readonly>`;
    }
    ["bchNewTask", "bchNewRole", "bchNewSpecialist", "bchNewDeadline", "bchNewCompleted", "bchNewResult", "bchNewStaffNote", "bchNewAdminNote"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    const st = document.getElementById("bchNewStatus"); if (st) st.value = "Đang triển khai";
    const f = document.getElementById("bchNewAttachment"); if (f) f.value = "";
    const adW = document.getElementById("bchNewAdminWrap"); if (adW) adW.style.display = isAdmin ? "" : "none";
    if (typeof setupBCHDateFields === "function") setupBCHDateFields();
    refreshBCHNewStatus();
    smoothOpenModal("bchAddModal");
}

function closeBCHAddModal() { smoothCloseModal("bchAddModal"); }

function refreshBCHNewStatus() {
    const due = document.getElementById("bchNewDeadline")?.value || "";
    const completed = document.getElementById("bchNewCompleted")?.value || "";
    const result = document.getElementById("bchNewResult")?.value || "";
    const file = document.getElementById("bchNewAttachment")?.files?.[0] || null;
    const key = bchStatusFor({ deadline: due, completed_date: completed, result, product: result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    const out = document.getElementById("bchNewStatus"); if (out) out.value = bchStatusLabel(key);
}

function stageNewBCHModalTask() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["bch", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản BCH được thêm nhiệm vụ."); return;
    }
    const isAdmin = CURRENT_USER.role === "admin";
    const officer = (document.getElementById("bchNewOfficer")?.value || CURRENT_USER.name || "").trim();
    const taskName = (document.getElementById("bchNewTask")?.value || "").trim();
    const role = "";
    const specialist = (document.getElementById("bchNewSpecialist")?.value || "").trim();
    const dueRaw = (document.getElementById("bchNewDeadline")?.value || "").trim();
    const completedRaw = (document.getElementById("bchNewCompleted")?.value || "").trim();
    const result = (document.getElementById("bchNewResult")?.value || "").trim();
    const staffNote = (document.getElementById("bchNewStaffNote")?.value || "").trim();
    const adminNote = isAdmin ? (document.getElementById("bchNewAdminNote")?.value || "").trim() : "";
    const file = document.getElementById("bchNewAttachment")?.files?.[0] || null;
    if (!officer) { showToast("error", "Thiếu lãnh đạo phụ trách", "Vui lòng chọn Lãnh đạo phụ trách."); return; }
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); return; }
    if (!dueRaw) { showToast("error", "Thiếu hạn hoàn thành", "Hạn hoàn thành là trường bắt buộc khi thêm nhiệm vụ."); return; }
    let deadline = "", completedDate = null;
    try {
        deadline = dateToDb(requireValidDate(dueRaw, "Hạn hoàn thành", true)) || "";
        completedDate = completedRaw ? (dateToDb(requireValidDate(completedRaw, "Ngày hoàn thành", false)) || null) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    if (completedDate && !bchHasResult(result) && !file) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Muốn nhập Ngày hoàn thành phải có Kết quả thực hiện hoặc tệp kết quả."); return;
    }
    if (!completedDate && bchHasResult(result)) {
        showToast("error", "Thiếu ngày hoàn thành", "Đã nhập Sản phẩm thì phải nhập Ngày hoàn thành mới lưu được."); return;
    }
    const statusKey = bchStatusFor({ deadline, completed_date: completedDate, result, product: result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    PENDING_BCH_TASK = { addMode: "modal", officer, taskName, role, specialist, deadline, completedDate, result, staffNote, adminNote, file, status: bchStatusLabel(statusKey) };
    openAddConfirm("BCH", PENDING_BCH_TASK, [
        ["Lãnh đạo phụ trách", officer], ["Nhiệm vụ", taskName], ["Chuyên viên phụ trách", specialist],
        ["Hạn hoàn thành", deadline], ["Ngày hoàn thành", completedDate || "Chưa nhập"], ["Trạng thái", bchStatusLabel(statusKey)],
        ["Kết quả thực hiện", result || "Chưa nhập"], ["Tệp kết quả", file ? file.name : "Không có"], ["Ghi chú cán bộ", staffNote || "Không có"], ["Ghi chú Admin", adminNote || "Không có"]
    ]);
}

function refreshBCHAddStatus() {
    const due = document.getElementById("bchAddDeadline")?.value || "";
    const completed = document.getElementById("bchAddCompleted")?.value || "";
    const result = document.getElementById("bchAddResult")?.value || "";
    const file = document.getElementById("bchAddAttachment")?.files?.[0] || null;
    const key = bchStatusFor({ deadline: due, completed_date: completed, result, product: result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    const out = document.getElementById("bchAddStatus"); if (out) out.value = bchStatusLabel(key);
}

function stageNewBCHTask() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["bch", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản BCH được thêm nhiệm vụ."); return;
    }
    const officer = (document.getElementById("bchAddOfficer")?.value || CURRENT_USER.name || "").trim();
    const taskName = (document.getElementById("bchAddTaskName")?.value || "").trim();
    const role = "";
    const specialist = (document.getElementById("bchAddSpecialist")?.value || "").trim();
    const dueRaw = (document.getElementById("bchAddDeadline")?.value || "").trim();
    const completedRaw = (document.getElementById("bchAddCompleted")?.value || "").trim();
    const result = (document.getElementById("bchAddResult")?.value || "").trim();
    const staffNote = (document.getElementById("bchAddStaffNote")?.value || "").trim();
    const file = document.getElementById("bchAddAttachment")?.files?.[0] || null;
    if (!officer) { showToast("error", "Thiếu lãnh đạo phụ trách", "Vui lòng chọn Lãnh đạo phụ trách."); return; }
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); return; }
    if (!dueRaw) { showToast("error", "Thiếu hạn hoàn thành", "Hạn hoàn thành là trường bắt buộc khi thêm nhiệm vụ."); return; }
    let deadline = "", completedDate = null;
    try {
        deadline = dateToDb(requireValidDate(dueRaw, "Hạn hoàn thành", true)) || "";
        completedDate = completedRaw ? (dateToDb(requireValidDate(completedRaw, "Ngày hoàn thành", false)) || null) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    if (completedDate && !bchHasResult(result) && !file) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Muốn nhập Ngày hoàn thành phải có Kết quả thực hiện hoặc tệp kết quả."); return;
    }
    if (!completedDate && bchHasResult(result)) {
        showToast("error", "Thiếu ngày hoàn thành", "Đã nhập Sản phẩm thì phải nhập Ngày hoàn thành mới lưu được."); return;
    }
    const statusKey = bchStatusFor({ deadline, completed_date: completedDate, result, product: result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    PENDING_BCH_TASK = { officer, taskName, role, specialist, deadline, completedDate, result, staffNote, file, status: bchStatusLabel(statusKey) };
    openAddConfirm("BCH", PENDING_BCH_TASK, [
        ["Lãnh đạo phụ trách", officer], ["Nhiệm vụ", taskName], ["Chuyên viên phụ trách", specialist],
        ["Hạn hoàn thành", deadline], ["Ngày hoàn thành", completedDate || "Chưa nhập"], ["Trạng thái", bchStatusLabel(statusKey)],
        ["Kết quả thực hiện", result || "Chưa nhập"], ["Tệp kết quả", file ? file.name : "Không có"], ["Ghi chú cán bộ", staffNote || "Không có"]
    ]);
}

async function confirmNewBCHTask() {
    const p = PENDING_BCH_TASK; if (!p) return;
    const btn = document.getElementById("confirmAddTaskBtn"), old = btn?.textContent || ""; if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang lưu..."; }
    const dbRow = {
        officer_name: p.officer, task_name: p.taskName,
        product: p.result || "", amount: p.specialist || "", deadline: p.deadline || "", result: p.result || "",
        note: "", phat_sinh: false, role: p.role || "", completed_date: p.completedDate,
        status: p.status, staff_note: p.staffNote || "", admin_note: "",
        attachment_path: "", attachment_name: "", attachment_type: "", attachment_size: 0,
        attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "",
        updated_at: new Date().toISOString()
    };
    if (p.adminNote !== undefined) dbRow.admin_note = p.adminNote || "";
    try {
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks`, { method: "POST", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" }, body: JSON.stringify(dbRow) });
        const tx = await r.text();
        if (!r.ok) { let msg = tx; try { const j = JSON.parse(tx); msg = j.message || j.details || j.hint || tx } catch (e) { } throw new Error(msg || `HTTP ${r.status}`); }
        const arr = JSON.parse(tx || "[]"), raw = Array.isArray(arr) ? arr[0] : arr;
        if (!raw) throw new Error("Supabase không trả lại nhiệm vụ vừa tạo.");
        raw.task_name = raw.task_name || p.taskName;
        raw.officer_name = raw.officer_name || p.officer;
        raw.deadline = raw.deadline || p.deadline;
        let obj = normalizeBCHTask(raw);
        if (!obj || !String(obj.task_name||"").trim()) { const fb={...raw, task_name:p.taskName, officer_name:p.officer, deadline:p.deadline, id: raw.id||Date.now()}; obj=normalizeBCHTask(fb); }
        if (!obj || !String(obj.task_name||"").trim()) throw new Error("Không thể chuẩn hóa nhiệm vụ vừa tạo. Raw: "+JSON.stringify(raw).slice(0,300));
        if (p.file) {
            const uploaded = await uploadBCHTaskFile(p.file, obj);
            const finalKey = bchStatusFor({ ...obj, attachment_path: uploaded.path }, { hasFile: true });
            const patch = { attachment_path: uploaded.path, attachment_name: uploaded.name, attachment_type: uploaded.type, attachment_size: uploaded.size, attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "", status: bchStatusLabel(finalKey), updated_at: new Date().toISOString() };
            const pr = await fetch(`${SUPABASE_URL}/rest/v1/tasks?id=eq.${encodeURIComponent(obj.id)}`, { method: "PATCH", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" }, body: JSON.stringify(patch) });
            const ptx = await pr.text(); if (!pr.ok) throw new Error(ptx || `HTTP ${pr.status}`);
        }
        await loadBCHData(true);
        moveTaskToTop(BCH_TASKS, obj.id);
        try { localStorage.setItem("bch_tasks_cache", JSON.stringify(BCH_TASKS)); writeCache("bch_tasks_cache", BCH_TASKS); } catch(e) {}
        const isPrivBch = CURRENT_USER.role === "admin" || isBchPrivilegedViewer(CURRENT_USER);
        if (p.addMode === "modal") { try { closeBCHAddModal(); } catch (e2) {} }
        else {
            const rows = isPrivBch ? BCH_TASKS : BCH_TASKS.filter(x => bchFold(x.officer_name) === bchFold(CURRENT_USER.name));
            renderBCHDrill(rows, isPrivBch ? "Tất cả nhiệm vụ BCH Đảng bộ" : `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤");
        }
        writeActivity("Thêm nhiệm vụ BCH", { task: obj.task_name, owner: obj.officer_name, id: obj.id });
        showToast("success", "Đã thêm nhiệm vụ BCH", "Nhiệm vụ mới đã được lưu trực tiếp vào Supabase.");
        smoothCloseModal("addConfirmModal");
    } catch (e) {
        console.error("Lỗi thêm nhiệm vụ BCH:", e);
        showToast("error", "Không thể thêm nhiệm vụ BCH", e.message || "Vui lòng kiểm tra Supabase.", 6000);
    } finally { PENDING_BCH_TASK = null; if (btn) { btn.disabled = false; btn.textContent = old || "✓ Xác nhận thêm"; } }
}

function openBCHTaskEdit(id) {
    const x = BCH_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    const o = bchOfficerMap().get(bchFold(x.officer_name)) || {};
    BCH_EDIT_ID = x.id;

    const can = canEditBCHTask(x);
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const isOwner = CURRENT_USER && String(CURRENT_USER.name||"").trim() === String(x.officer_name||"").trim();

    document.getElementById("bchEditOwnerLine").textContent = `Cán bộ: ${x.officer_name || "Chưa phân công"} · ${isAdmin ? "Admin đang chỉnh sửa" : isOwner ? "Nhiệm vụ của bạn" : "Chỉ xem"}`;
    document.getElementById("bchEditTask").value = x.task_name || "";

    const due = bchDeadlineDate(x.deadline);
    document.getElementById("bchEditDue").value = due ? formatDate(due) : "";

    const completed = bchCompletedDate(x.completed_date);
    document.getElementById("bchEditCompleted").value = completed ? formatDate(completed) : "";

    document.getElementById("bchEditProduct").value = (x.product && x.product !== "Không") ? x.product : "";
    document.getElementById("bchEditStaffNote").value = x.staff_note || "";
    document.getElementById("bchEditAdminNote").value = x.admin_note || x.note || "";
    document.getElementById("bchEditAttachment").value = "";

    // Quyền giống Văn phòng
    document.getElementById("bchEditTask").readOnly = !isAdmin;
    document.getElementById("bchEditDue").readOnly = !isAdmin;
    document.getElementById("bchEditCompleted").readOnly = !can;
    document.getElementById("bchEditProduct").readOnly = !can;
    document.getElementById("bchEditStaffNote").readOnly = !(isOwner || isAdmin);
    document.getElementById("bchEditAdminNote").readOnly = !isAdmin;
    document.getElementById("bchEditAttachment").disabled = !can;
    syncWorkspaceExtendButton("bchEditExtendBtn", "bch", x);

    document.getElementById("bchStaffNoteHelp").textContent = (isOwner || isAdmin)
        ? "Bạn có thể cập nhật ghi chú bổ sung cho nhiệm vụ này."
        : "Ghi chú của cán bộ phụ trách — Admin cũng có thể sửa.";
    document.getElementById("bchAdminNoteHelp").textContent = isAdmin
        ? "Admin có thể ghi lưu ý/chỉ đạo cho cán bộ."
        : "Ghi chú từ Admin — bạn chỉ có quyền xem.";

    const btn = document.getElementById("bchEditSaveBtn");
    btn.style.display = can || isAdmin ? "inline-flex" : "none";

    const delBtn = document.getElementById("bchEditDeleteBtn");
    if (delBtn) delBtn.style.display = can || isAdmin ? "inline-flex" : "none";

    renderBCHCurrentAttachment(x);
    if (typeof setupBCHDateFields === 'function') setupBCHDateFields();
    refreshBCHAutoStatus();
    smoothOpenModal("bchEditModal");
    focusFirstEditable("bchEditModal");
}

function refreshBCHAutoStatus() {
    const x = BCH_TASKS.find(r => String(r.id) === String(BCH_EDIT_ID)); if (!x) return;
    const selected = document.getElementById("bchEditAttachment")?.files?.[0] || null;
    const key = bchStatusFor(x, {
        deadline: document.getElementById("bchEditDue")?.value || x.deadline,
        completed_date: document.getElementById("bchEditCompleted")?.value || "",
        product: document.getElementById("bchEditProduct")?.value || "",
        hasFile: !!x.attachment_path || !!selected
    });
    const out = document.getElementById("bchEditStatus");
    if (out) out.value = bchStatusLabel(key);
}

function closeBCHTaskEdit() { smoothCloseModal("bchEditModal", () => { BCH_EDIT_ID = null; }); }

async function uploadBCHTaskFile(file, task) {
    if (!file) return null;
    if (file.size > 20 * 1024 * 1024) throw new Error("Tệp vượt quá 20 MB.");
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!new Set(["pdf", "doc", "docx", "xls", "xlsx"]).has(ext)) throw new Error("Chỉ chấp nhận PDF, Word hoặc Excel.");
    return { path: "", name: file.name, type: file.type || "application/octet-stream", size: file.size };
}

async function openBCHAttachment(id, allowPending = false) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xem/tải tệp BCH."); return;
    }
    const x = BCH_TASKS.find(r => String(r.id) === String(id)); if (!x || !x.attachment_path) return;
    if (!x.attachment_approved && !allowPending) {
        showToast("info", "Tệp đang chờ duyệt", "Hãy phê duyệt tệp trước."); return;
    }
    try {
        const r = await fetch(`${SUPABASE_URL}/storage/v1/object/authenticated/${BCH_STORAGE_BUCKET}/${encodePath(x.attachment_path)}`, {
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        if (!r.ok) throw new Error(await r.text());
        const blob = await r.blob(), url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.download = x.attachment_name || "tep-bch";
        document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { showToast("error", "Không mở được tệp", e.message || "Lỗi Storage."); }
}

async function deleteBCHAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xóa tệp BCH."); return;
    }
    const x = BCH_TASKS.find(r => String(r.id) === String(id));
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        showToast("error", "Không có tệp", "Nhiệm vụ này chưa có tệp để xóa."); return;
    }
    if (!confirm(`Xóa thẳng tệp "${x.attachment_name || "Tệp sản phẩm"}"?\n\nTệp sẽ bị xóa khỏi Storage và gỡ khỏi nhiệm vụ BCH.`)) return;

    const oldPath = x.attachment_path;
    try {
        // Xóa file vật lý khỏi Supabase Storage trước.
        const delUrl = oldPath ? `${SUPABASE_URL}/storage/v1/object/${BCH_STORAGE_BUCKET}/${oldPath.split("/").map(encodeURIComponent).join("/")}` : "";
        const dr = delUrl ? await fetch(delUrl, {
            method: "DELETE",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }) : { ok: true, status: 204, text: async () => "" };
        const storageText = await dr.text();
        if (!dr.ok && dr.status !== 404 && !/object not found|not found/i.test(storageText)) {
            throw new Error(storageText || `Storage HTTP ${dr.status}`);
        }

        // Gỡ toàn bộ metadata tệp khỏi nhiệm vụ.
        const patch = {
            attachment_name: null,
            attachment_path: null,
            attachment_type: null,
            attachment_size: null,
            attachment_approved: false,
            attachment_approved_at: null,
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks?id=eq.${encodeURIComponent(id)}`, {
            method: "PATCH",
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                Prefer: "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        let saved = null; try { saved = JSON.parse(tx)?.[0] || null } catch (_) { }
        Object.assign(x, saved || patch);

        // V44: cập nhật giao diện bằng các hàm BCH thực sự đang tồn tại.
        // V43 gọi renderBCHAll() (không được định nghĩa), khiến tệp đã xóa thành công
        // nhưng sau đó vẫn bật toast lỗi "renderBCHAll is not defined".
        renderBCHCurrentAttachment(x);
        applyBCHFilters();
        if (document.getElementById("bchDrillModal")?.classList.contains("open")) {
            renderBCHDrill(
                getBCHRowsByMode(BCH_DRILL_MODE),
                ({ all: "Tất cả nhiệm vụ BCH Đảng bộ", processing: "Nhiệm vụ BCH — Đang xử lý", done: "Nhiệm vụ BCH — Hoàn thành", overdue: "Nhiệm vụ BCH — Quá hạn" })[BCH_DRILL_MODE] || "Nhiệm vụ BCH Đảng bộ",
                ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[BCH_DRILL_MODE] || "🏛️"
            );
        }
        showToast("success", "Đã xóa tệp", "Tệp đã được xóa khỏi nhiệm vụ BCH.");
        writeActivity("BCH - Xóa file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) {
        showToast("error", "Không xóa được tệp", e.message || "Có lỗi khi xóa tệp BCH.");
    }
}

async function approveBCHAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") { showToast("error", "Không có quyền", "Chỉ Admin được phê duyệt tệp."); return; }
    const x = BCH_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    try {
        const patch = {
            attachment_approved: true,
            attachment_approved_at: new Date().toISOString(),
            attachment_approved_by: CURRENT_USER.name || "Admin",
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
            body: JSON.stringify(patch)
        });
        const tx = await r.text(); if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        Object.assign(x, patch); renderBCHCurrentAttachment(x); applyBCHFilters();
        showToast("success", "Đã phê duyệt", "Tệp BCH đã được phê duyệt.");
        writeActivity("BCH - Duyệt file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) { showToast("error", "Không thể phê duyệt", e.message || "Lỗi Supabase."); }
}

async function saveBCHTaskEdit() {
    const x = BCH_TASKS.find(r => String(r.id) === String(BCH_EDIT_ID)); if (!x) return;
    if (!canEditBCHTask(x) && !(CURRENT_USER && CURRENT_USER.role === "admin")) {
        showToast("error", "Không có quyền", "Bạn không có quyền cập nhật nhiệm vụ này."); return;
    }

    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const isOwner = CURRENT_USER && CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name;
    const btn = document.getElementById("bchEditSaveBtn"), old = btn.textContent;
    let uploaded = null;

    try {
        btn.disabled = true; btn.textContent = "⏳ Đang lưu...";
        const file = document.getElementById("bchEditAttachment")?.files?.[0] || null;
        if (file) {
            document.getElementById("bchUploadProgress").style.display = "block";
            uploaded = await uploadBCHTaskFile(file, x);
        }

        // Chỉ Admin được sửa Nội dung + Hạn hoàn thành
        const _bchTaskVal = (document.getElementById("bchEditTask").value || "").trim();
        if (_bchTaskVal !== String(x.task_name||"").trim() && !isAdmin) {
            showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ.");
            document.getElementById("bchEditTask").value = x.task_name || "";
        }
        const _bchDueVal = (document.getElementById("bchEditDue").value || "").trim();
        const _bchOrigDue = String(x.deadline||"").trim();
        if (_bchDueVal !== _bchOrigDue && !isAdmin && _bchDueVal) {
            const origDueNorm = _bchOrigDue ? (function(v){ try{return formatDate(bchDeadlineDate(v));}catch(_){return v;}}) (_bchOrigDue) : "";
            if (_bchDueVal !== origDueNorm) {
                showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành.");
                document.getElementById("bchEditDue").value = origDueNorm ? formatDate(bchDeadlineDate(_bchOrigDue)) : _bchOrigDue;
            }
        }
        const patch = {
            completed_date: dateToDb(document.getElementById("bchEditCompleted").value),
            product: (document.getElementById("bchEditProduct").value || "").trim() || "Không",
            updated_at: new Date().toISOString()
        };

        if (isAdmin) {
            patch.task_name = _bchTaskVal || x.task_name || "";
            patch.deadline = dateToDb(document.getElementById("bchEditDue").value);
            patch.admin_note = (document.getElementById("bchEditAdminNote").value || "").trim();
        }
        if (isOwner) {
            patch.staff_note = (document.getElementById("bchEditStaffNote").value || "").trim();
        }
        if (uploaded) {
            patch.attachment_path = uploaded.path;
            patch.attachment_name = uploaded.name;
            patch.attachment_type = uploaded.type;
            patch.attachment_size = uploaded.size;
            patch.attachment_approved = false;
            patch.attachment_approved_at = null;
            patch.attachment_approved_by = null;
        }

        const temp = { ...x, ...patch };
        if (uploaded) {
            temp.attachment_path = "";
            temp.attachment_name = uploaded.name;
        }
        patch.status = bchStatusLabel(bchStatusFor(temp, { hasFile: !!(temp.attachment_path || temp.attachment_name) }));

        const r = await fetch(`${SUPABASE_URL}/rest/v1/tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) { let msg = tx; try { const j = JSON.parse(tx); msg = j.message || j.details || j.hint || tx } catch (e) { } throw new Error(msg || `HTTP ${r.status}`); }

        Object.assign(x, patch);
        if (uploaded) {
            x.attachment_path = uploaded.path; x.attachment_name = uploaded.name; x.attachment_type = uploaded.type; x.attachment_size = uploaded.size;
            x.attachment_approved = false; x.attachment_approved_at = ""; x.attachment_approved_by = "";
        }
        x.statusKey = bchStatusFor(x);
        x._search = bchFold([x.officer_name, x.task_name, x.product, x.amount, x.deadline, x.result, x.staff_note, x.admin_note].join(" "));
        moveTaskToTop(BCH_TASKS, x.id);
        localStorage.setItem("bch_tasks_cache", JSON.stringify(BCH_TASKS));

        applyBCHFilters();
        if (document.getElementById("bchDrillModal")?.classList.contains("open")) {
            renderBCHDrill(getBCHRowsByMode(BCH_DRILL_MODE),
                ({ all: "Tất cả nhiệm vụ BCH Đảng bộ", processing: "Nhiệm vụ BCH — Đang xử lý", done: "Nhiệm vụ BCH — Hoàn thành", overdue: "Nhiệm vụ BCH — Quá hạn" })[BCH_DRILL_MODE] || "Nhiệm vụ BCH Đảng bộ",
                ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[BCH_DRILL_MODE] || "🏛️");
        }
        closeBCHTaskEdit();
        writeActivity("Sửa nhiệm vụ BCH", { task: x.task_name, owner: x.officer_name, id: x.id });
        showToast("success", "Đã lưu nhiệm vụ BCH", "Dữ liệu đã được cập nhật vào Supabase.");
    } catch (e) {
        console.error(e);
        showToast("error", "Không thể lưu nhiệm vụ BCH", e.message || "Vui lòng chạy migration V30 và kiểm tra Storage.", 6000);
    } finally {
        const p = document.getElementById("bchUploadProgress"); if (p) p.style.display = "none";
        btn.disabled = false; btn.textContent = old || "💾 Lưu thay đổi";
    }
}

function setBCHMonth(m) {
    BCH_MONTH = m || null;
    BCH_QUARTER = null;
    BCH_NODL = false;
    bchSyncMonthStrip();
    applyBCHFilters();
}

function setBCHQuarter(q) {
    BCH_QUARTER = q || null;
    BCH_MONTH = null;
    BCH_NODL = false;
    bchSyncMonthStrip();
    applyBCHFilters();
}

function setBCHNoDeadline() {
    BCH_NODL = !BCH_NODL;
    if (BCH_NODL) { BCH_MONTH = null; BCH_QUARTER = null; }
    BCH_PAGE = 1;
    bchSyncMonthStrip();
    applyBCHFilters();
}

function setBCHStatusFilter(status, el) {
    const sel = document.getElementById("bchStatusFilter"); if (sel) sel.value = status || "all";
    document.querySelectorAll("#bchSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");
    openBCHWorkspace();
    applyBCHFilters();
}

function resetBCHFilters() {
    const q = document.getElementById("bchSearch"), o = document.getElementById("bchOfficerFilter"), oq = document.getElementById("bchOfficerNameFilter"), s = document.getElementById("bchStatusFilter"), t = document.getElementById("bchTimeFilter");
    if (q) q.value = ""; if (o) o.value = ""; if (oq) oq.value = ""; if (s) s.value = "all"; if (t) t.value = "all";
    BCH_MONTH = null; BCH_QUARTER = null; BCH_NODL = false; BCH_DL_Q = ""; BCH_DL_DATE = null; BCH_PAGE = 1;
    ["bchFTask", "bchFLeader", "bchFDeadline"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    const pk = document.getElementById("bchFDeadlinePicker"); if (pk) pk.value = "";
    const fs = document.getElementById("bchFStatus"); if (fs) fs.value = "all";
    document.querySelectorAll("#bchMonthStrip button").forEach(b => b.classList.remove("active"));
    document.querySelectorAll("#bchSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    applyBCHFilters();
}

function openBCHWorkspace(el) {
    if (CURRENT_USER?.role === 'department' && !['vpub','action100'].includes(CURRENT_USER.scope)) return showToast('error', 'Khong co quyen', 'Token co quan chi duoc truy cap KH hanh dong 100 ngay.');
    document.getElementById("officeWorkspace")?.classList.remove("open");
    document.getElementById("action100Workspace")?.classList.remove("open");
    document.getElementById("mttqKpiWorkspace")?.classList.remove("open");
    document.getElementById("nqWorkspace")?.classList.remove("open");
    const ws = document.getElementById("bchWorkspace"); if (!ws) return;
    document.getElementById("ttbtvWorkspace")?.classList.remove("open");
    document.getElementById("provinceWorkspace")?.classList.remove("open");
    ws.classList.add("open");
    const item = el || document.getElementById("bchSidebarItem");
    if (item) {
        document.querySelectorAll(".sidebar-item").forEach(x => x.classList.remove("active"));
        item.classList.add("active");
        const sub = document.getElementById("bchSubmenu"); if (sub) { sub.classList.add("open"); requestAnimationFrame(() => { sub.style.maxHeight = sub.scrollHeight + "px"; }); }
        item.classList.remove("collapsed");
    }
    loadBCHData(false);
    try{ vpSaveLastWs("bchWorkspace"); }catch(e){}
}

function closeBCHWorkspace() {
    document.getElementById("bchWorkspace")?.classList.remove("open");
    document.getElementById("bchSidebarItem")?.classList.remove("active");
    document.querySelectorAll("#bchSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    const home = [...document.querySelectorAll(".sidebar-item")].find(x => x.textContent.includes("Trang chủ"));
    if (home) home.classList.add("active");
}

function normalizePROVOfficer(x) {
    return {
        id: x.id, name: String(x.name ?? "").trim(), token: String(x.token ?? "").trim(),
        title: String(x.title ?? "").trim(), unit: String(x.unit ?? "").trim(), note: String(x.note ?? "").trim()
    };
}

function normalizePROVTask(x) {
    const obj = {
        id: x.id, officer_name: String(x.officer_name ?? "").trim(),
        task_name: String(x.task_name ?? "").trim(), product: String(x.product ?? "").trim(),
        amount: String(x.amount ?? "").trim(), deadline: String(x.deadline ?? "").trim(),
        result: String(x.result ?? "").trim(), updated_at: x.updated_at || "",
        note: String(x.note ?? "").trim(), phat_sinh: !!x.phat_sinh,
        role: String(x.role ?? "").trim(),
        completed_date: String(x.completed_date ?? "").trim(),
        status: String(x.status ?? "").trim(),
        staff_note: String(x.staff_note ?? "").trim(),
        admin_note: String(x.admin_note ?? "").trim(),
        attachment_path: String(x.attachment_path ?? "").trim(),
        attachment_name: String(x.attachment_name ?? "").trim(),
        attachment_type: String(x.attachment_type ?? "").trim(),
        attachment_size: Number(x.attachment_size ?? 0) || 0,
        attachment_approved: x.attachment_approved === true,
        attachment_approved_at: String(x.attachment_approved_at ?? "").trim(),
        attachment_approved_by: String(x.attachment_approved_by ?? "").trim(),
        source_sheet: String(x.source_sheet ?? "").trim(),
        source_row: x.source_row ?? null,
        source_doc: String(x.source_doc ?? "").trim(),
        source_group: String(x.source_group ?? "").trim(),
        unit_name: String(x.unit_name ?? "").trim(),
        specialist_name: String(x.specialist_name ?? "").trim(),
        source_form: String(x.source_form ?? "").trim(),
        issuing_authority: String(x.issuing_authority ?? "").trim(),
        implementation_detail: String(x.implementation_detail ?? "").trim(),
        overdue_reason: String(x.overdue_reason ?? "").trim(),
        source_status: String(x.source_status ?? "").trim(),
        progress: String(x.progress ?? "").trim(),
        van_ban_tinh: String(x.van_ban_tinh ?? "").trim(),
        van_ban_xa: String(x.van_ban_xa ?? "").trim()
    };
    obj.statusKey = provinceStatusFor(obj);
    obj._search = provinceFold([obj.officer_name, obj.task_name, obj.product, obj.amount, obj.deadline, obj.result, obj.status, obj.note, obj.role, obj.source_doc, obj.source_group, obj.unit_name, obj.specialist_name, obj.source_form, obj.issuing_authority, obj.implementation_detail, obj.overdue_reason].join(" "));
    return obj;
}

async function loadPROVData(force = false) {
    if(DEMO_MODE){
        const snap = await getDemoSnapshot();
        const offRaw = Array.isArray(snap.province_officers) ? snap.province_officers : [];
        const taskRaw = Array.isArray(snap.province_tasks) ? snap.province_tasks : [];
        PROV_OFFICERS = offRaw.map(normalizePROVOfficer); PROV_TASKS = taskRaw.map(normalizePROVTask); PROV_LOADED = true;
        try{ writeOfficersCache("province_officers_cache", PROV_OFFICERS); localStorage.setItem("province_tasks_cache", JSON.stringify(PROV_TASKS)); }catch(e){}
        // nạp cây tỉnh giao mẫu nếu có
        try{
            if(Array.isArray(snap.province_plan_blocks) && snap.province_plan_blocks.length){
                // gán vào biến toàn cục nếu có, hoặc render trực tiếp qua provincePlanBlocks
                window.PROVINCE_PLAN_BLOCKS = snap.province_plan_blocks;
                try{ localStorage.setItem("province_plan_blocks_cache", JSON.stringify(snap.province_plan_blocks)); }catch(e){}
                if(typeof provincePlanLoad==="function"){ setTimeout(()=>{ try{ provincePlanLoad(); }catch(e){} }, 600); }
            }
        }catch(e){}
        applyPROVFilters(); renderPROVCharts(); if(typeof renderCharts==="function") renderCharts();
        const s=document.getElementById("provinceSyncText"); if(s) s.textContent=`✅ [DEMO] ${PROV_OFFICERS.length} cán bộ / ${PROV_TASKS.length} nhiệm vụ mẫu`; const b=document.getElementById("provinceRefreshBtn"); if(b) b.disabled=false; return;
    }
    if (PROV_LOADED && !force) { applyPROVFilters(); return; }
    const btn = document.getElementById("provinceRefreshBtn");
    const sync = document.getElementById("provinceSyncText");
    try {
        if (btn) btn.disabled = true;
        if (sync) sync.textContent = "⏳ Đang đồng bộ public.province_officers và public.province_tasks...";
        showTableSkeleton("provinceTableBody");
        let offRaw = [], taskRaw = [];
        try { offRaw = await provinceFetch(PROV_OFFICERS_API); }
        catch (offErr) {
            console.warn("PROV officers select chi tiết lỗi, thử select=*", offErr);
            offRaw = await provinceFetch(`${SUPABASE_URL}/rest/v1/province_officers?select=*&order=id.asc`);
        }
        try { taskRaw = await provinceFetch(PROV_TASKS_API); }
        catch (taskErr) {
            console.warn("PROV tasks select chi tiết lỗi, thử select=*", taskErr);
            taskRaw = await provinceFetch(`${SUPABASE_URL}/rest/v1/province_tasks?select=*&order=id.asc`);
        }
        PROV_OFFICERS = offRaw.map(normalizePROVOfficer);
        PROV_TASKS = taskRaw.map(normalizePROVTask);
        PROV_LOADED = true;
        console.info(`[V37 PROV] Supabase: ${PROV_OFFICERS.length} officers / ${PROV_TASKS.length} tasks`);
        writeOfficersCache("province_officers_cache", PROV_OFFICERS);
        localStorage.setItem("province_tasks_cache", JSON.stringify(PROV_TASKS));
        writeCache("province_tasks_cache", PROV_TASKS);
        rebuildPROVAgencyFilter();
        applyPROVFilters();
        renderPROVCharts();
        if (typeof renderCharts === "function") renderCharts();
        if (typeof updateGlobalHonors === "function") updateGlobalHonors();
        if (sync) sync.textContent = `✅ Đã tải ${PROV_OFFICERS.length} cán bộ và ${PROV_TASKS.length} nhiệm vụ Tỉnh giao lúc ${new Date().toLocaleTimeString("vi-VN")}${(PROV_OFFICERS.length === 10 && PROV_TASKS.length === 72) ? " · Khớp JSON nguồn" : ""}`;
    } catch (e) {
        console.error("Lỗi tải PROV:", e);
        try {
            const oc = readOfficersCache("province_officers_cache") || readCache("province_officers_cache") || [];
            const tc = readCache("province_tasks_cache") || [];
            if (oc.length || tc.length) {
                PROV_OFFICERS = oc.map(normalizePROVOfficer);
                PROV_TASKS = tc.map(normalizePROVTask);
                PROV_LOADED = true; rebuildPROVAgencyFilter(); applyPROVFilters(); renderPROVCharts();
                if (typeof renderCharts === "function") renderCharts();
                if (typeof updateGlobalHonors === "function") updateGlobalHonors();
                if (sync) sync.textContent = `⚠️ Mất kết nối · đang dùng cache ${PROV_TASKS.length} nhiệm vụ gần nhất`;
            } else throw e;
        } catch (_) {
            if (sync) sync.textContent = "❌ Không tải được dữ liệu PROV: " + (e.message || e);
            renderPROVTable([]);
        }
    } finally { if (btn) btn.disabled = false; }
}

function rebuildPROVAgencyFilter() {
    const sel = document.getElementById("provinceOfficerFilter"); if (!sel) return;
    const current = sel.value;
    const nameSet = new Set();
    const addAgencies = value => String(value || '').split(',').map(provinceAgencyLabel).filter(Boolean).forEach(s => nameSet.add(s));
    PROV_TASKS.forEach(x => addAgencies(x.unit_name));
    try {
        const treeRows = getPROVTreeRows(null);
        (treeRows || []).forEach(r => addAgencies(r.unit_name));
    } catch (e) {}
    const agencies = [...nameSet].sort((a, b) => a.localeCompare(b, "vi"));
    sel.innerHTML = '<option value="">Tất cả cơ quan</option>' + agencies.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
    if (agencies.includes(current)) sel.value = current;
}

function applyPROVFilters() {
    if (!document.getElementById("provinceWorkspace")) return;
    const q = provinceFold(document.getElementById("provinceSearch")?.value || "");
    const agency = document.getElementById("provinceOfficerFilter")?.value || "";
    const status = document.getElementById("provinceStatusFilter")?.value || "all";
    const timeMode = document.getElementById("provinceTimeFilter")?.value || "all";
    // Luôn dùng bảng province_tasks (DB) làm nguồn hiển thị chính
    PROV_TASKS.forEach(x => x.statusKey = provinceStatusFor(x));
    PROV_FILTERED = PROV_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (agency && !provinceFold([x.unit_name, x.role].filter(Boolean).join(" ")).includes(provinceFold(agency))) return false;
        if (status !== "all" && provinceStatusGroup(x.statusKey) !== status) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof PROV_MONTH !== "undefined" && PROV_MONTH) { const d = provinceDeadlineDate(x.deadline); if (!d || (d.getMonth()+1)!==PROV_MONTH) return false; }
        return true;
    });
    renderPROVKPIs();
    renderPROVTable(PROV_FILTERED);
    renderPROVCharts();
    try { applyProvincePlanTreeFilter(); } catch (e) { }
}

function setPROVMonth(m){
    PROV_MONTH = m || null;
    try{ document.querySelectorAll("#provinceMonthStrip button").forEach(b=> b.classList.toggle("active", String(b.dataset.month||"")===String(PROV_MONTH||""))); }catch(e){}
    applyPROVFilters();
}

function buildPROVPerfAgencies() {
    const out = [], tree = document.getElementById('provincePlanTree');
    if (!tree || !tree.children.length) return out;
    [...tree.querySelectorAll('.pp-task')].forEach((t, ti) => {
        if (t.style.display === 'none') return;
        [...t.querySelectorAll('.pp-agency')].forEach(ag => {
            const agency = provinceAgencyLabel(ag.querySelector('[data-k=agencyOther]')?.value || ag.querySelector('[data-k=agency]')?.value || '');
            if (!agency) return;
            const persons = [...ag.querySelectorAll('.pp-person')];
            if (!persons.length) { out.push({ agency_name: agency, statusKey: 'processing', _treeIdx: ti }); return; }
            persons.forEach(p => {
                let s = '-';
                try { s = (typeof ppPersonStrictStatus === 'function') ? ppPersonStrictStatus(p) : '-'; } catch (e) {}
                out.push({ agency_name: agency, statusKey: s === 'đúng hạn' || s === 'trước hạn' || s === 'HT quá hạn' ? 'done' : s === 'quá hạn' ? 'overdue' : 'processing', _treeIdx: ti });
            });
        });
    });
    return out;
}

function buildPROVPerfPersons() {
    // Tách từng tên cán bộ phụ trách trong cây (mỗi .pp-person = 1 người), không gộp chuỗi tên, không theo cơ quan.
    const out = [];
    const tree = document.getElementById('provincePlanTree');
    if (!tree || !tree.children.length) return out;
    [...tree.querySelectorAll('.pp-task')].forEach((t, ti) => {
        if (t.style.display === 'none') return;
        t.querySelectorAll('.pp-person').forEach((p) => {
            const name = (p.querySelector('[data-k=name]')?.value || '').trim();
            if (!name) return;
            const fin = (p.querySelector('[data-k=finish]')?.value || '').trim();
            let st;
            if (fin) st = 'done';
            else {
                let s = '-';
                try { s = (typeof ppPersonStrictStatus === 'function') ? ppPersonStrictStatus(p) : '-'; } catch (e) {}
                st = (s === 'quá hạn') ? 'overdue' : 'processing';
            }
            out.push({ officer_name: name, statusKey: st, _treeIdx: ti });
        });
    });
    return out;
}

function buildPROVDeadlineCategories() {
    // Đếm "Thời hạn xử lý" theo từng người trong cây thư mục (mỗi .pp-person = 1 người).
    const out = [];
    const tree = document.getElementById('provincePlanTree');
    if (!tree || !tree.children.length) return out;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    [...tree.querySelectorAll('.pp-task')].forEach((t, ti) => {
        if (t.style.display === 'none') return;
        t.querySelectorAll('.pp-person').forEach(p => {
            const deadline = (p.querySelector('[data-k=deadline]')?.value || '').trim();
            const finish = (p.querySelector('[data-k=finish]')?.value || '').trim();
            let cat;
            if (finish) { cat = 'done'; }
            else {
                const dl = ppParseDate(deadline);
                if (!dl) cat = 'none';
                else {
                    const days = Math.round((dl.getTime() - today.getTime()) / 86400000);
                    cat = days < 0 ? 'overdue' : days <= 7 ? 'soon7' : 'safe';
                }
            }
            out.push({ category: cat, _treeIdx: ti });
        });
    });
    return out;
}

function openPROVTaskDetail(id) {
    const x = PROV_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    const o = provinceOfficerMap().get(provinceFold(x.officer_name)) || {};
    const val = v => esc(String(v || "—"));
    const status = provinceStatusFor(x);
    document.getElementById("provinceDetailSubtitle").textContent = `${x.officer_name || "Chưa phân công"} · ${provinceStatusLabel(status)}`;
    document.getElementById("provinceDetailBody").innerHTML = `<div class="bch-detail-grid">
                <div class="bch-detail-field"><div class="bch-detail-label">STT</div><div class="bch-detail-value">${val(x.id)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Nhiệm vụ Tỉnh giao</div><div class="bch-detail-value">${val(x.task_name)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Văn bản tỉnh</div><div class="bch-detail-value">${val(x.van_ban_tinh || x.source_doc || x.source_form)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Văn bản xã</div><div class="bch-detail-value">${val(x.van_ban_xa || x.source_group || x.issuing_authority)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Cơ quan</div><div class="bch-detail-value">${val(x.unit_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Lãnh đạo (UBND)</div><div class="bch-detail-value">${val(x.officer_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Lãnh đạo phòng chuyên môn</div><div class="bch-detail-value">${val(x.role)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Chuyên viên</div><div class="bch-detail-value">${val(x.specialist_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Hạn hoàn thành</div><div class="bch-detail-value">${val(x.deadline)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Ngày hoàn thành</div><div class="bch-detail-value">${val(x.completed_date || "—")}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Thời gian còn lại</div><div class="bch-detail-value">${val(provinceRemainingText(x))}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Tiến độ</div><div class="bch-detail-value">${val(x.progress)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Trạng thái</div><div class="bch-detail-value"><span class="bch-badge ${status}">${provinceStatusLabel(status)}</span></div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Sản phẩm</div><div class="bch-detail-value">${val(x.product || "Chưa điền")}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Ghi chú</div><div class="bch-detail-value">${val(x.staff_note)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Ghi chú của Admin</div><div class="bch-detail-value">${val(x.admin_note)}</div></div>
            </div>`;
    smoothOpenModal("provinceDetailModal");
}

function closePROVTaskDetail() { smoothCloseModal("provinceDetailModal"); }

function getPROVTreeRows(mode) {
    // Bỏ cây thư mục: luôn dùng bảng province_tasks
    return null;
}

function getPROVRowsByMode(mode) {
    // Ưu tiên bảng province_tasks (đã gộp, không dùng cây thư mục nữa)
    PROV_TASKS.forEach(x => x.statusKey = provinceStatusFor(x));
    let use = [];
    if (mode === "processing") use = PROV_TASKS.filter(x => provinceStatusGroup(x.statusKey) === "processing");
    else if (mode === "done") use = PROV_TASKS.filter(x => provinceStatusGroup(x.statusKey) === "done");
    else if (mode === "overdue") use = PROV_TASKS.filter(x => provinceStatusGroup(x.statusKey) === "overdue");
    else use = [...PROV_TASKS];
    if (use && use.length) return use;
    const treeRows = getPROVTreeRows(mode);
    if (treeRows) return treeRows;
    return [];
}

function openPROVStatusPopup(mode = "all", el = null) {
    PROV_DRILL_MODE = mode;
    document.getElementById("provinceWorkspace")?.classList.add("open");
    document.querySelectorAll("#provinceSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");

    const labels = {
        all: ["Tất cả nhiệm vụ Tỉnh giao", "📋"],
        processing: ["Nhiệm vụ Tỉnh giao — Đang xử lý", "📌"],
        done: ["Nhiệm vụ Tỉnh giao — Hoàn thành", "✅"],
        overdue: ["Nhiệm vụ Tỉnh giao — Quá hạn", "⏰"]
    };
    const meta = labels[mode] || labels.all;
    const base = getPROVRowsByMode("all");
    const filtered = Array.isArray(PROV_FILTERED) ? PROV_FILTERED : base;
    const rows = mode === "all" ? filtered : filtered.filter(x => provinceStatusGroup(x.statusKey || provinceStatusFor(x)) === mode);
    renderPROVDrill(rows, meta[0], meta[1]);
}

function applyPROVDrillOrder(rows) {
    const mode = document.getElementById("provinceDrillOrder")?.value || "newest"; let out = [...rows];
    if (mode === "with_file") out = out.filter(x => !!x.attachment_path || !!x.attachment_name);
    const due = x => { const d = provinceDeadlineDate(x?.deadline); return d ? d.getTime() : null };
    if (mode === "oldest") out.sort((a, b) => provinceDrillTimestamp(a) - provinceDrillTimestamp(b));
    else if (mode === "due_far") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return B - A });
    else if (mode === "due_near") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return A - B });
    else out = sortNewestFirst(out); return out;
}

function onPROVDrillFilterChange() {
    const treeRows = getPROVTreeRows(null);
    const hasTree = treeRows && treeRows.length;
    let rows;
    if (hasTree) {
        rows = PROV_DRILL_STATE.ids.map(id => treeRows.find(r => String(r.id) === String(id))).filter(Boolean);
        if (!rows.length) rows = getPROVTreeRows(PROV_DRILL_MODE) || [];
    } else {
        rows = PROV_DRILL_STATE.ids.map(id => PROV_TASKS.find(x => String(x.id) === String(id))).filter(Boolean);
    }
    const q = provinceFold(document.getElementById("provinceDrillContentFilter")?.value || "");
    if (q) rows = rows.filter(x => provinceFold([x.task_name, x.unit_name, x.officer_name, x.product, x.result, x.progress, x.specialist_name, x.role, x.source_form, x.issuing_authority, x.staff_note, x.admin_note, x.note, x.source_doc, x.source_group].join(" ")).includes(q));
    const timeMode = document.getElementById("provinceDrillTimeFilter")?.value || "";
    if (timeMode) rows = rows.filter(x => { const d = provinceDeadlineDate(x.deadline); return d ? isDateInTimeRange(d, timeMode) : false; });
    const status = document.getElementById("provinceDrillStatusFilter")?.value || "all";
    if (status !== "all") rows = rows.filter(x => provinceStatusGroup(x._isTree ? (x.statusKey || 'processing') : provinceStatusFor(x)) === status);
    renderPROVDrill(rows, PROV_DRILL_STATE.title, PROV_DRILL_STATE.icon, false)
}

function appendPROVAddTaskRow() {
    const body = document.getElementById("provinceDrillBody");
    if (!body || document.getElementById("provinceAddTaskRow")) return;
    body.insertAdjacentHTML("beforeend", renderPROVAddTaskRow());
}

function openPROVAddTaskPanel() { if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["province", "data_entry"].includes(CURRENT_USER.scope)))) return; openPROVWorkspace();
    try{
        const w=document.getElementById("provinceTreeWrapper");
        if(w && w.style.display==="none"){ w.style.display=""; w.removeAttribute("aria-hidden"); const c=document.getElementById("provincePlanCard"); if(c) c.style.display=""; }
    }catch(e){}
    setTimeout(() => { try { document.getElementById("provincePlanCard")?.scrollIntoView({ behavior: "smooth", block: "start" }); } catch (e) {} if (typeof provincePlanAddTask === "function") provincePlanAddTask(); }, 150); }

function refreshPROVAddStatus() {
    const due = document.getElementById("provinceAddDeadline")?.value || "";
    const completed = document.getElementById("provinceAddCompleted")?.value || "";
    const result = document.getElementById("provinceAddProduct")?.value || "";
    const key = provinceStatusFor({ deadline: due, completed_date: completed, result }, { hasFile: false });
    const out = document.getElementById("provinceAddStatus"); if (out) out.value = provinceStatusLabel(key);
    const rem = document.getElementById("provinceAddRemaining");
    if (rem) {
        if (completed) { rem.value = "Đã hoàn thành"; }
        else if (due) {
            const d = parseDate(due); const now = new Date();
            const ms = d.getTime() - now.getTime(); const days = Math.ceil(ms / 86400000);
            rem.value = days > 0 ? `Còn ${days} ngày` : days === 0 ? "Hết hạn hôm nay" : `Trễ ${Math.abs(days)} ngày`;
        } else rem.value = "—";
    }
}

function stageNewPROVTask() {
    if (PENDING_PROV_TASK) return showToast("error", "Đang xử lý", "Một nhiệm vụ đang được thêm, vui lòng chờ hoàn tất.");
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["province", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản Tỉnh giao được thêm nhiệm vụ."); return;
    }
    const addOfficer = (document.getElementById("provinceAddOfficer")?.value || CURRENT_USER.name || "").trim();
    if (!addOfficer) { showToast("error", "Thiếu lãnh đạo phụ trách", "Vui lòng chọn Lãnh đạo (UBND) phụ trách."); return; }
    const taskName = (document.getElementById("provinceAddTaskName")?.value || "").trim();
    const role = (document.getElementById("provinceAddRole")?.value || "").trim();
    const specialist = (document.getElementById("provinceAddSpecialist")?.value || "").trim();
    const unit = (document.getElementById("provinceAddUnit")?.value || "").trim();
    const sourceForm = (document.getElementById("provinceAddSourceForm")?.value || "").trim();
    const issuingAuthority = (document.getElementById("provinceAddIssuingAuthority")?.value || "").trim();
    const progress = (document.getElementById("provinceAddProgress")?.value || "").trim();
    const dueRaw = (document.getElementById("provinceAddDeadline")?.value || "").trim();
    const completedRaw = (document.getElementById("provinceAddCompleted")?.value || "").trim();
    const product = (document.getElementById("provinceAddProduct")?.value || "").trim();
    const staffNote = (document.getElementById("provinceAddStaffNote")?.value || "").trim();
    const adminNote = (document.getElementById("provinceAddAdminNote")?.value || "").trim();
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); return; }
    if (!dueRaw) { showToast("error", "Thiếu hạn hoàn thành", "Hạn hoàn thành là trường bắt buộc khi thêm nhiệm vụ."); return; }
    let deadline = "", completedDate = null;
    try {
        deadline = dateToDb(requireValidDate(dueRaw, "Hạn hoàn thành", true)) || "";
        completedDate = completedRaw ? (dateToDb(requireValidDate(completedRaw, "Ngày hoàn thành", false)) || null) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    if (completedDate && !provinceHasProduct(product) && !progress) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Muốn nhập Ngày hoàn thành phải có Sản phẩm hoặc Tiến độ hoàn thành."); return;
    }
    const statusKey = provinceStatusFor({ deadline, completed_date: completedDate, result: product }, { hasFile: false });
    PENDING_PROV_TASK = { addOfficer, taskName, role, specialist, unit, sourceForm, issuingAuthority, progress, deadline, completedDate, product, staffNote, adminNote, status: provinceStatusLabel(statusKey) };
    openAddConfirm("Tỉnh giao", PENDING_PROV_TASK, [
        ["Nhiệm vụ", taskName], ["Văn bản tỉnh", sourceForm], ["Văn bản xã", issuingAuthority],
        ["Cơ quan", unit], ["Lãnh đạo (UBND)", addOfficer], ["Lãnh đạo phòng chuyên môn", role], ["Chuyên viên", specialist],
        ["Hạn hoàn thành", deadline], ["Ngày hoàn thành", completedDate || "Chưa nhập"],
        ["Thời gian còn lại", provinceRemainingText({ deadline, completed_date: completedDate })],
        ["Tiến độ", progress], ["Trạng thái", provinceStatusLabel(statusKey)], ["Sản phẩm", product || "Chưa nhập"],
        ["Ghi chú", staffNote || "Không có"], ["Ghi chú của Admin", adminNote || "Không có"]
    ]);
}

async function confirmNewPROVTask() {
  if (typeof showToast === 'function') showToast('info','Chức năng đang làm lại');
  console.log('[STUB] confirmNewPROVTask blocked');
  return;
}



function mirrorProvinceDoneDate(el) {
    const completedEl = document.getElementById("provinceEditCompleted");
    if (!completedEl) return;
    completedEl.value = el.value || "";
    try { if (typeof refreshPROVAutoStatus === "function") refreshPROVAutoStatus(); } catch (e) {}
}

function openPROVTaskEdit(id) {
    let x = PROV_TASKS.find(r => String(r.id) === String(id));
    let isTreeEdit = false;
    if (!x) {
        try{
            const tRows = getPROVTreeRows(null) || [];
            const found = tRows.find(r=> String(r.id)===String(id));
            if(found){ x=found; isTreeEdit=true; PROV_TREE_EDIT_IDX=found._treeIdx; }
            else{
                const m=String(id).match(/^tree-(\d+)$/);
                if(m){ const idx=parseInt(m[1],10); const tr=tRows.find(r=>r._treeIdx===idx); if(tr){ x=tr; isTreeEdit=true; PROV_TREE_EDIT_IDX=idx; } }
            }
        }catch(e){}
    } else { PROV_TREE_EDIT_IDX=null; }
    if (!x) return;
    const o = provinceOfficerMap().get(provinceFold(x.officer_name)) || {};
    PROV_EDIT_ID = x.id;
    if(isTreeEdit) PROV_EDIT_ID = x.id;
    // Dùng dữ liệu DB thực tế cho popup (không dùng dữ liệu cây cũ bị mask)
    if(isTreeEdit && PROV_EDIT_ID && !String(PROV_EDIT_ID).includes("-")){
      try{
        const dbX = (typeof PROV_TASKS !== "undefined" ? PROV_TASKS.find(r => String(r.id) === String(PROV_EDIT_ID)) : null);
        if(dbX) x = dbX;
      }catch(e){}
    }
    // Nếu mở từ cây cũ (UUID) thì tìm task tương ứng trong province_tasks để lưu đúng bảng
    if(isTreeEdit && String(PROV_EDIT_ID).includes("-")){
      try{
        if(typeof PROV_TASKS !== "undefined"){
          const kTask = (String(x.task_name||"").trim().substring(0,80)).toLowerCase();
          const match = PROV_TASKS.find(r => {
            const rTask = (String(r.task_name||"").trim().substring(0,80)).toLowerCase();
            const rOff = String(r.officer_name||"").trim().toLowerCase();
            const off = String(x.officer_name||"").trim().toLowerCase();
            const rUnit = String(r.unit_name||"").trim().toLowerCase();
            const un = String(x.unit_name||"").trim().toLowerCase();
            return (kTask === rTask || (kTask.length>10 && rTask.includes(kTask.substring(0,20)))) && (rOff === off || (off.length>2 && rOff.includes(off.substring(0,4)))) && rUnit === un;
          });
          if(match && match.id && !String(match.id).includes("-")) PROV_EDIT_ID = String(match.id);
        }
      }catch(e){}
    }

    const can = canEditPROVTask(x);
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const isOwner = provinceUserOwnsTask(x);

    document.getElementById("provinceEditOwnerLine").textContent = `Lãnh đạo: ${x.officer_name || "Chưa phân công"} · ${isAdmin ? "Admin chỉnh sửa trường nghiệp vụ · Trạng thái tự động" : isOwner ? "Nhiệm vụ của bạn" : "Chỉ xem"}`;

    const officerInput = document.getElementById("provinceEditOfficer");
    if (officerInput) {
        if(officerInput.tagName==="SELECT"){
            const names = [...new Set(PROV_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))];
            if (x.officer_name && !names.includes(x.officer_name)) names.unshift(x.officer_name);
            officerInput.innerHTML = names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
            if (!names.length) officerInput.innerHTML = '<option value="">Chưa phân công</option>';
            officerInput.value = x.officer_name || "";
        } else {
            officerInput.value = x.officer_name || "";
        }
    }

    document.getElementById("provinceEditTask").value = x.task_name || "";
    // Văn bản tỉnh/xã — menu xổ xuống (mỗi nhiệm vụ 1 tỉnh + 1 xã)
    try{
        let vbTinhVal=String(x.source_doc || x.van_ban_tinh || "").trim().split('\n')[0]||"";
        let vbXaVal=String(x.source_group || x.van_ban_xa || "").trim().split('\n')[0]||"";
        if(PROV_TREE_EDIT_IDX!==null && x._taskEl){
            try{
                const tDocsTinh=[...x._taskEl.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean)[0]||"";
                const tDocsXa=[...x._taskEl.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean)[0]||"";
                if(tDocsTinh) vbTinhVal=tDocsTinh;
                if(tDocsXa) vbXaVal=tDocsXa;
            }catch(e){}
        }
        if(typeof populateProvinceVanBanSelects==="function") populateProvinceVanBanSelects(vbTinhVal, vbXaVal);
    }catch(e){}
    try{ const sf=document.getElementById("provinceEditSourceForm"); if(sf) sf.value = x.source_form || ""; }catch(e){}
    try{ const ia=document.getElementById("provinceEditIssuingAuthority"); if(ia) ia.value = x.issuing_authority || ""; }catch(e){}
    // Cơ quan - select, khớp data Tỉnh như TT/BTV, tự thêm option lạ
    try{
        const unitSel=document.getElementById("provinceEditUnit");
        if(unitSel){
            const curUnit=String(x.unit_name||"").trim();
            if(curUnit && ![...unitSel.options].some(o=>o.value===curUnit)){
                // nếu là cơ quan lạ, thêm tạm vào select
                const opt=document.createElement("option"); opt.value=curUnit; opt.textContent=curUnit;
                const other=[...unitSel.options].find(o=>o.value==="__other__");
                if(other) unitSel.insertBefore(opt, other); else unitSel.appendChild(opt);
            }
            unitSel.value=x.unit_name||"";
            unitSel.dataset.prev=unitSel.value;
            if(typeof provinceSyncRoleGroup==="function") provinceSyncRoleGroup(unitSel);
        }
    }catch(e){}
    document.getElementById("provinceEditRole").value = (function(){
        let v = String(x.role ?? "").trim();
        if(v) return v;
        // Nhiệm vụ từ cây thư mục không có role: lấy tên người ở hàng "Lãnh đạo phòng" trong DOM cây
        try{
            if(x._taskEl){
                const rows = [...x._taskEl.querySelectorAll(".pp-person")];
                const hit = rows.find(r => /l[aã]nh\s*đ[aạ]o\s*ph[oò]ng/i.test(r.querySelector("span")?.textContent || ""));
                const nv = (hit?.querySelector("[data-k=name]")?.value ?? hit?.querySelector("[data-k=name]")?.textContent ?? "").trim();
                if(nv && nv !== "__other__") return nv;
            }
        }catch(e){}
        // Dữ liệu cũ chỉ lưu tên ở officer_name: cơ quan khác UBND xã thì Lãnh đạo phòng khớp Lãnh đạo phụ trách
        try{
            const isUBND = (typeof provinceIsUBND === "function") ? provinceIsUBND(x.unit_name) : false;
            if(!isUBND) return String(x.officer_name ?? "").trim();
        }catch(e){}
        return "";
    })();
    document.getElementById("provinceEditSpecialist").value = x.specialist_name || "";
    // Điền Vai trò thực hiện từ note JSON (giống TT/BTV)
    try{ if(typeof provinceFillEditRoles==="function") provinceFillEditRoles(x); }catch(e){}
    document.getElementById("provinceEditProgress").value = x.progress || "";

    const due = provinceDeadlineDate(x.deadline);
    document.getElementById("provinceEditDue").value = due ? formatDate(due) : "";

    const completed = provinceCompletedDate(x.completed_date);
    document.getElementById("provinceEditCompleted").value = completed ? formatDate(completed) : "";

    document.getElementById("provinceEditProduct").value = (x.product && x.product !== "Không" && x.product !== "Chưa điền") ? x.product : "";
    document.getElementById("provinceEditStatus").value = provinceStatusLabel(x.statusKey || provinceStatusFor(x));
    document.getElementById("provinceEditStaffNote").value = x.staff_note || "";
    // Ghi chú Admin: nếu note là JSON roles thì không lấy note làm admin_note
    try{
        const isRolesNote = provinceParseRoleNote(x.note);
        document.getElementById("provinceEditAdminNote").value = x.admin_note || (isRolesNote ? "" : (x.note||""));
    }catch(e){ document.getElementById("provinceEditAdminNote").value = x.admin_note || x.note || ""; }
    document.getElementById("provinceEditAttachment").value = "";
    refreshPROVAutoRemaining();
    try{ if(typeof provinceRefreshRoleStatuses==="function") provinceRefreshRoleStatuses(); }catch(e){}

    // V48: Admin + CV nhập liệu sửa trường nghiệp vụ Tỉnh giao; cán bộ chỉ cập nhật phần thực hiện.
    // CV nhập liệu: khóa Nội dung nhiệm vụ + Hạn hoàn thành (chỉ Admin).
    const fullProv = isAdmin || CURRENT_USER?.scope === "data_entry";
    document.getElementById("provinceEditOfficer").disabled = !fullProv;
    document.getElementById("provinceEditTask").readOnly = !isAdmin;
    try{ const sf=document.getElementById("provinceEditSourceForm"); if(sf) sf.readOnly = !fullProv; }catch(e){}
    try{ const ia=document.getElementById("provinceEditIssuingAuthority"); if(ia) ia.readOnly = !fullProv; }catch(e){}
    const unitEl=document.getElementById("provinceEditUnit"); if(unitEl){ unitEl.disabled=!fullProv; }
    document.getElementById("provinceEditRole").readOnly = !fullProv;
    // Lãnh đạo UBND giờ là text, cho phép tự nhập
    const offTextEl=document.getElementById("provinceEditOfficer");
    if(offTextEl){
        if(offTextEl.tagName==="SELECT") offTextEl.disabled=!fullProv;
        else offTextEl.readOnly=!fullProv;
    }
    // Hạn hoàn thành: chỉ token Admin mới sửa được
    document.getElementById("provinceEditDue").readOnly = !isAdmin;
    document.getElementById("provinceEditStatus").readOnly = true;
    document.getElementById("provinceEditSpecialist").readOnly = !fullProv;
    // Vai trò chi tiết: Hạn hoàn thành chỉ Admin; Ngày hoàn thành cán bộ/Admin sửa được
    try{
        const lockRole = !fullProv;
        ["provinceEditRoleUBNDDue","provinceEditRoleUBNDDone","provinceEditRoleUBNDResult","provinceEditRoleUBNDReason",
         "provinceEditRolePhongDue","provinceEditRolePhongDone","provinceEditRolePhongResult","provinceEditRolePhongReason",
         "provinceEditRoleCVDue","provinceEditRoleCVDone","provinceEditRoleCVResult","provinceEditRoleCVReason"].forEach(id=>{
            const el=document.getElementById(id);
            if(!el) return;
            if(id.includes("Due")){
                el.readOnly = !isAdmin;
            } else if(id.includes("Done")){
                el.readOnly = !can;
            } else {
                el.readOnly = lockRole && !can;
            }
        });
        // Tên trong vai trò: Admin/CV mới sửa được Họ tên
        const offEl2=document.getElementById("provinceEditOfficer");
        if(offEl2){
            if(offEl2.tagName==="SELECT") offEl2.disabled=!fullProv;
            else offEl2.readOnly=!fullProv;
        }
        document.getElementById("provinceEditRole").readOnly = !fullProv;
        document.getElementById("provinceEditSpecialist").readOnly = !fullProv;
    }catch(e){}
    document.getElementById("provinceEditCompleted").readOnly = !can;
    document.getElementById("provinceEditProduct").readOnly = !can;
    document.getElementById("provinceEditProgress").readOnly = !can;
    document.getElementById("provinceEditStaffNote").readOnly = !(isOwner || isAdmin);
    document.getElementById("provinceEditAdminNote").readOnly = !isAdmin;
    document.getElementById("provinceEditAttachment").disabled = !can;
    syncWorkspaceExtendButton("provinceEditExtendBtn", "province", x);

    document.getElementById("provinceStaffNoteHelp").textContent = (isOwner || isAdmin)
        ? "Bạn có thể cập nhật ghi chú bổ sung cho nhiệm vụ này."
        : "Ghi chú của cán bộ phụ trách — Admin cũng có thể sửa.";
    document.getElementById("provinceAdminNoteHelp").textContent = isAdmin
        ? "Admin có thể ghi lưu ý/chỉ đạo cho cán bộ."
        : "Ghi chú từ Admin — bạn chỉ có quyền xem.";

    const btn = document.getElementById("provinceEditSaveBtn");
    btn.style.display = can || isAdmin ? "inline-flex" : "none";

    const delBtn = document.getElementById("provinceEditDeleteBtn");
    if (delBtn) delBtn.style.display = can || isAdmin ? "inline-flex" : "none";

    renderPROVCurrentAttachment(x);
    refreshPROVAutoStatus();
    smoothOpenModal("provinceEditModal");
    focusFirstEditable("provinceEditModal");
}

function refreshPROVAutoRemaining() {
    const x = PROV_TASKS.find(r => String(r.id) === String(PROV_EDIT_ID));
    const rem = document.getElementById("provinceEditRemaining"); if (!rem) return;
    // Nếu đang ở modal Tỉnh với group vai trò, ưu tiên Hạn của lãnh đạo chính để tính còn lại (khớp TT/BTV)
    let due = "";
    try{
        const unitSel=document.getElementById("provinceEditUnit");
        const isUBND=unitSel ? provinceIsUBND(unitSel.value) : false;
        const leaderDue=isUBND ? (document.getElementById("provinceEditRoleUBNDDue")?.value||"") : (document.getElementById("provinceEditRolePhongDue")?.value||"");
        const leaderHasData=leaderDue || document.getElementById(isUBND?"provinceEditRoleUBNDDone":"provinceEditRolePhongDone")?.value || document.getElementById(isUBND?"provinceEditRoleUBNDResult":"provinceEditRolePhongResult")?.value;
        if(leaderHasData) due=leaderDue;
        else due=document.getElementById("provinceEditDue")?.value || (x?.deadline || "");
    }catch(e){ due=document.getElementById("provinceEditDue")?.value || (x?.deadline || ""); }
    const completed = document.getElementById("provinceEditCompleted")?.value || "";
    // Nếu group đã hoàn thành (theo logic roles) thì cũng hiển thị Đã hoàn thành
    try{
        const rolesLive=provinceCollectEditRoles();
        const gk=provinceGroupKeyFromRoles(rolesLive, provinceDeadlineDate(due), provinceCompletedDate(completed), document.getElementById("provinceEditUnit")?.value||x.unit_name);
        if(gk && ["early","ontime","latedone","done"].includes(gk)){ rem.value="Đã hoàn thành"; return; }
    }catch(e){}
    if (completed) { rem.value = "Đã hoàn thành"; return; }
    if (!due) { rem.value = "—"; return; }
    const d = parseDate(due); if (!d) { rem.value = "—"; return; }
    const days = Math.ceil((d.getTime() - new Date().getTime()) / 86400000);
    rem.value = days > 0 ? `Còn ${days} ngày` : days === 0 ? "Hết hạn hôm nay" : `Trễ ${Math.abs(days)} ngày`;
}

function refreshPROVAutoStatus() {
    try{ if(typeof provinceRefreshRoleStatuses==="function") provinceRefreshRoleStatuses(); }catch(e){}
    const x = PROV_TASKS.find(r => String(r.id) === String(PROV_EDIT_ID));
    const isNew = !x;
    const selected = document.getElementById("provinceEditAttachment")?.files?.[0] || null;
    const product = document.getElementById("provinceEditProduct")?.value || "";
    const progress = document.getElementById("provinceEditProgress")?.value || "";
    // Khi thêm mới chưa có x, vẫn tính trạng thái từ input để per-role đã nhảy
    const base = x || { deadline:"", completed_date:"", result:"", attachment_path:"", note:"", unit_name: document.getElementById("provinceEditUnit")?.value || "" };
    const key = provinceStatusFor(base, {
        deadline: document.getElementById("provinceEditDue")?.value || base.deadline,
        completed_date: document.getElementById("provinceEditCompleted")?.value || "",
        result: product,
        hasFile: !!(base.attachment_path || selected) || provinceHasResult(progress),
        roles: (()=>{ try{ return provinceCollectEditRoles(); }catch(e){ return undefined; } })(),
        role: document.getElementById("provinceEditUnit")?.value || base.unit_name,
        unit_name: document.getElementById("provinceEditUnit")?.value || base.unit_name
    });
    const out = document.getElementById("provinceEditStatus");
    if (out) out.value = provinceStatusLabel(key);
    refreshPROVAutoRemaining();
}

function closePROVTaskEdit() { smoothCloseModal("provinceEditModal", () => { PROV_EDIT_ID = null; PROV_TREE_EDIT_IDX=null; }); }

function openPROVAddModal(){
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["province", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error","Không có quyền","Chỉ Admin hoặc cán bộ Tỉnh giao được thêm nhiệm vụ."); return;
    }
    PROV_EDIT_ID = null; PROV_TREE_EDIT_IDX = null;
    // Mở modal Thêm (dùng chung provinceEditModal nhưng reset form)
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    document.getElementById("provinceEditOwnerLine").textContent = isAdmin ? "Admin thêm nhiệm vụ mới" : "Thêm nhiệm vụ Tỉnh giao";
    document.getElementById("provinceEditTask").value = "";
    const unitSelAdd=document.getElementById("provinceEditUnit"); if(unitSelAdd){ unitSelAdd.value=""; unitSelAdd.dataset.prev=""; try{ if(typeof provinceSyncRoleGroup==="function") provinceSyncRoleGroup(unitSelAdd); }catch(e){} }
    const offSel=document.getElementById("provinceEditOfficer");
    if(offSel){
        if(offSel.tagName==="SELECT"){
            const names=[...new Set(PROV_OFFICERS.map(o=>String(o.name||"").trim()).filter(Boolean))];
            offSel.innerHTML=names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join("")||'<option value="">Chưa phân công</option>';
            offSel.value=CURRENT_USER.name||names[0]||"";
        } else {
            offSel.value=CURRENT_USER.name||"";
        }
    }
    document.getElementById("provinceEditRole").value="";
    document.getElementById("provinceEditSpecialist").value="";
    document.getElementById("provinceEditDue").value="";
    document.getElementById("provinceEditCompleted").value="";
    document.getElementById("provinceEditProduct").value="";
    document.getElementById("provinceEditProgress").value="";
    document.getElementById("provinceEditStatus").value="Đang triển khai";
    document.getElementById("provinceEditStaffNote").value="";
    document.getElementById("provinceEditAdminNote").value="";
    document.getElementById("provinceEditAttachment").value="";
    try{ populateProvinceVanBanSelects("",""); }catch(e){}
    // Reset vai trò giống TT/BTV
    try{
        ["provinceEditRoleUBNDDue","provinceEditRoleUBNDDone","provinceEditRoleUBNDResult","provinceEditRoleUBNDReason","provinceEditRoleUBNDStatus",
         "provinceEditRolePhongDue","provinceEditRolePhongDone","provinceEditRolePhongResult","provinceEditRolePhongReason","provinceEditRolePhongStatus",
         "provinceEditRoleCVDue","provinceEditRoleCVDone","provinceEditRoleCVResult","provinceEditRoleCVReason","provinceEditRoleCVStatus"].forEach(id=>{
            const el=document.getElementById(id); if(el) el.value=id.includes("Status")?"—":"";
        });
        if(typeof provinceRefreshRoleStatuses==="function") provinceRefreshRoleStatuses();
    }catch(e){}
    // Mở khóa các trường cho Admin
    document.getElementById("provinceEditTask").readOnly=!isAdmin;
    document.getElementById("provinceEditDue").readOnly=!isAdmin;
    document.getElementById("provinceEditOfficer").disabled=false;
    const unitAddEl=document.getElementById("provinceEditUnit"); if(unitAddEl) unitAddEl.disabled=false;
    document.getElementById("provinceEditRole").readOnly=false;
    document.getElementById("provinceEditSpecialist").readOnly=false;
    document.getElementById("provinceEditCompleted").readOnly=false;
    document.getElementById("provinceEditProduct").readOnly=false;
    document.getElementById("provinceEditProgress").readOnly=false;
    document.getElementById("provinceEditStaffNote").readOnly=false;
    document.getElementById("provinceEditAdminNote").readOnly=!isAdmin;
    document.getElementById("provinceEditAttachment").disabled=false;
    const delBtn=document.getElementById("provinceEditDeleteBtn"); if(delBtn) delBtn.style.display="none";
    const extBtn=document.getElementById("provinceEditExtendBtn"); if(extBtn) extBtn.style.display="none";
    const saveBtn=document.getElementById("provinceEditSaveBtn"); if(saveBtn) saveBtn.textContent="💾 Thêm nhiệm vụ";
    renderPROVCurrentAttachment({attachment_path:"",attachment_name:""});
    refreshPROVAutoStatus();
    smoothOpenModal("provinceEditModal");
    focusFirstEditable("provinceEditModal");
}

async function deletePROVTask() { deletePROVTaskById(PROV_EDIT_ID); }

async function deletePROVTaskById(id) {
    const x = PROV_TASKS.find(r => String(r.id) === String(id));
    if (!x) { showToast("error", "Không thể xóa nhiệm vụ", "Không tìm thấy nhiệm vụ."); return; }
    if (!canEditPROVTask(x)) { showToast("error", "Không có quyền", "Bạn không có quyền xóa nhiệm vụ này."); return; }
    const isEditing = String(PROV_EDIT_ID ?? "") === String(x.id);

    const hasFile = !!x.attachment_path || !!x.attachment_name;
    const name = x.task_name || "Nhiệm vụ";
    const summary = `
                <div class="confirm-row"><span>Cán bộ</span><strong>${esc(x.officer_name || "")}</strong></div>
                <div class="confirm-row"><span>Nhiệm vụ</span><strong>${esc(name)}</strong></div>
                ${hasFile ? `<div class="confirm-row"><span>Tệp đính kèm</span><strong>${esc(x.attachment_name || "Có")}</strong></div><div class="confirm-note">Lưu ý: nếu chọn "Không, chỉ xóa nhiệm vụ", tệp vẫn được giữ lại trong Storage.</div>` : ""}
            `;
    openDeleteTaskConfirm({
        label: `Xóa nhiệm vụ "${name}"?`,
        summary,
        hasFile,
        onConfirm: async (deleteFile) => {
            try {
                if (deleteFile && x.attachment_path) {
                    const delUrl = `${SUPABASE_URL}/storage/v1/object/${PROV_STORAGE_BUCKET}/${x.attachment_path.split("/").map(encodeURIComponent).join("/")}`;
                    const dr = await fetch(delUrl, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                    if (!dr.ok && dr.status !== 404) { const tx = await dr.text(); throw new Error(tx || `Storage HTTP ${dr.status}`); }
                }
                const delUrl2 = `${SUPABASE_URL}/rest/v1/province_tasks?id=eq.${encodeURIComponent(x.id)}`;
                const r = await fetch(delUrl2, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (!r.ok && r.status !== 404) { const tx = await r.text(); throw new Error(tx || `HTTP ${r.status}`); }

                const di = PROV_TASKS.findIndex(t => String(t.id) === String(x.id));
                if (di >= 0) PROV_TASKS.splice(di, 1);
                localStorage.setItem("province_tasks_cache", JSON.stringify(PROV_TASKS));
                applyPROVFilters();
                if (document.getElementById("provinceDrillModal")?.classList.contains("open")) {
                    renderPROVDrill(getPROVRowsByMode(PROV_DRILL_MODE),
                        ({ all: "Tất cả nhiệm vụ Tỉnh giao Đảng bộ", processing: "Nhiệm vụ PROV — Đang xử lý", done: "Nhiệm vụ PROV — Hoàn thành", overdue: "Nhiệm vụ PROV — Quá hạn" })[PROV_DRILL_MODE] || "Nhiệm vụ Tỉnh giao",
                        ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[PROV_DRILL_MODE] || "🏢");
                }
                if (isEditing) closePROVTaskEdit();
                writeActivity("Xóa nhiệm vụ Tỉnh giao", { task: name, owner: x.officer_name, id: x.id });
                showToast("success", "Đã xóa nhiệm vụ", `Đã xóa nhiệm vụ "${name}".`);
            } catch (e) {
                console.error(e);
                showToast("error", "Không thể xóa nhiệm vụ", e.message || "Vui lòng thử lại.", 6000);
            }
        }
    });
}

async function uploadPROVTaskFile(file, task) {
    if (!file) return null;
    if (file.size > 20 * 1024 * 1024) throw new Error("Tệp vượt quá 20 MB.");
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!new Set(["pdf", "doc", "docx", "xls", "xlsx"]).has(ext)) throw new Error("Chỉ chấp nhận PDF, Word hoặc Excel.");
    return { path: "", name: file.name, type: file.type || "application/octet-stream", size: file.size };
}

async function openPROVAttachment(id, allowPending = false) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xem/tải tệp PROV."); return;
    }
    const x = PROV_TASKS.find(r => String(r.id) === String(id)); if (!x || !x.attachment_path) return;
    if (!x.attachment_approved && !allowPending) {
        showToast("info", "Tệp đang chờ duyệt", "Hãy phê duyệt tệp trước."); return;
    }
    try {
        const r = await fetch(`${SUPABASE_URL}/storage/v1/object/authenticated/${PROV_STORAGE_BUCKET}/${encodePath(x.attachment_path)}`, {
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        if (!r.ok) throw new Error(await r.text());
        const blob = await r.blob(), url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.download = x.attachment_name || "tep-province";
        document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { showToast("error", "Không mở được tệp", e.message || "Lỗi Storage."); }
}

async function deletePROVAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xóa tệp PROV."); return;
    }
    const x = PROV_TASKS.find(r => String(r.id) === String(id));
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        showToast("error", "Không có tệp", "Nhiệm vụ này chưa có tệp để xóa."); return;
    }
    if (!confirm(`Xóa thẳng tệp "${x.attachment_name || "Tệp sản phẩm"}"?\n\nTệp sẽ bị xóa khỏi Storage và gỡ khỏi nhiệm vụ Tỉnh giao.`)) return;

    const oldPath = x.attachment_path;
    try {
        // Xóa file vật lý khỏi Supabase Storage trước.
        const delUrl = oldPath ? `${SUPABASE_URL}/storage/v1/object/${PROV_STORAGE_BUCKET}/${oldPath.split("/").map(encodeURIComponent).join("/")}` : "";
        const dr = delUrl ? await fetch(delUrl, {
            method: "DELETE",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }) : { ok: true, status: 204, text: async () => "" };
        const storageText = await dr.text();
        if (!dr.ok && dr.status !== 404 && !/object not found|not found/i.test(storageText)) {
            throw new Error(storageText || `Storage HTTP ${dr.status}`);
        }

        // Gỡ toàn bộ metadata tệp khỏi nhiệm vụ.
        const patch = {
            // Các cột này trong province_tasks là NOT NULL: dùng chuỗi rỗng/0 thay vì null.
            attachment_name: "",
            attachment_path: "",
            attachment_type: "",
            attachment_size: 0,
            attachment_approved: false,
            attachment_approved_at: null,
            attachment_approved_by: "",
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?id=eq.${encodeURIComponent(id)}`, {
            method: "PATCH",
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                Prefer: "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        let saved = null; try { saved = JSON.parse(tx)?.[0] || null } catch (_) { }
        Object.assign(x, saved || patch);

        // V44: cập nhật giao diện bằng các hàm PROV thực sự đang tồn tại.
        // V43 gọi renderPROVAll() (không được định nghĩa), khiến tệp đã xóa thành công
        // nhưng sau đó vẫn bật toast lỗi "renderPROVAll is not defined".
        renderPROVCurrentAttachment(x);
        applyPROVFilters();
        if (document.getElementById("provinceDrillModal")?.classList.contains("open")) {
            renderPROVDrill(
                getPROVRowsByMode(PROV_DRILL_MODE),
                ({ all: "Tất cả nhiệm vụ Tỉnh giao Đảng bộ", processing: "Nhiệm vụ PROV — Đang xử lý", done: "Nhiệm vụ PROV — Hoàn thành", overdue: "Nhiệm vụ PROV — Quá hạn" })[PROV_DRILL_MODE] || "Nhiệm vụ Tỉnh giao",
                ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[PROV_DRILL_MODE] || "🏢"
            );
        }
        showToast("success", "Đã xóa tệp", "Tệp đã được xóa khỏi nhiệm vụ Tỉnh giao.");
        writeActivity("Tỉnh giao - Xóa file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) {
        showToast("error", "Không xóa được tệp", e.message || "Có lỗi khi xóa tệp PROV.");
    }
}

async function approvePROVAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") { showToast("error", "Không có quyền", "Chỉ Admin được phê duyệt tệp."); return; }
    const x = PROV_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    try {
        const patch = {
            attachment_approved: true,
            attachment_approved_at: new Date().toISOString(),
            attachment_approved_by: CURRENT_USER.name || "Admin",
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
            body: JSON.stringify(patch)
        });
        const tx = await r.text(); if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        Object.assign(x, patch); renderPROVCurrentAttachment(x); applyPROVFilters();
        showToast("success", "Đã phê duyệt", "Tệp PROV đã được phê duyệt.");
        writeActivity("Tỉnh giao - Duyệt file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) { showToast("error", "Không thể phê duyệt", e.message || "Lỗi Supabase."); }
}

async function savePROVTaskEdit() {
  const btn = document.getElementById("provinceEditSaveBtn");
  const oldText = btn ? btn.textContent : "";
  try {
    if(btn){ btn.disabled=true; btn.textContent="⏳ Đang lưu..."; }
    const taskName = (document.getElementById("provinceEditTask")?.value || "").trim();
    if(!taskName){ showToast("error","Thiếu nhiệm vụ","Nhập Nhiệm vụ Tỉnh giao"); return; }
    const officerName = (document.getElementById("provinceEditOfficer")?.value || "").trim() || CURRENT_USER?.name || "Chưa phân công";
    const unitName = (document.getElementById("provinceEditUnit")?.value || "").trim();
    const roleName = (document.getElementById("provinceEditRole")?.value || "").trim();
    const specialistName = (document.getElementById("provinceEditSpecialist")?.value || "").trim();
    const dueRaw = (document.getElementById("provinceEditDue")?.value || "").trim();
    const completedRaw = (document.getElementById("provinceEditCompleted")?.value || "").trim();
    const product = (document.getElementById("provinceEditProduct")?.value || "").trim();
    const progress = (document.getElementById("provinceEditProgress")?.value || "").trim();
    const status = (document.getElementById("provinceEditStatus")?.value || "").trim() || "Đang triển khai";
    const staffNote = (document.getElementById("provinceEditStaffNote")?.value || "").trim();
    const adminNote = (document.getElementById("provinceEditAdminNote")?.value || "").trim();
    // Thu thập vai trò để lưu vào note JSON
    const rolesLive = (()=>{ try{ return provinceCollectEditRoles(); }catch(e){ return []; } })();
    const noteJSON = JSON.stringify(rolesLive.length ? {roles: rolesLive} : []);
    let vbTinh = ""; let vbXa = "";
    try{ vbTinh = (typeof getProvinceVanBanTinhEffective==="function" ? getProvinceVanBanTinhEffective() : (document.getElementById("provinceEditVanBanTinh")?.value || "")).trim(); }catch(e){ vbTinh = (document.getElementById("provinceEditVanBanTinh")?.value || "").trim(); }
    try{ vbXa = (typeof getProvinceVanBanXaEffective==="function" ? getProvinceVanBanXaEffective() : (document.getElementById("provinceEditVanBanXa")?.value || "")).trim(); }catch(e){ vbXa = (document.getElementById("provinceEditVanBanXa")?.value || "").trim(); }
    const srcForm = (document.getElementById("provinceEditSourceForm")?.value || "").trim();
    const issuingAuth = (document.getElementById("provinceEditIssuingAuthority")?.value || "").trim();
    // Giữ giá trị gốc các cột không có input trong modal để không ghi đè rỗng
    const _orig = (typeof PROV_TASKS !== "undefined" && PROV_TASKS && PROV_EDIT_ID) ? PROV_TASKS.find(r => String(r.id) === String(PROV_EDIT_ID)) : null;

    let file = document.getElementById("provinceEditAttachment")?.files?.[0] || null;
    let uploaded = null;
    if(file && typeof uploadPROVTaskFile==="function"){
      const p=document.getElementById("provinceUploadProgress"); if(p) p.style.display="block";
      uploaded = await uploadPROVTaskFile(file, {id: PROV_EDIT_ID || "new"});
    }

    const dbRow = {
      officer_name: officerName,
      task_name: taskName,
      unit_name: unitName,
      role: roleName,
      specialist_name: specialistName,
      deadline: dueRaw ? (typeof dateToDb==="function" ? (dateToDb(dueRaw)||dueRaw) : dueRaw) : "",
      completed_date: completedRaw ? (typeof dateToDb==="function" ? (dateToDb(completedRaw)||null) : completedRaw) : null,
      product: product,
      result: product || "Chưa điền",
      progress: progress,
      status: status,
      staff_note: staffNote,
      admin_note: adminNote,
      note: noteJSON,
      source_doc: vbTinh,
      source_group: vbXa || (_orig ? String(_orig.source_group || "") : ""),
      issuing_authority: issuingAuth || vbXa,
      implementation_detail: _orig ? String(_orig.implementation_detail || "") : "",
      overdue_reason: _orig ? String(_orig.overdue_reason || "") : "",
      source_form: srcForm,
      source_sheet: "manual",
      source_row: Math.floor(Math.random()*2147483640)+1,
      updated_at: new Date().toISOString()
    };
    if(uploaded){
      dbRow.attachment_path = uploaded.path || "";
      dbRow.attachment_name = uploaded.name || file?.name || "";
      dbRow.attachment_type = uploaded.type || file?.type || "";
      dbRow.attachment_size = uploaded.size || file?.size || 0;
    }

    // ID là UUID (cây cũ) -> không match mơ hồ nữa: thử lấy id số từ cây, nếu không có thì báo lỗi rõ
    let targetId = PROV_EDIT_ID;
    if(targetId && String(targetId).includes("-")){
      targetId = null;
      if(typeof PROV_TREE_EDIT_IDX !== "undefined" && PROV_TREE_EDIT_IDX !== null){
        try{
          const tRows = (typeof getPROVTreeRows==="function" ? getPROVTreeRows(null) : []) || [];
          const found = tRows.find(r=>r._treeIdx===PROV_TREE_EDIT_IDX);
          if(found && found.id && !String(found.id).includes("-")) targetId = String(found.id);
        }catch(e){}
      }
      if(!targetId){
        showToast("error","Không lưu được","Nhiệm vụ này chưa có trong bảng province_tasks. Hãy dùng nút Thêm để tạo mới.");
        return;
      }
    }

    const isNew = !targetId;
    let res, txtResp;
    if(isNew){
      res = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks`, {
        method: "POST",
        headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
        body: JSON.stringify(dbRow)
      });
      txtResp = await res.text();
      if(!res.ok){ let msg=txtResp; try{ const j=JSON.parse(txtResp); msg=j.message||j.details||j.hint||txtResp; }catch(e){} throw new Error(msg); }
      showToast("success","Đã thêm","Đã lưu vào province_tasks.");
    } else {
      const numericId = String(targetId).replace(/[^0-9]/g,"");
      if(!numericId) throw new Error("ID không hợp lệ");
      res = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?id=eq.${encodeURIComponent(numericId)}`, {
        method: "PATCH",
        headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
        body: JSON.stringify(dbRow)
      });
      txtResp = await res.text();
      if(!res.ok){ let msg=txtResp; try{ const j=JSON.parse(txtResp); msg=j.message||j.details||j.hint||txtResp; }catch(e){} throw new Error(msg); }
      showToast("success","Đã cập nhật",`#${numericId} đã cập nhật.`);
    }

    // Cập nhật mảng cục bộ ngay sau khi lưu thành công để popup mở lại đúng
    try{
      const respData = JSON.parse(txtResp);
      const arr = Array.isArray(respData) ? respData : (respData ? [respData] : []);
      arr.forEach(row => {
        if(!row || !row.id) return;
        const nRow = (typeof normalizePROVTask === "function") ? normalizePROVTask(row) : row;
        const idx = (typeof PROV_TASKS !== "undefined" && PROV_TASKS) ? PROV_TASKS.findIndex(r => String(r.id) === String(row.id)) : -1;
        if(idx >= 0) { PROV_TASKS[idx] = { ...PROV_TASKS[idx], ...nRow }; }
        else if(typeof PROV_TASKS !== "undefined") PROV_TASKS.push(nRow);
      });
      // đồng bộ cache với dữ liệu mới nhất
      try{ localStorage.setItem("province_tasks_cache", JSON.stringify(PROV_TASKS)); }catch(e){}
    }catch(e){}

    PROV_EDIT_ID = null;
    if(typeof PROV_TREE_EDIT_IDX !== "undefined") PROV_TREE_EDIT_IDX = null;

    if(typeof closePROVTaskEdit==="function") closePROVTaskEdit(); else if(typeof smoothCloseModal==="function") smoothCloseModal("provinceEditModal");

    // Re-render ngay từ dữ liệu cục bộ, không reload toàn bộ từ Supabase
    try{ applyPROVFilters(); }catch(e){ console.warn("applyPROVFilters loi:", e); }
    try{ rebuildPROVAgencyFilter(); }catch(e){}

  } catch(e){
    console.error("savePROVTaskEdit loi:", e);
    showToast("error","Không lưu được", (e.message||"Lỗi").slice(0,400), 6000);
  } finally {
    if(btn){ btn.disabled=false; btn.textContent=oldText||"💾 Lưu"; }
    const p=document.getElementById("provinceUploadProgress"); if(p) p.style.display="none";
  }
}






function scrollToPROVTreeTask(idx, taskId = '', agencyName = '') {
    try {
        const tasks = [...document.querySelectorAll('#provincePlanTree .pp-task')];
        const t = (taskId && tasks.find(el => String(el.dataset.id || '') === String(taskId))) || tasks[Number(idx)];
        if (!t) return;
        t.style.display = '';
        const body = t.querySelector('.pp-task-body');
        const btn = t.querySelector('button[onclick="ppToggleTask(this)"]');
        if (btn && body && body.style.display === 'none') btn.click();
        const wanted = provinceFold(agencyName);
        const agency = wanted ? [...t.querySelectorAll('.pp-agency')].find(ag => {
            const value = provinceAgencyLabel(ag.querySelector('[data-k=agencyOther]')?.value || ag.querySelector('[data-k=agency]')?.value || '');
            const folded = provinceFold(value);
            return folded === wanted || folded.includes(wanted) || wanted.includes(folded);
        }) : null;
        const agencyBody = agency?.querySelector('.pp-agency-content');
        const agencyBtn = agency?.querySelector('.pp-agency-toggle');
        if (agencyBtn && agencyBody?.style.display === 'none') agencyBtn.click();
        requestAnimationFrame(() => {
            t.scrollIntoView({ behavior: 'smooth', block: 'center' });
            t.style.outline = '2px solid #6d28d9';
            if (agency) agency.style.outline = '2px solid #6d28d9';
            setTimeout(() => { t.style.outline = ''; if (agency) agency.style.outline = ''; }, 1800);
        });
    } catch (e) {}
}

function setPROVStatusFilter(status, el) {
    const sel = document.getElementById("provinceStatusFilter"); if (sel) sel.value = status || "all";
    document.querySelectorAll("#provinceSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");
    openPROVWorkspace();
    applyPROVFilters();
}

function resetPROVFilters() {
    const q = document.getElementById("provinceSearch"), o = document.getElementById("provinceOfficerFilter"), s = document.getElementById("provinceStatusFilter"), t = document.getElementById("provinceTimeFilter");
    if (q) q.value = ""; if (o) o.value = ""; if (s) s.value = "all"; if (t) t.value = "all";
    PROV_MONTH = null;
    try{ document.querySelectorAll("#provinceMonthStrip button").forEach(b=> b.classList.remove("active")); }catch(e){}
    document.querySelectorAll("#provinceSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    applyPROVFilters();
}

function openPROVWorkspace(el) {
    if (CURRENT_USER?.role === 'department' && !['vpub','action100'].includes(CURRENT_USER.scope)) return showToast('error', 'Khong co quyen', 'Token nay chi duoc xem workspace VPUB va cac workspace duoc phep.');
    document.getElementById("officeWorkspace")?.classList.remove("open");
    document.getElementById("action100Workspace")?.classList.remove("open");
    document.getElementById("mttqKpiWorkspace")?.classList.remove("open");
    document.getElementById("nqWorkspace")?.classList.remove("open");
    const ws = document.getElementById("provinceWorkspace"); if (!ws) return;
    document.getElementById("bchWorkspace")?.classList.remove("open");
    document.getElementById("ttbtvWorkspace")?.classList.remove("open");
    ws.classList.add("open");
    const item = el || document.getElementById("provinceSidebarItem");
    if (item) {
        document.querySelectorAll(".sidebar-item").forEach(x => x.classList.remove("active"));
        item.classList.add("active");
        const sub = document.getElementById("provinceSubmenu"); if (sub) { sub.classList.add("open"); requestAnimationFrame(() => { sub.style.maxHeight = sub.scrollHeight + "px"; }); }
        item.classList.remove("collapsed");
    }
    loadPROVData(false);
    try{ vpSaveLastWs("provinceWorkspace"); }catch(e){}
}

function closePROVWorkspace() {
    document.getElementById("provinceWorkspace")?.classList.remove("open");
    document.getElementById("provinceSidebarItem")?.classList.remove("active");
    document.querySelectorAll("#provinceSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    const home = [...document.querySelectorAll(".sidebar-item")].find(x => x.textContent.includes("Trang chủ"));
    if (home) home.classList.add("active");
}
