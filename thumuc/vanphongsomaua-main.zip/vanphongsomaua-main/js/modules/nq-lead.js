// js/modules/nq-lead.js — 3 nut lanh dao o Tong quan NQ: Top viec cham, Bang diem co quan, Pheu chi tieu.
// Classic script (load truoc legacy.js). Chi dung globals luc runtime (onclick) nen an toan.
let NQ_AGENCY_CACHE = [];
function nqLeadStOf(x) { return x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none"); }
function nqLeadRowHtml(x, i) {
    const s = nqLeadStOf(x);
    const admin = (typeof canEditNqTw === "function") && canEditNqTw();
    return `<tr class="nq-row"${admin ? ` onclick="openNqTwEdit(${x.id})"` : ``}><td>${i + 1}</td>
        <td><div class="nq-name"><b>${esc(x.name)}</b></div><div class="nq-sub1">${esc(x.co_quan || "")}</div></td>
        <td><span class="nq-badge" title="${NQ_CAP_LABEL[x.cap || "TW"]}">${NQ_CAP_SHORT[x.cap || "TW"]}</span></td>
        <td><div class="nq-person">${esc(x.thuong_truc || "")}</div></td>
        <td><b>${Number(x.tien_do || 0)}%</b></td>
        <td><span class="nq-badge ${s}">${NQ_STATUS_LABEL[s]}</span></td></tr>`;
}
function nqLeadFillList(titleId, countId, bodyId, emptyId, title, rows) {
    document.getElementById(titleId).textContent = title;
    document.getElementById(countId).textContent = rows.length;
    const body = document.getElementById(bodyId), empty = document.getElementById(emptyId);
    if (!rows.length) { body.innerHTML = ""; if (empty) empty.style.display = ""; }
    else { if (empty) empty.style.display = "none"; body.innerHTML = rows.map((x, i) => nqLeadRowHtml(x, i)).join(""); }
}
// Nut 1: Top 5 viec cham tien do (tien do thap nhat truoc)
function openNqSlowModal() {
    const rows = NQ_TW_LIST.filter(x => nqLeadStOf(x) === "late")
        .sort((a, b) => Number(a.tien_do || 0) - Number(b.tien_do || 0)).slice(0, 5);
    nqLeadFillList("nqSlowTitle", "nqSlowCount", "nqSlowBody", "nqSlowEmpty",
        "⚠️ Top việc chậm tiến độ — " + rows.length + " nghị quyết", rows);
    document.getElementById("nqSlowModal")?.classList.add("open");
}
function closeNqSlowModal() { document.getElementById("nqSlowModal")?.classList.remove("open"); }
// Nut 2: Bang diem co quan chu tri (viec cham nhieu nhat len dau)
function openNqAgencyModal() {
    const by = {};
    NQ_TW_LIST.forEach(x => {
        const k = ((x.co_quan || "").trim()) || "Chưa phân công";
        const g = (by[k] = by[k] || { total: 0, done: 0, late: 0, prog: 0 });
        g.total++; g.prog += Number(x.tien_do || 0);
        const s = nqLeadStOf(x);
        if (s === "done") g.done++;
        if (s === "late") g.late++;
    });
    NQ_AGENCY_CACHE = Object.entries(by).map(([k, g]) => ({ name: k, total: g.total, done: g.done, late: g.late, avg: g.total ? Math.round(g.prog / g.total) : 0 }))
        .sort((a, b) => b.late - a.late || a.avg - b.avg);
    document.getElementById("nqAgencyCount").textContent = NQ_AGENCY_CACHE.length;
    const body = document.getElementById("nqAgencyBody"), empty = document.getElementById("nqAgencyEmpty");
    if (!NQ_AGENCY_CACHE.length) { body.innerHTML = ""; empty.style.display = ""; }
    else {
        empty.style.display = "none";
        body.innerHTML = NQ_AGENCY_CACHE.map((a, i) => `<tr class="nq-row" onclick="openNqAgencyList(${i})" title="Bấm để xem danh sách nghị quyết"><td>${i + 1}</td>
            <td><b>${esc(a.name)}</b></td><td>${a.total}</td><td>${a.done}</td>
            <td>${a.late ? `<b style="color:#dc2626">${a.late}</b>` : "0"}</td>
            <td><div style="display:flex;align-items:center;gap:8px"><div class="nq-bar" style="flex:1"><span style="width:${a.avg}%"></span></div><b>${a.avg}%</b></div></td></tr>`).join("");
    }
    document.getElementById("nqAgencyModal")?.classList.add("open");
}
function closeNqAgencyModal() { document.getElementById("nqAgencyModal")?.classList.remove("open"); }
// Drill-down tu bang diem co quan -> tai dung popup nqKpiModal (nam sau trong DOM nen noi len tren)
function openNqAgencyList(i) {
    const a = NQ_AGENCY_CACHE[i];
    if (!a) return;
    const rows = NQ_TW_LIST.filter(x => (((x.co_quan || "").trim()) || "Chưa phân công") === a.name);
    nqLeadFillList("nqKpiTitle", "nqKpiCount", "nqKpiBody", "nqKpiEmpty",
        "Cơ quan: " + a.name + " — " + rows.length + " nghị quyết", rows);
    document.getElementById("nqKpiModal")?.classList.add("open");
}
// Nut 3: Pheu chi tieu theo 3 cap TW/Tinh/Xa (lanh dao TW nhin xuong)
function openNqFunnelModal() {
    const colorOf = p => p >= 80 ? "#16a34a" : p >= 50 ? "#f59e0b" : "#dc2626";
    const rows = ["TW", "TINH", "XA"].map(c => {
        const list = NQ_TW_LIST.filter(x => (x.cap || "TW") === c);
        const total = list.reduce((s, x) => s + Number(x.so_chi_tieu || 0), 0);
        const done = list.reduce((s, x) => s + Number(x.so_chi_tieu_dan_da || 0), 0);
        return { cap: c, total, done, pct: total ? Math.round(done / total * 100) : 0 };
    });
    const tT = rows.reduce((s, r) => s + r.total, 0), tD = rows.reduce((s, r) => s + r.done, 0);
    const tP = tT ? Math.round(tD / tT * 100) : 0;
    const rowHtml = r => `<div class="nq-funnel-row"><div class="nq-funnel-name">${NQ_CAP_LABEL[r.cap]}</div>
        <div class="nq-bar nq-funnel-bar"><span style="width:${r.pct}%;background:${colorOf(r.pct)}"></span></div>
        <div class="nq-funnel-nums"><b>${r.done}/${r.total}</b> (${r.pct}%)</div></div>`;
    document.getElementById("nqFunnelBody").innerHTML = rows.map(rowHtml).join("") +
        `<div class="nq-funnel-row nq-funnel-total"><div class="nq-funnel-name">Tổng cộng</div>
        <div class="nq-bar nq-funnel-bar"><span style="width:${tP}%;background:${colorOf(tP)}"></span></div>
        <div class="nq-funnel-nums"><b>${tD}/${tT}</b> (${tP}%)</div></div>`;
    document.getElementById("nqFunnelCount").textContent = tT;
    document.getElementById("nqFunnelModal")?.classList.add("open");
}
function closeNqFunnelModal() { document.getElementById("nqFunnelModal")?.classList.remove("open"); }
