/* js/modules/utils.js — tach tu js/legacy.js (nhom 2 utils core, 60 ham).
 * Classic script (window globals), load TRUOC js/legacy.js. legacy.js giu ban goc (trung lap vo hai).
 * Ranges goc: 8-8, 9-9, 10-10, 11-11, 29-35, 36-51, 52-52, 53-60, 80-98, 99-113, 115-118, 119-125, 147-147, 151-151, 163-177, 218-218, 224-233, 234-240, 241-250, 251-260, 262-271, 275-279, 280-291, 292-314, 315-365, 389-392, 394-399, 401-403, 405-454, 456-517, 851-861, 1058-1066, 1098-1098, 2153-2166, 2167-2170, 2171-2175, 2176-2181, 2182-2188, 2189-2195, 2197-2200, 2205-2227, 2229-2238, 2240-2249, 2251-2270, 2272-2282, 2284-2331, 2881-2893, 9367-9534, 9535-9540, 9963-9979, 10674-10674, 10675-10675, 10676-10676, 10677-10677, 11162-11162, 11174-11187, 11240-11249, 11286-11295, 11379-11379, 11380-11380
 */

function safeLSSet(k,v){ try{ localStorage.setItem(k, typeof v==="string"?v:JSON.stringify(v)); }catch(e){ console.warn("LS set fail",k,e); } }

function safeLSGet(k, fallback=null){ try{ const v=localStorage.getItem(k); return v===null?fallback:v; }catch(e){ return fallback; } }

function readCache(baseKey){ try{ const raw=localStorage.getItem(baseKey); return raw?JSON.parse(raw):null; }catch(e){ return null; } }

function writeCache(baseKey, obj){ try{ localStorage.setItem(baseKey, JSON.stringify(obj)); }catch(e){} }

// Skeleton loading cho bang (audit UI 2026-09-30): hien gach mo truoc khi fetch xong.
// render*Table se ghi de innerHTML khi co data that, nen khong can tu xoa.
function showTableSkeleton(tbodyId, bars){
    try{
        var n = bars || 5, body = document.getElementById(tbodyId);
        if(!body) return;
        var h = "";
        for(var i = 0; i < n; i++) h += '<tr class="skel-row"><td colspan="12"><div class="skel-bar"></div></td></tr>';
        body.innerHTML = h;
    }catch(e){}
}

// Tag thang cho NV Thuong xuyen cu (chua co marker trong ten) — chi hien thi, khong ghi DB
function regularMonthTagText(x) {
    try {
        if (!x || !x.is_regular) return "";
        const t = String(x.task || x.task_name || "");
        if (t.includes("NV Thường xuyên từ Tháng trước") || t.includes("NV từ tháng")) return "";
        const d = x._createdDate || (typeof getCreationDate === "function" ? getCreationDate(x) : null) || parseDate(x.created_at);
        if (!d) return "";
        return ` [NV từ tháng ${d.getMonth()+1}/${d.getFullYear()}]`;
    } catch (e) { return ""; }
}
function regularMonthTagHtml(x) {
    try {
        if (!x || !x.is_regular) return "";
        const t = String(x.task || x.task_name || "");
        if (t.includes("NV Thường xuyên từ Tháng trước") || t.includes("NV từ tháng")) return "";
        const d = x._createdDate || (typeof getCreationDate === "function" ? getCreationDate(x) : null) || parseDate(x.created_at);
        if (!d) return "";
        const lb = `${d.getMonth()+1}/${d.getFullYear()}`;
        return ` <span class="regular-month-tag" title="Nhiệm vụ thường xuyên của tháng ${lb} — hiện mọi bộ lọc tháng">(NV từ tháng ${lb})</span>`;
    } catch (e) { return ""; }
}

function _obfOfficers(arr){
  if(!Array.isArray(arr)) return arr;
  return arr.map(o=>{
    if(!o || !o.token) return o;
    try{ return {...o, token: _obfToken(String(o.token))}; }catch(_){ return o; }
  });
}

function _deobfOfficers(arr){
  if(!Array.isArray(arr)) return arr;
  return arr.map(o=>{
    if(!o || !o.token) return o;
    const t = String(o.token);
    // Nếu đã là base64 đảo thì atob thành công và reverse ra pattern CB-/CQ-/ADM-
    try{
      const dec = _deobfToken(t);
      if(/^(CB-|CQ-|ADM-)/.test(dec)) return {...o, token: dec};
      // fallback: token cũ plain không match pattern -> thử deobf, nếu fail giữ plain
      // Nếu dec không match nhưng t khác dec thì vẫn là obf
      if(dec !== t && dec.length>4) return {...o, token: dec};
    }catch(_){}
    return o;
  });
}

function writeOfficersCache(key, arr){ try{ localStorage.setItem(key, JSON.stringify(_obfOfficers(arr))); }catch(e){} try{ writeCache(key, _obfOfficers(arr)); }catch(_){} }

function readOfficersCache(key){
  try{
    const raw = localStorage.getItem(key);
    if(raw){ const arr = JSON.parse(raw); const dec = _deobfOfficers(arr); if(dec!==arr) return dec; return dec; }
  }catch(_){}
  try{ const c = readCache(key); if(c) return _deobfOfficers(c); }catch(_){}
  return null;
}

function demoMaskName(name){
    if(!DEMO_MODE) return name;
    const raw = String(name||'').trim(); if(!raw) return raw;
    if(_demoNameMap.has(raw)) return _demoNameMap.get(raw);
    // ẩn theo cấu trúc họ và tên: giữ ký tự đầu mỗi từ, còn lại thành ***
    const parts = raw.split(/\s+/);
    let masked = parts.map(w=>{
        if(!w) return w;
        const first = w[0];
        // nếu tên chỉ 1 ký tự -> giữ + ***
        if(w.length <= 1) return first + '***';
        return first + '***';
    }).join(' ');
    // đảm bảo không trùng lặp hoàn toàn: thêm hậu tố số nếu đã tồn tại masked
    let uniq = masked, n=2;
    const used = new Set(_demoNameMap.values());
    while(used.has(uniq)){ uniq = masked + ' ' + n; n++; }
    _demoNameMap.set(raw, uniq); return uniq;
}

function demoMaskText(text){
    if(!DEMO_MODE || !text) return text;
    let out = String(text);
    // thay tên dài trước để tránh thay nhầm substring
    const entries = [..._demoNameMap.entries()].sort((a,b)=> b[0].length - a[0].length);
    // nếu chưa có map (chưa render bảng) thì tạo mask tạm cho các tên trong text
    if(!entries.length && out){
        // fallback: mask trực tiếp các cụm họ tên trong text (2-4 từ viết hoa)
        return out;
    }
    entries.forEach(([real, masked])=>{
        if(real && out.includes(real)) out = out.split(real).join(masked);
    });
    return out;
}

function demoEnsureNames(names){
    if(!DEMO_MODE || !names) return;
    (Array.isArray(names)?names:[names]).forEach(n=>{ if(n) demoMaskName(n); });
}

function isDemoWriteBlocked(url, method){
    if(!DEMO_MODE) return false;
    const m = String(method||'GET').toUpperCase();
    if(!['POST','PATCH','PUT','DELETE'].includes(m)) return false;
    try{ if(String(url||'').includes('supabase.co')) return true; }catch(e){}
    return false;
}

    function showDemoBanner(){ const b=document.getElementById('demoBanner'); if(b) b.style.display='block'; try{ document.title='[DEMO] '+document.title; }catch(e){} }

    function demoMaskProvinceInputs(){ try{ document.querySelectorAll('#provincePlanTree [data-k=name]').forEach(inp=>{ const v=String(inp.value||'').trim(); if(!v || inp.dataset.demoMasked) return; const m=demoMaskName(v); if(m!==v){ inp.value=m; inp.dataset.demoMasked='1'; } }); }catch(e){} }

async function getDemoSnapshot(){
    if(DEMO_SNAPSHOT_CACHE) return DEMO_SNAPSHOT_CACHE;
    // thử 3 đường dẫn khác nhau để tránh lỗi khi chạy ở subfolder
    const tryUrls = ['data/demo-snapshot.json','./data/demo-snapshot.json','/data/demo-snapshot.json'];
    for(const u of tryUrls){
        try{
            const r = await fetch(u, { cache:'no-store' });
            if(r.ok){ const j = await r.json(); DEMO_SNAPSHOT_CACHE = j; return j; }
        }catch(e){}
    }
    console.warn('[DEMO] fetch snapshot thất bại (có thể mở file:// hoặc chưa chạy server), dùng bản nhúng');
    try{ showToast('info','Demo offline','Dùng dữ liệu mẫu nhúng sẵn - không cần server'); }catch(_){}
    DEMO_SNAPSHOT_CACHE = DEMO_SNAPSHOT_EMBED;
    return DEMO_SNAPSHOT_EMBED;
}

function debounce(fn, wait){ let t; return function(...a){ clearTimeout(t); t=setTimeout(()=>fn.apply(this,a), wait); }; }

function getTimeRange(mode){
  const now=new Date(); now.setHours(0,0,0,0);
  if(mode==='week'){ const day=now.getDay()||7; const from=new Date(now); from.setDate(now.getDate()-day+1); const to=new Date(from); to.setDate(from.getDate()+6); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='month'){ const from=new Date(now.getFullYear(), now.getMonth(), 1); const to=new Date(now.getFullYear(), now.getMonth()+1, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='prevMonth'){ const from=new Date(now.getFullYear(), now.getMonth()-1, 1); const to=new Date(now.getFullYear(), now.getMonth(), 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='nextMonth'){ const from=new Date(now.getFullYear(), now.getMonth()+1, 1); const to=new Date(now.getFullYear(), now.getMonth()+2, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='quarter'){ const q=Math.floor(now.getMonth()/3); const from=new Date(now.getFullYear(), q*3, 1); const to=new Date(now.getFullYear(), q*3+3, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='today'){ const from=new Date(now); const to=new Date(now); to.setHours(23,59,59,999); return {from,to}; }
  return null;
}

function isDateInTimeRange(dateObj, mode){
  if(!mode || mode==='all') return true;
  if(!dateObj || isNaN(dateObj)) return false;
  const r=getTimeRange(mode); if(!r) return true;
  const d=new Date(dateObj); d.setHours(12,0,0,0);
  return d>=r.from && d<=r.to;
}

function getCreationDate(x){
  if(!x) return null;
  const v = x.created_at || x.createdAt || x.updated_at || x.updatedAt || x.created || "";
  if(!v) return null;
  const d=new Date(v);
  if(!isNaN(d)) return d;
  const m=String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(m){ const dt=new Date(+m[1],+m[2]-1,+m[3]); return isNaN(dt)?null:dt; }
  return null;
}

function parseDeadlineAny(s){
  if(!s) return null;
  if(s instanceof Date) return isNaN(s)?null:new Date(s.getFullYear(), s.getMonth(), s.getDate());
  const str=String(s).trim();
  // thử parseDate (dd/mm/yyyy hoặc iso)
  try{ const p=parseDate(str); if(p && !isNaN(p)) return new Date(p.getFullYear(), p.getMonth(), p.getDate()); }catch(e){}
  try{ const p=typeof bchDeadlineDate==='function'?bchDeadlineDate(str):null; if(p && !isNaN(p)) return p; }catch(e){}
  try{ const p=typeof action100ParseDate==='function'?action100ParseDate(str):null; if(p && !isNaN(p)) return p; }catch(e){}
  const d=new Date(str); return isNaN(d)?null:new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

async function writeActivity(action, details = {}) {
    if (!CURRENT_USER) return;
    try {
        await fetch(`${SUPABASE_URL}/rest/v1/activity_logs`, {
            method: "POST",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", Prefer: "return=minimal" },
            body: JSON.stringify({ user_id: CURRENT_USER.id, user_name: CURRENT_USER.name, user_role: CURRENT_USER.role, action, details })
        });
    } catch (e) { console.warn("Không ghi được nhật ký hoạt động", e); }
}

function renderActivityLog(rows) {
    const body = rows.map((x,i) => `<tr><td>${i+1}</td><td><span class="activity-action-badge" data-full="${esc(x.action || "")}">${esc(x.action || "")}</span></td><td class="activity-account-cell" title="${esc(x.user_name || "")}">${esc(x.user_name || "")}</td><td class="activity-date-cell">${esc(formatDate(x.created_at).replaceAll('/','-'))} ${new Date(x.created_at).toLocaleTimeString("vi-VN",{hour:'2-digit',minute:'2-digit'})}</td><td class="activity-note-cell" title="${esc(x.details?.task || JSON.stringify(x.details||"").slice(0,120))}">${esc(x.details?.task || (x.details? JSON.stringify(x.details).slice(0,80): ""))}</td><td><button class="btn-danger-soft activity-delete-btn" onclick="deleteActivityLog(${Number(x.id)})">Xóa</button></td></tr>`).join("");
    document.getElementById("drillCount").textContent = rows.length;
    document.getElementById("drillBody").innerHTML = body || `<tr><td colspan="6" style="text-align:center;padding:24px;color:#94a3b8">Chưa có dữ liệu</td></tr>`;
}

async function deleteActivityLog(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const pass = prompt("Nhập mật khẩu xác nhận xóa nhật ký:");
    if (pass !== "2095") return showToast("error", "Sai mật khẩu", "Không thể xóa bản ghi nhật ký.");
    const row = ACTIVITY_LOG_ROWS.find(x => Number(x.id) === Number(id));
    const r = await fetch(`${SUPABASE_URL}/rest/v1/activity_logs?id=eq.${encodeURIComponent(id)}`, { method: "DELETE", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
    if (!r.ok) return showToast("error", "Không thể xóa nhật ký", await r.text());
    ACTIVITY_LOG_ROWS = ACTIVITY_LOG_ROWS.filter(x => Number(x.id) !== Number(id));
    renderActivityLog(ACTIVITY_LOG_ROWS);
    writeActivity("Xóa nhật ký hoạt động", { deleted_id: id, deleted_action: row?.action || "" });
    showToast("success", "Đã xóa nhật ký");
}

function filterActivityLog() {
    const q = document.getElementById("activityNameFilter").value.trim().toLowerCase();
    const action = document.getElementById("activityActionFilter").value.trim().toLowerCase();
    const adminMode = document.getElementById("activityAdminFilter").value;
    const taskMode = document.getElementById("activityTaskFilter").value;
    const date = document.getElementById("activityDateFilter").value;
    const sort = document.getElementById("activitySortFilter")?.value || "";
    let rows = ACTIVITY_LOG_ROWS.filter(x => {
        const hasTask = !!String(x.details?.task || "").trim();
        const isAdmin = String(x.user_role || "").toLowerCase() === "admin";
        const hay = [x.user_name, x.action, x.user_role, x.created_at, x.details?.task, x.details?.note, x.details?.source, x.details?.officer, typeof x.details === 'object' ? JSON.stringify(x.details) : String(x.details||'')].join(' ').toLowerCase();
        const adminOk = !adminMode || (adminMode === "admin" ? isAdmin : adminMode === "non_admin" ? !isAdmin : String(x.user_name || "").trim() === adminMode);
        return (!q || hay.includes(q))
            && (!action || String(x.action || "").toLowerCase() === action)
            && adminOk
            && (!taskMode || (taskMode === "has_task" && hasTask))
            && (!date || String(x.created_at || "").startsWith(date));
    });
    if (sort === "name") rows.sort((a,b)=> String(a.user_name||"").localeCompare(String(b.user_name||""),"vi"));
    else if (sort === "action") rows.sort((a,b)=> String(a.action||"").localeCompare(String(b.action||""),"vi"));
    else if (sort === "date") rows.sort((a,b)=> new Date(b.created_at) - new Date(a.created_at));
    renderActivityLog(rows);
}

async function openActivityLog() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const r = await fetch(`${SUPABASE_URL}/rest/v1/activity_logs?select=*&order=created_at.desc&limit=300`, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
    if (!r.ok) { showToast("error", "Không thể tải nhật ký", await r.text()); return; }
    const rows = await r.json();
    const excludeActions = new Set(["Xóa nhật ký hoạt động", "Cảnh báo nhiệm vụ hàng ngày"]);
    const visibleRows = rows.filter(x => !excludeActions.has(String(x.action || "").trim()));
    ACTIVITY_LOG_ROWS = visibleRows;
    const modal = document.getElementById("drillModal");
    modal.classList.add("activity-log-mode");
    document.getElementById("drillTitle").textContent = "🧾 Nhật ký hoạt động";
    document.getElementById("activityNameFilter").value = "";
    const actionFilter = document.getElementById("activityActionFilter");
    if (actionFilter) {
        const actions = [...new Set(visibleRows.map(x => String(x.action || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        actionFilter.innerHTML = '<option value="">Tất cả thao tác</option>' + actions.map(a => `<option value="${esc(a)}">${esc(a)}</option>`).join("");
        actionFilter.value = "";
    }
    const adminFilter = document.getElementById("activityAdminFilter");
    if (adminFilter) {
        const names = [...new Set(visibleRows.map(x => String(x.user_name || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        adminFilter.innerHTML = '<option value="">Tất cả tài khoản</option><option value="admin">Chỉ dòng của Admin</option><option value="non_admin">Không phải Admin</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
        adminFilter.value = "";
    }
    document.getElementById("activityTaskFilter").value = "";
    document.getElementById("activityDateFilter").value = "";
    const _actSort = document.getElementById("activitySortFilter"); if (_actSort) { _actSort.value = ""; _actSort.style.display = ""; }
    const _afWrap = document.getElementById("activityFilterWrap"); if (_afWrap) _afWrap.style.display = "";
    const _ofWrapHide = document.getElementById("officeFilterWrap"); if (_ofWrapHide) _ofWrapHide.style.display = "none";
    document.getElementById("activityLogFilters").style.display = "flex";
    document.getElementById("activityLogFilters").style.flexDirection = "column";
    // hiện đủ 6 lọc Nhật ký như cũ: Tên/thao tác/tài khoản/ghi chú/ngày + Sắp xếp; ẩn lọc Văn phòng
    ["activityNameFilter","activityActionFilter","activityAdminFilter","activityTaskFilter","activityDateFilter","activitySortFilter"].forEach(id=>{ const el=document.getElementById(id); if(el) el.style.display=""; });
    document.getElementById("officeDrillOrderLabel").style.display = "none";
    const _oOrderAct = document.getElementById("officeDrillOrder"); if (_oOrderAct) _oOrderAct.style.display = "none";
    const _sortFieldHide = document.getElementById("officeSortField") || document.querySelector("#officeFilterWrap .of-sort"); if (_sortFieldHide) _sortFieldHide.style.display = "none";
    document.getElementById("officeDrillOfficerFilter").style.display = "none";
    const _oqnHide = document.getElementById("officeDrillOfficerNameFilter"); if (_oqnHide) _oqnHide.style.display = "none";
    const _oclHide = document.getElementById("officeDrillClearFilter"); if (_oclHide) _oclHide.style.display = "none";
    document.getElementById("officeDrillOfficerSelect").style.display = "none";
    document.getElementById("officeDrillStatusFilter").style.display = "none";
    ["officeDrillTimeFilter", "officeDrillQuarterFilter", "officeDrillMonthFilter"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = "none"; });
    document.getElementById("officeDrillFilterHint").style.display = "none";
    document.getElementById("drillEmpty").style.display = "none";
    const drillTbl = document.querySelector("#drillModal .drill-table");
    if (drillTbl) { drillTbl.classList.remove("office-drill-table"); drillTbl.classList.add("activity-log-table"); }
    document.querySelector("#drillModal thead").innerHTML = "<tr><th>STT</th><th>Thao tác</th><th class=\"activity-account-head\">Tài khoản</th><th class=\"activity-date-head\">Ngày</th><th>Ghi chú</th><th>Xóa</th></tr>";
    renderActivityLog(visibleRows);
    document.getElementById("drillEmpty").style.display = "none";
    smoothOpenModal(modal);
}

function setBackupStatus(msg, isError = false) {
    const el = document.getElementById("backupStatus");
    if (el) el.innerHTML = msg === "" ? "" : `<span style="color:${isError ? "#dc2626" : "#334155"}">${esc(String(msg))}</span>`;
}

function openBackupModal() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    setBackupStatus("Sẵn sàng. Chọn 'Tải xuống bản sao lưu' hoặc 'Khôi phục từ tệp sao lưu'.");
    document.getElementById("backupRestoreFile").value = "";
    smoothOpenModal("backupModal");
}

function closeBackupModal() {
    smoothCloseModal("backupModal", () => setBackupStatus(""));
}

async function backupData() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const btn = document.getElementById("backupExportBtn");
    const oldText = btn ? btn.textContent : "";
    if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang sao lưu..."; }
    try {
        const payload = { exported_at: new Date().toISOString(), app: "vanphongtonghop", version: 2, tables: {}, skipped: [] };
        const headers = { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` };
        let totalRows = 0;
        for (const table of BACKUP_TABLES) {
            // Đọc phân trang (PostgREST mặc định cắt 1000 dòng) + bỏ qua bảng lỗi thay vì sập cả bản sao lưu
            try {
                const all = [];
                let offset = 0;
                for (;;) {
                    setBackupStatus(`Đang đọc bảng ${table} (${all.length} dòng)...`);
                    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=*&order=id.asc&limit=1000&offset=${offset}`, { headers });
                    if (!r.ok) { const t = await r.text(); throw new Error(t || ("HTTP " + r.status)); }
                    const batch = await r.json();
                    if (!Array.isArray(batch) || !batch.length) break;
                    all.push(...batch);
                    if (batch.length < 1000) break;
                    offset += 1000;
                }
                payload.tables[table] = all;
                totalRows += all.length;
            } catch (e) {
                payload.skipped.push({ table, error: String((e && e.message) || e) });
            }
        }
        const json = JSON.stringify(payload, null, 2);
        const blob = new Blob([json], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `backup-vpdu-${new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-")}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        writeActivity("Sao lưu dữ liệu", { tables: Object.keys(payload.tables), rows: totalRows, skipped: payload.skipped.map(s => s.table) });
        const skipMsg = payload.skipped.length ? ` Bỏ qua ${payload.skipped.length} bảng lỗi: ${payload.skipped.map(s => s.table).join(", ")}.` : "";
        setBackupStatus(`✓ Đã tạo bản sao lưu (${Object.keys(payload.tables).length} bảng, ${totalRows} dòng, ${new Blob([json]).size} bytes). Tệp đã được tải xuống.${skipMsg}`);
    } catch (e) {
        console.error("Lỗi sao lưu:", e);
        setBackupStatus(`✗ Lỗi sao lưu: ${e.message || "Vui lòng kiểm tra kết nối."}`, true);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = oldText; }
    }
}

async function restoreBackup(event) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const file = event.target && event.target.files && event.target.files[0];
    if (!file) return;
    const entered = prompt("Nhập mật khẩu quản trị để xác nhận khôi phục dữ liệu:\n(Thao tác này sẽ GHI ĐÈ lên toàn bộ dữ liệu hiện tại)");
    if (entered === null) { event.target.value = ""; return; }
    if (entered !== "2095@Admin!MauA!TheMinh@") { event.target.value = ""; showToast("error", "Sai mật khẩu", "Bạn cần mật khẩu quản trị để khôi phục dữ liệu."); return; }
    if (!window.confirm("Khôi phục dữ liệu sẽ GHI ĐÈ lên dữ liệu hiện tại theo ID. Bạn chắc chắn muốn tiếp tục?")) { event.target.value = ""; return; }
    setBackupStatus("Đang đọc tệp sao lưu...");
    try {
        const payload = JSON.parse(await file.text());
        const tables = payload && payload.tables && typeof payload.tables === "object" ? payload.tables : null;
        if (!tables) throw new Error("Tệp không phải bản sao lưu hợp lệ (thiếu trường 'tables').");

        // 1) Xoá sạch dữ liệu cũ theo thứ tự NGƯỢC (Con trước, Cha sau) để tránh lỗi FK
        const reversedTables = [...BACKUP_TABLES].reverse();
        for (const table of reversedTables) {
            setBackupStatus(`Đang dọn dẹp bảng ${table}...`);
            // id=not.is.null xóa sạch mọi bản ghi, tương thích cả id số và id uuid (province_plan_blocks)
            const del = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=not.is.null`, { method: "DELETE", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
            if (!del.ok && del.status !== 404) {
                const t = await del.text();
                if (t.includes("42501") || t.includes("row-level security")) {
                    throw new Error(`Lỗi quyền (RLS) trên bảng ${table}. Bạn cần vào Supabase SQL Editor chạy lệnh: ALTER TABLE ${table} DISABLE ROW LEVEL SECURITY;`);
                }
                throw new Error(`Không xoá được bảng ${table}: ${t || del.status}`);
            }
        }

        // 2) Chèn lại dữ liệu theo thứ tự THUẬN (Cha trước, Con sau)
        let restored = 0, skipped = 0;
        for (const table of BACKUP_TABLES) {
            const rows = Array.isArray(tables[table]) ? tables[table] : null;
            if (!rows) { skipped++; continue; }
            setBackupStatus(`Đang khôi phục dữ liệu bảng ${table}...`);
            if (!rows.length) continue;
            for (let i = 0; i < rows.length; i += 250) {
                const batch = rows.slice(i, i + 250);
                const up = await fetch(`${SUPABASE_URL}/rest/v1/${table}?on_conflict=id`, {
                    method: "POST",
                    headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "resolution=merge-duplicates,return=minimal" },
                    body: JSON.stringify(batch)
                });
                if (!up.ok) {
                    const t = await up.text();
                    if (t.includes("42501") || t.includes("row-level security")) {
                        throw new Error(`Lỗi quyền (RLS) khi chèn bảng ${table}. Bạn cần vào Supabase SQL Editor chạy lệnh: ALTER TABLE ${table} DISABLE ROW LEVEL SECURITY;`);
                    }
                    throw new Error(`Không chèn được bảng ${table}: ${t || up.status}`);
                }
            }
            restored += rows.length;
        }
        writeActivity("Khôi phục dữ liệu", { restored, skipped });
        setBackupStatus(`✓ Đã khôi phục ${restored} bản ghi (bỏ qua ${skipped} bảng không có trong tệp). Nên tải lại trang để áp dụng toàn bộ.`);
    } catch (e) {
        console.error("Lỗi khôi phục:", e);
        setBackupStatus(`✗ Lỗi khôi phục: ${e.message || "Tệp không hợp lệ."}`, true);
    } finally {
        event.target.value = "";
    }
}

function showToast(type, title, message = "", duration = 3200, options = {}) {
    const wrap = document.getElementById("appToastWrap");
    if (!wrap) return;
    const icons = { success: "✓", error: "!", info: "i", warning: "⏰" };
    const el = document.createElement("div");
    el.className = `app-toast ${type || "info"}${options.onClick ? " clickable" : ""}`;
    el.innerHTML = `<div class="app-toast-icon">${icons[type] || icons.info}</div><div><div class="app-toast-title">${esc(title)}</div>${message ? `<div class="app-toast-msg">${esc(message)}</div>` : ""}</div>`;
    if (options.onClick) el.addEventListener("click", () => { el.remove(); options.onClick(); });
    wrap.appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 220); }, duration);
}

function safeFileName(name) {
    const dot = name.lastIndexOf(".");
    const ext = dot >= 0 ? name.slice(dot).toLowerCase() : "";
    const base = (dot >= 0 ? name.slice(0, dot) : name)
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d").replace(/Đ/g, "D")
        .replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "") || "tep-san-pham";
    return (base.slice(0, 90) + ext).toLowerCase();
}

function encodePath(path) { return String(path).split("/").map(encodeURIComponent).join("/"); }

function parseDate(v) {
    if (!v) return null;
    if (v instanceof Date) return isNaN(v) ? null : new Date(v.getFullYear(), v.getMonth(), v.getDate());
    const s = String(v).trim();
    let y, m, d, a = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);
    if (a) { y = +a[1]; m = +a[2]; d = +a[3]; }
    else {
        a = s.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
        if (!a) return null;
        d = +a[1]; m = +a[2]; y = +a[3];
    }
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
}

function formatDate(v) {
    const d = parseDate(v);
    return d ? `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}` : (v || "—");
}

function dateToDb(v) {
    if (!v) return null;
    const d = parseDate(v); if (!d) return null;
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function dateMask(el) {
    let x = String(el.value || "").replace(/\D/g, "").slice(0, 8);
    if (x.length > 4) x = x.slice(0, 2) + "/" + x.slice(2, 4) + "/" + x.slice(4);
    else if (x.length > 2) x = x.slice(0, 2) + "/" + x.slice(2);
    el.value = x;
}

function requireValidDate(value, label, required = false) {
    const s = String(value || "").trim();
    if (!s) { if (required) throw new Error(`${label} không được để trống.`); return null; }
    const db = dateToDb(s);
    if (!db) throw new Error(`${label} chưa phải là ngày hợp lệ.`);
    return db;
}

function dayDiff(v) {
    const d = v instanceof Date ? v : parseDate(v);
    if (!d) return null;
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    return Math.round((d - now) / 86400000);
}

function hasMeaningfulProduct(v) {
    const t = String(v ?? "").trim().toLowerCase();
    return !!t && !["không", "khong", "none", "null", "---", "--", "-"].includes(t);
}

function calculateTaskStatus(x, overrides = {}) {
    if (overrides._regular === true) return "Thường xuyên";
    if (overrides._regular !== false && String(overrides.status ?? x?.status ?? "").trim() === "Thường xuyên") return "Thường xuyên";
    const due = parseDate(overrides.due !== undefined ? overrides.due : x?.due);
    const completed = parseDate(overrides.completed_date !== undefined ? overrides.completed_date : x?.completed_date);
    const product = overrides.product !== undefined ? overrides.product : x?.product;
    const hasFile = overrides.hasFile !== undefined ? !!overrides.hasFile : !!x?.attachment_path;
    const ready = (hasMeaningfulProduct(product) || hasFile) && !!completed && !!due;

    if (ready) {
        const delta = completed.getTime() - due.getTime();
        if (delta < 0) return "Hoàn thành trước hạn";
        if (delta === 0) return "Hoàn thành đúng hạn";
        return "Hoàn thành quá hạn";
    }

    // Chưa đủ điều kiện hoàn thành: nếu mốc thực tế (ngày hoàn thành đã nhập hoặc hôm nay) vượt hạn => Quá hạn.
    if (due) {
        const ref = completed || (() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; })();
        if (ref.getTime() > due.getTime()) return "Quá hạn";
    }
    return "Đang triển khai";
}

function statusBadgeClass(status) {
    return ({
        "Đang triển khai": "badge-status-doing",
        "Hoàn thành trước hạn": "badge-status-early",
        "Hoàn thành đúng hạn": "badge-status-ontime",
        "Hoàn thành quá hạn": "badge-status-late-done",
        "Quá hạn": "badge-status-overdue",
        "Thường xuyên": "badge-status-regular"
    })[status] || "badge-status-doing";
}

function urgencyInfo(x) {
    if (String(x.status || "").trim() === "Thường xuyên") return { key: "regular", label: "🔁 Thường xuyên", cls: "u-regular" };
    if (completedStatuses.has(x.status)) return { key: "done", label: "✅ Đã hoàn thành", cls: "u-safe" };
    const n = dayDiff(x.due);
    if (n === null) return { key: "none", label: "Chưa có hạn", cls: "u-safe" };
    if (n < 0) return { key: "overdue", label: `⏰ Quá ${Math.abs(n)} ngày`, cls: "u-overdue" };
    if (n === 0) return { key: "today", label: "📅 Hôm nay", cls: "u-today" };
    if (n <= 3) return { key: "soon3", label: `⏳ Còn ${n} ngày`, cls: "u-soon" };
    return { key: "safe", label: `📅 Còn ${n} ngày`, cls: "u-safe" };
}

function canonicalStatus(v) {
    const raw = String(v ?? "").trim().toLowerCase();
    const legacy = {
        "trước hạn": "Hoàn thành trước hạn",
        "đúng hạn": "Hoàn thành đúng hạn",
        "đã hoàn thành": "Hoàn thành đúng hạn",
        "hoàn thành": "Hoàn thành đúng hạn",
        "hoàn thành trước hạn": "Hoàn thành trước hạn",
        "hoàn thành đúng hạn": "Hoàn thành đúng hạn",
        "hoàn thành quá hạn": "Hoàn thành quá hạn",
        "quá hạn": "Quá hạn",
        "thường xuyên": "Thường xuyên",
        "regular": "Thường xuyên",
        "đang triển khai": "Đang triển khai",
        "chưa cập nhật": "Đang triển khai",
        "none": "Đang triển khai",
        "": "Đang triển khai"
    };
    return legacy[raw] || "Đang triển khai";
}

function dbStatus(v) {
    const map = {
        "Đang triển khai": "đang triển khai",
        "Hoàn thành trước hạn": "hoàn thành trước hạn",
        "Hoàn thành đúng hạn": "hoàn thành đúng hạn",
        "Hoàn thành quá hạn": "hoàn thành quá hạn",
        "Quá hạn": "quá hạn",
        "Thường xuyên": "thường xuyên"
    };
    return map[v] || "đang triển khai";
}

function normalizeTask(x, i, source = "office") {
    const due = String(x.deadline_date ?? x.deadline ?? x.due ?? "").trim();
    const taskText = String(x.task_name ?? x.task ?? x.nhiemVu ?? x["Nhiệm vụ"] ?? "").trim();
    if (!taskText || (!isNaN(taskText) && String(taskText).trim() !== "")) return null;
    if (taskText.length < 2) return null;

    const owner = String(x.officer_name ?? x.owner ?? x.sheet_name ?? "Chưa xác định").trim();
    const _isRegRaw = x.is_regular === true || String(x.is_regular || "").toLowerCase() === "true" || String(x.status || "").trim().toLowerCase() === "thường xuyên" || String(x.status || "").trim().toLowerCase() === "regular";
    const obj = {
        id: x.id,
        owner,
        position: String(x.position ?? "").trim(),
        stt: x.stt ?? x.id ?? (i + 1),
        task: taskText,
        role: String(x.role ?? "").trim(),
        due,
        completed_date: String(x.completed_date ?? x.completed ?? "").trim(),
        status: canonicalStatus(x.status),
        admin_note: String(x.note ?? x.admin_note ?? "").trim(),
        staff_note: String(x.staff_note ?? "").trim(),
        emergent: x.is_arising === true || x.emergent === true,
        extended: x.is_extended === true || x.extended === true,
        is_regular: _isRegRaw,
        product: String(x.product ?? "").trim() || "Không",
        attachment_path: String(x.attachment_path ?? "").trim(),
        attachment_name: String(x.attachment_name ?? "").trim(),
        attachment_type: String(x.attachment_type ?? "").trim(),
        attachment_size: Number(x.attachment_size ?? 0) || 0,
        attachment_approved: x.attachment_approved === undefined || x.attachment_approved === null
            ? !!String(x.attachment_path ?? "").trim()
            : x.attachment_approved === true,
        attachment_approved_at: String(x.attachment_approved_at ?? "").trim(),
        attachment_approved_by: String(x.attachment_approved_by ?? "").trim(),
        sheet_name: String(x.sheet_name ?? "").trim(),
        row_number: Number(x.row_number ?? 0) || 0,
        updated_at: String(x.updated_at ?? "").trim(),
        created_at: String(x.created_at ?? x.createdAt ?? "").trim(),
        _source: source
    };
    if (obj.is_regular && obj.status === "Thường xuyên") obj.status = "Đang triển khai";
    obj._matchKey = taskMatchKey(owner, taskText);
    obj.status = calculateTaskStatus(obj, { _regular: false });
    obj._dueDate = parseDate(due);
    obj._createdDate = getCreationDate(obj);
    try { obj.role = officeRoleCanonical(obj.role) || obj.role; } catch (e) {}
    obj._search = (obj.task + " " + obj.owner + " " + obj.role + " " + (officeRoleDisplay(obj.role) || "") + " " + obj.staff_note + " " + obj.admin_note + " " + obj.product).toLowerCase();
    return obj;
}

    function alertHTML(x) {
        const u = urgencyInfo(x);
        const urgencyColor = u.cls.includes("overdue") ? "#ef4444" : u.cls.includes("today") ? "#f59e0b" : "#3b82f6";
        return `<div class="alert-item">
                    <div class="alert-indicator" style="background: ${urgencyColor}"></div>
                    <div class="alert-content">
                        <div class="alert-task" onclick="event.stopPropagation(); openHomeTaskDrill('${String(homeSourceKey(x)).replace(/'/g,"\\'")}', '${String(x.id).replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')" title="${esc(x.task || x.task_name)}">
                            ${esc(String(x.task || x.task_name || "").slice(0, 55))}${String(x.task || x.task_name || "").length > 55 ? "..." : ""}
                        </div>
                        <div class="alert-meta">👤 ${esc(x.owner || x.officer_name || "")} · 📅 ${formatDate(homeDue(x))}</div>
                    </div>
                </div>`;
    }

function exportWorkspaceExcelDo(ws, selectedPeople){
    const w = String(ws || "").toLowerCase();
    const target = (w === "action100" && typeof ACTION100_MODE !== "undefined" && ACTION100_MODE === "vpub") ? "vpub" : w;
    const dateTag = new Date().toISOString().slice(0, 10);
    const fmt = v => { if (!v) return ""; try { if (typeof formatDate === "function" && /^\d{4}-\d{2}-\d{2}/.test(String(v))) return formatDate(v); } catch (e) {} return String(v); };
    const dmn = v => { try{ return (typeof demoMaskName==='function' ? demoMaskName(v) : v); }catch(e){ return v; } };
    const dmt = v => { try{ return (typeof demoMaskText==='function' ? demoMaskText(v) : v); }catch(e){ return v; } };
    const matchPeople=(name)=>{ if(!selectedPeople||!selectedPeople.length) return true; const n=String(name||"").trim(); return selectedPeople.some(s=> String(s).trim()===n); };
    try {
        if (target === "office") {
            let src = (typeof filtered !== "undefined" && filtered && filtered.length) ? filtered : (typeof DATA !== "undefined" ? DATA : []);
            src = src.filter(x=> matchPeople(x.owner||x.officer_name));
            if (!src.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
            const headers = ["STT", "Nhiệm vụ", "Cán bộ", "Vai trò", "Hạn", "Ngày hoàn thành", "Trạng thái", "Sản phẩm", "Ghi chú cán bộ", "Ghi chú Admin", "Tệp đính kèm"];
            const rows = src.map((x, i) => [i + 1, dmt(x.task || x.task_name || ""), dmn(x.owner || x.officer_name || ""), x.role || x.unit_name || "", fmt(x.due || x.deadline || x.deadline_date || ""), fmt(x.completed_date || x.completed || ""), x.status || x.statusKey || "", dmt(x.product || "Không"), dmt(x.staff_note || ""), dmt(x.admin_note || ""), isAdmin ? (x.attachment_path ? (x.attachment_approved ? (x.attachment_name || "Đã duyệt") : "Chờ duyệt") : "") : (x.attachment_approved ? "Đã duyệt" : (x.attachment_path ? "Chờ duyệt" : ""))]);
            return exportToExcel({ filename: `VP_DangUy_${dateTag}.xlsx`, sheetName: "VP Dang uy", headers, rows });
        }
        if (target === "bch") {
            const all = (typeof BCH_TASKS !== "undefined" ? BCH_TASKS : []);
            let src = (typeof BCH_FILTERED !== "undefined" && BCH_FILTERED && (BCH_FILTERED.length || document.getElementById("bchSearch")?.value || document.getElementById("bchStatusFilter")?.value !== "all")) ? BCH_FILTERED : all;
            src = src.filter(x=> matchPeople(x.officer_name));
            if (!src.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const omap = (typeof bchOfficerMap === "function" ? bchOfficerMap() : new Map());
            const headers = ["STT", "Nhiệm vụ cụ thể", "Cán bộ", "Chức vụ", "Chuyên viên", "Nguồn giao", "Hạn hoàn thành", "Ngày hoàn thành", "Kết quả", "Trạng thái"];
            const sheets = selectedPeople.map(p=>{
                const personRows = src.filter(x=> String(x.officer_name||"").trim() === String(p).trim());
                const rows = personRows.map((x, i) => {
                    const o = omap.get(typeof bchFold === "function" ? bchFold(x.officer_name) : String(x.officer_name || "").toLowerCase()) || {};
                    const st = (typeof bchStatusLabel === "function" ? bchStatusLabel(x.statusKey) : x.statusKey || "");
                    const result = [x.product, x.result].map(v => String(v || "").trim()).find(v => v) || "Chưa điền";
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), o.title || "", dmn(x.specialist_name || ""), x.source_doc || x.amount || "", fmt(x.deadline || ""), fmt(x.completed_date || ""), dmt(result), st];
                });
                const sheetName = String(p||"Chưa rõ").slice(0,31).replace(/[\\\/\?\*\[\]\:]/g,"_");
                return { sheetName, headers, rows };
            }).filter(s=> s.rows.length);
            if (!sheets.length) {
                const rows = src.map((x, i) => {
                    const o = omap.get(typeof bchFold === "function" ? bchFold(x.officer_name) : String(x.officer_name || "").toLowerCase()) || {};
                    const st = (typeof bchStatusLabel === "function" ? bchStatusLabel(x.statusKey) : x.statusKey || "");
                    const result = [x.product, x.result].map(v => String(v || "").trim()).find(v => v) || "Chưa điền";
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), o.title || "", dmn(x.specialist_name || ""), x.source_doc || x.amount || "", fmt(x.deadline || ""), fmt(x.completed_date || ""), dmt(result), st];
                });
                return exportToExcel({ filename: `BCH_DangBo_${dateTag}.xlsx`, sheetName: "BCH", headers, rows });
            }
            return exportToExcelMulti(`BCH_DangBo_${dateTag}.xlsx`, sheets);
        }
        if (target === "ttbtv") {
            const all = (typeof TTBTV_TASKS !== "undefined" ? TTBTV_TASKS : []);
            const src = (typeof TTBTV_FILTERED !== "undefined" && TTBTV_FILTERED ? TTBTV_FILTERED : all);
            let use = src.length ? src : all;
            use = use.filter(x=> matchPeople(x.officer_name));
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ", "Lãnh đạo phụ trách", "Cơ quan chủ trì", "Lãnh đạo UBND", "Chuyên viên", "Hạn hoàn thành", "Ngày hoàn thành", "Số ngày còn lại", "Trạng thái", "Kết quả", "Nguồn giao"];
            const sheets = selectedPeople.map(p=>{
                const personRows = use.filter(x=> String(x.officer_name||"").trim() === String(p).trim());
                const rows = personRows.map((x, i) => {
                    const st = (typeof ttbtvStatusLabel === "function" ? ttbtvStatusLabel(x.statusKey) : x.statusKey || "");
                    let remain = "";
                    try { const s = (typeof ttbtvStatusGroup === "function" ? ttbtvStatusGroup(x.statusKey) : ""); if (["done"].includes(s)) remain = "Đã hoàn thành"; else { const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"; } } catch (e) { remain = ""; }
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), x.role || x.unit_name || "", dmn(x.officer_name || ""), dmn(x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || x.staff_note || ""), x.amount || x.source_doc || ""];
                });
                const sheetName = String(p||"Chưa rõ").slice(0,31).replace(/[\\\/\?\*\[\]\:]/g,"_");
                return { sheetName, headers, rows };
            }).filter(s=> s.rows.length);
            if (!sheets.length) {
                const rows = use.map((x, i) => {
                    const st = (typeof ttbtvStatusLabel === "function" ? ttbtvStatusLabel(x.statusKey) : x.statusKey || "");
                    let remain = "";
                    try { const s = (typeof ttbtvStatusGroup === "function" ? ttbtvStatusGroup(x.statusKey) : ""); if (["done"].includes(s)) remain = "Đã hoàn thành"; else { const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"; } } catch (e) { remain = ""; }
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), x.role || x.unit_name || "", dmn(x.officer_name || ""), dmn(x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || x.staff_note || ""), x.amount || x.source_doc || ""];
                });
                return exportToExcel({ filename: `TT_BTV_${dateTag}.xlsx`, sheetName: "TT BTV", headers, rows });
            }
            return exportToExcelMulti(`TT_BTV_${dateTag}.xlsx`, sheets);
        }
        if (target === "province") {
            let use = [];
            try { if (typeof PROV_FILTERED !== "undefined" && PROV_FILTERED && PROV_FILTERED.length) use = PROV_FILTERED; } catch (e) {}
            if (!use.length) { try { const tr = (typeof getPROVTreeRows === "function" ? getPROVTreeRows(null) : null); if (tr && tr.length) use = tr; } catch (e) {} }
            if (!use.length && typeof PROV_TASKS !== "undefined" && PROV_TASKS.length) use = PROV_TASKS;
            use = use.filter(x=> matchPeople(x.officer_name || x.officer));
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ cụ thể", "Cơ quan tham mưu", "Lãnh đạo phụ trách", "Hạn hoàn thành", "Ngày hoàn thành", "Thời gian còn lại", "Tiến độ", "Trạng thái", "Sản phẩm", "Nguồn giao", "Văn bản tỉnh", "Văn bản xã"];
            const rows = use.map((x, i) => {
                const st = (typeof provinceStatusLabel === "function" && x.statusKey ? provinceStatusLabel(x.statusKey) : (x.statusKey || x.status || ""));
                let remain = x.remaining || "";
                try { if (!remain && x.deadline) { const d = (typeof provinceParseDate === "function" ? provinceParseDate(x.deadline) : (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null)); if (d) { const diff = Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000); remain = diff >= 0 ? `${diff} ngày` : `Quá ${Math.abs(diff)} ngày`; } } } catch (e) {}
                const leader = (typeof provinceTaskLeader === "function" ? provinceTaskLeader(x) : (String(x.role || "").trim() || String(x.officer_name || x.officer || "").trim())) || x.officer_name || x.officer || "";
                return [i + 1, dmt(x.task_name || x.nhiem_vu || ""), x.unit_name || x.role || x.agency || "", dmn(leader), fmt(x.deadline || ""), fmt(x.completed_date || x.completed || ""), remain, x.progress || "", typeof provinceBadgeStatus === "function" ? provinceBadgeStatus(x) : st, dmt(x.product || x.result || ""), x.amount || x.source_doc || "", x.van_ban_tinh || x.source || "", x.van_ban_xa || ""];
            });
            return exportToExcel({ filename: `TinhGiao_${dateTag}.xlsx`, sheetName: "Tinh giao", headers, rows });
        }
        if (target === "action100") {
            const all = (typeof ACTION100_TASKS !== "undefined" ? ACTION100_TASKS : []);
            let use = all;
            try {
                const q = (typeof provinceFold === "function" ? provinceFold(document.getElementById("action100Search")?.value || "") : String(document.getElementById("action100Search")?.value || "").toLowerCase());
                const filter = document.getElementById("action100Status")?.value || "all";
                const timeMode = document.getElementById("action100TimeFilter")?.value || "all";
                const agency = document.getElementById("action100Agency")?.value || "all";
                use = all.filter(x => {
                    const s = (typeof action100Status === "function" ? action100Status(x) : "");
                    const matchesFilter = filter === "all" || s === filter || (filter === "done" && ["early", "ontime", "latedone"].includes(s));
                    if (!matchesFilter) return false;
                    if (timeMode !== "all") { const d = (typeof getCreationDate === "function" ? getCreationDate(x) : null); if (d && typeof isDateInTimeRange === "function" && !isDateInTimeRange(d, timeMode)) return false; }
                    if (agency !== "all") {
                        const norm = v => String(v || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/Đ/g, "D").replace(/đ/g, "d").toLowerCase().trim();
                        const ag = norm(agency); const av = norm(x.commune_leader); const bv = norm(x.unit_name); if (ag !== av && ag !== bv) return false;
                    }
                    if (!q) return true;
                    const label = (typeof provinceFold === "function" ? provinceFold(typeof action100Label === "function" ? action100Label(s) : s) : "");
                    const hay = (typeof provinceFold === "function" ? provinceFold(`${x.task_name || ""} ${x.officer_name || ""} ${x.commune_leader || ""} ${x.unit_name || ""} ${x.product || ""}`) : "");
                    return hay.includes(q) || label.includes(q);
                });
                if (!document.getElementById("action100Search")?.value && filter === "all" && timeMode === "all" && agency === "all") use = all;
                else if (!use.length && !q && filter === "all") use = all;
            } catch (e) {}
            use = use.filter(x=> { const n=String(x.commune_leader||x.officer_name||"").trim(); return selectedPeople.some(s=> String(s).trim()===n) || (!n && selectedPeople.length===0); }); if(!selectedPeople.length) use=all.filter(x=>true);
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ", "Cơ quan phụ trách", "Cơ quan phối hợp", "Lãnh đạo cơ quan phụ trách", "Lãnh đạo xã", "Chuyên viên", "Hạn hoàn thành", "Ngày hoàn thành", "Số ngày còn lại", "Trạng thái", "Sản phẩm", "Ghi chú"];
            const rows = use.map((x, i) => {
                const st = (typeof action100Label === "function" ? action100Label(typeof action100Status === "function" ? action100Status(x) : "") : "");
                let remain = "";
                try { const done = ["early", "ontime", "latedone"].includes(typeof action100Status === "function" ? action100Status(x) : ""); const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = done ? "Đã hoàn thành" : (d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"); } catch (e) {}
                return [i + 1, dmt(x.task_name || ""), x.commune_leader || "", x.unit_name || "", dmn(x.office_leader || ""), dmn(x.xa_leader || ""), dmn(x.officer_name || x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || ""), dmt(x.admin_note || x.staff_note || "")];
            });
            return exportToExcel({ filename: `KH100_${dateTag}.xlsx`, sheetName: "KH100", headers, rows });
        }
        if (target === "vpub") {
            const all = (typeof ACTION100_TASKS !== "undefined" ? ACTION100_TASKS : []);
            let use = all;
            try {
                const q = (typeof provinceFold === "function" ? provinceFold(document.getElementById("action100Search")?.value || "") : String(document.getElementById("action100Search")?.value || "").toLowerCase());
                const filter = document.getElementById("action100Status")?.value || "all";
                use = all.filter(x => {
                    const s = (typeof action100Status === "function" ? action100Status(x) : "");
                    const matchesFilter = filter === "all" || s === filter || (filter === "done" && ["early", "ontime", "latedone"].includes(s));
                    if (!matchesFilter) return false;
                    if (!q) return true;
                    const hay = (typeof provinceFold === "function" ? provinceFold(`${x.task_name || ""} ${x.unit || ""} ${x.field || ""} ${x.leader || ""} ${x.office_leader || ""}`) : "");
                    return hay.includes(q);
                });
                if (!document.getElementById("action100Search")?.value && filter === "all") use = all;
            } catch (e) {}
            use = use.filter(x=>{ const cands=[x.unit, x.office_leader, x.leader].map(v=>String(v||"").trim()).filter(Boolean); return cands.some(c=> selectedPeople.includes(c)); });
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nguồn giao", "Nội dung nhiệm vụ", "Cơ quan phụ trách", "Cơ quan phối hợp", "Lãnh đạo xã", "Lãnh đạo CQ phụ trách", "Ngày bắt đầu", "Thời hạn", "Kết quả tuần", "Khó khăn", "Đề xuất", "Trạng thái", "Ghi chú"];
            const rows = use.map((x, i) => {
                const st = (typeof action100Label === "function" ? action100Label(typeof action100Status === "function" ? action100Status(x) : "") : "");
                return [i + 1, dmt(x.source || ""), dmt(x.task_name || ""), x.unit || "", x.field || "", dmn(x.leader || ""), dmn(x.office_leader || ""), fmt(x.start_date || ""), fmt(x.deadline || ""), dmt(x.weekly_result || x.product || ""), dmt(x.difficulties || ""), dmt(x.proposal || ""), st, dmt(x.note || x.admin_note || "")];
            });
            return exportToExcel({ filename: `VPUB_${dateTag}.xlsx`, sheetName: "VPUB", headers, rows });
        }
        if (target === "mttq") {
            const scoped = (typeof mttqKpiScopedTasks === "function" ? mttqKpiScopedTasks() : (typeof MTTQ_KPI_TASKS !== "undefined" ? MTTQ_KPI_TASKS : []));
            const q = (typeof mttqKpiFold === "function" ? mttqKpiFold(document.getElementById("mttqKpiSearch")?.value) : "");
            const statusFilter = document.getElementById("mttqKpiStatusFilter")?.value || "all";
            let use = scoped.filter(x => { const status = (typeof mttqKpiStatusKey === "function" ? mttqKpiStatusKey(x) : ""); if (statusFilter !== "all" && status !== statusFilter && !(statusFilter === "done" && typeof mttqKpiIsDone === "function" && mttqKpiIsDone(x))) return false; if (!q) return true; const hay = (typeof mttqKpiFold === "function" ? mttqKpiFold(`${typeof mttqKpiPersonName === "function" ? mttqKpiPersonName(x) : ""} ${x.task_name} ${x.assigner} ${x.product} ${x.outcome}`) : ""); return hay.includes(q); });
            if (!use.length && !q && statusFilter === "all") use = scoped;
            use = use.filter(x=>{ const n=String((typeof mttqKpiPersonName==="function"?mttqKpiPersonName(x):"").trim()); return selectedPeople.includes(n); });
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Cán bộ", "Nhiệm vụ", "Người giao", "Hạn", "Kết quả", "Số lần sai sót", "Cấp độ", "Hệ số", "Điểm quy đổi", "Trục KPI", "Sản phẩm", "Ghi chú", "Trạng thái", "Tháng", "Năm"];
            const rows = use.map((x, i) => [i + 1, dmn((typeof mttqKpiPersonName === "function" ? mttqKpiPersonName(x) : "")), dmt(x.task_name || ""), dmn(x.assigner || ""), (typeof mttqKpiDateDisplay === "function" ? mttqKpiDateDisplay(x.deadline) : fmt(x.deadline || "")), x.outcome || "Chưa hoàn thành", x.quality_errors ?? 0, x.level ?? "", x.conversion_factor ?? "", (typeof mttqKpiScore === "function" ? mttqKpiScore(x).toFixed(2) : ""), x.kpi_axis || "", dmt(x.product || ""), dmt(x.note || ""), (typeof mttqKpiStatusLabel === "function" ? mttqKpiStatusLabel(typeof mttqKpiStatusKey === "function" ? mttqKpiStatusKey(x) : "") : ""), x.task_month || "", x.task_year || ""]);
            return exportToExcel({ filename: `KPI_MTTQ_${dateTag}.xlsx`, sheetName: "KPI MTTQ", headers, rows });
        }
        return showToast("error", "Không hỗ trợ", `Workspace ${ws} chưa có cấu hình xuất Excel.`);
    } catch (e) { console.error("exportWorkspaceExcel fail", e); try { showToast("error", "Xuất Excel lỗi", e.message); } catch (err) {} }
}

function exportWorkspaceExcel(ws){
    const w=String(ws||"").toLowerCase(); const target=(w==="action100"&&typeof ACTION100_MODE!=="undefined"&&ACTION100_MODE==="vpub")?"vpub":w;
    const people=getExportPeople(target);
    if(!people.length) return showToast("info","Không có dữ liệu","Workspace chưa có người để chọn.");
    openExportSelectModal(ws);
}

function setupVPUBDateFields() {
    if (ACTION100_MODE !== 'vpub') return;
    const field = document.getElementById('vpubField');
    if (field) {
        const currentField = field.value;
        const label = field.previousElementSibling; if (label) label.textContent = 'Cơ quan phối hợp';
        if (field.tagName !== 'SELECT') {
            const select = document.createElement('select'); select.id = 'vpubField'; field.replaceWith(select);
        }
        const select = document.getElementById('vpubField'); select.innerHTML = '<option value="">Chọn cơ quan phối hợp</option>' + VPUB_AGENCY_LIST.map(o => `<option>${o}</option>`).join('') + '<option value="__other__">Khác (nhập tên)</option>'; if (currentField) select.value = currentField; select.onchange = () => ttbtvHandleRoleOther(select);
    }
    ['vpubStartDate', 'vpubDeadline', 'action100EditDue', 'action100EditCompleted'].forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        el.type = 'text'; el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric'; el.oninput = () => dateMask(el);
        if (typeof vpubWrapDateInput === 'function') vpubWrapDateInput(el);
    });
}

function ppParseDate(s) { const t = String(s || '').trim(); const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) { const d = new Date(+iso[1], +iso[2] - 1, +iso[3]); return isNaN(d) ? null : d; } const p = t.split('/'); if (p.length !== 3) return null; if (!/^\d{4}$/.test(String(p[2]).trim())) return null; const y=+p[2], m=+p[1], day=+p[0]; if(m<1||m>12||day<1||day>31) return null; const d = new Date(y, m - 1, day); if(d.getFullYear()!==y||d.getMonth()!==m-1||d.getDate()!==day) return null; return isNaN(d) ? null : d; }

function ppDateInputVal(v) { const t = String(v || '').trim(); if (!t) return ''; const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`; const m = t.match(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/); if (m) return `${m[3]}-${String(m[2]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`; return ''; }

function ppDateDisplayVal(v) { const d = ppParseDate(v); return d ? `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` : ''; }

function ppDispDate(v) { const t = String(v || '').trim(); if (!t) return ''; const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`; return t; }

function ppNormalizeDateInputs() { document.querySelectorAll('#provincePlanTree input.date-ddmmyyyy').forEach(el => { const raw = el.value || ''; if (el.type !== 'text') el.type = 'text'; if (raw) { const isIso = /^\d{4}-\d{2}-\d{2}/.test(raw); const isFullDMY = /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(raw.trim()); if(isIso||isFullDMY){ const fmt = ppDateDisplayVal(raw); if (fmt && fmt !== raw) el.value = fmt; } } el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric'; if(!el._ppBound){ el._ppBound=true; el.addEventListener('input', () => { dateMask(el); try{ ppUpdateAll(); }catch(e){} }); el.addEventListener('blur', () => { const v=(el.value||'').trim(); if(!v) return; const d=ppParseDate(v); if(d){ const fmt=ppDateDisplayVal(v); if(fmt) el.value=fmt; } }); } }); }

function vpubWrapDateInput(el) {
    if (!el || el.dataset.calWrapped) return;
    el.dataset.calWrapped = '1';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:100%;box-sizing:border-box';
    el.parentElement.insertBefore(wrap, el);
    wrap.appendChild(el);
    el.style.paddingRight = '26px';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pp-date-btn'; b.title = 'Chọn ngày'; b.textContent = '📅';
    b.style.cssText = 'position:absolute;right:2px;top:50%;transform:translateY(-50%);border:none;background:transparent;cursor:pointer;font-size:14px;line-height:1;padding:2px 4px';
    b.onclick = function () { vpubOpenDatePicker(b); };
    wrap.appendChild(b);
}

/* Generic: every input marked data-ds-date="1" becomes a dd/mm/yyyy masked text field + calendar button */
function dsNormalizeDateFields(root) {
    const scope = root && root.querySelectorAll ? root : document;
    scope.querySelectorAll('input[data-ds-date]').forEach(el => {
        if (!el.dataset.dsDateDone) {
            el.dataset.dsDateDone = '1';
            if (el.type === 'date') {
                const raw = el.value;
                el.type = 'text';
                if (raw) { let s = ''; try { s = ppDateDisplayVal(raw) || ''; } catch (e) {} if (!s) { try { s = formatDate(raw) || ''; } catch (e) {} } if (s) el.value = s; }
            }
            el.placeholder = 'dd/mm/yyyy';
            el.inputMode = 'numeric';
            el.removeAttribute('lang');
            const cls = el.getAttribute('class') || '';
            if (cls.indexOf('date-ddmmyyyy') < 0) el.className = (cls ? cls + ' ' : '') + 'date-ddmmyyyy';
            if (!el.getAttribute('oninput')) el.setAttribute('oninput', 'dateMask(this)');
        }
        // calendar button: vpubWrapDateInput only exists after legacy.js loads, so keep retrying
        if (el.dataset.calWrapped || typeof window.vpubWrapDateInput !== 'function') return;
        const prevParent = el.parentElement;
        try { window.vpubWrapDateInput(el); } catch (e) { return; }
        if (el.parentElement && el.parentElement !== prevParent) el.parentElement.classList.add('ds-date-wrap');
    });
}
function dsWatchDateFields() {
    try { dsNormalizeDateFields(document); } catch (e) {}
    if (window._dsDateObserver || !document.body) return;
    let t = null;
    window._dsDateObserver = new MutationObserver(() => { if (t) return; t = setTimeout(() => { t = null; try { dsNormalizeDateFields(document); } catch (e) {} }, 60); });
    window._dsDateObserver.observe(document.body, { childList: true, subtree: true });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', dsWatchDateFields); else dsWatchDateFields();

function setupTTBTVDateFields() {
    const map = { ttbtvAddDeadline: 'add', ttbtvAddCompleted: 'add', ttbtvNewDeadline: 'new', ttbtvNewCompleted: 'new', ttbtvEditDue: 'edit', ttbtvEditCompleted: 'edit', ttbtvRoleUBNDDue: 'new', ttbtvRoleUBNDDone: 'new', ttbtvRolePhongDue: 'new', ttbtvRolePhongDone: 'new', ttbtvRoleCVDue: 'new', ttbtvRoleCVDone: 'new', ttbtvEditRoleUBNDDue: 'edit', ttbtvEditRoleUBNDDone: 'edit', ttbtvEditRolePhongDue: 'edit', ttbtvEditRolePhongDone: 'edit', ttbtvEditRoleCVDue: 'edit', ttbtvEditRoleCVDone: 'edit' };
    Object.keys(map).forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        if (el.type !== 'text') el.type = 'text';
        el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric';
        el.oninput = () => { dateMask(el); try { if (id === 'ttbtvRoleUBNDDone' || id === 'ttbtvRolePhongDone') { try { ttbtvSyncMainDatesFromLeader('new'); } catch(e){} } else if (id === 'ttbtvEditRoleUBNDDone' || id === 'ttbtvEditRolePhongDone') { try { ttbtvSyncMainDatesFromLeader('edit'); } catch(e){} } if (map[id] === 'add') refreshTTBTVAddStatus(); else if (map[id] === 'new') refreshTTBTVNewStatus(); else refreshTTBTVAutoStatus(); } catch (e) {} };
        if (typeof ttbtvWrapDateInput === 'function') ttbtvWrapDateInput(el);
    });
}

function setupBCHDateFields() {
    const map = { bchAddDeadline: 'add', bchAddCompleted: 'add', bchNewDeadline: 'new', bchNewCompleted: 'new', bchEditDue: 'edit', bchEditCompleted: 'edit' };
    Object.keys(map).forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        if (el.type !== 'text') el.type = 'text';
        el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric';
        el.oninput = () => { dateMask(el); try { if (map[id] === 'add') refreshBCHAddStatus(); else if (map[id] === 'new') refreshBCHNewStatus(); else refreshBCHAutoStatus(); } catch (e) {} };
        if (typeof bchWrapDateInput === 'function') bchWrapDateInput(el);
    });
}

function ppNorm(s){ return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase().trim(); }

function ppInitials(s){ const n=ppNorm(s); if(!n.includes(' ') && n.length<=6 && /^[a-z0-9]+$/.test(n)) return n; return n.split(/[^a-z0-9]+/).filter(Boolean).map(w=>w[0]).join(''); }
