/* js/modules/ttbtv.js — tach tu js/legacy.js (nhom 6 TTBTV/VPUB/Action100/Office).
 * Classic script (window globals), load SAU auth, TRUOC legacy.js.
 */

function refreshEditOfficeRegular() {
    refreshEditAutoStatus();
}

async function deleteOfficeTask() {
    let x = null; if (window.OFFICE_EDIT_ID != null) x = DATA.find(r => String(r.id) === String(window.OFFICE_EDIT_ID)); if (!x && editingDataIndex >= 0) x = DATA[editingDataIndex];
    const idx = x ? DATA.indexOf(x) : -1;
    if (!x) { showToast("error", "Không thể xóa nhiệm vụ", "Không tìm thấy nhiệm vụ đang chỉnh sửa."); return; }
    if (!canEditTask(x)) { showToast("error", "Không có quyền", "Bạn không có quyền xóa nhiệm vụ này."); return; }

    const hasFile = !!x.attachment_path || !!x.attachment_name;
    const name = x.task || "Nhiệm vụ";
    const summary = `
                <div class="confirm-row"><span>Cán bộ</span><strong>${esc(x.owner || "")}</strong></div>
                <div class="confirm-row"><span>Nhiệm vụ</span><strong>${esc(name)}</strong></div>
                ${hasFile ? `<div class="confirm-row"><span>Tệp đính kèm</span><strong>${esc(x.attachment_name || "Có")}</strong></div><div class="confirm-note">Lưu ý: nếu chọn "Không, chỉ xóa nhiệm vụ", tệp vẫn được giữ lại trong Storage.</div>` : ""}
            `;
    openDeleteTaskConfirm({
        label: `Xóa nhiệm vụ "${name}"?`,
        summary,
        hasFile,
        onConfirm: async (deleteFile) => {
            try {
                if (deleteFile && x.attachment_path) {
                    const delUrl = `${SUPABASE_URL}/storage/v1/object/${STORAGE_BUCKET}/${encodePath(x.attachment_path)}`;
                    const dr = await fetch(delUrl, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                    if (!dr.ok && dr.status !== 404) { const tx = await dr.text(); throw new Error(tx || `Storage HTTP ${dr.status}`); }
                }
                const delUrl2 = `${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`;
                const r = await fetch(delUrl2, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (!r.ok && r.status !== 404) { const tx = await r.text(); throw new Error(tx || `HTTP ${r.status}`); }

                DATA.splice(idx, 1);
        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
        writeCache("vp_tasks_cache", DATA);
        rebuildFilters();
                applyFilters();
                if (typeof refreshActiveDrillPopup === "function") refreshActiveDrillPopup();
                closeEditTask();
                writeActivity("Xóa nhiệm vụ", { task: name, id: x.id, delete_file: deleteFile });
                showToast("success", "Đã xóa nhiệm vụ", `Đã xóa nhiệm vụ "${name}".`);
            } catch (e) {
                console.error(e);
                showToast("error", "Không thể xóa nhiệm vụ", e.message || "Vui lòng thử lại.", 6000);
            }
        }
    });
}

function officePerformanceRows() {
    const query = (document.getElementById("officePerformanceSearch")?.value || "").toLowerCase().trim();
    const status = document.getElementById("officePerformanceStatus")?.value || "";
    const drange = document.getElementById("officePerformanceDate")?.value || "";
    const quarter = document.getElementById("officeQuarterFilter")?.value || "";
    const month = document.getElementById("officeMonthFilter")?.value || "";
    const rows = DATA.filter(x => {
        if (query && !String(x._search || "").includes(query)) return false;
        if (status) {
            if (status === "Hoàn thành") { if (!completedStatuses.has(x.status)) return false; }
            else if (status === "Thường xuyên") { if (!x.is_regular) return false; }
            else if (status === "Phát sinh") { if (!(x.emergent || x.is_arising)) return false; }
            else if (x.status !== status) return false;
        }
        if (drange) {
            const isNextMonth = drange === "nextMonth";
            if (isNextMonth) {
                const d = x._dueDate || parseDate(x.due);
                if (!d || !isDateInTimeRange(d, drange)) return false;
            } else {
                const isRegular = !!x.is_regular;
                if (!isRegular) {
                    const d = x._createdDate || getCreationDate(x);
                    if (!d || !isDateInTimeRange(d, drange)) return false;
                }
            }
        }
        if (quarter) {
            // Thuong xuyen hien moi thang/quy (giong applyFilters bang chinh)
            if (!x.is_regular) {
                const d = x._createdDate || getCreationDate(x);
                if (!d) return false;
                const q = Math.floor(d.getMonth() / 3) + 1;
                if (q !== Number(quarter)) return false;
            }
        }
        if (month) {
            // Thuong xuyen hien moi thang/quy (giong applyFilters bang chinh)
            if (!x.is_regular) {
                const d = x._createdDate || getCreationDate(x);
                if (!d) return false;
                if (d.getMonth() + 1 !== Number(month)) return false;
            }
        }
        return true;
    });
    if (drange === "nextMonth") {
        return [...rows].sort((a, b) => {
            const da = a._dueDate || parseDate(a.due); const db = b._dueDate || parseDate(b.due);
            if (!da && !db) return 0; if (!da) return 1; if (!db) return -1; return da - db;
        });
    }
    return rows;
}

function resetOfficePerformanceFilter() { const q = document.getElementById("officePerformanceSearch"), s = document.getElementById("officePerformanceStatus"), d = document.getElementById("officePerformanceDate"), qq = document.getElementById("officeQuarterFilter"), mm = document.getElementById("officeMonthFilter"); if (q) q.value = ""; if (s) s.value = ""; if (d) d.value = ""; if (qq) qq.value = ""; if (mm) mm.value = ""; renderOfficeCharts(); }

function officeKpiRows(type) {
    const quarter = document.getElementById("officeQuarterFilter")?.value || "";
    const month = document.getElementById("officeMonthFilter")?.value || "";
    return DATA.filter(x => {
        // Thuong xuyen hien moi thang/quy (giong applyFilters bang chinh)
        if ((quarter || month) && !x.is_regular) {
            const d = x._createdDate || getCreationDate(x);
            if (!d) return false;
            if (quarter && Math.floor(d.getMonth() / 3) + 1 !== Number(quarter)) return false;
            if (month && d.getMonth() + 1 !== Number(month)) return false;
        }
        const n = dayDiff(x.due);
        if (type === "total") return true;
        if (type === "done") return completedStatuses.has(x.status);
        if (type === "doing") return x.status === "Đang triển khai";
        if (type === "late") return action100StatusText(x.status) === "qua han";
        if (type === "soon") return n !== null && n >= 0 && n <= 3 && !completedStatuses.has(x.status);
        if (type === "regular") return !!x.is_regular;
        if (type === "emergent") return Boolean(x.emergent || x.is_arising);
        return false;
    });
}

function officeAlertHTML(x) {
    const n = dayDiff(x.due);
    const urgencyColor = x.status === "Quá hạn" ? "#D55E00" : n === 0 ? "#f59e0b" : "#3b82f6";
    return `<div class="alert-item"><div class="alert-indicator" style="background:${urgencyColor}"></div><div class="alert-content"><div class="alert-task" onclick="event.stopPropagation(); drillTask('${esc(x.owner)}')" title="${esc(x.task)}">${esc(x.task.slice(0, 55))}${x.task.length > 55 ? "..." : ""}</div><div class="alert-meta">👤 ${esc(x.owner)} · 📅 ${formatDate(x.due)}</div></div></div>`;
}

function officeAlertRows(type) {
    return DATA.filter(x => {
        if (completedStatuses.has(x.status)) return false;
        const n = dayDiff(x.due);
        if (type === "overdue") return action100StatusText(x.status) === "qua han";
        if (type === "today") return n === 0;
        if (type === "soon3") return n !== null && n >= 1 && n <= 3;
        if (type === "soon7") return n !== null && n >= 1 && n <= 7;
        return false;
    });
}

function officeDrillAlert(type) {
    const meta = { overdue: ["Văn phòng · Nhiệm vụ quá hạn", "⏰"], today: ["Văn phòng · Nhiệm vụ đến hạn hôm nay", "📅"], soon3: ["Văn phòng · Sắp đến hạn ≤ 3 ngày", "⏳"], soon7: ["Văn phòng · Sắp đến hạn ≤ 7 ngày", "🗓️"] };
    const [title, icon] = meta[type] || ["Văn phòng · Chi tiết nhiệm vụ", "📋"];
    showDrill(officeAlertRows(type), title, icon);
}

function handleOfficeChartDrill(canvasId, label) {
    if (!canAccessOfficeData(CURRENT_USER)) { showToast('error', 'Khong co quyen', 'Token nay khong duoc xem du lieu Van phong.'); return; }
    if (canvasId === "officeChart1") { showDrill(DATA.filter(x => x.status === label), `Văn phòng · ${label}`, "🎯"); return; }
    if (canvasId === "officeChart2") {
        const map = { "Quá hạn": "overdue", "Hôm nay": "today", "Sắp đến ≤3 ngày": "soon3", "An toàn": "safe", "Hoàn thành": "done" };
        showDrill(DATA.filter(x => urgencyInfo(x).key === map[label]), `Văn phòng · Thời hạn ${label}`, "⏰"); return;
    }
    if (canvasId === "officeChart3") { showDrill(DATA.filter(x => (x.owner || "Chưa xác định") === label), `Văn phòng · ${label}`, "👤"); return; }
    if (canvasId === "officeChart4") { showDrill(DATA.filter(x => officeChartRole(x.role) === label), `Văn phòng · Vai trò ${label}`, "🧭"); return; }
}

function openOfficeWorkspace(el) {
    if (!canAccessOfficeData(CURRENT_USER)) { if (CURRENT_USER?.scope === "data_entry") { openTTBTVWorkspace(); return; } return showToast('error', 'Khong co quyen', 'Token nay khong duoc truy cap du lieu Van phong.'); }
    const ws = document.getElementById("officeWorkspace"); if (!ws) return;
    document.getElementById("bchWorkspace")?.classList.remove("open");
    document.getElementById("ttbtvWorkspace")?.classList.remove("open");
    document.getElementById("provinceWorkspace")?.classList.remove("open");
    document.getElementById("action100Workspace")?.classList.remove("open");
    document.getElementById("mttqKpiWorkspace")?.classList.remove("open");
    document.getElementById("nqWorkspace")?.classList.remove("open");
    ws.classList.add("open");
    const item = el || document.getElementById("officeSidebarItem");
    document.querySelectorAll(".sidebar-item").forEach(x => x.classList.remove("active"));
    if (item) { item.classList.add("active"); const sub = item.nextElementSibling; if (sub?.classList.contains("sidebar-submenu")) { sub.classList.add("open"); requestAnimationFrame(() => sub.style.maxHeight = sub.scrollHeight + "px"); } item.classList.remove("collapsed"); }
    requestAnimationFrame(renderOfficeCharts);
    try{ vpSaveLastWs("officeWorkspace"); }catch(e){}
}

function closeOfficeWorkspace() {
    document.getElementById("officeWorkspace")?.classList.remove("open");
    document.getElementById("officeSidebarItem")?.classList.remove("active");
    const home = [...document.querySelectorAll(".sidebar-item")].find(x => x.textContent.includes("Trang chủ")); if (home) home.classList.add("active");
}

function openOfficeSection() { openOfficeWorkspace(document.getElementById("officeSidebarItem")); }

function addOfficerOptions() {
    const names = [...new Set(DATA.map(x => x.owner).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
    return names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
}

function refreshAddOfficeStatus() {
    updateAddCompletedDateAccess();
}

function officeDrillTimestamp(x) {
    const t = Date.parse(x?.updated_at || "");
    return Number.isFinite(t) ? t : (Number(x?.id) || 0);
}

function officeFold(s) { return String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim(); }

function officeStatusGroup(x) {
    const s = typeof x === "string" ? x : x?.status;
    const obj = typeof x === "object" ? x : null;
    if (obj && (obj.emergent || obj.is_arising)) return "emergent";
    if (obj && obj.is_regular) return "regular";
    if (completedStatuses.has(s)) return "done";
    if (String(s || "").trim() === "Quá hạn") return "overdue";
    return "doing";
}

function applyOfficeDrillOrder(rows) {
    const mode = document.getElementById("officeDrillOrder")?.value || "newest";
    let out = [...rows];
    if (mode === "with_file") out = out.filter(x => !!x.attachment_path || !!x.attachment_name);
    const dueVal = x => { const d = x?._dueDate || (typeof parseDate === "function" ? parseDate(x?.due) : null); return d ? d.getTime() : null };
    const timeActive = (document.getElementById("officeDrillTimeFilter")?.value || "") || (document.getElementById("officeDrillQuarterFilter")?.value || "") || (document.getElementById("officeDrillMonthFilter")?.value || "");
    if (mode === "oldest") out.sort((a, b) => officeDrillTimestamp(a) - officeDrillTimestamp(b));
    else if (mode === "due_far") out.sort((a, b) => { const A = dueVal(a), B = dueVal(b); if (A === null) return 1; if (B === null) return -1; return B - A });
    else if (mode === "due_near") out.sort((a, b) => { const A = dueVal(a), B = dueVal(b); if (A === null) return 1; if (B === null) return -1; return A - B });
    else if (mode === "newest" && timeActive) out.sort((a, b) => { const A = dueVal(a), B = dueVal(b); if (A === null) return 1; if (B === null) return -1; return A - B });
    else out = sortNewestFirst(out);
    return out;
}

function onOfficeDrillFilterChange() {
    const map = new Map(DATA.map(v => [String(v.id), v]));
    let rows = OFFICE_DRILL_STATE.ids.map(id => map.get(String(id))).filter(Boolean);
    const status = document.getElementById("officeDrillStatusFilter")?.value || "all";
    if (status !== "all") rows = rows.filter(x => officeStatusGroup(x) === status);
    const selOfficer = document.getElementById("officeDrillOfficerSelect")?.value || "";
    if (selOfficer) rows = rows.filter(x => officeFold(x.owner || "") === officeFold(selOfficer));
    const q = officeFold(document.getElementById("officeDrillOfficerFilter")?.value || "");
    if (q) rows = rows.filter(x => officeFold([x.task, x.product, x.staff_note, x.admin_note, x.role, x.owner].join(" ")).includes(q));
    const drange = document.getElementById("officeDrillTimeFilter")?.value || "";
    if (drange) {
        const isNextMonth = drange === "nextMonth";
        rows = rows.filter(x => {
            if (!!x.is_regular && !isNextMonth) return true;
            const d = x._dueDate || (typeof parseDate === "function" ? parseDate(x.due) : null);
            return d ? isDateInTimeRange(d, drange) : false;
        });
    }
    const dQuarter = document.getElementById("officeDrillQuarterFilter")?.value || "";
    if (dQuarter) rows = rows.filter(x => { if (!!x.is_regular) return true; const d = x._dueDate || (typeof parseDate === "function" ? parseDate(x.due) : null); return d ? (Math.floor(d.getMonth() / 3) + 1) === Number(dQuarter) : false; });
    const dMonth = document.getElementById("officeDrillMonthFilter")?.value || "";
    if (dMonth) rows = rows.filter(x => { if (!!x.is_regular) return true; const d = x._dueDate || (typeof parseDate === "function" ? parseDate(x.due) : null); return d ? (d.getMonth() + 1) === Number(dMonth) : false; });
    renderOfficeDrillRows(rows, OFFICE_DRILL_STATE.title, OFFICE_DRILL_STATE.icon, false);
}

function bchOfficerMap() {
    const map = new Map();
    BCH_OFFICERS.forEach(o => map.set(bchFold(o.name), o));
    return map;
}

function ttbtvFold(s) {
    return String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
}

function ttbtvIsUBND(v) { return ttbtvFold(v) === "ubnd xa"; }

function ttbtvHasProduct(v) {
    const s = ttbtvFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(s);
}

function ttbtvHasResult(v) {
    const s = ttbtvFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null", "dang trien khai"].includes(s);
}

function ttbtvDeadlineDate(v) {
    const s = String(v ?? "").trim();
    if (!s) return null;
    // Hỗ trợ yyyy-mm-dd và chuỗi tiếng Việt có dd/mm/yyyy, ví dụ: "Hoàn thành trước ngày 30/9/2026".
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) {
        const y = +iso[1], mo = +iso[2], d = +iso[3], dt = new Date(y, mo - 1, d);
        return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
    }
    const matches = [...s.matchAll(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/g)];
    if (!matches.length) return null;
    const m = matches[matches.length - 1], d = +m[1], mo = +m[2], y = +m[3];
    const dt = new Date(y, mo - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
}

function ttbtvCompletedDate(v) {
    return ttbtvDeadlineDate(v);
}

function ttbtvStatusFor(x, overrides = {}) {
    // "Thường xuyên": chỉ Admin gán/bỏ (checkbox ttbtvEditRegular), bỏ qua mọi logic hạn/ngày/kết quả cũ.
    if (overrides._regular === true) return "regular";
    if (overrides._regular !== false && String(overrides.status ?? x.status ?? "").trim() === "Thường xuyên") return "regular";
    const due = ttbtvDeadlineDate(overrides.deadline ?? x.deadline);
    const completed = ttbtvCompletedDate(overrides.completed_date ?? x.completed_date);
    const result = overrides.result ?? x.result;
    const hasFile = overrides.hasFile !== undefined ? !!overrides.hasFile : !!x.attachment_path;
    // TT/BTV: đã có Ngày hoàn thành thì xác định hoàn thành theo so sánh ngày;
    // không để nhiệm vụ đã nhập đủ ngày tiếp tục bị báo Quá hạn.
    const hasEvidence = !!completed || ttbtvHasResult(result) || hasFile;

    // Group vai trò: nhiệm vụ chính chỉ Hoàn thành khi lãnh đạo bắt buộc đều Hoàn thành.
    const _roles = overrides.roles !== undefined ? overrides.roles : ttbtvParseRoleNote(x.note);
    const _gk = ttbtvGroupKeyFromRoles(_roles, due, completed, overrides.role ?? x.role);
    if (_gk) return _gk;

    // V48: trạng thái KHÔNG được sửa tay. Chỉ hoàn thành khi có Ngày hoàn thành
    // và có Kết quả thực hiện hoặc tệp sản phẩm. Sau đó so ngày hoàn thành với hạn.
    if (completed && hasEvidence) {
        if (due) {
            const a = new Date(completed.getFullYear(), completed.getMonth(), completed.getDate()).getTime();
            const b = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
            if (a < b) return "early";
            if (a === b) return "ontime";
            return "latedone";
        }
        return "ontime";
    }

    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (due && due < today) return "overdue";
    return "processing";
}

function ttbtvStatusLabel(k) {
    return ({
        processing: "Đang triển khai",
        done: "Hoàn thành",
        early: "Hoàn thành trước hạn",
        ontime: "Hoàn thành đúng hạn",
        latedone: "Hoàn thành quá hạn",
        overdue: "Quá hạn",
        regular: "Thường xuyên"
    })[k] || "Đang triển khai";
}

function ttbtvStatusGroup(k) {
    // V37: gom 3 trạng thái hoàn thành chi tiết về nhóm "done" cho KPI/bộ lọc.
    if (["early", "ontime", "latedone", "done"].includes(k)) return "done";
    if (k === "regular") return "regular";
    return (k || "processing");
}

function ttbtvDocDate(source) {
    const s = String(source || "").trim(); if (!s) return null;
    const ms = [...s.matchAll(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/g)];
    if (ms.length) { const last = ms[ms.length - 1]; const d = +last[1], m = +last[2] - 1, y = +last[3]; const dt = new Date(y, m, d); if (!isNaN(dt)) return dt; }
    const iso = s.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (iso) { const dt = new Date(+iso[1], +iso[2] - 1, +iso[3]); if (!isNaN(dt)) return dt; }
    return null;
}

function vpubDocDate(source) { return ttbtvDocDate(source); }

function normalizeTTBTVOfficer(x) {
    return {
        id: x.id, name: String(x.name ?? "").trim(), token: String(x.token ?? "").trim(),
        title: String(x.title ?? "").trim(), unit: String(x.unit ?? "").trim(), note: String(x.note ?? "").trim()
    };
}

function normalizeTTBTVTask(x) {
    const obj = {
        id: x.id, officer_name: String(x.officer_name ?? "").trim(), ubnd_leader: String(x.ubnd_leader ?? "").trim(),
        task_name: String(x.task_name ?? "").trim(), product: String(x.product ?? "").trim(),
        amount: String(x.amount ?? "").trim(), ubnd_source: String(x.ubnd_source ?? "").trim(), deadline: String(x.deadline ?? "").trim(),
        result: String(x.result ?? "").trim(), updated_at: x.updated_at || "",
        note: String(x.note ?? "").trim(), phat_sinh: !!x.phat_sinh,
        role: String(x.role ?? "").trim(),
        completed_date: String(x.completed_date ?? "").trim(),
        status: String(x.status ?? "").trim(),
        staff_note: String(x.staff_note ?? "").trim(),
        admin_note: String(x.admin_note ?? "").trim(),
        attachment_path: String(x.attachment_path ?? "").trim(),
        attachment_name: String(x.attachment_name ?? "").trim(),
        attachment_type: String(x.attachment_type ?? "").trim(),
        attachment_size: Number(x.attachment_size ?? 0) || 0,
        attachment_approved: x.attachment_approved === true,
        attachment_approved_at: String(x.attachment_approved_at ?? "").trim(),
        attachment_approved_by: String(x.attachment_approved_by ?? "").trim(),
        source_sheet: String(x.source_sheet ?? "").trim(),
        source_row: x.source_row ?? null,
        source_doc: String(x.source_doc ?? "").trim(),
        source_group: String(x.source_group ?? "").trim(),
        unit_name: String(x.unit_name ?? "").trim(),
        specialist_name: String(x.specialist_name ?? "").trim()
    };
    obj.statusKey = ttbtvStatusFor(obj);
    obj._search = ttbtvFold([obj.officer_name, obj.task_name, obj.product, obj.amount, obj.ubnd_source, obj.deadline, obj.result, obj.status, obj.note, obj.role, obj.source_doc, obj.source_group, obj.unit_name, obj.specialist_name].join(" "));
    return obj;
}

function ttbtvOfficerMap() {
    const map = new Map();
    TTBTV_OFFICERS.forEach(o => map.set(ttbtvFold(o.name), o));
    return map;
}

async function ttbtvFetch(url) {
    const r = await fetch(url, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json" } });
    const tx = await r.text();
    if (!r.ok) { if(String(tx).includes("42501")||String(tx).toLowerCase().includes("row-level security")) throw new Error(tx+" (RLS chặn)"); throw new Error(tx || `HTTP ${r.status}`); }
    const j = JSON.parse(tx);
    if (!Array.isArray(j)) throw new Error("Dữ liệu TTBTV không phải mảng.");
    return j;
}

async function loadTTBTVData(force = false) {
    if(DEMO_MODE){
        const snap = await getDemoSnapshot();
        const offRaw = Array.isArray(snap.tt_btv_officers) ? snap.tt_btv_officers : [];
        const taskRaw = Array.isArray(snap.tt_btv_tasks) ? snap.tt_btv_tasks : [];
        TTBTV_OFFICERS = offRaw.map(normalizeTTBTVOfficer); TTBTV_TASKS = taskRaw.map(normalizeTTBTVTask); TTBTV_TASKS.forEach(x=> x._search = ttbtvFold([x.officer_name,x.task_name,x.product,x.amount,x.deadline,x.result].join(" "))); TTBTV_LOADED = true;
        try{ writeOfficersCache("ttbtv_officers_cache", TTBTV_OFFICERS); localStorage.setItem("ttbtv_tasks_cache", JSON.stringify(TTBTV_TASKS)); }catch(e){}
        rebuildTTBTVOfficerFilter(); applyTTBTVFilters(); renderTTBTVCharts(); if(typeof renderCharts==="function") renderCharts();
        const s=document.getElementById("ttbtvSyncText"); if(s) s.textContent=`✅ [DEMO] ${TTBTV_OFFICERS.length} cán bộ / ${TTBTV_TASKS.length} nhiệm vụ mẫu`; const b=document.getElementById("ttbtvRefreshBtn"); if(b) b.disabled=false; return;
    }
    if (TTBTV_LOADED && !force) { applyTTBTVFilters(); return; }
    const btn = document.getElementById("ttbtvRefreshBtn");
    const sync = document.getElementById("ttbtvSyncText");
    try {
        if (btn) btn.disabled = true;
        if (sync) sync.textContent = "⏳ Đang đồng bộ public.tt_btv_officers và public.tt_btv_tasks...";
        showTableSkeleton("ttbtvTableBody");
        let offRaw = [], taskRaw = [];
        try { offRaw = await ttbtvFetch(TTBTV_OFFICERS_API); }
        catch (offErr) {
            console.warn("TTBTV officers select chi tiết lỗi, thử select=*", offErr);
            offRaw = await ttbtvFetch(`${SUPABASE_URL}/rest/v1/tt_btv_officers?select=*&order=id.asc`);
        }
        try { taskRaw = await ttbtvFetch(TTBTV_TASKS_API); }
        catch (taskErr) {
            console.warn("TTBTV tasks select chi tiết lỗi, thử select=*", taskErr);
            taskRaw = await ttbtvFetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks?select=*&order=id.asc`);
        }
        TTBTV_OFFICERS = offRaw.map(normalizeTTBTVOfficer);
        TTBTV_TASKS = taskRaw.map(normalizeTTBTVTask);
        TTBTV_LOADED = true;
        console.info(`[V37 TTBTV] Supabase: ${TTBTV_OFFICERS.length} officers / ${TTBTV_TASKS.length} tasks`);
        writeOfficersCache("ttbtv_officers_cache", TTBTV_OFFICERS);
        localStorage.setItem("ttbtv_tasks_cache", JSON.stringify(TTBTV_TASKS));
        writeCache("ttbtv_tasks_cache", TTBTV_TASKS);
        rebuildTTBTVOfficerFilter(); rebuildTTBTVAgencyFilter();
        applyTTBTVFilters();
        renderTTBTVCharts();
        if (typeof renderCharts === "function") renderCharts();
        if (typeof updateGlobalHonors === "function") updateGlobalHonors();
        try { const eS=document.getElementById("ttbtvEditSource"); if(eS&&eS.tagName==="SELECT") populateTTBTVSourceSelect(eS,eS.value); const aS=document.getElementById("ttbtvAddSource"); if(aS) populateTTBTVSourceSelect(aS,aS.value); } catch(_e) {}
        if (sync) sync.textContent = `✅ Đã tải ${TTBTV_OFFICERS.length} cán bộ và ${TTBTV_TASKS.length} nhiệm vụ TT/BTV lúc ${new Date().toLocaleTimeString("vi-VN")}${(TTBTV_OFFICERS.length === 10 && TTBTV_TASKS.length === 72) ? " · Khớp JSON nguồn" : ""}`;
    } catch (e) {
        console.error("Lỗi tải TTBTV:", e);
        try {
            const oc = readOfficersCache("ttbtv_officers_cache") || readCache("ttbtv_officers_cache") || [];
            const tc = readCache("ttbtv_tasks_cache") || [];
            if (oc.length || tc.length) {
                TTBTV_OFFICERS = oc.map(normalizeTTBTVOfficer);
                TTBTV_TASKS = tc.map(normalizeTTBTVTask);
                TTBTV_LOADED = true; rebuildTTBTVOfficerFilter(); rebuildTTBTVAgencyFilter(); applyTTBTVFilters(); renderTTBTVCharts();
                if (typeof renderCharts === "function") renderCharts();
                if (typeof updateGlobalHonors === "function") updateGlobalHonors();
                try { const eS=document.getElementById("ttbtvEditSource"); if(eS&&eS.tagName==="SELECT") populateTTBTVSourceSelect(eS,eS.value); const aS=document.getElementById("ttbtvAddSource"); if(aS) populateTTBTVSourceSelect(aS,aS.value); } catch(_e) {}
                if (sync) sync.textContent = `⚠️ Mất kết nối · đang dùng cache ${TTBTV_TASKS.length} nhiệm vụ gần nhất`;
            } else throw e;
        } catch (_) {
            if (sync) sync.textContent = "❌ Không tải được dữ liệu TTBTV: " + (e.message || e);
            renderTTBTVTable([]);
        }
    } finally { if (btn) btn.disabled = false; }
}

function rebuildTTBTVOfficerFilter() {
    const sel = document.getElementById("ttbtvOfficerFilter"); if (!sel) return;
    const current = sel.value;
    const names = [...new Set(TTBTV_TASKS.map(x => x.officer_name).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
    sel.innerHTML = '<option value="">Tất cả cán bộ</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
    if (names.includes(current)) sel.value = current;
}

function ttbtvTaskLeader(x) {
    // Lãnh đạo phụ trách khớp group Vai trò: UBND xã -> LĐ UBND, còn lại -> LĐ phòng.
    if (ttbtvIsUBND(x.role || x.unit_name)) return String(x.ubnd_leader || "").trim() || String(x.officer_name || "").trim() || "—";
    return String(x.officer_name || "").trim() || "—";
}

function ttbtvMatchAgency(x, agency) {
    if (!agency) return true;
    const a = String(x.role || x.unit_name || "").trim();
    if (agency === "Chưa rõ cơ quan chủ trì") return !a;
    if (ttbtvFold(a) === ttbtvFold(agency)) return true;
    try {
        const parent = TTBTV_AGENCY_TREE.find(t => ttbtvFold(t.name) === ttbtvFold(agency));
        if (parent && parent.children && parent.children.length) {
            const childSet = new Set(parent.children.map(c => ttbtvFold(c)));
            if (childSet.has(ttbtvFold(a))) return true;
        }
    } catch (e) {}
    return false;
}

function rebuildTTBTVAgencyFilter() {
    const sel = document.getElementById("ttbtvAgencyFilter"); if (!sel) return;
    const current = sel.value;
    const agencies = [...new Set(TTBTV_TASKS.map(x => String(x.role || x.unit_name || "").trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi'));
    sel.innerHTML = '<option value="">Tất cả cơ quan</option>' + agencies.map(a => `<option value="${esc(a)}">${esc(a)}</option>`).join("");
    if (agencies.includes(current)) sel.value = current;
}

function applyTTBTVFilters() {
    if (!document.getElementById("ttbtvWorkspace")) return;
    const q = ttbtvFold(document.getElementById("ttbtvSearch")?.value || "");
    const officer = document.getElementById("ttbtvOfficerFilter")?.value || "";
    const agency = document.getElementById("ttbtvAgencyFilter")?.value || "";
    const status = document.getElementById("ttbtvStatusFilter")?.value || "all";
    const timeMode = document.getElementById("ttbtvTimeFilter")?.value || "all";
    TTBTV_TASKS.forEach(x => x.statusKey = ttbtvStatusFor(x));
    TTBTV_FILTERED = TTBTV_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (officer && x.officer_name !== officer) return false;
        if (!ttbtvMatchAgency(x, agency)) return false;
        if (typeof TTBTV_SRC_Q !== "undefined" && TTBTV_SRC_Q && !ttbtvFold(x.amount || x.source_doc || x.ubnd_source || "").includes(TTBTV_SRC_Q)) return false;
        if (status !== "all" && ttbtvStatusGroup(x.statusKey) !== status) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof TTBTV_MONTH !== "undefined" && TTBTV_MONTH) { const d = ttbtvDeadlineDate(x.deadline); if (!d || (d.getMonth() + 1) !== TTBTV_MONTH) return false; }
        if (typeof TTBTV_DL_DATE !== "undefined" && TTBTV_DL_DATE) { const dd = ttbtvDeadlineDate(x.deadline); if (!dd || new Date(dd.getFullYear(), dd.getMonth(), dd.getDate()).getTime() !== TTBTV_DL_DATE) return false; }
        else if (typeof TTBTV_DL_Q !== "undefined" && TTBTV_DL_Q && !ttbtvFold(x.deadline || "").includes(TTBTV_DL_Q)) return false;
        return true;
    });
    if (typeof TTBTV_PAGE !== "undefined") TTBTV_PAGE = 1;
    renderTTBTVKPIs();
    renderTTBTVTable(TTBTV_FILTERED);
    if (typeof renderTTBTVCharts === "function") renderTTBTVCharts();
}

function ttbtvScopeRows() {
    const q = ttbtvFold(document.getElementById("ttbtvSearch")?.value || "");
    const officer = document.getElementById("ttbtvOfficerFilter")?.value || "";
    const agency = document.getElementById("ttbtvAgencyFilter")?.value || "";
    const timeMode = document.getElementById("ttbtvTimeFilter")?.value || "all";
    TTBTV_TASKS.forEach(x => { if (!x.statusKey) x.statusKey = ttbtvStatusFor(x); });
    return TTBTV_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (officer && x.officer_name !== officer) return false;
        if (!ttbtvMatchAgency(x, agency)) return false;
        if (typeof TTBTV_SRC_Q !== "undefined" && TTBTV_SRC_Q && !ttbtvFold(x.amount || x.source_doc || x.ubnd_source || "").includes(TTBTV_SRC_Q)) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof TTBTV_MONTH !== "undefined" && TTBTV_MONTH) { const d = ttbtvDeadlineDate(x.deadline); if (!d || (d.getMonth() + 1) !== TTBTV_MONTH) return false; }
        if (typeof TTBTV_DL_DATE !== "undefined" && TTBTV_DL_DATE) { const dd = ttbtvDeadlineDate(x.deadline); if (!dd || new Date(dd.getFullYear(), dd.getMonth(), dd.getDate()).getTime() !== TTBTV_DL_DATE) return false; }
        else if (typeof TTBTV_DL_Q !== "undefined" && TTBTV_DL_Q && !ttbtvFold(x.deadline || "").includes(TTBTV_DL_Q)) return false;
        return true;
    });
}

function ttbtvRenderChart(canvasId, labels, data, colorsList, legendId, drillKind) {
    const canvas = document.getElementById(canvasId); if (!canvas || typeof Chart === "undefined") return;
    if (TTBTV_CHARTS[canvasId]) TTBTV_CHARTS[canvasId].destroy();
    TTBTV_CHARTS[canvasId] = new Chart(canvas.getContext("2d"), {
        type: "doughnut",
        data: { labels, datasets: [{ data, backgroundColor: colorsList, borderColor: "#fff", borderWidth: 2 }] },
        options: {
            responsive: true, maintainAspectRatio: false, cutout: "62%",
            plugins: {
                legend: { display: false },
                tooltip: { enabled: true, titleFont: { size: 15, weight: "700" }, bodyFont: { size: 14, weight: "600" }, padding: 12, cornerRadius: 8, backgroundColor: "rgba(15,23,42,0.92)", titleColor: "#f8fafc", bodyColor: "#e2e8f0", displayColors: true, boxPadding: 4 }
            },
            onClick: (evt, els) => {
                if (!els.length) return;
                const label = labels[els[0].index];
                drillTTBTVChart(drillKind, label);
            }
        }
    });
    const lg = document.getElementById(legendId);
    if (lg) lg.innerHTML = labels.map((l, i) => `<div class="legend-item" onclick="drillTTBTVChart('${drillKind}',${JSON.stringify(l).replace(/"/g, '&quot;')})"><span class="legend-color" style="background:${colorsList[i]}"></span><span>${esc(l)} (${data[i]})</span></div>`).join("");
}

function openTTBTVTaskDetail(id) {
    const x = TTBTV_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    const o = ttbtvOfficerMap().get(ttbtvFold(x.officer_name)) || {};
    const val = v => esc(String(v || "—"));
    const status = ttbtvStatusFor(x);
    document.getElementById("ttbtvDetailSubtitle").textContent = `${x.officer_name || "Chưa phân công"} · ${ttbtvStatusLabel(status)}`;
    const roleRows = ttbtvParseRoleNote(x.note) || [];
    const roleNames = { "Lãnh đạo UBND": x.ubnd_leader, "Lãnh đạo phòng": x.officer_name, "CV tham mưu": x.specialist_name };
    const roleHtml = roleRows.filter(r => r && (roleNames[r.title] || r.due || r.done || r.result || r.reason)).map(r => {
        const bits = [`<b>${esc(r.title)}</b>: ${esc(roleNames[r.title] || "—")}`];
        if (r.due) bits.push(`Hạn: ${esc(r.due)}`);
        if (r.done) bits.push(`HT: ${esc(r.done)}`);
        if (r.result) bits.push(`KQ: ${esc(r.result)}`);
        if (r.reason) bits.push(`Lý do: ${esc(r.reason)}`);
        return `<div>${bits.join(" · ")}</div>`;
    }).join("");
    document.getElementById("ttbtvDetailBody").innerHTML = `<div class="bch-detail-grid">
                <div class="bch-detail-field"><div class="bch-detail-label">Cán bộ phụ trách</div><div class="bch-detail-value">${val(x.officer_name)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Chức vụ</div><div class="bch-detail-value">${val(o.title)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Nhiệm vụ cụ thể</div><div class="bch-detail-value">${val(x.task_name)}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Chuyên viên phụ trách</div><div class="bch-detail-value">${val(x.specialist_name || x.product)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Số lượng</div><div class="bch-detail-value">${val(x.amount)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Hạn hoàn thành</div><div class="bch-detail-value">${val(x.deadline)}</div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Trạng thái</div><div class="bch-detail-value"><span class="bch-badge ${status}">${ttbtvStatusLabel(status)}</span></div></div>
                <div class="bch-detail-field"><div class="bch-detail-label">Phát sinh</div><div class="bch-detail-value">${x.phat_sinh ? "Có" : "Không"}</div></div>
                <div class="bch-detail-field wide"><div class="bch-detail-label">Kết quả</div><div class="bch-detail-value">${val(x.result || "Chưa điền")}</div></div>
                ${roleHtml ? `<div class="bch-detail-field wide"><div class="bch-detail-label">Vai trò thực hiện</div><div class="bch-detail-value">${roleHtml}</div></div>` : ""}
                <div class="bch-detail-field wide"><div class="bch-detail-label">Ghi chú</div><div class="bch-detail-value">${roleRows.length ? "—" : val(x.note)}</div></div>
            </div>`;
    smoothOpenModal("ttbtvDetailModal");
}

function closeTTBTVTaskDetail() { smoothCloseModal("ttbtvDetailModal"); }

function ttbtvCanEdit(x) {
    if (!CURRENT_USER) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return true;
    return CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name);
}

function getTTBTVRowsByMode(mode) {
    TTBTV_TASKS.forEach(x => x.statusKey = ttbtvStatusFor(x));
    const base = (typeof ttbtvScopeRows === "function") ? ttbtvScopeRows() : [...TTBTV_TASKS];
    if (mode === "processing") return base.filter(x => ttbtvStatusGroup(x.statusKey) === "processing");
    if (mode === "done") return base.filter(x => ttbtvStatusGroup(x.statusKey) === "done");
    if (mode === "overdue") return base.filter(x => ttbtvStatusGroup(x.statusKey) === "overdue");
    if (mode === "regular") return base.filter(x => ttbtvStatusGroup(x.statusKey) === "regular");
    if (mode === "dueToday") {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        return base.filter(x => {
            const d = ttbtvDeadlineDate(x.deadline);
            if (!d || ttbtvCompletedDate(x.completed_date)) return false;
            const dd = new Date(d.getFullYear(), d.getMonth(), d.getDate());
            return dd.getTime() === today.getTime();
        });
    }
    return [...base];
}

function openTTBTVFilePopup() {
    TTBTV_TASKS.forEach(x => x.statusKey = ttbtvStatusFor(x));
    const base = (typeof ttbtvScopeRows === "function") ? ttbtvScopeRows() : [...TTBTV_TASKS];
    const rows = base.filter(x => String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim());
    const agency = document.getElementById("ttbtvAgencyFilter")?.value || "";
    renderTTBTVDrill(rows, `Nhiệm vụ TT/BTV — Có file đính kèm${agency ? ` — ${agency}` : ""}`, "📎");
}

function openTTBTVStatusPopup(mode = "all", el = null) {
    TTBTV_DRILL_MODE = mode;
    document.getElementById("ttbtvWorkspace")?.classList.add("open");
    document.querySelectorAll("#ttbtvSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");

    const labels = {
        all: ["Tất cả nhiệm vụ TT/BTV Đảng bộ", "📋"],
        processing: ["Nhiệm vụ TTBTV — Đang xử lý", "📌"],
        done: ["Nhiệm vụ TTBTV — Hoàn thành", "✅"],
        overdue: ["Nhiệm vụ TTBTV — Quá hạn", "⏰"],
        dueToday: ["Nhiệm vụ TTBTV — Đến hạn", "📅"],
        regular: ["Nhiệm vụ TTBTV — Thường xuyên", "🔁"]
    };
    const meta = labels[mode] || labels.all;
    const agency = document.getElementById("ttbtvAgencyFilter")?.value || "";
    renderTTBTVDrill(getTTBTVRowsByMode(mode), meta[0] + (agency ? ` — ${agency}` : ""), meta[1]);
}

function ttbtvDrillTimestamp(x) { const t = Date.parse(x?.updated_at || ""); return Number.isFinite(t) ? t : (Number(x?.id) || 0) }

function applyTTBTVDrillOrder(rows) {
    const mode = document.getElementById("ttbtvDrillOrder")?.value || "newest"; let out = [...rows];
    if (mode === "with_file") out = out.filter(x => !!x.attachment_path || !!x.attachment_name);
    const due = x => { const d = ttbtvDeadlineDate(x?.deadline); return d ? d.getTime() : null };
    if (mode === "oldest") out.sort((a, b) => ttbtvDrillTimestamp(a) - ttbtvDrillTimestamp(b));
    else if (mode === "due_far") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return B - A });
    else if (mode === "due_near") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return A - B });
    else out = sortNewestFirst(out); return out;
}

function onTTBTVDrillFilterChange() { const rows = TTBTV_DRILL_STATE.ids.map(id => TTBTV_TASKS.find(x => String(x.id) === String(id))).filter(Boolean); renderTTBTVDrill(rows, TTBTV_DRILL_STATE.title, TTBTV_DRILL_STATE.icon, false) }

function appendTTBTVAddTaskRow() {
    const body = document.getElementById("ttbtvDrillBody");
    if (!body || document.getElementById("ttbtvAddTaskRow")) return;
    body.insertAdjacentHTML("beforeend", renderTTBTVAddTaskRow());
    const sel=document.getElementById("ttbtvAddSource"); if(sel) populateTTBTVSourceSelect(sel,"");
}

function openTTBTVAddTaskPanel() { if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || CURRENT_USER.role === "department" || CURRENT_USER.scope === "action100" || !!CURRENT_USER.isNGN || (CURRENT_USER.role === "staff" && ["ttbtv", "data_entry"].includes(CURRENT_USER.scope)))) return; openTTBTVWorkspace(); openTTBTVAddModal(); }

function openTTBTVAddModal() {
    if (!CURRENT_USER) return;
    const isAdmin = CURRENT_USER.role === "admin";
    const offSel = document.getElementById("ttbtvNewOfficer");
    if (offSel) {
        if (offSel.tagName === "SELECT") {
            const names = [...new Set(TTBTV_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))];
            offSel.innerHTML = names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("") + `<option value="__other__">Khác (Nhập tên)</option>`;
            offSel.value = (!isAdmin && CURRENT_USER.name) ? CURRENT_USER.name : (names[0] || "");
            if (![...offSel.options].some(o => o.value === offSel.value)) offSel.value = names[0] || "";
            offSel.onchange = () => ttbtvHandleOfficerOther(offSel);
        } else if (!isAdmin && CURRENT_USER.name && !offSel.value) {
            offSel.value = CURRENT_USER.name;
        }
    }
    const roleSel = document.getElementById("ttbtvNewRole");
    if (roleSel) { roleSel.value = ""; roleSel.onchange = async () => { try { await ttbtvHandleRoleOther(roleSel); } catch (e) {} try { refreshTTBTVNewStatus(); } catch (e) {} }; }
    const srcSel = document.getElementById("ttbtvNewSource"); if (srcSel) populateTTBTVSourceSelect(srcSel, "");
    ["ttbtvNewUBNDLeader", "ttbtvNewTask", "ttbtvNewDeadline", "ttbtvNewCompleted", "ttbtvNewResult", "ttbtvNewSpecialist", "ttbtvNewStaffNote", "ttbtvNewAdminNote", "ttbtvRoleUBNDDue", "ttbtvRoleUBNDDone", "ttbtvRoleUBNDResult", "ttbtvRoleUBNDReason", "ttbtvRolePhongDue", "ttbtvRolePhongDone", "ttbtvRolePhongResult", "ttbtvRolePhongReason", "ttbtvRoleCVDue", "ttbtvRoleCVDone", "ttbtvRoleCVResult", "ttbtvRoleCVReason"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    try { ttbtvSyncRoleGroup(document.getElementById("ttbtvNewRole")); } catch (e) {}
    const ub = document.getElementById("ttbtvNewUBNDSource"); if (ub) ub.value = "Chưa rõ";
    const st = document.getElementById("ttbtvNewStatus"); if (st) st.value = "Đang triển khai";
    const rg = document.getElementById("ttbtvNewRegular"); if (rg) rg.checked = false;
    const rgW = document.getElementById("ttbtvNewRegularWrap"); if (rgW) rgW.style.display = isAdmin ? "" : "none";
    const adW = document.getElementById("ttbtvNewAdminWrap"); if (adW) adW.style.display = isAdmin ? "" : "none";
    const f = document.getElementById("ttbtvNewAttachment"); if (f) f.value = "";
    if (typeof setupTTBTVDateFields === "function") setupTTBTVDateFields();
    refreshTTBTVNewStatus();
    smoothOpenModal("ttbtvAddModal");
}

function closeTTBTVAddModal() { smoothCloseModal("ttbtvAddModal"); }

function refreshTTBTVNewStatus() {
    if (document.getElementById("ttbtvNewRegular")?.checked) { const out = document.getElementById("ttbtvNewStatus"); if (out) out.value = "Thường xuyên"; return; }
    
    const due = document.getElementById("ttbtvNewDeadline")?.value || "";
    const completed = document.getElementById("ttbtvNewCompleted")?.value || "";
    const result = document.getElementById("ttbtvNewResult")?.value || "";
    const file = document.getElementById("ttbtvNewAttachment")?.files?.[0] || null;
    let roles; try { roles = ttbtvCollectRoleRows(); } catch (e) { roles = []; }
    ttbtvRefreshRoleStatuses("new");
    const key = ttbtvStatusFor({ deadline: due, completed_date: completed, result, attachment_path: file ? "pending" : "" }, { hasFile: !!file, roles, role: document.getElementById("ttbtvNewRole")?.value || "" });
    const out = document.getElementById("ttbtvNewStatus"); if (out) out.value = ttbtvStatusLabel(key);
}

function stageNewTTBTVModalTask() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || CURRENT_USER.role === "department" || CURRENT_USER.scope === "action100" || !!CURRENT_USER.isNGN || (CURRENT_USER.role === "staff" && ["ttbtv", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản TT/BTV được thêm nhiệm vụ."); return;
    }
    const isAdmin = CURRENT_USER.role === "admin";
    const addOfficer = (document.getElementById("ttbtvNewOfficer")?.value || CURRENT_USER.name || "").trim();
    if (!addOfficer) { showToast("error", "Thiếu lãnh đạo phụ trách", "Vui lòng chọn Lãnh đạo phụ trách."); return; }
    const taskName = (document.getElementById("ttbtvNewTask")?.value || "").trim();
    const role = (document.getElementById("ttbtvNewRole")?.value || "").trim();
    const specialist = (document.getElementById("ttbtvNewSpecialist")?.value || "").trim();
    const source = (document.getElementById("ttbtvNewSource")?.value || "").trim();
    const ubndSource = (document.getElementById("ttbtvNewUBNDSource")?.value || "").trim();
    const ubndLeader = (document.getElementById("ttbtvNewUBNDLeader")?.value || "").trim();
    const dueRaw = (document.getElementById("ttbtvNewDeadline")?.value || "").trim();
    const completedRaw = (document.getElementById("ttbtvNewCompleted")?.value || "").trim();
    const result = (document.getElementById("ttbtvNewResult")?.value || "").trim();
    const staffNote = (document.getElementById("ttbtvNewStaffNote")?.value || "").trim();
    const adminNote = isAdmin ? (document.getElementById("ttbtvNewAdminNote")?.value || "").trim() : "";
    const file = document.getElementById("ttbtvNewAttachment")?.files?.[0] || null;
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); return; }
    if (!source) { showToast("error", "Thiếu nguồn giao", "Nguồn giao là trường bắt buộc khi thêm nhiệm vụ."); return; }
    if (!dueRaw) { showToast("error", "Thiếu hạn hoàn thành", "Hạn hoàn thành là trường bắt buộc khi thêm nhiệm vụ."); return; }
    let deadline = "", completedDate = null;
    try {
        deadline = dateToDb(requireValidDate(dueRaw, "Hạn hoàn thành", true)) || "";
        completedDate = completedRaw ? (dateToDb(requireValidDate(completedRaw, "Ngày hoàn thành", false)) || null) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    if (completedDate && !ttbtvHasResult(result) && !file) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Muốn nhập Ngày hoàn thành phải có Kết quả thực hiện hoặc tệp kết quả."); return;
    }
    if (!completedDate && ttbtvHasResult(result)) {
        showToast("error", "Thiếu ngày hoàn thành", "Đã nhập Sản phẩm thì phải nhập Ngày hoàn thành mới lưu được."); return;
    }
    let roles = [];
    try {
        roles = ttbtvCollectRoleRows();
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    // Hạn/Ngày HT chính tự động lấy theo Lãnh đạo UBND hoặc Lãnh đạo phòng.
    const _isUBND = ttbtvIsUBND(role);
    const _lead = (roles || []).find(r => r && r.title === (_isUBND ? "Lãnh đạo UBND" : "Lãnh đạo phòng")) || {};
    if (String(_lead.due || "").trim()) deadline = dateToDb(_lead.due) || deadline;
    // Ngày HT chính LUÔN lấy theo LĐ (trống => chưa hoàn thành); chỉ giữ tay khi chưa nhập vai trò nào (legacy).
    if (roles.some(r => r.name || r.due || r.done || r.result || r.reason)) completedDate = String(_lead.done || "").trim() ? (dateToDb(_lead.done) || null) : null;
    // Kiểm lại gate sau khi chốt ngày theo LĐ.
    if (completedDate && !ttbtvHasResult(result) && !file) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Lãnh đạo đã có Ngày hoàn thành thì phải nhập Kết quả thực hiện hoặc tệp kết quả."); return;
    }
    let statusKey = ttbtvStatusFor({ deadline, completed_date: completedDate, result, attachment_path: file ? "pending" : "" }, { hasFile: !!file, roles, role });
    if (document.getElementById("ttbtvNewRegular")?.checked && isAdmin) statusKey = "regular";
    const roleNote = roles.some(r => r.name || r.due || r.done || r.result || r.reason) ? JSON.stringify({ roles }) : "";
    const roleSummary = roles.filter(r => r.name || r.due || r.done || r.result).map(r => `${r.title}: ${r.name || "—"}${r.due ? ` (Hạn: ${String(r.due).replaceAll("/", "-")}` : ""}${r.done ? `, HT: ${String(r.done).replaceAll("/", "-")}` : ""}${r.due ? ")" : ""}`).join(" · ") || "—";
    PENDING_TTBTV_TASK = { addMode: "modal", addOfficer, taskName, role, specialist, source, ubndSource, ubndLeader, deadline, completedDate, result, staffNote, adminNote, file, status: ttbtvStatusLabel(statusKey), noteVaitro: roleNote };
    openAddConfirm("TT/BTV", PENDING_TTBTV_TASK, [
        ["Lãnh đạo phụ trách", addOfficer], ["Lãnh đạo UBND", ubndLeader || "—"], ["Nhiệm vụ", taskName], ["Cơ quan chủ trì", role], ["Chuyên viên phụ trách", specialist],
        ["Vai trò thực hiện", roleSummary],
        ["Nguồn giao", source || "Không có"], ["Hạn hoàn thành", ttbtvConfirmDate(deadline)], ["Ngày hoàn thành", ttbtvConfirmDate(completedDate)], ["Trạng thái", ttbtvStatusLabel(statusKey)],
        ["Kết quả thực hiện", result || "Chưa nhập"], ["Tệp kết quả", file ? file.name : "Không có"], ["Ghi chú cán bộ", staffNote || "Không có"], ["Ghi chú Admin", adminNote || "Không có"]
    ]);
}

function refreshTTBTVAddStatus() {
    if (document.getElementById("ttbtvAddRegular")?.checked) { const out=document.getElementById("ttbtvAddStatus"); if(out) out.value="Thường xuyên"; return; }
    const due = document.getElementById("ttbtvAddDeadline")?.value || "";
    const completed = document.getElementById("ttbtvAddCompleted")?.value || "";
    const result = document.getElementById("ttbtvAddResult")?.value || "";
    const file = document.getElementById("ttbtvAddAttachment")?.files?.[0] || null;
    const key = ttbtvStatusFor({ deadline: due, completed_date: completed, result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    const out = document.getElementById("ttbtvAddStatus"); if (out) out.value = ttbtvStatusLabel(key);
}

function stageNewTTBTVTask() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || CURRENT_USER.role === "department" || CURRENT_USER.scope === "action100" || !!CURRENT_USER.isNGN || (CURRENT_USER.role === "staff" && ["ttbtv", "data_entry"].includes(CURRENT_USER.scope)))) {
        showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản TT/BTV được thêm nhiệm vụ."); return;
    }
    const addOfficer = (document.getElementById("ttbtvAddOfficer")?.value || CURRENT_USER.name || "").trim();
    if (!addOfficer) { showToast("error", "Thiếu lãnh đạo phụ trách", "Vui lòng chọn Lãnh đạo phụ trách."); return; }
    const taskName = (document.getElementById("ttbtvAddTaskName")?.value || "").trim();
    const role = (document.getElementById("ttbtvAddRole")?.value || "").trim();
    const specialist = (document.getElementById("ttbtvAddSpecialist")?.value || "").trim();
    const source = (document.getElementById("ttbtvAddSource")?.value || "").trim();
    const ubndSource = (document.getElementById("ttbtvAddUBNDSource")?.value || "").trim();
    const dueRaw = (document.getElementById("ttbtvAddDeadline")?.value || "").trim();
    const completedRaw = (document.getElementById("ttbtvAddCompleted")?.value || "").trim();
    const result = (document.getElementById("ttbtvAddResult")?.value || "").trim();
    const staffNote = (document.getElementById("ttbtvAddStaffNote")?.value || "").trim();
    const file = document.getElementById("ttbtvAddAttachment")?.files?.[0] || null;
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); return; }
    if (!source) { showToast("error", "Thiếu nguồn giao", "Nguồn giao là trường bắt buộc khi thêm nhiệm vụ."); return; }
    if (!ubndSource) { showToast("error", "Thiếu nguồn giao của UBND", "Nguồn giao của UBND là trường bắt buộc khi thêm nhiệm vụ."); return; }
    if (!dueRaw) { showToast("error", "Thiếu hạn hoàn thành", "Hạn hoàn thành là trường bắt buộc khi thêm nhiệm vụ."); return; }
    let deadline = "", completedDate = null;
    try {
        deadline = dateToDb(requireValidDate(dueRaw, "Hạn hoàn thành", true)) || "";
        completedDate = completedRaw ? (dateToDb(requireValidDate(completedRaw, "Ngày hoàn thành", false)) || null) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    if (completedDate && !ttbtvHasResult(result) && !file) {
        showToast("error", "Chưa đủ điều kiện hoàn thành", "Muốn nhập Ngày hoàn thành phải có Kết quả thực hiện hoặc tệp kết quả."); return;
    }
    if (!completedDate && ttbtvHasResult(result)) {
        showToast("error", "Thiếu ngày hoàn thành", "Đã nhập Sản phẩm thì phải nhập Ngày hoàn thành mới lưu được."); return;
    }
    let statusKey = ttbtvStatusFor({ deadline, completed_date: completedDate, result, attachment_path: file ? "pending" : "" }, { hasFile: !!file });
    if (document.getElementById("ttbtvAddRegular")?.checked && CURRENT_USER?.role==="admin") statusKey="regular";
    PENDING_TTBTV_TASK = { addOfficer, taskName, role, specialist, source, ubndSource, deadline, completedDate, result, staffNote, file, status: ttbtvStatusLabel(statusKey) };
    openAddConfirm("TT/BTV", PENDING_TTBTV_TASK, [
        ["Lãnh đạo phụ trách", addOfficer], ["Nhiệm vụ", taskName], ["Cơ quan chủ trì", role], ["Chuyên viên phụ trách", specialist],
        ["Nguồn giao", source || "Không có"], ["Nguồn giao của UBND", ubndSource], ["Hạn hoàn thành", ttbtvConfirmDate(deadline)], ["Ngày hoàn thành", ttbtvConfirmDate(completedDate)], ["Trạng thái", ttbtvStatusLabel(statusKey)],
        ["Kết quả thực hiện", result || "Chưa nhập"], ["Tệp kết quả", file ? file.name : "Không có"], ["Ghi chú cán bộ", staffNote || "Không có"]
    ]);
}

async function confirmNewTTBTVTask() {
    const p = PENDING_TTBTV_TASK; if (!p) return;
    const btn = document.getElementById("confirmAddTaskBtn"), old = btn?.textContent || ""; if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang lưu..."; }
    const dbRow = {
        officer_name: p.addOfficer, task_name: p.taskName, product: p.specialist || "", specialist_name: p.specialist || "",
        amount: p.source || "", ubnd_source: p.ubndSource || "", source_doc: "", deadline: p.deadline || "", result: p.result || "", note: p.noteVaitro || "",
        phat_sinh: false, role: p.role || "", unit_name: p.role || "", completed_date: p.completedDate,
        status: p.status, staff_note: p.staffNote || "", admin_note: "",
        attachment_path: "", attachment_name: "", attachment_type: "", attachment_size: 0,
        attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "",
        source_sheet: "APP_V49", source_row: Math.floor(100000000 + Math.random() * 1900000000), source_group: "",
        updated_at: new Date().toISOString()
    };
    if (p.ubndLeader !== undefined) dbRow.ubnd_leader = p.ubndLeader || "";
    if (p.adminNote !== undefined) dbRow.admin_note = p.adminNote || "";
    try {
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks`, { method: "POST", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" }, body: JSON.stringify(dbRow) });
        const tx = await r.text();
        if (!r.ok) { let msg = tx; try { const j = JSON.parse(tx); msg = j.message || j.details || j.hint || tx } catch (e) { } throw new Error(msg || `HTTP ${r.status}`); }
        const arr = JSON.parse(tx || "[]"), raw = Array.isArray(arr) ? arr[0] : arr; if (!raw) throw new Error("Supabase không trả lại nhiệm vụ vừa tạo.");
        raw.task_name = raw.task_name || p.taskName;
        raw.officer_name = raw.officer_name || p.addOfficer;
        raw.deadline = raw.deadline || p.deadline;
        let obj = normalizeTTBTVTask(raw);
        if (!obj || !String(obj.task_name||"").trim()) { const fb={...raw, task_name:p.taskName, officer_name:p.addOfficer, deadline:p.deadline, id: raw.id||Date.now()}; obj=normalizeTTBTVTask(fb); }
        if (!obj || !String(obj.task_name||"").trim()) throw new Error("Không thể chuẩn hóa nhiệm vụ vừa tạo. Raw: "+JSON.stringify(raw).slice(0,300));
        if (p.file) {
            const uploaded = await uploadTTBTVTaskFile(p.file, obj);
            const finalKey = ttbtvStatusFor({ ...obj, attachment_path: uploaded.path }, { hasFile: true });
            const patch = { attachment_path: uploaded.path, attachment_name: uploaded.name, attachment_type: uploaded.type, attachment_size: uploaded.size, attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "", status: ttbtvStatusLabel(finalKey), updated_at: new Date().toISOString() };
            const pr = await fetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks?id=eq.${encodeURIComponent(obj.id)}`, { method: "PATCH", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" }, body: JSON.stringify(patch) });
            const ptx = await pr.text(); if (!pr.ok) throw new Error(ptx || `HTTP ${pr.status}`);
            Object.assign(obj, patch); obj.statusKey = ttbtvStatusFor(obj);
        }
        await loadTTBTVData(true);
        moveTaskToTop(TTBTV_TASKS, obj.id);
        try { localStorage.setItem("ttbtv_tasks_cache", JSON.stringify(TTBTV_TASKS)); writeCache("ttbtv_tasks_cache", TTBTV_TASKS); } catch(e) {}
        const isPrivTt = CURRENT_USER.role === "admin" || isBchPrivilegedViewer(CURRENT_USER);
        if (p.addMode === "modal") { try { closeTTBTVAddModal(); } catch (e2) {} }
        else {
            const mine = isPrivTt ? TTBTV_TASKS : TTBTV_TASKS.filter(x => ttbtvFold(x.officer_name) === ttbtvFold(CURRENT_USER.name));
            renderTTBTVDrill(mine, isPrivTt ? "Tất cả nhiệm vụ TT/BTV Đảng bộ" : `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤"); appendTTBTVAddTaskRow();
        }
        showToast("success", "Đã thêm nhiệm vụ TT/BTV", `Nhiệm vụ #${obj.id} đã được lưu trực tiếp vào Supabase.`);
        writeActivity("Thêm nhiệm vụ TT/BTV", { task: obj.task_name, owner: obj.officer_name, id: obj.id });
        smoothCloseModal("addConfirmModal");
    } catch (e) { console.error("Lỗi thêm nhiệm vụ TT/BTV:", e); showToast("error", "Không thể thêm nhiệm vụ TT/BTV", e.message || "Vui lòng kiểm tra Supabase.", 6000); }
    finally { PENDING_TTBTV_TASK = null; if (btn) { btn.disabled = false; btn.textContent = old || "✓ Xác nhận thêm"; } }
}

function TTBTVDrillPopulateFilters() {
    const roleEl = document.getElementById("ttbtvDrillRoleFilter"), offEl = document.getElementById("ttbtvDrillOfficerFilter");
    if (roleEl && roleEl.options.length <= 1) {
        const fixedRoles = ["Văn phòng Đảng uỷ", "Ban Xây dựng Đảng", "UBKT Đảng uỷ", "MTTQ", "HĐND xã", "Ban Kinh tế", "Ban văn hoá", "UBND xã", "Văn phòng HĐND&UBND", "Phòng Kinh tế, hạ tầng", "Phòng Văn hoá - xã hội", "Phòng Nông nghiệp và Môi trường", "Trung tâm PV HCC", "Trung tâm DVTH", "Ban QLDA đầu tư XD", "Công an xã", "Quân sự xã"];
        try { (TTBTV_TASKS || []).forEach(x => { const v = String(x.role || x.unit_name || "").trim(); if (v && !fixedRoles.includes(v)) fixedRoles.push(v); }); } catch (e) {}
        roleEl.insertAdjacentHTML("beforeend", fixedRoles.map(r => `<option value="${esc(r)}">${esc(r)}</option>`).join(""));
    }
    if (offEl && offEl.options.length <= 1) {
        const names = [...new Set(TTBTV_TASKS.map(x => (x.officer_name || "Chưa phân công").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        offEl.insertAdjacentHTML("beforeend", names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join(""));
    }
}

function exportTTBTVDrillCSV() {
    const all = TTBTV_DRILL_STATE.ids.map(id => TTBTV_TASKS.find(x => String(x.id) === String(id))).filter(Boolean);
    const roleF = document.getElementById("ttbtvDrillRoleFilter")?.value || "";
    const offF = document.getElementById("ttbtvDrillOfficerFilter")?.value || "";
    const q = ttbtvFold(document.getElementById("ttbtvDrillSearch")?.value || "");
    let rows = all.filter(x => {
        const roleMatch = !roleF || (x.role || x.unit_name || "Chưa rõ cơ quan chủ trì") === roleF;
        const offMatch = !offF || x.officer_name === offF;
        const qMatch = !q || ttbtvFold([x.officer_name, x.task_name, x.role, x.unit_name, x.specialist_name, x.product, x.amount, x.source_doc, x.note, x.result, x.staff_note, x.admin_note].join(" ")).includes(q);
        return roleMatch && offMatch && qMatch;
    });
    rows = applyTTBTVDrillOrder(rows);
    const header = ["STT", "Nhiệm vụ", "Lãnh đạo phụ trách", "Cơ quan chủ trì", "Hạn hoàn thành", "Thời gian còn lại", "Trạng thái", "Chuyên viên phụ trách", "Kết quả"];
    const data = rows.map((x, i) => [i + 1, x.task_name || "", x.officer_name || "", (x.role || x.unit_name) || "", x.deadline || "", ttbtvRemainingText(x).t, ttbtvStatusLabel(x.statusKey), x.product || "", x.staff_note || x.result || ""]);
    const title = (document.getElementById("ttbtvDrillTitle")?.textContent || "Nhiem-vu-TTBTV").replace(/[^\p{L}\p{N}]+/gu, "_").replace(/^_+|_+$/g, "") || "Nhiem-vu-TTBTV";
    return exportToExcel({ filename: title + ".xlsx", sheetName: "TTBTV", headers: header, rows: data });
}

function openTTBTVTaskEdit(id) {
    const x = TTBTV_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    const o = ttbtvOfficerMap().get(ttbtvFold(x.officer_name)) || {};
    TTBTV_EDIT_ID = x.id;

    const can = canEditTTBTVTask(x);
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const isDataEntry = CURRENT_USER && CURRENT_USER.scope === "data_entry";
    const isNGN = canNGNEditTask(x);
    const isAgencyEditor = can && !isAdmin && !isDataEntry && !isNGN && !(CURRENT_USER && CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name);
    const fullAccess = isAdmin || isDataEntry || isNGN || isAgencyEditor || can;
    const canAdminNote = !!isAdmin;
    const isOwner = isNGN || (CURRENT_USER && CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name) || isAgencyEditor;

    document.getElementById("ttbtvEditOwnerLine").textContent = `Lãnh đạo: ${x.officer_name || "Chưa phân công"} · ${fullAccess ? (isAdmin ? "Admin chỉnh sửa trường nghiệp vụ · Trạng thái tự động" : isNGN ? "Nguyễn Giang Nam chỉnh sửa nhiệm vụ được phân quyền · Trạng thái tự động" : isAgencyEditor ? `Cơ quan ${CURRENT_USER.name} chỉnh sửa nhiệm vụ của cơ quan mình` : isDataEntry ? "CV nhập liệu chỉnh sửa toàn bộ nhiệm vụ · Trạng thái tự động" : "Có quyền sửa") : isOwner ? "Nhiệm vụ của bạn" : "Chỉ xem"}`;

    const officerSelect = document.getElementById("ttbtvEditOfficer");
    if (officerSelect) {
        if (officerSelect.tagName === "SELECT") {
            const names = [...new Set(TTBTV_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))];
            if (x.officer_name && !names.includes(x.officer_name)) names.unshift(x.officer_name);
            officerSelect.innerHTML = names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("") + `<option value="__other__">Khác (nhập tên...)</option>`;
            if (!names.length) officerSelect.innerHTML = '<option value="">Chưa phân công</option><option value="__other__">Khác (nhập tên...)</option>';
            officerSelect.value = x.officer_name || "";
            officerSelect.dataset.prev = x.officer_name || "";
            officerSelect.onchange = () => ttbtvHandleOfficerOther(officerSelect);
        } else {
            officerSelect.value = x.officer_name || "";
        }
    }

    document.getElementById("ttbtvEditTask").value = x.task_name || "";
    document.getElementById("ttbtvEditRole").value = x.role || x.unit_name || "";
    const roleSelect = document.getElementById("ttbtvEditRole");
    if (roleSelect) {
        roleSelect.dataset.prev = roleSelect.value;
        roleSelect.onchange = async () => { try { await ttbtvHandleRoleOther(roleSelect); } catch (e) {} try { refreshTTBTVAutoStatus(); } catch (e) {} };
        if (roleSelect.value === "") roleSelect.value = x.role || x.unit_name || "";
        if (roleSelect.value && ![...roleSelect.options].some(o => o.value === roleSelect.value)) {
            const opt = document.createElement("option"); opt.value = roleSelect.value; opt.textContent = roleSelect.value;
            roleSelect.insertBefore(opt, roleSelect.querySelector('option[value="__other__"]'));
        }
        roleSelect.value = x.role || x.unit_name || "";
        roleSelect.dataset.prev = roleSelect.value;
    }
    document.getElementById("ttbtvEditSpecialist").value = x.specialist_name || x.product || "";
    document.getElementById("ttbtvEditUBNDLeader").value = x.ubnd_leader || "";
    try { ttbtvFillEditRoles(x); } catch (e) {}
    try { ttbtvSyncRoleGroup(document.getElementById("ttbtvEditRole"), "ttbtvEditRoleUBNDRow"); } catch (e) {}
    const srcEl = document.getElementById("ttbtvEditSource"); if (srcEl) populateTTBTVSourceSelect(srcEl, x.amount || "");

    const due = ttbtvDeadlineDate(x.deadline);
    document.getElementById("ttbtvEditDue").value = due ? ttbtvDdmmyyyy(due) : "";

    const completed = ttbtvCompletedDate(x.completed_date);
    document.getElementById("ttbtvEditCompleted").value = completed ? ttbtvDdmmyyyy(completed) : "";

    document.getElementById("ttbtvEditProduct").value = (x.result && x.result !== "Không" && x.result !== "Chưa điền") ? x.result : "";
    document.getElementById("ttbtvEditStatus").value = ttbtvStatusLabel(x.statusKey || ttbtvStatusFor(x));
    const regWrap = document.getElementById("ttbtvEditRegularWrap");
    const regBox = document.getElementById("ttbtvEditRegular");
    if (regWrap) regWrap.style.display = isAdmin ? "" : "none";
    if (regBox) { regBox.checked = (x.statusKey === "regular" || String(x.status || "").trim() === "Thường xuyên"); regBox.disabled = !isAdmin; regBox.onchange = () => refreshTTBTVAutoStatus(); }
    document.getElementById("ttbtvEditStaffNote").value = x.staff_note || "";
    document.getElementById("ttbtvEditAdminNote").value = x.admin_note || (ttbtvParseRoleNote(x.note) ? "" : (x.note || ""));
    document.getElementById("ttbtvEditAttachment").value = "";

    // V48: Admin sửa toàn bộ trường nghiệp vụ TT/BTV; cán bộ chỉ cập nhật phần thực hiện.
    // Toàn hệ thống: Chỉ Admin được sửa Nội dung nhiệm vụ (yêu cầu mới).
    // CV nhập liệu: khóa Nội dung nhiệm vụ + Hạn hoàn thành (chỉ Admin/NGN).
    // Cơ quan: nếu tên cơ quan khớp role/unit_name thì được sửa như chủ trì cơ quan
    const canEditCore = isAdmin || isNGN || isAgencyEditor;
    document.getElementById("ttbtvEditOfficer").disabled = !(fullAccess || isOwner);
    ["ttbtvEditUBNDLeader", "ttbtvEditRoleUBNDDue", "ttbtvEditRoleUBNDDone", "ttbtvEditRoleUBNDResult", "ttbtvEditRoleUBNDReason", "ttbtvEditRolePhongDue", "ttbtvEditRolePhongDone", "ttbtvEditRolePhongResult", "ttbtvEditRolePhongReason", "ttbtvEditRoleCVDue", "ttbtvEditRoleCVDone", "ttbtvEditRoleCVResult", "ttbtvEditRoleCVReason"].forEach(id => { const el = document.getElementById(id); if (el) el.readOnly = !can; });
    document.getElementById("ttbtvEditTask").readOnly = !isAdmin;
    document.getElementById("ttbtvEditTask").style.background = isAdmin ? "#fff" : "#f1f5f9";
    document.getElementById("ttbtvEditTask").title = isAdmin ? "" : "Chỉ Admin được sửa Nội dung nhiệm vụ.";
    document.getElementById("ttbtvEditRole").readOnly = !fullAccess;
    document.getElementById("ttbtvEditDue").readOnly = !isAdmin;
    document.getElementById("ttbtvEditDue").style.background = isAdmin ? "#fff" : "#f1f5f9";
    document.getElementById("ttbtvEditDue").title = isAdmin ? "" : "Chỉ Admin được sửa Hạn hoàn thành.";
    document.getElementById("ttbtvEditStatus").readOnly = true;
    document.getElementById("ttbtvEditSpecialist").readOnly = !fullAccess;
    const srcSel=document.getElementById("ttbtvEditSource"); if(srcSel){ if(srcSel.tagName==="SELECT") srcSel.disabled=!isAdmin; else srcSel.readOnly=!isAdmin; }
    document.getElementById("ttbtvEditCompleted").readOnly = !can;
    document.getElementById("ttbtvEditProduct").readOnly = !can;
    document.getElementById("ttbtvEditStaffNote").readOnly = !(isOwner || isAdmin || isDataEntry || isAgencyEditor);
    document.getElementById("ttbtvEditAdminNote").readOnly = !canAdminNote;
    document.getElementById("ttbtvEditAttachment").disabled = !can;
    syncWorkspaceExtendButton("ttbtvEditExtendBtn", "ttbtv", x);

    document.getElementById("ttbtvStaffNoteHelp").textContent = (isOwner || isAdmin || isDataEntry)
        ? "Bạn có thể cập nhật ghi chú bổ sung cho nhiệm vụ này."
        : "Ghi chú của cán bộ phụ trách — Admin cũng có thể sửa.";
    document.getElementById("ttbtvAdminNoteHelp").textContent = canAdminNote
        ? "Có thể ghi lưu ý/chỉ đạo cho cán bộ."
        : "Ghi chú từ Admin — bạn chỉ có quyền xem.";

    const btn = document.getElementById("ttbtvEditSaveBtn");
    btn.style.display = can || isAdmin ? "inline-flex" : "none";

    const delBtn = document.getElementById("ttbtvEditDeleteBtn");
    if (delBtn) delBtn.style.display = can || isAdmin ? "inline-flex" : "none";

    renderTTBTVCurrentAttachment(x);
    if (typeof setupTTBTVDateFields === 'function') setupTTBTVDateFields();
    refreshTTBTVAutoStatus();
    if (typeof highlightTTBTVEditable === 'function') highlightTTBTVEditable();
    smoothOpenModal("ttbtvEditModal");
    focusFirstEditable("ttbtvEditModal");
}

function refreshTTBTVAutoStatus() {
    const x = TTBTV_TASKS.find(r => String(r.id) === String(TTBTV_EDIT_ID)); if (!x) return;
    const out = document.getElementById("ttbtvEditStatus");
    if (document.getElementById("ttbtvEditRegular")?.checked) {
        if (out) out.value = "Thường xuyên";
        const _pw = document.getElementById("ttbtvEditProduct")?.closest(".wide"); if (_pw) _pw.style.display = "";
        return;
    }

    const selected = document.getElementById("ttbtvEditAttachment")?.files?.[0] || null;
    let editRoles; try { editRoles = ttbtvCollectEditRoles(); } catch (e) { editRoles = []; }
    ttbtvRefreshRoleStatuses("edit");
    // Lãnh đạo bắt buộc đã nhập đủ Ngày hoàn thành + Kết quả => lấy kết quả của Lãnh đạo và ẩn ô "Kết quả thực hiện".
    try { ttbtvSyncLeaderCompletion(editRoles); } catch (e) {}
    const key = ttbtvStatusFor(x, {
        deadline: document.getElementById("ttbtvEditDue")?.value || x.deadline,
        completed_date: document.getElementById("ttbtvEditCompleted")?.value || "",
        result: document.getElementById("ttbtvEditProduct")?.value || "",
        hasFile: !!x.attachment_path || !!selected,
        roles: editRoles,
        role: document.getElementById("ttbtvEditRole")?.value || x.role || "",
        _regular: false
    });
    if (out) out.value = ttbtvStatusLabel(key);
}

function ttbtvSyncLeaderCompletion(editRoles) {
    // Cùng luật với ttbtvGroupKeyFromRoles: LĐ phòng luôn bắt buộc, thêm LĐ UBND khi Cơ quan chủ trì là UBND xã.
    const isUBND = ttbtvIsUBND(document.getElementById("ttbtvEditRole")?.value);
    const required = isUBND ? ["Lãnh đạo UBND", "Lãnh đạo phòng"] : ["Lãnh đạo phòng"];
    const byTitle = {};
    (editRoles || []).forEach(r => { if (r && r.title && !byTitle[r.title]) byTitle[r.title] = r; });
    const isDone = t => byTitle[t] && ["early", "ontime", "latedone"].includes(ttbtvRoleMemberKey(byTitle[t]));
    const leaderComplete = required.every(isDone);
    const product = document.getElementById("ttbtvEditProduct");
    if (leaderComplete && product) {
        const leadResult = required.map(t => String((byTitle[t] || {}).result || "").trim()).filter(Boolean).pop() || "";
        if (!String(product.value || "").trim() && leadResult) product.value = leadResult;
    }
    const wrap = product ? product.closest(".wide") : null;
    if (wrap) wrap.style.display = leaderComplete ? "none" : "";
}

function highlightTTBTVEditable() {
    const modal = document.getElementById('ttbtvEditModal'); if (!modal) return;
    modal.querySelectorAll('.bch-edit-grid label').forEach(l => l.classList.remove('is-editable'));
    modal.querySelectorAll('.bch-edit-grid > div').forEach(wrap => {
        const el = wrap.querySelector('input, textarea, select');
        if (!el) return;
        if (el.classList.contains('auto-status-field')) return;
        const isEditable = !el.readOnly && !el.disabled;
        if (isEditable) {
            const label = wrap.querySelector('label');
            if (label) label.classList.add('is-editable');
        }
    });
    const att = document.getElementById('ttbtvEditAttachment');
    if (att && !att.disabled) {
        const w = att.closest('.bch-upload-box');
        const l = w ? w.querySelector('label') : null;
        if (l) l.classList.add('is-editable');
    }
}

function closeTTBTVTaskEdit() { smoothCloseModal("ttbtvEditModal", () => { TTBTV_EDIT_ID = null; }); }

async function deleteTTBTVTask() {
    const x = TTBTV_TASKS.find(r => String(r.id) === String(TTBTV_EDIT_ID));
    if (!x) { showToast("error", "Không thể xóa nhiệm vụ", "Không tìm thấy nhiệm vụ đang chỉnh sửa."); return; }
    if (!canEditTTBTVTask(x)) { showToast("error", "Không có quyền", "Bạn không có quyền xóa nhiệm vụ này."); return; }

    const hasFile = !!x.attachment_path || !!x.attachment_name;
    const name = x.task_name || "Nhiệm vụ";
    const summary = `
                <div class="confirm-row"><span>Cán bộ</span><strong>${esc(x.officer_name || "")}</strong></div>
                <div class="confirm-row"><span>Nhiệm vụ</span><strong>${esc(name)}</strong></div>
                ${hasFile ? `<div class="confirm-row"><span>Tệp đính kèm</span><strong>${esc(x.attachment_name || "Có")}</strong></div><div class="confirm-note">Lưu ý: nếu chọn "Không, chỉ xóa nhiệm vụ", tệp vẫn được giữ lại trong Storage.</div>` : ""}
            `;
    openDeleteTaskConfirm({
        label: `Xóa nhiệm vụ "${name}"?`,
        summary,
        hasFile,
        onConfirm: async (deleteFile) => {
            try {
                if (deleteFile && x.attachment_path) {
                    const delUrl = `${SUPABASE_URL}/storage/v1/object/${TTBTV_STORAGE_BUCKET}/${x.attachment_path.split("/").map(encodeURIComponent).join("/")}`;
                    const dr = await fetch(delUrl, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                    if (!dr.ok && dr.status !== 404) { const tx = await dr.text(); throw new Error(tx || `Storage HTTP ${dr.status}`); }
                }
                const delUrl2 = `${SUPABASE_URL}/rest/v1/tt_btv_tasks?id=eq.${encodeURIComponent(x.id)}`;
                const r = await fetch(delUrl2, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (!r.ok && r.status !== 404) { const tx = await r.text(); throw new Error(tx || `HTTP ${r.status}`); }

                const di = TTBTV_TASKS.findIndex(t => String(t.id) === String(x.id));
                if (di >= 0) TTBTV_TASKS.splice(di, 1);
                localStorage.setItem("ttbtv_tasks_cache", JSON.stringify(TTBTV_TASKS));
                applyTTBTVFilters();
                if (document.getElementById("ttbtvDrillModal")?.classList.contains("open")) {
                    renderTTBTVDrill(getTTBTVRowsByMode(TTBTV_DRILL_MODE),
                        ({ all: "Tất cả nhiệm vụ TT/BTV Đảng bộ", processing: "Nhiệm vụ TTBTV — Đang xử lý", done: "Nhiệm vụ TTBTV — Hoàn thành", overdue: "Nhiệm vụ TTBTV — Quá hạn" })[TTBTV_DRILL_MODE] || "Nhiệm vụ TT, BTV ĐU giao",
                        ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[TTBTV_DRILL_MODE] || "🏛️");
                }
                closeTTBTVTaskEdit();
                writeActivity("Xóa nhiệm vụ TT/BTV", { task: name, owner: x.officer_name, id: x.id });
                showToast("success", "Đã xóa nhiệm vụ", `Đã xóa nhiệm vụ "${name}".`);
            } catch (e) {
                console.error(e);
                showToast("error", "Không thể xóa nhiệm vụ", e.message || "Vui lòng thử lại.", 6000);
            }
        }
    });
}

async function uploadTTBTVTaskFile(file, task) {
    if (!file) return null;
    if (file.size > 20 * 1024 * 1024) throw new Error("Tệp vượt quá 20 MB.");
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!new Set(["pdf", "doc", "docx", "xls", "xlsx"]).has(ext)) throw new Error("Chỉ chấp nhận PDF, Word hoặc Excel.");
    return { path: "", name: file.name, type: file.type || "application/octet-stream", size: file.size };
}

async function openTTBTVAttachment(id, allowPending = false) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xem/tải tệp TTBTV."); return;
    }
    const x = TTBTV_TASKS.find(r => String(r.id) === String(id)); if (!x || !x.attachment_path) return;
    if (!x.attachment_approved && !allowPending) {
        showToast("info", "Tệp đang chờ duyệt", "Hãy phê duyệt tệp trước."); return;
    }
    try {
        const r = await fetch(`${SUPABASE_URL}/storage/v1/object/authenticated/${TTBTV_STORAGE_BUCKET}/${encodePath(x.attachment_path)}`, {
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        if (!r.ok) throw new Error(await r.text());
        const blob = await r.blob(), url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.download = x.attachment_name || "tep-ttbtv";
        document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { showToast("error", "Không mở được tệp", e.message || "Lỗi Storage."); }
}

async function deleteTTBTVAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được xóa tệp TTBTV."); return;
    }
    const x = TTBTV_TASKS.find(r => String(r.id) === String(id));
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        showToast("error", "Không có tệp", "Nhiệm vụ này chưa có tệp để xóa."); return;
    }
    if (!confirm(`Xóa thẳng tệp "${x.attachment_name || "Tệp sản phẩm"}"?\n\nTệp sẽ bị xóa khỏi Storage và gỡ khỏi nhiệm vụ TT/BTV.`)) return;

    const oldPath = x.attachment_path;
    try {
        // Xóa file vật lý khỏi Supabase Storage trước.
        const delUrl = oldPath ? `${SUPABASE_URL}/storage/v1/object/${TTBTV_STORAGE_BUCKET}/${oldPath.split("/").map(encodeURIComponent).join("/")}` : "";
        const dr = delUrl ? await fetch(delUrl, {
            method: "DELETE",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }) : { ok: true, status: 204, text: async () => "" };
        const storageText = await dr.text();
        if (!dr.ok && dr.status !== 404 && !/object not found|not found/i.test(storageText)) {
            throw new Error(storageText || `Storage HTTP ${dr.status}`);
        }

        // Gỡ toàn bộ metadata tệp khỏi nhiệm vụ.
        const patch = {
            // Các cột này trong tt_btv_tasks là NOT NULL: dùng chuỗi rỗng/0 thay vì null.
            attachment_name: "",
            attachment_path: "",
            attachment_type: "",
            attachment_size: 0,
            attachment_approved: false,
            attachment_approved_at: null,
            attachment_approved_by: "",
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks?id=eq.${encodeURIComponent(id)}`, {
            method: "PATCH",
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                Prefer: "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        let saved = null; try { saved = JSON.parse(tx)?.[0] || null } catch (_) { }
        Object.assign(x, saved || patch);

        // V44: cập nhật giao diện bằng các hàm TTBTV thực sự đang tồn tại.
        // V43 gọi renderTTBTVAll() (không được định nghĩa), khiến tệp đã xóa thành công
        // nhưng sau đó vẫn bật toast lỗi "renderTTBTVAll is not defined".
        renderTTBTVCurrentAttachment(x);
        applyTTBTVFilters();
        if (document.getElementById("ttbtvDrillModal")?.classList.contains("open")) {
            renderTTBTVDrill(
                getTTBTVRowsByMode(TTBTV_DRILL_MODE),
                ({ all: "Tất cả nhiệm vụ TT/BTV Đảng bộ", processing: "Nhiệm vụ TTBTV — Đang xử lý", done: "Nhiệm vụ TTBTV — Hoàn thành", overdue: "Nhiệm vụ TTBTV — Quá hạn" })[TTBTV_DRILL_MODE] || "Nhiệm vụ TT, BTV ĐU giao",
                ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[TTBTV_DRILL_MODE] || "🏛️"
            );
        }
        showToast("success", "Đã xóa tệp", "Tệp đã được xóa khỏi nhiệm vụ TT/BTV.");
        writeActivity("TT/BTV - Xóa file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) {
        showToast("error", "Không xóa được tệp", e.message || "Có lỗi khi xóa tệp TTBTV.");
    }
}

async function approveTTBTVAttachment(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") { showToast("error", "Không có quyền", "Chỉ Admin được phê duyệt tệp."); return; }
    const x = TTBTV_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    try {
        const patch = {
            attachment_approved: true,
            attachment_approved_at: new Date().toISOString(),
            attachment_approved_by: CURRENT_USER.name || "Admin",
            updated_at: new Date().toISOString()
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
            body: JSON.stringify(patch)
        });
        const tx = await r.text(); if (!r.ok) throw new Error(tx || `HTTP ${r.status}`);
        Object.assign(x, patch); renderTTBTVCurrentAttachment(x); applyTTBTVFilters();
        showToast("success", "Đã phê duyệt", "Tệp TTBTV đã được phê duyệt.");
        writeActivity("TT/BTV - Duyệt file", { task: x.task_name, id: x.id, file: x.attachment_name || "" });
    } catch (e) { showToast("error", "Không thể phê duyệt", e.message || "Lỗi Supabase."); }
}

async function ttbtvHandleOfficerOther(sel) {
    if (!sel) return;
    if (sel.value !== '__other__') { sel.dataset.prev = sel.value; return; }
    const prev = sel.dataset.prev || '';
    const bodyHtml = `<div style="margin-top:4px"><input id="customOfficerInput" type="text" placeholder="Nhập tên lãnh đạo khác..." maxlength="80" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none;transition:border-color .15s,box-shadow .15s" onfocus="this.style.borderColor='#10b981';this.style.boxShadow='0 0 0 3px rgba(16,185,129,.14)'" onblur="this.style.borderColor='#cbd5e1';this.style.boxShadow='none'" /></div><div style="font-size:11px;color:#94a3b8;margin-top:6px">Nhấn <b>Thêm</b> để dùng tên này • Enter để xác nhận</div>`;
    setTimeout(() => { const inp = document.getElementById('customOfficerInput'); if (inp) { inp.focus(); try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (_) {} inp.addEventListener('keydown', function _h(e) { if (e.key === 'Enter') { e.preventDefault(); document.getElementById('provinceConfirmOkBtn')?.click(); } }); } }, 120);
    const ok = await provinceConfirm({ icon: '👤', title: 'Nhập tên lãnh đạo khác', message: 'Vui lòng nhập tên lãnh đạo không có trong danh sách', bodyHtml, confirmText: 'Thêm', cancelText: 'Hủy', confirmClass: 'btn-primary' });
    const inp2 = document.getElementById('customOfficerInput');
    const custom = inp2 ? inp2.value.trim() : '';
    if (ok && custom) {
        if (![...sel.options].some(o => o.value === custom)) {
            const opt = document.createElement('option');
            opt.value = custom;
            opt.textContent = custom;
            const otherOpt = [...sel.options].find(o => o.value === '__other__');
            if (otherOpt) sel.insertBefore(opt, otherOpt); else sel.appendChild(opt);
        }
        sel.value = custom;
        sel.dataset.prev = custom;
    } else {
        if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
        else if (sel.options.length) sel.selectedIndex = 0;
        if (sel.value === '__other__') sel.selectedIndex = 0;
    }
}

function ttbtvToDateInputVal(v) {
    const d = ttbtvDeadlineDate(v);
    if (!d) return "";
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function ttbtvSyncMainDatesFromLeader(mode) {
    try {
        const isNew = mode === "new";
        const isUBND = ttbtvIsUBND(document.getElementById(isNew ? "ttbtvNewRole" : "ttbtvEditRole")?.value);
        const leadDone = document.getElementById(isNew ? (isUBND ? "ttbtvRoleUBNDDone" : "ttbtvRolePhongDone") : (isUBND ? "ttbtvEditRoleUBNDDone" : "ttbtvEditRolePhongDone"))?.value || "";
        const mainDone = document.getElementById(isNew ? "ttbtvNewCompleted" : "ttbtvEditCompleted");
        if (mainDone) mainDone.value = String(leadDone || "").trim();
    } catch (e) {}
}

function getTTBTVSourceList() {
    const set = new Set();
    try { (TTBTV_TASKS || []).forEach(x => { const v = String(x.amount || "").trim(); if (v) set.add(v); }); } catch(e) {}
    return [...set].sort((a,b)=>a.localeCompare(b,'vi'));
}

function populateTTBTVSourceSelect(sel, currentValue) {
    if (!sel) return;
    const list = getTTBTVSourceList();
    const cur = String(currentValue || "").trim();
    if (cur && !list.includes(cur)) list.unshift(cur);
    const opts = ['<option value="">Chọn nguồn giao</option>'].concat(list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`)).concat(['<option value="__other__">Khác (nhập văn bản)</option>']);
    sel.innerHTML = opts.join('');
    if (cur) sel.value = cur;
    else if (list.length) sel.value = "";
    sel.dataset.prev = sel.value;
}

async function ttbtvHandleSourceOther(sel) {
    if (!sel) return;
    if (sel.value !== "__other__") { sel.dataset.prev = sel.value; return; }
    const prev = sel.dataset.prev || "";
    const bodyHtml = `<div style="margin-top:4px"><input id="customTTBTVSourceInput" type="text" placeholder="Nhập văn bản nguồn giao..." maxlength="200" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none"></div>`;
    setTimeout(() => document.getElementById("customTTBTVSourceInput")?.focus(), 120);
    const ok = await provinceConfirm({ icon: "📄", title: "Nhập văn bản nguồn giao", message: "Vui lòng nhập tên văn bản nguồn giao", bodyHtml, confirmText: "Thêm", cancelText: "Hủy", confirmClass: "btn-primary" });
    const custom = document.getElementById("customTTBTVSourceInput")?.value.trim() || "";
    if (ok && custom) {
        if (![...sel.options].some(o => o.value === custom)) {
            const opt = document.createElement("option"); opt.value = custom; opt.textContent = custom;
            const other = [...sel.options].find(o => o.value === "__other__");
            if (other) sel.insertBefore(opt, other); else sel.appendChild(opt);
        }
        sel.value = custom; sel.dataset.prev = custom;
    } else {
        sel.value = prev || "";
    }
}

function getVPUBSourceList() {
    const src = (typeof VPUB_TASKS_CACHE !== 'undefined' && VPUB_TASKS_CACHE.length ? VPUB_TASKS_CACHE : (typeof ACTION100_TASKS !== 'undefined' ? ACTION100_TASKS : []));
    const set = new Set();
    try { src.forEach(x => { const v = String(x.source || "").trim(); if (v) set.add(v); }); } catch(e) {}
    return [...set].sort((a,b)=>a.localeCompare(b,'vi'));
}

function populateVPUBSourceSelect(sel, currentValue) {
    if (!sel) return;
    const list = getVPUBSourceList();
    const cur = String(currentValue || "").trim();
    if (cur && !list.includes(cur)) list.unshift(cur);
    const opts = ['<option value="">Chọn nguồn giao</option>'].concat(list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`)).concat(['<option value="__other__">Khác (nhập văn bản)</option>']);
    sel.innerHTML = opts.join('');
    if (cur) sel.value = cur;
    sel.dataset.prev = sel.value;
}

async function vpubHandleSourceOther(sel) {
    if (!sel) return;
    if (sel.value !== "__other__") { sel.dataset.prev = sel.value; return; }
    const prev = sel.dataset.prev || "";
    const bodyHtml = `<div style="margin-top:4px"><input id="customVPUBSourceInput" type="text" placeholder="Nhập văn bản nguồn giao..." maxlength="200" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none"></div>`;
    setTimeout(()=>document.getElementById("customVPUBSourceInput")?.focus(),120);
    const ok = await provinceConfirm({ icon:"📄", title:"Nhập văn bản nguồn giao", message:"Vui lòng nhập tên văn bản nguồn giao", bodyHtml, confirmText:"Thêm", cancelText:"Hủy", confirmClass:"btn-primary" });
    const custom = document.getElementById("customVPUBSourceInput")?.value.trim() || "";
    if (ok && custom) {
        if (![...sel.options].some(o=>o.value===custom)) {
            const opt=document.createElement("option"); opt.value=custom; opt.textContent=custom;
            const other=[...sel.options].find(o=>o.value==="__other__");
            if(other) sel.insertBefore(opt, other); else sel.appendChild(opt);
        }
        sel.value=custom; sel.dataset.prev=custom;
    } else {
        sel.value=prev||"";
    }
}

async function saveTTBTVTaskEdit() {
    const x = TTBTV_TASKS.find(r => String(r.id) === String(TTBTV_EDIT_ID)); if (!x) return;
    if (!canEditTTBTVTask(x) && !(CURRENT_USER && CURRENT_USER.role === "admin")) {
        showToast("error", "Không có quyền", "Bạn không có quyền cập nhật nhiệm vụ này."); return;
    }

    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const isDataEntry = CURRENT_USER && CURRENT_USER.scope === "data_entry";
    const isNGN = canNGNEditTask(x);
    const isAgencyEditor = canEditTTBTVTask(x) && !isAdmin && !isDataEntry && !isNGN && !(CURRENT_USER && CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name);
    const fullAccess = isAdmin || isDataEntry || isNGN || isAgencyEditor;
    const isOwner = isNGN || (CURRENT_USER && CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name) || isAgencyEditor;
    const btn = document.getElementById("ttbtvEditSaveBtn"), old = btn.textContent;
    let uploaded = null;

    try {
        btn.disabled = true; btn.textContent = "⏳ Đang lưu...";
        const file = document.getElementById("ttbtvEditAttachment")?.files?.[0] || null;
        if (file) {
            document.getElementById("ttbtvUploadProgress").style.display = "block";
            uploaded = await uploadTTBTVTaskFile(file, x);
        }

        // V48: luôn giữ deadline là giá trị NOT NULL. Đây là lỗi khiến cán bộ
        // chỉ tải tệp nhưng PATCH lại có thể vướng constraint "deadline".
        const existingDeadline = String(x.deadline ?? "").trim();
        const patch = {
            deadline: existingDeadline,
            completed_date: dateToDb(document.getElementById("ttbtvEditCompleted").value),
            result: (document.getElementById("ttbtvEditProduct").value || "").trim() || "Chưa điền",
            updated_at: new Date().toISOString()
        };

        if (fullAccess) {
            // Ten lanh dao duoc phep de trong ("") — khong ep "Chua phan cong"
            const officer = (document.getElementById("ttbtvEditOfficer").value || "").trim();
            const role = (document.getElementById("ttbtvEditRole").value || "").trim();
            // Chỉ Admin được sửa Nội dung nhiệm vụ (toàn hệ thống) - các role khác giữ nguyên
            let taskName = (document.getElementById("ttbtvEditTask").value || "").trim();
            if (!isAdmin && taskName !== String(x.task_name||"").trim()) {
                showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ.");
                taskName = String(x.task_name||"").trim();
                document.getElementById("ttbtvEditTask").value = taskName;
            }
            if (isDataEntry) taskName = x.task_name || "";
            const specialist = (document.getElementById("ttbtvEditSpecialist").value || "").trim();
            if (!taskName) throw new Error("Nhiệm vụ không được để trống.");
            const dueInput = (document.getElementById("ttbtvEditDue").value || "").trim();
            // Hạn hoàn thành chỉ Admin được sửa (toàn hệ thống)
            if (!isAdmin) {
                const curDueNorm = String(existingDeadline||"").trim();
                const inputDueNorm = dueInput ? (dateToDb(dueInput) || dueInput) : "";
                if (inputDueNorm !== curDueNorm) {
                    showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành.");
                    document.getElementById("ttbtvEditDue").value = curDueNorm ? ttbtvDdmmyyyy(ttbtvDeadlineDate(curDueNorm)) : "";
                }
            }
            // Cột deadline là NOT NULL; cho phép để trống nhưng phải lưu "" thay vì null.
            patch.deadline = isAdmin ? (dueInput ? (dateToDb(dueInput) || dueInput) : "") : existingDeadline;
            patch.officer_name = officer;
            patch.task_name = taskName;
            patch.role = role;
            patch.unit_name = role;
            patch.specialist_name = specialist;
            patch.product = specialist;
        }
        if (!fullAccess && isOwner) {
            patch.officer_name = (document.getElementById("ttbtvEditOfficer").value || "").trim();
        }
        if (fullAccess || isOwner) {
            const srcEl = document.getElementById("ttbtvEditSource");
            const srcVal = srcEl ? (srcEl.value || "").trim() : "";
            if (!srcVal) throw new Error("Nguồn giao là trường bắt buộc, không được để trống.");
            patch.amount = srcVal;
            patch.ubnd_leader = (document.getElementById("ttbtvEditUBNDLeader")?.value || "").trim();
            const editRoles = ttbtvCollectEditRoles();
            if (editRoles.some(r => r.due || r.done || r.result || r.reason)) patch.note = JSON.stringify({ roles: editRoles });
            else if (!ttbtvParseRoleNote(x.note)) patch.note = x.note || "";
            else patch.note = "";
            // Hạn/Ngày HT chính tự động lấy theo Lãnh đạo UBND hoặc Lãnh đạo phòng.
            const _isUBND = ttbtvIsUBND(document.getElementById("ttbtvEditRole")?.value);
            const _lead = (editRoles || []).find(r => r && r.title === (_isUBND ? "Lãnh đạo UBND" : "Lãnh đạo phòng")) || {};
            if (String(_lead.due || "").trim()) { const _db = dateToDb(_lead.due); if (_db) patch.deadline = _db; }
            // Ngày HT chính LUÔN lấy theo LĐ (trống => xóa ngày HT); legacy chưa nhập vai trò nào thì giữ tay.
            if (editRoles.some(r => r.due || r.done || r.result || r.reason)) patch.completed_date = String(_lead.done || "").trim() ? (dateToDb(_lead.done) || null) : null;
        }
        if (isAdmin) {
            patch.admin_note = (document.getElementById("ttbtvEditAdminNote").value || "").trim();
        }
        if (isOwner || isDataEntry) {
            patch.staff_note = (document.getElementById("ttbtvEditStaffNote").value || "").trim();
        }
        if (uploaded) {
            patch.attachment_path = uploaded.path;
            patch.attachment_name = uploaded.name;
            patch.attachment_type = uploaded.type;
            patch.attachment_size = uploaded.size;
            patch.attachment_approved = false;
            patch.attachment_approved_at = null;
            // SQL V45 khai báo NOT NULL, vì vậy tuyệt đối không gửi null.
            patch.attachment_approved_by = "";
        }

        const temp = { ...x, ...patch };
        if (uploaded) temp.attachment_path = uploaded.path;
        const wasRegular = String(x.status || "").trim() === "Thường xuyên" || x.statusKey === "regular";
        if (isAdmin && document.getElementById("ttbtvEditRegular")?.checked) {
            patch.status = "Thường xuyên";
        } else if (!isAdmin && wasRegular) {
            patch.status = "Thường xuyên";
        } else {
            const autoStatusKey = ttbtvStatusFor(temp, { hasFile: !!temp.attachment_path, _regular: false, roles: ttbtvParseRoleNote(patch.note !== undefined ? patch.note : temp.note) || undefined, role: temp.role });
            patch.status = ttbtvStatusLabel(autoStatusKey);
        }

        const r = await fetch(`${SUPABASE_URL}/rest/v1/tt_btv_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) { let msg = tx; try { const j = JSON.parse(tx); msg = j.message || j.details || j.hint || tx } catch (e) { } throw new Error(msg || `HTTP ${r.status}`); }
        // Doi chieu ten Lanh dao server tra ve (Prefer return=representation): lech la bao ngay
        try {
            const sj = JSON.parse(tx || "null");
            const srow = Array.isArray(sj) ? sj[0] : sj;
            if (srow && typeof srow === "object") {
                const leaks = [];
                if (patch.ubnd_leader !== undefined && String(srow.ubnd_leader ?? "") !== String(patch.ubnd_leader)) leaks.push("Lãnh đạo UBND/phòng");
                if (patch.officer_name !== undefined && String(srow.officer_name ?? "") !== String(patch.officer_name)) leaks.push("Lãnh đạo (officer)");
                if (leaks.length) showToast("error", "Tên Lãnh đạo chưa lưu được", leaks.join(" + ") + ": server trả về khác giá trị đã gửi. Hãy chụp toast này gửi dev.");
            }
        } catch (e) { void e; }

        Object.assign(x, patch);
        if (uploaded) {
            x.attachment_path = uploaded.path; x.attachment_name = uploaded.name; x.attachment_type = uploaded.type; x.attachment_size = uploaded.size;
            x.attachment_approved = false; x.attachment_approved_at = ""; x.attachment_approved_by = "";
        }
        x.statusKey = ttbtvStatusFor(x);
        x._search = ttbtvFold([x.officer_name, x.task_name, x.role, x.unit_name, x.specialist_name, x.product, x.amount, x.ubnd_source, x.source_doc, x.deadline, x.result, x.staff_note, x.admin_note].join(" "));
        moveTaskToTop(TTBTV_TASKS, x.id);
        localStorage.setItem("ttbtv_tasks_cache", JSON.stringify(TTBTV_TASKS));

        applyTTBTVFilters();
        if (document.getElementById("ttbtvDrillModal")?.classList.contains("open")) {
            renderTTBTVDrill(getTTBTVRowsByMode(TTBTV_DRILL_MODE),
                ({ all: "Tất cả nhiệm vụ TT/BTV Đảng bộ", processing: "Nhiệm vụ TTBTV — Đang xử lý", done: "Nhiệm vụ TTBTV — Hoàn thành", overdue: "Nhiệm vụ TTBTV — Quá hạn", regular: "Nhiệm vụ TTBTV — Thường xuyên" })[TTBTV_DRILL_MODE] || "Nhiệm vụ TT, BTV ĐU giao",
                ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰", regular: "🔁" })[TTBTV_DRILL_MODE] || "🏛️");
        }
        closeTTBTVTaskEdit();
        showToast("success", "Đã lưu nhiệm vụ TT/BTV", "Dữ liệu đã được cập nhật vào Supabase.");
        writeActivity("Sửa nhiệm vụ TT/BTV", { task: x.task_name, owner: x.officer_name, id: x.id });
    } catch (e) {
        console.error(e);
        showToast("error", "Không thể lưu nhiệm vụ TT/BTV", e.message || "Vui lòng chạy migration V30 và kiểm tra Storage.", 6000);
    } finally {
        const p = document.getElementById("ttbtvUploadProgress"); if (p) p.style.display = "none";
        btn.disabled = false; btn.textContent = old || "💾 Lưu thay đổi";
    }
}

function ttbtvDispDate(v) {
    const d = ttbtvDeadlineDate(v);
    if (!d) return String(v || "").trim() || "Chưa có hạn";
    return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${d.getFullYear()}`;
}

function ttbtvRemainingText(x) {
    const d = ttbtvDeadlineDate(x.deadline);
    const c = ttbtvCompletedDate(x.completed_date);
    const day = dt => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime();
    if (c && d) {
        const diff = Math.round((day(d) - day(c)) / 86400000);
        if (diff > 0) return { t: `Trước hạn ${diff} ngày`, cls: "done" };
        if (diff === 0) return { t: "Đúng hạn", cls: "done" };
        return { t: `Trễ ${Math.abs(diff)} ngày`, cls: "late" };
    }
    if (c) return { t: "Đã hoàn thành", cls: "done" };
    if (!d) return { t: "—", cls: "" };
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const days = Math.round((day(d) - today.getTime()) / 86400000);
    if (days > 0) return { t: `Còn ${days} ngày`, cls: "" };
    if (days === 0) return { t: "Hết hạn hôm nay", cls: "today" };
    return { t: `Trễ ${Math.abs(days)} ngày`, cls: "late" };
}

function setTTBTVMonth(m) {
    TTBTV_MONTH = m || null;
    try { document.querySelectorAll("#ttbtvMonthStrip button").forEach(b => b.classList.toggle("active", String(b.dataset.month || "") === String(TTBTV_MONTH || ""))); } catch (e) {}
    TTBTV_PAGE = 1;
    applyTTBTVFilters();
}

function ttbtvHeaderSourceFilter(v) {
    TTBTV_SRC_Q = ttbtvFold(v || "");
    TTBTV_PAGE = 1;
    applyTTBTVFiltersKeepPage();
}

function applyTTBTVFiltersKeepPage() {
    if (!document.getElementById("ttbtvWorkspace")) return;
    const q = ttbtvFold(document.getElementById("ttbtvSearch")?.value || "");
    const officer = document.getElementById("ttbtvOfficerFilter")?.value || "";
    const agency = document.getElementById("ttbtvAgencyFilter")?.value || "";
    const status = document.getElementById("ttbtvStatusFilter")?.value || "all";
    const timeMode = document.getElementById("ttbtvTimeFilter")?.value || "all";
    TTBTV_TASKS.forEach(x => x.statusKey = ttbtvStatusFor(x));
    TTBTV_FILTERED = TTBTV_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (officer && x.officer_name !== officer) return false;
        if (!ttbtvMatchAgency(x, agency)) return false;
        if (typeof TTBTV_SRC_Q !== "undefined" && TTBTV_SRC_Q && !ttbtvFold(x.amount || x.source_doc || x.ubnd_source || "").includes(TTBTV_SRC_Q)) return false;
        if (status !== "all" && ttbtvStatusGroup(x.statusKey) !== status) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof TTBTV_MONTH !== "undefined" && TTBTV_MONTH) { const d = ttbtvDeadlineDate(x.deadline); if (!d || (d.getMonth() + 1) !== TTBTV_MONTH) return false; }
        if (typeof TTBTV_DL_DATE !== "undefined" && TTBTV_DL_DATE) { const dd = ttbtvDeadlineDate(x.deadline); if (!dd || new Date(dd.getFullYear(), dd.getMonth(), dd.getDate()).getTime() !== TTBTV_DL_DATE) return false; }
        else if (typeof TTBTV_DL_Q !== "undefined" && TTBTV_DL_Q && !ttbtvFold(x.deadline || "").includes(TTBTV_DL_Q)) return false;
        return true;
    });
    renderTTBTVKPIs();
    renderTTBTVTable(TTBTV_FILTERED);
    if (typeof renderTTBTVCharts === "function") renderTTBTVCharts();
}

function ttbtvHeaderDeadlineDate(v) {
    const s = String(v || "").trim();
    TTBTV_DL_Q = ttbtvFold(s);
    TTBTV_DL_DATE = null;
    const m = s.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{4})/);
    if (m) { const d = new Date(+m[3], +m[2] - 1, +m[1]); if (!isNaN(d)) TTBTV_DL_DATE = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); }
    TTBTV_PAGE = 1;
    applyTTBTVFiltersKeepPage();
}

function ttbtvPickDeadline() { const p = document.getElementById("ttbtvFDeadlinePicker"); if (p && p.showPicker) try { p.showPicker(); } catch (e) { p.focus(); } else if (p) p.focus(); }

function ttbtvPickerDeadline(v) {
    if (!v) { TTBTV_DL_DATE = null; const inp = document.getElementById("ttbtvFDeadline"); if (inp) inp.value = ""; }
    else { const [y, m, d] = v.split("-").map(Number); const dt = new Date(y, m - 1, d); TTBTV_DL_DATE = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime(); const inp = document.getElementById("ttbtvFDeadline"); if (inp) inp.value = `${String(d).padStart(2, "0")}/${String(m).padStart(2, "0")}/${y}`; TTBTV_DL_Q = ""; }
    TTBTV_PAGE = 1;
    applyTTBTVFiltersKeepPage();
}

function ttbtvSetPageSize(v) { TTBTV_PAGE_SIZE = Math.max(5, Number(v) || 20); TTBTV_PAGE = 1; renderTTBTVTable(TTBTV_FILTERED); }

function ttbtvGotoPage(p) {
    const total = Math.max(1, Math.ceil((TTBTV_FILTERED.length || 0) / TTBTV_PAGE_SIZE));
    TTBTV_PAGE = Math.min(total, Math.max(1, Number(p) || 1));
    renderTTBTVTable(TTBTV_FILTERED);
}

function ttbtvPickAgency(n) {
    const sel = document.getElementById("ttbtvAgencyFilter"); if (!sel) return;
    if (![...sel.options].some(o => o.value === n)) { const opt = document.createElement("option"); opt.value = n; opt.textContent = n; sel.appendChild(opt); }
    sel.value = n;
    try { if (typeof applyTTBTVFilters === "function") applyTTBTVFilters(); } catch (e) {}
    try { if (typeof renderTTBTVLeaderList === "function") renderTTBTVLeaderList(); } catch (e) {}
}

function ttbtvToggleSourceGroup(id, btn) { const row = document.getElementById(id); if (!row) return; const open = row.style.display !== "none"; row.style.display = open ? "none" : "table-row"; const headRow = btn?.closest("tr"); if (headRow) headRow.classList.toggle("expanded", !open); const toggle = headRow?.querySelector(".ttbtv-source-toggle"); if (toggle) { toggle.setAttribute("aria-label", open ? "Mở rộng" : "Thu gọn"); toggle.innerHTML = open ? '<svg class="ttbtv-icon-plus" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>' : '<svg class="ttbtv-icon-minus" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"/></svg>'; } }

function setTTBTVStatusFilter(status, el) {
    const sel = document.getElementById("ttbtvStatusFilter"); if (sel) sel.value = status || "all";
    document.querySelectorAll("#ttbtvSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    if (el) el.classList.add("active-sub");
    openTTBTVWorkspace();
    applyTTBTVFilters();
}

function resetTTBTVFilters() {
    const q = document.getElementById("ttbtvSearch"), o = document.getElementById("ttbtvOfficerFilter"), a = document.getElementById("ttbtvAgencyFilter"), s = document.getElementById("ttbtvStatusFilter"), t = document.getElementById("ttbtvTimeFilter");
    if (q) q.value = ""; if (o) o.value = ""; if (a) a.value = ""; if (s) s.value = "all"; if (t) t.value = "all";
    TTBTV_MONTH = null; TTBTV_DL_Q = ""; TTBTV_DL_DATE = null; TTBTV_SRC_Q = ""; TTBTV_PAGE = 1;
    ["ttbtvFTask", "ttbtvFSource", "ttbtvFDeadline"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    const pk = document.getElementById("ttbtvFDeadlinePicker"); if (pk) pk.value = "";
    const fs = document.getElementById("ttbtvFStatus"); if (fs) fs.value = "all";
    const ls = document.getElementById("ttbtvLeaderSearch"); if (ls) ls.value = "";
    document.querySelectorAll("#ttbtvMonthStrip button").forEach(b => b.classList.remove("active"));
    document.querySelectorAll("#ttbtvSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    applyTTBTVFilters();
}

function openTTBTVWorkspace(el) {
    if (CURRENT_USER?.role === 'department' && !['vpub','action100'].includes(CURRENT_USER.scope) && !TTBTV_ALLOWED_TOKENS.has(CURRENT_USER?._rawToken)) return showToast('error', 'Khong co quyen', 'Token nay chi duoc xem workspace VPUB va cac workspace duoc phep.');
    document.getElementById("officeWorkspace")?.classList.remove("open");
    document.getElementById("action100Workspace")?.classList.remove("open");
    document.getElementById("mttqKpiWorkspace")?.classList.remove("open");
    document.getElementById("nqWorkspace")?.classList.remove("open");
    const ws = document.getElementById("ttbtvWorkspace"); if (!ws) return;
    document.getElementById("bchWorkspace")?.classList.remove("open");
    document.getElementById("provinceWorkspace")?.classList.remove("open");
    ws.classList.add("open");
    const item = el || document.getElementById("ttbtvSidebarItem");
    if (item) {
        document.querySelectorAll(".sidebar-item").forEach(x => x.classList.remove("active"));
        item.classList.add("active");
        const sub = document.getElementById("ttbtvSubmenu"); if (sub) { sub.classList.add("open"); requestAnimationFrame(() => { sub.style.maxHeight = sub.scrollHeight + "px"; }); }
        item.classList.remove("collapsed");
    }
    loadTTBTVData(false);
    try{ vpSaveLastWs("ttbtvWorkspace"); }catch(e){}
}

function closeTTBTVWorkspace() {
    document.getElementById("ttbtvWorkspace")?.classList.remove("open");
    document.getElementById("ttbtvSidebarItem")?.classList.remove("active");
    document.querySelectorAll("#ttbtvSubmenu .sidebar-subitem").forEach(x => x.classList.remove("active-sub"));
    const home = [...document.querySelectorAll(".sidebar-item")].find(x => x.textContent.includes("Trang chủ"));
    if (home) home.classList.add("active");
}

function provinceOfficerMap() {
    const map = new Map();
    PROV_OFFICERS.forEach(o => map.set(provinceFold(o.name), o));
    return map;
}

function toggleOfficeWorkspaceSidebar(el) {
    if (!el) return;
    const ws = document.getElementById("officeWorkspace");
    if (!ws?.classList.contains("open")) { openOfficeWorkspace(el); return; }
    toggleSubmenu(el);
}

function action100StatusText(value) { return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }

function action100ParseDate(s) {
    const v = String(s || '').trim(); if (!v) return null;
    const iso = v.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) { const y = +iso[1], m = +iso[2] - 1, d = +iso[3]; const dt = new Date(y, m, d); return dt.getFullYear() === y && dt.getMonth() === m && dt.getDate() === d ? dt : null; }
    const ms = [...v.matchAll(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/g)];
    if (ms.length) { const lst = ms[ms.length - 1]; const d = +lst[1], m = +lst[2] - 1, y = +lst[3]; const dt = new Date(y, m, d); return dt.getFullYear() === y && dt.getMonth() === m && dt.getDate() === d ? dt : null; }
    const dt = new Date(v); return isNaN(dt) ? null : new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
}

function action100HasResult(v) {
    const s = provinceFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null", "dang trien khai", "chua co", "chua", "trong", ""].includes(s);
}

function action100StatusFromValues({ deadline, completed_date, product, result, staff_note, weekly_result, status } = {}) {
    if (String(status || '').trim() === 'Thường xuyên') return 'regular';
    if (String(status || '').trim() === 'Theo kế hoạch') return 'planned';
    const due = action100ParseDate(deadline);
    const completed = action100ParseDate(completed_date);
    const hasResult = action100HasResult(product) || action100HasResult(result) || action100HasResult(staff_note) || action100HasResult(weekly_result);
    if (completed && hasResult) {
        if (!due) return 'ontime';
        const completedDay = new Date(completed.getFullYear(), completed.getMonth(), completed.getDate()).getTime();
        const dueDay = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
        if (completedDay < dueDay) return 'early';
        if (completedDay === dueDay) return 'ontime';
        return 'latedone';
    }
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return due && due < today ? 'overdue' : 'processing';
}

function action100Status(x) { return action100StatusFromValues(x); }

function action100Label(k, isVPUB) {
    const vpub = isVPUB === true || (typeof ACTION100_MODE !== 'undefined' && ACTION100_MODE === 'vpub');
    if (k === 'overdue' && vpub) return 'NV đang xử lý';
    return ({ processing: '\u0110ang tri\u1ec3n khai', early: 'Ho\u00e0n th\u00e0nh tr\u01b0\u1edbc h\u1ea1n', ontime: 'Ho\u00e0n th\u00e0nh \u0111\u00fang h\u1ea1n', latedone: 'Ho\u00e0n th\u00e0nh qu\u00e1 h\u1ea1n', overdue: 'Qu\u00e1 h\u1ea1n', regular: 'Th\u01b0\u1eddng xuy\u00ean', planned: 'Theo k\u1ebf ho\u1ea1ch' })[k] || '\u0110ang tri\u1ec3n khai';
}

async function loadAction100Data(force = false) {
    if(DEMO_MODE){
        const snap = await getDemoSnapshot();
        const isVpub = (typeof ACTION100_MODE!=='undefined' && ACTION100_MODE==='vpub');
        const tKey = isVpub ? 'vpub_tasks' : 'action_100_days_tasks';
        const oKey = 'action_100_days_officers';
        ACTION100_TASKS = Array.isArray(snap[tKey]) ? snap[tKey] : (Array.isArray(snap.action_100_days_tasks) ? snap.action_100_days_tasks : []);
        ACTION100_OFFICERS = Array.isArray(snap[oKey]) ? snap[oKey] : [];
        if(isVpub){ VPUB_TASKS_CACHE=[...ACTION100_TASKS]; try{ writeCache("vpub_tasks_cache", VPUB_TASKS_CACHE);}catch(e){} } else { KH100_TASKS_CACHE=[...ACTION100_TASKS]; try{ writeCache("action100_tasks_cache", KH100_TASKS_CACHE);}catch(e){} }
        const sync=document.getElementById('action100SyncText'); if(sync) sync.textContent=`✅ [DEMO] ${ACTION100_TASKS.length} nhiệm vụ mẫu (không fetch Supabase)`;
        const title=document.querySelector('#action100Workspace .bch-title h1'); if(title) title.textContent=isVpub ? 'Nhiệm vụ VPUB' : 'KH hành động 100 ngày';
        populateAction100AgencyFilter(); renderAction100Table(); renderAction100AddBox(); setupVPUBDateFields();
        return;
    }
    const h = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };
    showTableSkeleton("action100TableBody");
    try {
        const [tr, or] = await Promise.all([fetch(ACTION100_TASKS_API, { headers: h }), fetch(ACTION100_OFFICERS_API, { headers: h })]);
        if (!tr.ok || !or.ok) throw new Error('Kh\u00f4ng th\u1ec3 \u0111\u1ecdc d\u1eef li\u1ec7u KH h\u00e0nh \u0111\u1ed9ng 100 ng\u00e0y.');
        ACTION100_TASKS = await tr.json(); ACTION100_OFFICERS = await or.json();
        if(ACTION100_MODE==='vpub'){ VPUB_TASKS_CACHE=[...ACTION100_TASKS]; writeCache("vpub_tasks_cache", VPUB_TASKS_CACHE); } else { KH100_TASKS_CACHE=[...ACTION100_TASKS]; writeCache("action100_tasks_cache", KH100_TASKS_CACHE); }
        const sync = document.getElementById('action100SyncText'); if (sync) sync.textContent = `Đã cập nhật lúc ${new Date().toLocaleTimeString('vi-VN')}`;
        const title = document.querySelector('#action100Workspace .bch-title h1'); if (title) title.textContent = ACTION100_MODE === 'vpub' ? 'Nhiệm vụ VPUB' : 'KH hành động 100 ngày';
        const editTitle = document.querySelector('#action100EditModal .bch-edit-head h3'); if (editTitle) editTitle.textContent = ACTION100_MODE === 'vpub' ? 'Cập nhật nhiệm vụ VPUB' : 'Cập nhật nhiệm vụ KH hành động 100 ngày';
        const addTitle = document.querySelector('#action100AddBox .add-task-title span'); if (addTitle) addTitle.textContent = ACTION100_MODE === 'vpub' ? 'Thêm nhiệm vụ VPUB' : 'Thêm nhiệm vụ KH hành động 100 ngày';
        syncAction100OverdueLabel();
        populateAction100AgencyFilter(); renderAction100Table(); renderAction100AddBox(); setupVPUBDateFields();
        try { const s=document.getElementById('action100EditSource'); if(s && s.tagName==='SELECT' && ACTION100_MODE==='vpub') populateVPUBSourceSelect(s, s.value); const aS=document.getElementById('vpubSource'); if(aS) populateVPUBSourceSelect(aS, aS.value); } catch(_e) {}
        const action100StatusLabel = document.getElementById('action100StatusField')?.previousElementSibling;
        if (action100StatusLabel) action100StatusLabel.innerHTML = 'Tr&#7841;ng th&#225;i <span style="font-size:11px;color:#64748b">(t&#7921; &#273;&#7897;ng)</span>';
    } catch (e) {
        console.error(e);
        const cached = ACTION100_MODE==='vpub' ? readCache("vpub_tasks_cache") : readCache("action100_tasks_cache");
        if (cached && cached.length) {
            ACTION100_TASKS = cached;
            if(ACTION100_MODE==='vpub') VPUB_TASKS_CACHE=[...cached]; else KH100_TASKS_CACHE=[...cached];
            syncAction100OverdueLabel();
            populateAction100AgencyFilter(); renderAction100Table(); renderAction100AddBox(); setupVPUBDateFields();
            try { const s=document.getElementById('action100EditSource'); if(s && s.tagName==='SELECT' && ACTION100_MODE==='vpub') populateVPUBSourceSelect(s, s.value); const aS=document.getElementById('vpubSource'); if(aS) populateVPUBSourceSelect(aS, aS.value); } catch(_e) {}
            const sync = document.getElementById('action100SyncText'); if (sync) sync.textContent = '⚠️ Mất kết nối · dùng dữ liệu lưu gần nhất';
            return;
        }
        showToast('error', 'Kh\u00f4ng t\u1ea3i \u0111\u01b0\u1ee3c d\u1eef li\u1ec7u', e.message);
    }
}

function filterAction100ByKPI(status, element) {
    if (ACTION100_MODE === 'vpub') return openVPUBDrill(status, element);
    const filter = document.getElementById('action100Status'), search = document.getElementById('action100Search');
    if (filter) filter.value = status;
    if (search) search.value = '';
    document.querySelectorAll('#action100Workspace .bch-kpi').forEach(kpi => kpi.classList.remove('selected'));
    if (element) element.classList.add('selected');
    renderAction100Table();
    document.getElementById('action100TableBody')?.closest('.bch-table-wrap')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function vpubDrillTimestamp(x) { const t = Date.parse(x?.updated_at || x?.created_at || ""); return Number.isFinite(t) ? t : (Number(x?.id) || 0); }

function applyVPUBDrillOrder(rows) { const mode = document.getElementById("vpubDrillOrder")?.value || "newest"; let out = [...rows]; if (mode === "with_file") out = out.filter(x => !!x.attachment_path || !!x.attachment_name); const due = x => { const d = action100ParseDate(x?.deadline); return d ? d.getTime() : null; }; if (mode === "oldest") out.sort((a, b) => vpubDrillTimestamp(a) - vpubDrillTimestamp(b)); else if (mode === "due_far") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return B - A; }); else if (mode === "due_near") out.sort((a, b) => { const A = due(a), B = due(b); if (A === null) return 1; if (B === null) return -1; return A - B; }); else out = sortNewestFirst(out); return out; }

function onVPUBDrillFilterChange() { let rows = VPUB_DRILL_STATE.ids.map(id => (ACTION100_TASKS || []).find(x => String(x.id) === String(id))).filter(Boolean); const q = provinceFold(document.getElementById("vpubDrillContentFilter")?.value || ""); if (q) rows = rows.filter(x => provinceFold([x.task_name, x.unit, x.field, x.leader, x.office_leader, x.weekly_result, x.difficulties, x.proposal, x.note, x.source, x.ubnd_source].join(" ")).includes(q)); const timeMode = document.getElementById("vpubDrillTimeFilter")?.value || ""; if (timeMode) rows = rows.filter(x => { const d = action100ParseDate(x.deadline); return d ? isDateInTimeRange(d, timeMode) : false; }); const agency = document.getElementById("vpubDrillAgencyFilter")?.value || ""; if (agency) rows = rows.filter(x => provinceFold(x.unit || "") === provinceFold(agency)); const status = document.getElementById("vpubDrillStatusFilter")?.value || "all"; if (status !== "all") rows = rows.filter(x => { const s = action100Status(x); if (status === "done") return ["early", "ontime", "latedone", "done"].includes(s); return s === status; }); renderVPUBDrill(rows, VPUB_DRILL_STATE.title, VPUB_DRILL_STATE.icon, false); }

function resetAction100Filters() {
    const s = document.getElementById('action100Search'); if (s) s.value = '';
    const f = document.getElementById('action100Status'); if (f) f.value = 'all';
    const t = document.getElementById('action100TimeFilter'); if (t) t.value = 'all';
    const a = document.getElementById('action100Agency'); if (a) a.value = 'all';
    document.querySelectorAll('#action100Workspace .bch-kpi').forEach(k => k.classList.remove('selected'));
    renderAction100Table();
}

function vpubToggleSourceGroup(id, btn) { return ttbtvToggleSourceGroup(id, btn); }

function syncAction100Head() {
    const tr = document.querySelector('#action100Workspace thead tr'); if (!tr) return;
    if (!tr.dataset.orig) tr.dataset.orig = tr.innerHTML;
    if (ACTION100_MODE === 'vpub') tr.innerHTML = '<th>STT</th><th>Nguồn giao</th><th>Nhiệm vụ</th><th>Cơ quan phụ trách</th><th>Cơ quan phối hợp</th><th>Lãnh đạo CQPT</th>';
    else if (tr.dataset.orig && tr.innerHTML !== tr.dataset.orig) tr.innerHTML = tr.dataset.orig;
}

function vpubSourceGroupsHtml(rows) {
    const groups = new Map();
    rows.forEach(x => { const key = String(x.source || '').trim() || 'Chưa có nguồn giao'; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(x); });
    const sortedGroups = [...groups.entries()].sort((a,b)=>{ const da=vpubDocDate(a[0]), db=vpubDocDate(b[0]); if(da&&db) return da-db; if(da&&!db) return -1; if(!da&&db) return 1; return String(a[0]).localeCompare(String(b[0]),'vi'); });
    let stt = 0;
    return sortedGroups.map(([source, items]) => {
        const gid = `vpub-source-${++stt}`;
        const units = [...new Set(items.map(x => x.unit).filter(Boolean))].join(', ') || '—';
        const fields = [...new Set(items.map(x => x.field).filter(Boolean))].join(', ') || '—';
        const leaders = [...new Set(items.map(x => x.office_leader || x.leader).filter(Boolean))].join(', ') || '—';
        let done = 0, proc = 0, over = 0, reg = 0, pla = 0;
        items.forEach(x => { const s = action100Status(x); if (['early', 'ontime', 'latedone'].includes(s)) done++; else if (s === 'overdue') over++; else if (s === 'regular') reg++; else if (s === 'planned') pla++; else proc++; });
        const summary = `<div class="ttbtv-status-summary">${[['done', 'Hoàn thành', done], ['processing', 'Đang triển khai', proc], ['overdue', 'NV đang xử lý', over], ['regular', 'Thường xuyên', reg], ['planned', 'Theo kế hoạch', pla]].filter(([, , n]) => n > 0).map(([cls, label, n]) => { const c = cls === 'overdue' ? 'vpub-overdue' : cls; return `<span class="${c}">${label} (${n})</span>`; }).join('')}</div>`;
        const detail = items.map((x, i) => {
            const s = action100Status(x); const badgeCls = s === 'overdue' ? 'vpub-overdue' : s;
            const taskName = x.task_name || 'Chưa nhập nhiệm vụ';
            const titleFull = `${i + 1}. ${taskName}`;
            const prod = x.product || x.weekly_result || x.result || 'Chưa có';
            return `<div class="ttbtv-source-task" onclick="openAction100TaskEdit(${x.id})"><div class="ttbtv-task-main"><div class="vpub-task-head"><span class="vpub-task-stt">${i + 1}.</span><b class="ttbtv-task-title task-tip" data-full="${esc(demoMaskText(titleFull))}">${esc(demoMaskText(taskName))}</b></div><span class="bch-badge ${badgeCls}">${esc(action100Label(s, true))}</span></div><div class="ttbtv-task-meta"><span>🏢 ${esc(x.unit || '—')}</span><span>🤝 ${esc(x.field || '—')}</span><span>👤 ${esc(demoMaskName(x.office_leader || x.leader) || '—')}</span><span>📅 Hạn: ${esc(x.deadline ? formatDate(x.deadline) : 'Chưa có')}</span><span>✅ HT: ${esc(x.completed_date ? formatDate(x.completed_date) : 'Chưa nhập')}</span><span>📦 ${esc(demoMaskText(prod))}</span></div></div>`;
        }).join('');
        return `<tr class="ttbtv-source-row" onclick="if(!event.target.closest('button'))vpubToggleSourceGroup('${gid}',this.querySelector('.ttbtv-source-toggle'))"><td class="c-stt">${stt}</td><td class="c-amount"><b>${esc(demoMaskText(source))}</b></td><td class="c-task"><button class="ttbtv-source-toggle" aria-label="Mở rộng" onclick="event.stopPropagation();vpubToggleSourceGroup('${gid}',this)"><svg class="ttbtv-icon-plus" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></button><b>${items.length} nhiệm vụ</b>${summary}</td><td class="c-officer">${esc(units)}</td><td class="c-title">${esc(fields)}</td><td>${esc(demoMaskText(leaders))}</td></tr><tr id="${gid}" class="ttbtv-source-detail" style="display:none"><td colspan="6"><div class="ttbtv-source-task-list">${detail}</div></td></tr>`;
    }).join('');
}

function vpubAddFormHtml() {
    return `<div><label>Cơ quan phụ trách</label><select id="vpubUnit" onchange="ttbtvHandleRoleOther(this)"><option value="">Chọn cơ quan phụ trách</option>${VPUB_AGENCY_LIST.map(o => `<option>${o}</option>`).join('')}<option value="__other__">Khác (nhập tên)</option></select></div><div><label>Lĩnh vực</label><input id="vpubField"></div><div class="wide"><label>Nội dung nhiệm vụ</label><textarea id="vpubTaskName"></textarea></div><div><label>Nguồn giao nhiệm vụ</label><select id="vpubSource" onchange="vpubHandleSourceOther(this)">${(() => { const list=getVPUBSourceList(); const opts=['<option value="">Chọn nguồn giao</option>'].concat(list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`)); opts.push('<option value="__other__">Khác (nhập văn bản)</option>'); return opts.join(''); })()}</select></div><div><label>Nguồn giao của UBND</label><input id="vpubUBNDSource" value="Chưa rõ"></div><div><label>Lãnh đạo xã phụ trách</label><select id="vpubLeader" onchange="ttbtvHandleRoleOther(this,'leader')"><option value="">Chọn lãnh đạo xã</option>${VPUB_XA_LEADER_LIST.map(o => `<option>${o}</option>`).join('')}<option value="__other__">Khác (nhập tên)</option></select></div><div><label>Lãnh đạo cơ quan phụ trách</label><select id="vpubOfficeLeader" onchange="ttbtvHandleRoleOther(this,'leader')"><option value="">Chọn lãnh đạo cơ quan</option>${VPUB_LEADER_LIST.map(o => `<option>${o}</option>`).join('')}<option value="__other__">Khác (nhập tên)</option></select></div><div><label>Ngày bắt đầu</label><input id="vpubStartDate" type="date"></div><div><label>Thời hạn</label><input id="vpubDeadline" type="date"></div><div class="wide"><label>Kết quả thực hiện tuần này</label><textarea id="vpubWeeklyResult"></textarea></div><div class="wide"><label>Khó khăn, vướng mắc</label><textarea id="vpubDifficulties"></textarea></div><div class="wide"><label>Đề xuất, kiến nghị</label><textarea id="vpubProposal"></textarea></div><div><label>Trạng thái</label><input id="vpubStatus" value="Đang triển khai" readonly></div><div><label>🔁 Thường xuyên (chỉ CV nhập liệu)</label><label style="display:flex;align-items:center;gap:8px;font-weight:600"><input type="checkbox" id="vpubAddRegular" style="width:auto" onchange="handleVPUBAddStatusCheckbox('regular')"> Thường xuyên</label></div><div><label>📅 Theo kế hoạch (chỉ CV nhập liệu)</label><label style="display:flex;align-items:center;gap:8px;font-weight:600"><input type="checkbox" id="vpubAddPlanned" style="width:auto" onchange="handleVPUBAddStatusCheckbox('planned')"> Theo kế hoạch</label></div><div class="wide"><label>Ghi chú</label><textarea id="vpubNote"></textarea></div>`;
}

function toggleAction100Custom(selectId, inputId) { const s = document.getElementById(selectId), i = document.getElementById(inputId); if (i) i.style.display = s?.value === '__custom__' ? '' : 'none'; }

function refreshAction100AddMeta() { const deadline = document.getElementById('action100Deadline')?.value, completed_date = document.getElementById('action100Completed')?.value, product = document.getElementById('action100Product')?.value, result = document.getElementById('action100Result')?.value, status = action100StatusFromValues({ deadline, completed_date, product, result }); const s = document.getElementById('action100StatusField'); if (s) s.value = action100Label(status); const r = document.getElementById('action100Remaining'); if (r) { const due = action100ParseDate(deadline); r.value = ['early', 'ontime', 'latedone'].includes(status) ? '\u0110\u00e3 ho\u00e0n th\u00e0nh' : (due ? `${Math.ceil((due.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ng\u00e0y` : '-'); } }

function prepareAction100AddTask() {
    if (PENDING_ACTION100_ADD_TASK) return showToast("error", "Đang xử lý", "Một nhiệm vụ đang được thêm, vui lòng chờ hoàn tất."); if (ACTION100_MODE === 'vpub') {
        const isCV = CURRENT_USER?.scope === 'data_entry';
        let statusVal = document.getElementById('vpubStatus')?.value || 'Đang triển khai';
        if (isCV) {
            if (document.getElementById('vpubAddRegular')?.checked) statusVal = 'Thường xuyên';
            else if (document.getElementById('vpubAddPlanned')?.checked) statusVal = 'Theo kế hoạch';
        }
        const p = { unit: document.getElementById('vpubUnit')?.value || '', field: document.getElementById('vpubField')?.value.trim() || '', task_name: document.getElementById('vpubTaskName')?.value.trim() || '', source: document.getElementById('vpubSource')?.value.trim() || '', ubndSource: document.getElementById('vpubUBNDSource')?.value.trim() || 'Chưa rõ', leader: document.getElementById('vpubLeader')?.value.trim() || '', office_leader: document.getElementById('vpubOfficeLeader')?.value.trim() || '', start_date: document.getElementById('vpubStartDate')?.value || null, deadline: document.getElementById('vpubDeadline')?.value || '', weekly_result: document.getElementById('vpubWeeklyResult')?.value.trim() || '', difficulties: document.getElementById('vpubDifficulties')?.value.trim() || '', proposal: document.getElementById('vpubProposal')?.value.trim() || '', status: statusVal, note: document.getElementById('vpubNote')?.value.trim() || '' };
        if (!p.unit || !p.task_name || !p.deadline) return showToast('error', 'Thiếu thông tin', 'Vui lòng nhập Cơ quan phụ trách, Nội dung nhiệm vụ và Thời hạn.');
        PENDING_ACTION100_ADD_TASK = p; const s = document.getElementById('action100AddConfirmSummary'); if (s) s.innerHTML = `<div><b>Cơ quan phụ trách:</b> ${esc(p.unit)}</div><div><b>Lĩnh vực:</b> ${esc(p.field || '-')}</div><div><b>Nội dung nhiệm vụ:</b> ${esc(p.task_name)}</div><div><b>Nguồn giao nhiệm vụ:</b> ${esc(p.source || '-')}</div><div><b>Nguồn giao của UBND:</b> ${esc(p.ubndSource || '-')}</div><div><b>Lãnh đạo xã phụ trách:</b> ${esc(p.leader || '-')}</div><div><b>Lãnh đạo cơ quan phụ trách:</b> ${esc(p.office_leader || '-')}</div><div><b>Ngày bắt đầu:</b> ${p.start_date ? formatDate(p.start_date) : '-'}</div><div><b>Thời hạn:</b> ${formatDate(p.deadline)}</div><div><b>Kết quả thực hiện tuần này:</b> ${esc(p.weekly_result || '-')}</div><div><b>Khó khăn, vướng mắc:</b> ${esc(p.difficulties || '-')}</div><div><b>Đề xuất, kiến nghị:</b> ${esc(p.proposal || '-')}</div><div><b>Trạng thái:</b> ${esc(p.status)}</div><div><b>Ghi chú:</b> ${esc(p.note || '-')}</div>`; const confirmTitle = document.querySelector('#action100AddConfirmModal .drill-head h3'); if (confirmTitle) confirmTitle.textContent = 'Xác nhận thêm nhiệm vụ VPUB'; smoothOpenModal('action100AddConfirmModal'); return;
    }
    const officer_name = document.getElementById('action100Officer')?.value.trim() || '';
    const task_name = document.getElementById('action100TaskName')?.value.trim() || '';
    const commune_leader = document.getElementById('action100CommuneLeader')?.value.trim() || '';
    const office_leader = document.getElementById('action100OfficeLeader')?.value.trim() || '';
    const coord_agency = document.getElementById('action100CoordAgency')?.value.trim() || '';
    const xa_leader = document.getElementById('action100XaLeader')?.value.trim() || '';
    const deadline = document.getElementById('action100Deadline')?.value || '';
    const completed_date = document.getElementById('action100Completed')?.value || null;
    const product = document.getElementById('action100Product')?.value.trim() || '';
    const result = document.getElementById('action100Result')?.value.trim() || '';
    const admin_note = document.getElementById('action100AdminNote')?.value.trim() || '';
    if (!task_name) return showToast('error', 'Thi\u1ebfu th\u00f4ng tin', 'Vui l\u00f2ng nh\u1eadp t\u00ean nhi\u1ec7m v\u1ee5.');
    if (!deadline) return showToast('error', 'Thi\u1ebfu th\u00f4ng tin', 'H\u1ea1n ho\u00e0n th\u00e0nh l\u00e0 b\u1eaft bu\u1ed9c.');
    PENDING_ACTION100_ADD_TASK = { officer_name, task_name, commune_leader, office_leader, unit_name: coord_agency, deadline, completed_date, product, result, admin_note };
    const s = document.getElementById('action100AddConfirmSummary');
    const confirmTitle = document.querySelector('#action100AddConfirmModal .drill-head h3'); if (confirmTitle) confirmTitle.textContent = ACTION100_MODE === 'vpub' ? 'Xác nhận thêm nhiệm vụ VPUB' : 'Xác nhận thêm nhiệm vụ KH 100 ngày';
    if (s) s.innerHTML = `<div><b>Chuyên viên:</b> ${esc(officer_name || '-')}</div><div><b>Nhiệm vụ:</b> ${esc(task_name)}</div><div><b>Cơ quan phụ trách:</b> ${esc(commune_leader || '-')}</div><div><b>Lãnh đạo xã phụ trách:</b> ${esc(xa_leader || '-')}</div><div><b>Lãnh đạo cơ quan:</b> ${esc(office_leader || '-')}</div><div><b>Cơ quan phối hợp:</b> ${esc(coord_agency || '-')}</div><div><b>Hạn hoàn thành:</b> ${formatDate(deadline)}</div><div><b>Ng&#224;y ho&#224;n th&#224;nh:</b> ${completed_date ? formatDate(completed_date) : 'Ch&#432;a nh&#7853;p'}</div><div><b>Tr&#7841;ng th&#225;i:</b> ${esc(action100Label(action100Status(PENDING_ACTION100_ADD_TASK)))}</div><div><b>S&#7843;n ph&#7849;m:</b> ${esc(product || '-')}</div><div><b>K&#7871;t qu&#7843;:</b> ${esc(result || '-')}</div><div><b>Ghi ch&#250; ADMIN:</b> ${esc(admin_note || '-')}</div>`;
    smoothOpenModal('action100AddConfirmModal');
}

function cancelAction100AddTask() { PENDING_ACTION100_ADD_TASK = null; smoothCloseModal('action100AddConfirmModal'); }

async function confirmAction100AddTask() {
    const p = PENDING_ACTION100_ADD_TASK; if (!p) return;
    if (ACTION100_MODE === 'vpub') {
        const start = p.start_date ? dateToDb(p.start_date) : null, deadline = dateToDb(p.deadline);
        if (!deadline) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Thời hạn theo dạng dd/mm/yyyy.');
        if (p.start_date && !start) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Ngày bắt đầu theo dạng dd/mm/yyyy.');
        p.start_date = start; p.deadline = deadline;
    } else {
        const d = dateToDb(p.deadline), c = p.completed_date ? dateToDb(p.completed_date) : null;
        if (!d) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Hạn hoàn thành theo dạng dd/mm/yyyy hoặc yyyy-mm-dd.');
        if (p.completed_date && !c) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Ngày hoàn thành theo dạng dd/mm/yyyy hoặc yyyy-mm-dd.');
        p.deadline = d; p.completed_date = c;
    }
    const btn = document.getElementById('action100ConfirmAddBtn'); const oldText = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = '\u0110ang th\u00eam...'; }
    try {
        const body = ACTION100_MODE === 'vpub' ? { unit: p.unit, field: p.field, task_name: p.task_name, source: p.source, ubnd_source: p.ubndSource, leader: p.leader, office_leader: p.office_leader, start_date: p.start_date, deadline: p.deadline, weekly_result: p.weekly_result, difficulties: p.difficulties, proposal: p.proposal, status: p.status, note: p.note } : { officer_name: p.officer_name, task_name: p.task_name, deadline: p.deadline, completed_date: p.completed_date, commune_leader: p.commune_leader, office_leader: p.office_leader, unit_name: p.unit_name || '', role: p.office_leader, specialist_name: p.officer_name, product: p.product, result: p.result, staff_note: p.result, admin_note: p.admin_note, updated_at: new Date().toISOString() };
        const r = await fetch(ACTION100_TASKS_API.split('?')[0], { method: 'POST', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(body) });
        if (!r.ok) return showToast('error', 'Kh\u00f4ng th\u1ec3 l\u01b0u', await r.text());
        writeActivity(ACTION100_MODE === 'vpub' ? 'Thêm nhiệm vụ VPUB' : 'Thêm nhiệm vụ KH 100 ngày', { task: p.task_name, id: p.id || '' });
        cancelAction100AddTask();
        if (ACTION100_MODE === 'vpub') { const g = document.getElementById('vpubAddFormGrid'); if (g) g.innerHTML = ''; smoothCloseModal('vpubAddTaskModal'); }
        ['action100TaskName', 'action100CommuneLeader', 'action100XaLeader', 'action100OfficeLeader', 'action100CoordAgency', 'action100Deadline', 'action100Completed', 'action100Product', 'action100Result', 'action100AdminNote'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
        const officer = document.getElementById('action100Officer'); if (officer) officer.value = '';
        refreshAction100AddMeta(); await loadAction100Data(true); showToast('success', '\u0110\u00e3 th\u00eam nhi\u1ec7m v\u1ee5');
    } catch (e) { console.error(e); showToast('error', 'Kh\u00f4ng th\u1ec3 th\u00eam', e.message || 'L\u1ed7i kh\u00f4ng x\u00e1c \u0111\u1ecbnh'); }
    finally { if (btn) { btn.disabled = false; btn.textContent = oldText || 'X\u00e1c nh\u1eadn th\u00eam'; } PENDING_ACTION100_ADD_TASK = null; }
}

function openAction100TaskEdit(id) {
    const x = ACTION100_TASKS.find(r => String(r.id) === String(id)); if (!x) return;
    setupVPUBDateFields();
    if (!canEditAction100Task(x)) return showToast('error', 'Không có quyền sửa', 'Bạn chỉ được sửa nhiệm vụ có tên của mình.');
    window.ACTION100_EDIT_ID = x.id;
    document.getElementById('action100EditOfficer').value = x.officer_name || '';
    document.getElementById('action100EditTask').value = x.task_name || ''; 
    if (ACTION100_MODE === 'vpub') {
        document.getElementById('action100EditCommuneLeader').value = x.unit || '';
        document.getElementById('action100EditOfficeLeader').value = x.office_leader || '';
        const coordEl = document.getElementById('action100EditCoordAgency'); if (coordEl) { fillSelect(coordEl, VPUB_AGENCY_LIST, x.field || ''); coordEl.onchange = () => ttbtvHandleRoleOther(coordEl); }
        const xaEl0 = document.getElementById('action100EditXaLeader');
        if (xaEl0) {
            let xaSel = xaEl0;
            if (xaSel.tagName !== 'SELECT') { const s2 = document.createElement('select'); s2.id = 'action100EditXaLeader'; xaSel.replaceWith(s2); xaSel = s2; }
            xaSel.innerHTML = '<option value="">Chọn lãnh đạo xã</option>' + VPUB_XA_LEADER_LIST.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('') + '<option value="__other__">Khác (nhập tên)</option>';
            if (x.leader) {
                if (![...xaSel.options].some(o => o.value === x.leader)) { const opt = document.createElement('option'); opt.value = x.leader; opt.textContent = x.leader; xaSel.insertBefore(opt, xaSel.querySelector('option[value="__other__"]')); }
                xaSel.value = x.leader;
            }
            xaSel.dataset.prev = x.leader || '';
            xaSel.onchange = function () { ttbtvHandleRoleOther(xaSel, 'leader'); };
        }
        const srcEl = document.getElementById('action100EditSource'); if (srcEl) { if (ACTION100_MODE==='vpub' && srcEl.tagName==='SELECT') populateVPUBSourceSelect(srcEl, x.source||''); else srcEl.value = x.source || ''; }
        const usrcEl = document.getElementById('action100EditUBNDSource'); if (usrcEl) usrcEl.value = x.ubnd_source || 'Chưa rõ';
    } else {
        document.getElementById('action100EditCommuneLeader').value = x.commune_leader || ''; document.getElementById('action100EditOfficeLeader').value = x.office_leader || ''; const coordEl = document.getElementById('action100EditCoordAgency'); if (coordEl) { fillSelect(coordEl, [...new Set(ACTION100_TASKS.map(t => t.unit_name).filter(Boolean))], x.unit_name || ''); coordEl.onchange = () => ttbtvHandleRoleOther(coordEl); }
    }
    const cqEl = document.getElementById('action100EditCommuneLeader');
    const srcRow = document.getElementById('action100EditSource')?.closest('div');
    const usrcRow = document.getElementById('action100EditUBNDSource')?.closest('div');
    [srcRow, usrcRow].forEach(el => { if (el) el.style.display = ACTION100_MODE === 'vpub' ? '' : 'none'; });
    const ldEl = document.getElementById('action100EditOfficeLeader');
    if (cqEl) { cqEl.innerHTML = ''; cqEl.onchange = () => ttbtvHandleRoleOther(cqEl); }
    if (ldEl) { ldEl.innerHTML = ''; ldEl.onchange = () => ttbtvHandleRoleOther(ldEl, "leader"); }
    if (ACTION100_MODE === 'vpub') {
        fillSelect(cqEl, VPUB_AGENCY_LIST, x.unit || '');
        fillSelect(ldEl, VPUB_LEADER_LIST, x.office_leader || '');
    } else {
        fillSelect(cqEl, [...new Set(ACTION100_TASKS.map(t => t.commune_leader).filter(Boolean))], x.commune_leader || '');
        fillSelect(ldEl, [...new Set(ACTION100_TASKS.map(t => t.office_leader).filter(Boolean))], x.office_leader || '');
    }
    document.getElementById('action100EditDue').value = x.deadline ? formatDate(x.deadline) : ''; document.getElementById('action100EditCompleted').value = x.completed_date ? formatDate(x.completed_date) : ''; document.getElementById('action100EditProduct').value = x.product || '';
    document.getElementById('action100EditResult').value = ACTION100_MODE === 'vpub' ? (x.weekly_result || '') : (x.staff_note || x.result || ''); document.getElementById('action100EditAdminNote').value = x.admin_note || '';
    const isAdmin100 = CURRENT_USER?.role === 'admin';
    const full100 = isAdmin100 || CURRENT_USER?.scope === 'data_entry';
    // CV nhập liệu: khóa Nội dung nhiệm vụ + Hạn hoàn thành (chỉ Admin).
    ['action100EditOfficer', 'action100EditCommuneLeader', 'action100EditOfficeLeader', 'action100EditXaLeader', 'action100EditCoordAgency'].forEach(id => { const e = document.getElementById(id); if (e) { e.readOnly = !full100; e.disabled = !full100; e.style.opacity = full100 ? '' : '0.6'; } });
    // Chỉ Admin được sửa Nội dung nhiệm vụ (toàn hệ thống)
    ['action100EditTask', 'action100EditDue'].forEach(id => { const e = document.getElementById(id); const allowed = isAdmin100; if (e) { e.readOnly = !allowed; e.disabled = !allowed; e.style.opacity = allowed ? '' : '0.6'; e.title = allowed ? "" : "Chỉ Admin được sửa Nội dung nhiệm vụ / Hạn."; } });
    const an100 = document.getElementById('action100EditAdminNote'); if (an100) { an100.readOnly = !isAdmin100; an100.disabled = !isAdmin100; an100.style.opacity = isAdmin100 ? '' : '0.6'; }
    const isCVToken = CURRENT_USER?.scope === 'data_entry';
    const reg100 = document.getElementById('action100EditRegular');
    if (reg100) {
        reg100.checked = String(x.status || '').trim() === 'Thường xuyên';
        reg100.disabled = !isCVToken;
        reg100.title = isCVToken ? '' : 'Chỉ CV nhập liệu được tick';
        const regRow = reg100.closest('div'); if (regRow) { regRow.style.display = ACTION100_MODE === 'vpub' ? '' : 'none'; regRow.style.opacity = isCVToken ? '' : '0.6'; }
    }
    const plan100 = document.getElementById('action100EditPlanned');
    if (plan100) {
        plan100.checked = String(x.status || '').trim() === 'Theo kế hoạch';
        plan100.disabled = !isCVToken;
        plan100.title = isCVToken ? '' : 'Chỉ CV nhập liệu được tick';
        const planRow = plan100.closest('div'); if (planRow) { planRow.style.display = ACTION100_MODE === 'vpub' ? '' : 'none'; planRow.style.opacity = isCVToken ? '' : '0.6'; }
    }
    refreshAction100EditMeta();
    document.getElementById('action100EditSubtitle').textContent = `Nhi\u1ec7m v\u1ee5 #${x.id} - Tr\u1ea1ng th\u00e1i: ${action100Label(action100Status(x))}`;
    smoothOpenModal('action100EditModal');
    focusFirstEditable('action100EditModal');
}

function deleteAction100Task() {
    const id = window.ACTION100_EDIT_ID, task = ACTION100_TASKS.find(x => String(x.id) === String(id));
    if (!task) return;
    const wsId = ACTION100_MODE === 'vpub' ? 'vpub' : 'action100';
    if (CURRENT_USER.scope === 'action100' && !userCan(CURRENT_USER, 'delete', wsId)) return showToast('error', 'Không có quyền xóa', 'Bạn chỉ được cập nhật nhiệm vụ của mình.');
    if (CURRENT_USER.scope === 'data_entry' && !(ACTION100_MODE === 'vpub' && CURRENT_USER.scope === 'data_entry')) return showToast('error', 'Không có quyền xóa', 'Bạn chỉ được cập nhật nhiệm vụ.');
    if (!canEditAction100Task(task)) return showToast('error', 'Không có quyền xóa', 'Bạn chỉ được xóa nhiệm vụ có tên của mình.');
    openDeleteTaskConfirm({
        label: `Xóa nhiệm vụ "${task.task_name || 'Nhiệm vụ'}"?`,
        summary: `<div class="confirm-row"><span>Nhiệm vụ</span><strong>${esc(task.task_name || '')}</strong></div><div class="confirm-row"><span>Chuyên viên</span><strong>${esc(task.officer_name || '')}</strong></div>`,
        hasFile: false,
        onConfirm: async () => {
            try {
                const response = await fetch(`${ACTION100_TASKS_API.split('?')[0]}?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (!response.ok && response.status !== 404) throw new Error(await response.text());
                closeAction100TaskEdit(); await loadAction100Data(true); writeActivity(ACTION100_MODE === 'vpub' ? 'Xóa nhiệm vụ VPUB' : 'Xóa nhiệm vụ KH 100 ngày', { task: task.task_name || '', officer_name: task.officer_name || '', id }); showToast('success', 'Đã xóa nhiệm vụ');
            } catch (error) { showToast('error', 'Không thể xóa nhiệm vụ', error.message || 'Vui lòng thử lại.'); }
        }
    });
}

function closeAction100TaskEdit() { smoothCloseModal('action100EditModal'); window.ACTION100_EDIT_ID = null; }

async function saveAction100TaskEdit() {
    const id = window.ACTION100_EDIT_ID; if (!id) return;
    const current = ACTION100_TASKS.find(x => String(x.id) === String(id));
    if (!canEditAction100Task(current)) return showToast('error', 'Không có quyền sửa', 'Bạn chỉ được sửa nhiệm vụ có tên của mình.');
    const officer_name = document.getElementById('action100EditOfficer').value.trim(); const coordAgency = document.getElementById('action100EditCoordAgency')?.value.trim() || ''; let patch;
    if (ACTION100_MODE === 'vpub') {
        const vpubXaLeader = document.getElementById('action100EditXaLeader')?.value.trim() || '';
        const vpubOfficeLeader = document.getElementById('action100EditOfficeLeader')?.value.trim() || '';
        const dueRaw = document.getElementById('action100EditDue').value.trim(), completedRaw = document.getElementById('action100EditCompleted').value.trim(), due = dateToDb(dueRaw), completed = completedRaw ? dateToDb(completedRaw) : null;
        if (!due) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Hạn hoàn thành theo dạng dd/mm/yyyy.');
        if (completedRaw && !completed) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Ngày hoàn thành theo dạng dd/mm/yyyy.');
        patch = { officer_name, task_name: document.getElementById('action100EditTask').value.trim(), unit: document.getElementById('action100EditCommuneLeader').value.trim() || '', field: coordAgency, leader: vpubXaLeader, office_leader: vpubOfficeLeader, source: document.getElementById('action100EditSource')?.value.trim() || '', ubnd_source: document.getElementById('action100EditUBNDSource')?.value.trim() || 'Chưa rõ', deadline: due, completed_date: completed, product: document.getElementById('action100EditProduct').value.trim(), result: document.getElementById('action100EditResult').value.trim(), staff_note: document.getElementById('action100EditResult').value.trim(), weekly_result: document.getElementById('action100EditResult').value.trim(), admin_note: document.getElementById('action100EditAdminNote').value.trim(), note: document.getElementById('action100EditAdminNote').value.trim(), updated_at: new Date().toISOString() };
        if (CURRENT_USER?.scope === 'data_entry') {
            if (document.getElementById('action100EditRegular')?.checked) patch.status = 'Thường xuyên';
            else if (document.getElementById('action100EditPlanned')?.checked) patch.status = 'Theo kế hoạch';
            else if (['Thường xuyên','Theo kế hoạch'].includes(String(current?.status || '').trim())) patch.status = 'Đang triển khai';
            else patch.status = current?.status || 'Đang triển khai';
        } else {
            patch.status = current?.status || 'Đang triển khai';
        }
    } else {
        const dueRaw2 = document.getElementById('action100EditDue').value.trim(), completedRaw2 = document.getElementById('action100EditCompleted').value.trim();
        const due2 = dueRaw2 ? dateToDb(dueRaw2) : null, completed2 = completedRaw2 ? dateToDb(completedRaw2) : null;
        if (dueRaw2 && !due2) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Hạn hoàn thành theo dạng dd/mm/yyyy hoặc yyyy-mm-dd.');
        if (completedRaw2 && !completed2) return showToast('error', 'Ngày không hợp lệ', 'Vui lòng nhập Ngày hoàn thành theo dạng dd/mm/yyyy hoặc yyyy-mm-dd.');
        patch = { officer_name, task_name: document.getElementById('action100EditTask').value.trim(), commune_leader: document.getElementById('action100EditCommuneLeader').value.trim(), office_leader: document.getElementById('action100EditOfficeLeader').value.trim(), unit_name: coordAgency, role: document.getElementById('action100EditOfficeLeader').value.trim(), specialist_name: officer_name, deadline: due2, completed_date: completed2, product: document.getElementById('action100EditProduct').value.trim(), result: document.getElementById('action100EditResult').value.trim(), staff_note: document.getElementById('action100EditResult').value.trim(), admin_note: document.getElementById('action100EditAdminNote').value.trim(), updated_at: new Date().toISOString() };
    }
    // Chỉ Admin được sửa Nội dung + Hạn hoàn thành (toàn hệ thống)
    if (CURRENT_USER?.role !== 'admin' && patch.task_name !== String(current?.task_name||"").trim()) {
        showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ.");
        patch.task_name = current?.task_name || "";
        const _t100 = document.getElementById('action100EditTask'); if (_t100) _t100.value = patch.task_name;
    }
    if (CURRENT_USER?.role !== 'admin' && String(patch.deadline||"").trim() !== String(current?.deadline||"").trim()) {
        showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành.");
        patch.deadline = current?.deadline || null;
        const _d100 = document.getElementById('action100EditDue'); if (_d100) _d100.value = current?.deadline ? formatDate(current.deadline) : "";
    }
    // CV nhập liệu: giữ nguyên Nội dung + Hạn cũ (chỉ Admin được đổi).
    if (CURRENT_USER?.scope === 'data_entry' && current && !(ACTION100_MODE === 'vpub' && CURRENT_USER?.scope === 'data_entry')) { patch.task_name = current.task_name || ''; patch.deadline = current.deadline || null; }
    if (!patch.task_name || !patch.deadline) return showToast('error', 'Thi\u1ebfu th\u00f4ng tin', 'Nhi\u1ec7m v\u1ee5 v\u00e0 h\u1ea1n ho\u00e0n th\u00e0nh l\u00e0 b\u1eaft bu\u1ed9c.');
    const r = await fetch(`${ACTION100_TASKS_API.split('?')[0]}?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(patch) });
    if (!r.ok) return showToast('error', 'Kh\u00f4ng th\u1ec3 l\u01b0u', await r.text());
    closeAction100TaskEdit(); await loadAction100Data(true); writeActivity(ACTION100_MODE === 'vpub' ? 'Sửa nhiệm vụ VPUB' : 'Sửa nhiệm vụ KH 100 ngày', { task: patch.task_name, officer_name, id }); showToast('success', '\u0110\u00e3 c\u1eadp nh\u1eadt nhi\u1ec7m v\u1ee5');
}

function refreshAction100EditMeta() { const deadline = document.getElementById('action100EditDue')?.value, completed_date = document.getElementById('action100EditCompleted')?.value, product = document.getElementById('action100EditProduct')?.value, result = document.getElementById('action100EditResult')?.value; let status;
    if (ACTION100_MODE === 'vpub' && document.getElementById('action100EditRegular')?.checked) status = 'regular';
    else if (ACTION100_MODE === 'vpub' && document.getElementById('action100EditPlanned')?.checked) status = 'planned';
    else status = action100StatusFromValues({ deadline, completed_date, product, result });
    const s = document.getElementById('action100EditStatus'); if (s) s.value = action100Label(status); const r = document.getElementById('action100EditRemaining'); if (r) { const due = action100ParseDate(deadline); const isSpecial = status === 'regular' || status === 'planned'; r.value = isSpecial ? '-' : (['early', 'ontime', 'latedone'].includes(status) ? '\u0110\u00e3 ho\u00e0n th\u00e0nh' : (due ? `${Math.ceil((due.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ng\u00e0y` : '-')); } }

function openVPUBWorkspace(el) {
    if (CURRENT_USER?.role === 'department' && !['vpub','action100'].includes(CURRENT_USER.scope)) return showToast('error', 'Không có quyền', 'Token này chỉ được xem KH hành động 100 ngày.');
    ACTION100_MODE = 'vpub'; ACTION100_TASKS_API = `${SUPABASE_URL}/rest/v1/vpub_tasks?select=*&order=id.asc`;
    ['officeWorkspace', 'bchWorkspace', 'ttbtvWorkspace', 'provinceWorkspace', 'mttqKpiWorkspace', 'nqWorkspace'].forEach(id => document.getElementById(id)?.classList.remove('open'));
    const ws = document.getElementById('action100Workspace'); if (!ws) return; ws.classList.add('open');
    document.querySelectorAll('.sidebar-item').forEach(x => x.classList.remove('active')); (el || document.getElementById('vpubSidebarItem'))?.classList.add('active'); syncAction100OverdueLabel(); loadAction100Data(false); syncVPUBQuickAddBtn();
    try{ localStorage.setItem("vp_last_ws","action100Workspace"); localStorage.setItem("vp_last_ws_mode","vpub"); }catch(e){}
}

function openVPUBAddTaskPanel() {
    if (!canAddVPUBTask()) return;
    openVPUBWorkspace();
    setTimeout(() => {
        try {
            const grid = document.getElementById('vpubAddFormGrid');
            if (grid) grid.innerHTML = vpubAddFormHtml();
            setupVPUBDateFields();
            try { const s=document.getElementById('vpubSource'); if(s) populateVPUBSourceSelect(s, ""); } catch(e) {}
            const isCV = CURRENT_USER?.scope === 'data_entry';
            ['vpubAddRegular','vpubAddPlanned'].forEach(id=>{const el=document.getElementById(id); if(el){el.disabled=!isCV; el.title=isCV?'':'Chỉ CV nhập liệu được tick'; const lab=el.closest('div'); if(lab) lab.style.opacity=isCV?'':'0.6';}});
            smoothOpenModal('vpubAddTaskModal');
            document.getElementById('vpubUnit')?.focus({ preventScroll: true });
        } catch (e) {}
    }, 150);
}

function handleVPUBAddStatusCheckbox(which){
    const r=document.getElementById('vpubAddRegular'), p=document.getElementById('vpubAddPlanned'), s=document.getElementById('vpubStatus');
    if(!r||!p) return;
    if(which==='regular'&&r.checked) p.checked=false;
    if(which==='planned'&&p.checked) r.checked=false;
    if(s){
        if(r.checked) s.value='Thường xuyên';
        else if(p.checked) s.value='Theo kế hoạch';
        else s.value='Đang triển khai';
    }
}

function handleVPUBStatusCheckbox(which){
    const r=document.getElementById('action100EditRegular'), p=document.getElementById('action100EditPlanned');
    if(!r||!p) return;
    if(which==='regular'&&r.checked) p.checked=false;
    if(which==='planned'&&p.checked) r.checked=false;
    refreshAction100EditMeta();
}

function closeVPUBAddTaskModal() { try { if (typeof ppCloseCal === 'function') ppCloseCal(); } catch (e) {} smoothCloseModal('vpubAddTaskModal'); }

function officeAddFormHtml() {
    if (!CURRENT_USER) return '';
    const isAdmin = CURRENT_USER.role === "admin";
    const canToggleRegular = isAdmin || CURRENT_USER.scope === "office";
    const officerControl = isAdmin
        ? `<select id="officeAddOfficer"><option value="">Chọn cán bộ...</option>${addOfficerOptions()}</select>`
        : `<input id="officeAddOfficer" value="${esc(CURRENT_USER.name)}" readonly>`;
    const adminNoteControl = isAdmin
        ? `<textarea id="officeAddNote" placeholder="Ghi chú của Admin (nếu có)"></textarea>`
        : `<textarea id="officeAddNote" readonly placeholder="Chỉ Admin được nhập ghi chú"></textarea>`;
    const staffNoteControl = isAdmin
        ? `<textarea id="officeAddStaffNote" readonly placeholder="Cán bộ phụ trách sẽ bổ sung sau"></textarea>`
        : `<textarea id="officeAddStaffNote" placeholder="Ghi chú bổ sung của bạn (nếu có)"></textarea>`;
    return `<div><label>Cán bộ</label>${officerControl}</div>`
        + `<div class="wide"><label>Nhiệm vụ <span style="color:#dc2626">*</span></label><textarea id="officeAddTaskName" placeholder="Nhập nội dung nhiệm vụ..."></textarea></div>`
        + `<div><label>Vai trò <span style="color:#dc2626">*</span></label><select id="officeAddRole" onchange="handleOfficeRoleOther(this)">${officeRoleOptionsHtml("")}</select><input id="officeAddRoleOther" type="text" placeholder="Nhập vai trò khác" style="display:none;margin-top:6px"></div>`
        + `<div><label>Hạn hoàn thành <span style="color:#dc2626">*</span></label><input id="officeAddDeadline" type="date" data-ds-date="1" class="date-ddmmyyyy" lang="vi" placeholder="dd/mm/yyyy" oninput="dateMask(this);officeUpdateAddStatus()"></div>`
        + `<div><label>Ngày hoàn thành</label><input id="officeAddCompletedDate" type="date" data-ds-date="1" class="date-ddmmyyyy" lang="vi" placeholder="dd/mm/yyyy" oninput="dateMask(this);officeUpdateAddStatus()"></div>`
        + `<div><label>Trạng thái <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="officeAddStatus" class="auto-status-field" type="text" readonly value="Đang triển khai" title="Hệ thống tự tính trạng thái"></div>`
        + `<div class="wide"><label>Sản phẩm / kết quả</label><textarea id="officeAddProduct" oninput="officeUpdateAddStatus()" placeholder="Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp..."></textarea></div>`
        + `<div><label>Tệp sản phẩm</label><input id="officeAddAttachment" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx" onchange="officeUpdateAddStatus()"></div>`
        + `<div><label>Phát sinh</label><div class="add-arising-wrap"><input id="officeAddArising" type="checkbox"><span>Ngoài kế hoạch</span></div></div>`
        + `<div><label class="regular-toggle" title="${canToggleRegular ? "Bật để giữ nhiệm vụ sang tháng sau" : "Chỉ Admin và token Văn phòng được gán Thường xuyên"}"><span class="regular-icon">🔁</span><span class="regular-toggle-desc"><b>Thường xuyên</b><small>giữ sang tháng sau</small></span><input type="checkbox" id="officeAddRegular" onchange="refreshOfficeAddRegular()" ${canToggleRegular ? "" : "disabled"}><span class="regular-switch-ui"></span></label></div>`
        + `<div class="wide"><label>👤 Ghi chú cán bộ</label>${staffNoteControl}</div>`
        + `<div class="wide"><label>📝 Ghi chú Admin</label>${adminNoteControl}</div>`;
}

function officeUpdateAddStatus() {
    const el = document.getElementById("officeAddCompletedDate"); if (!el) return;
    const due = document.getElementById("officeAddDeadline")?.value || "";
    const completed = el.value || "";
    const product = document.getElementById("officeAddProduct")?.value || "";
    const file = document.getElementById("officeAddAttachment")?.files?.[0] || null;
    const out = document.getElementById("officeAddStatus");
    if (out) out.value = calculateTaskStatus({}, { _regular: !!document.getElementById("officeAddRegular")?.checked, due, completed_date: completed, product, hasFile: !!file });
}

function refreshOfficeAddRegular() { officeUpdateAddStatus(); }

function openOfficeAddTaskPanel() {
    if (!canAccessOfficeData(CURRENT_USER)) return showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản Văn phòng được thêm nhiệm vụ.");
    openOfficeWorkspace();
    setTimeout(() => {
        try {
            const grid = document.getElementById("officeAddFormGrid");
            if (grid) grid.innerHTML = officeAddFormHtml();
            officeUpdateAddStatus();
            smoothOpenModal("officeAddTaskModal");
            document.getElementById("officeAddTaskName")?.focus({ preventScroll: true });
        } catch (e) { console.warn(e); }
    }, 150);
}

function closeOfficeAddTaskModal() { try { if (typeof ppCloseCal === 'function') ppCloseCal(); } catch (e) {} smoothCloseModal("officeAddTaskModal"); }

function prepareOfficeAddTask() {
    if (!CURRENT_USER) return;
    if (!canAccessOfficeData(CURRENT_USER)) return showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản Văn phòng được thêm nhiệm vụ.");
    const officer = CURRENT_USER.role === "admin" ? (document.getElementById("officeAddOfficer")?.value || "").trim() : CURRENT_USER.name;
    const taskName = (document.getElementById("officeAddTaskName")?.value || "").trim();
    const _rawRoleOffice = (function(){ try{ return getOfficeRoleValue("officeAddRole"); }catch(e){ return (document.getElementById("officeAddRole")?.value||"").trim(); }})();
    const role = officeRoleCanonical(_rawRoleOffice) || _rawRoleOffice;
    const isOfficeRegular = !!document.getElementById("officeAddRegular")?.checked;
    let deadline = null, completedDate = null;
    try {
        const dlRaw = (document.getElementById("officeAddDeadline")?.value || "").trim();
        if (isOfficeRegular) deadline = dlRaw ? requireValidDate(dlRaw, "Hạn hoàn thành", false) : null;
        else deadline = requireValidDate(dlRaw, "Hạn hoàn thành", true);
        const cr = (document.getElementById("officeAddCompletedDate")?.value || "").trim();
        completedDate = cr ? requireValidDate(cr, "Ngày hoàn thành", false) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    const product = (document.getElementById("officeAddProduct")?.value || "").trim() || "Không";
    const note = CURRENT_USER.role === "admin" ? (document.getElementById("officeAddNote")?.value || "").trim() : "";
    const staffNote = CURRENT_USER.role === "staff" ? (document.getElementById("officeAddStaffNote")?.value || "").trim() : "";
    const isArising = !!document.getElementById("officeAddArising")?.checked;
    const file = document.getElementById("officeAddAttachment")?.files?.[0] || null;
    const status = calculateTaskStatus({}, { _regular: isOfficeRegular, due: deadline, completed_date: completedDate, product, hasFile: !!file });
    if (!officer) return showToast("error", "Thiếu cán bộ", "Vui lòng chọn cán bộ phụ trách.");
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); document.getElementById("officeAddTaskName")?.focus(); return; }
    if (taskName.length < 2) { showToast("error", "Nhiệm vụ quá ngắn", "Vui lòng nhập ít nhất 2 ký tự (ví dụ: AB)."); document.getElementById("officeAddTaskName")?.focus(); return; }
    if (!role) { showToast("error", "Thiếu vai trò", "Vui lòng nhập vai trò của nhiệm vụ."); document.getElementById("officeAddRole")?.focus(); return; }
    PENDING_ADD_TASK = { officer, taskName, role, deadline, completedDate, status, product, note, staffNote, isArising, is_regular: isOfficeRegular, file, _fromOfficePopup: true };
    const s = document.getElementById("addConfirmSummary");
    if (s) s.innerHTML = `<div><b>Cán bộ:</b> ${esc(officer)}</div><div><b>Nhiệm vụ:</b> ${esc(taskName)}</div><div><b>Vai trò:</b> ${esc(role)} &nbsp; · &nbsp; <b>Trạng thái:</b> ${esc(status)} ${isOfficeRegular ? '<span style="color:#7c3aed">· 🔁 Thường xuyên</span>' : ''}</div><div><b>Thường xuyên:</b> ${isOfficeRegular ? "Có (giữ sang tháng sau)" : "Không"}</div><div><b>Hạn hoàn thành:</b> ${deadline ? formatDate(deadline) : "Chưa nhập"}</div><div><b>Ngày hoàn thành:</b> ${completedDate ? formatDate(completedDate) : "Chưa nhập"}</div><div><b>Sản phẩm:</b> ${esc(product)}</div><div><b>Ghi chú cán bộ:</b> ${staffNote ? esc(staffNote) : "Không có"}</div><div><b>Tệp:</b> ${file ? esc(file.name) : "Không có tệp"}</div>`;
    smoothOpenModal("addConfirmModal");
}

function ttbtvWrapDateInput(el) {
    if (!el || el.dataset.calWrapped) return;
    el.dataset.calWrapped = '1';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:100%;box-sizing:border-box';
    el.parentElement.insertBefore(wrap, el);
    wrap.appendChild(el);
    el.style.paddingRight = '26px';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pp-date-btn'; b.title = 'Chọn ngày'; b.textContent = '📅';
    b.style.cssText = 'position:absolute;right:2px;top:50%;transform:translateY(-50%);border:none;background:transparent;cursor:pointer;font-size:14px;line-height:1;padding:2px 4px';
    b.onclick = function () { ttbtvOpenDatePicker(b); };
    wrap.appendChild(b);
}

function ttbtvDateDisplay(v, fallback) { const s = String(v ?? '').trim(); if (!s) return fallback; return /^\d{4}-\d{2}-\d{2}/.test(s) ? formatDate(s) : s; }

function ttbtvDdmmyyyy(d) { return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear(); }

function ttbtvConfirmDate(v, fallback) { try { const d = ttbtvDeadlineDate(v); if (!d) return fallback || "Chưa nhập"; return ttbtvDdmmyyyy(d).replaceAll("/", "-"); } catch (e) { return fallback || "Chưa nhập"; } }
