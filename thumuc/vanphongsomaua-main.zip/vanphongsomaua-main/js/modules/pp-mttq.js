/* js/modules/pp-mttq.js — tach tu js/legacy.js (nhom 7 pp/ProvincePlan/MTTQ KPI).
 * Classic script (window globals), load SAU prov-bch, TRUOC legacy.js.
 */

function provinceFold(s) {
    return String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
}

function provinceAgencyLabel(v) {
    const s = String(v ?? '').replace(/\s+/g, ' ').trim();
    return provinceFold(s) === 'van phong dang uy' ? 'Văn phòng Đảng ủy' : s;
}

function provinceHasProduct(v) {
    const s = provinceFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(s);
}

function provinceHasResult(v) {
    const s = provinceFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null", "dang trien khai"].includes(s);
}

function provinceRemainingText(x) {
    if (provinceCompletedDate(x.completed_date)) return "Đã hoàn thành";
    const d = provinceDeadlineDate(x.deadline); if (!d) return "—";
    const days = Math.ceil((d.getTime() - new Date().getTime()) / 86400000);
    return days > 0 ? `Còn ${days} ngày` : days === 0 ? "Hết hạn hôm nay" : `Trễ ${Math.abs(days)} ngày`;
}

function provinceDeadlineDate(v) {
    const s = String(v ?? "").trim();
    if (!s) return null;
    // Hỗ trợ yyyy-mm-dd và chuỗi tiếng Việt có dd/mm/yyyy, ví dụ: "Hoàn thành trước ngày 30/9/2026".
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) {
        const y = +iso[1], mo = +iso[2], d = +iso[3], dt = new Date(y, mo - 1, d);
        return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
    }
    const matches = [...s.matchAll(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/g)];
    if (!matches.length) return null;
    const m = matches[matches.length - 1], d = +m[1], mo = +m[2], y = +m[3];
    const dt = new Date(y, mo - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
}

function provinceCompletedDate(v) {
    return provinceDeadlineDate(v);
}

function provinceStatusFor(x, overrides = {}) {
    // Group vai trò: như TT/BTV, trạng thái chính phụ thuộc vai trò lãnh đạo
    const _roles = overrides.roles !== undefined ? overrides.roles : provinceParseRoleNote(x.note);
    const _dueG = provinceDeadlineDate(overrides.deadline ?? x.deadline);
    const _compG = provinceCompletedDate(overrides.completed_date ?? x.completed_date);
    const _gk = provinceGroupKeyFromRoles(_roles, _dueG, _compG, overrides.role ?? overrides.unit_name ?? x.role ?? x.unit_name ?? x.unit_name);
    if(_gk) return _gk;
    const due = provinceDeadlineDate(overrides.deadline ?? x.deadline);
    const completed = provinceCompletedDate(overrides.completed_date ?? x.completed_date);
    const result = overrides.result ?? x.result;
    const hasFile = overrides.hasFile !== undefined ? !!overrides.hasFile : !!x.attachment_path;
    const hasEvidence = provinceHasResult(result) || hasFile;

    // V48: trạng thái KHÔNG được sửa tay. Có Ngày HT là chốt theo ngày (đồng bộ cây).
    if (completed) {
        if (due) {
            const a = new Date(completed.getFullYear(), completed.getMonth(), completed.getDate()).getTime();
            const b = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
            if (a < b) return "early";
            if (a === b) return "ontime";
            return "latedone";
        }
        return "ontime";
    }

    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (due && due < today) return "overdue";
    return "processing";
}

function provinceStatusLabel(k) {
    return ({
        processing: "Đang triển khai",
        early: "Hoàn thành trước hạn",
        ontime: "Hoàn thành đúng hạn",
        latedone: "Hoàn thành quá hạn",
        overdue: "Quá hạn",
        done: "Hoàn thành"
    })[k] || "Đang triển khai";
}

function provinceStatusGroup(k) {
    // V37: gom 3 trạng thái hoàn thành chi tiết về nhóm "done" cho KPI/bộ lọc.
    return ["early", "ontime", "latedone", "done"].includes(k) ? "done" : (k || "processing");
}

function provinceBadgeStatus(x) {
    // Cột Trạng thái (tự động): nhiệm vụ hoàn thành chỉ ghi "Hoàn thành", giữ chi tiết trong tooltip.
    const k = x.statusKey || provinceStatusFor(x);
    const full = provinceStatusLabel(k);
    const short = provinceStatusGroup(k) === "done" ? "Hoàn thành" : full;
    return `<span class="bch-badge ${k}" title="${esc(full)}">${esc(short)}</span>`;
}

function provinceFilteredBadgeStatus(x, selectedAgency) {
    if (!selectedAgency || !x?._isTree || !x._taskEl) return provinceBadgeStatus(x);
    const wanted = provinceFold(selectedAgency);
    const agency = [...x._taskEl.querySelectorAll('.pp-agency')].find(ag => {
        const value = provinceAgencyLabel(ag.querySelector('[data-k=agencyOther]')?.value || ag.querySelector('[data-k=agency]')?.value || '');
        const folded = provinceFold(value);
        return folded === wanted || folded.includes(wanted) || wanted.includes(folded);
    });
    if (!agency) return provinceBadgeStatus(x);
    const rows = [...agency.querySelectorAll('.pp-person')].filter(row => ['name', 'deadline', 'finish'].some(k => (row.querySelector(`[data-k=${k}]`)?.value || '').trim()));
    if (!rows.length) return provinceBadgeStatus(x);
    const statuses = rows.map(ppPersonStrictStatus);
    const judged = statuses.filter(s => s !== '-');
    const done = judged.length && judged.every(s => ['trước hạn', 'đúng hạn', 'HT quá hạn'].includes(s));
    const key = judged.some(s => s === 'quá hạn') ? 'overdue' : done ? 'done' : 'processing';
    return provinceBadgeStatus({ statusKey: key });
}

async function provinceFetch(url) {
    const r = await fetch(url, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json" } });
    const tx = await r.text();
    if (!r.ok) { if(String(tx).includes("42501")||String(tx).toLowerCase().includes("row-level security")) throw new Error(tx+" (RLS chặn)"); throw new Error(tx || `HTTP ${r.status}`); }
    const j = JSON.parse(tx);
    if (!Array.isArray(j)) throw new Error("Dữ liệu PROV không phải mảng.");
    return j;
}

function provinceRenderChart(canvasId, labels, data, colorsList, legendId, drillKind) {
    const canvas = document.getElementById(canvasId); if (!canvas || typeof Chart === "undefined") return;
    if (PROV_CHARTS[canvasId]) PROV_CHARTS[canvasId].destroy();
    PROV_CHARTS[canvasId] = new Chart(canvas.getContext("2d"), {
        type: "doughnut",
        data: { labels, datasets: [{ data, backgroundColor: colorsList, borderColor: "#fff", borderWidth: 2 }] },
        options: {
            responsive: true, maintainAspectRatio: false, cutout: "62%",
            plugins: { legend: { display: false } },
            onClick: (evt, els) => {
                if (!els.length) return;
                const label = labels[els[0].index];
                drillPROVChart(drillKind, label);
            }
        }
    });
    const lg = document.getElementById(legendId);
    if (lg) lg.innerHTML = labels.map((l, i) => `<div class="legend-item" onclick="drillPROVChart('${drillKind}',${JSON.stringify(l).replace(/"/g, '&quot;')})"><span class="legend-color" style="background:${colorsList[i]}"></span><span>${esc(l)} (${data[i]})</span></div>`).join("");
}

function provinceUserOwnsTask(x) {
    if (!CURRENT_USER || CURRENT_USER.role !== "staff") return false;
    // Ưu tiên so sánh chính xác (tránh va chạm khi normalize bỏ dấu) - fix Lỗi 4 REPORT
    if (String(x.officer_name || "").trim() === String(CURRENT_USER.name || "").trim()) return true;
    const me = provinceFold(CURRENT_USER.name);
    if (me && provinceFold(x.officer_name) === me) {
        // Chỉ cho normalize khi tên đủ dài (>4) để giảm va chạm "Le Van A" vs "Lê Văn A"
        if (String(CURRENT_USER.name || "").trim().length > 4) return true;
    }
    const names = String(x.specialist_name || x.product || "").split(/[;,]/).map(provinceFold).filter(Boolean);
    return names.includes(me);
}

function provinceCanEdit(x) {
    if (!CURRENT_USER) return false;
    return CURRENT_USER.role === "admin" || provinceUserOwnsTask(x);
}

function provinceDrillTimestamp(x) { const t = Date.parse(x?.updated_at || ""); return Number.isFinite(t) ? t : (Number(x?.id) || 0) }

function provinceIsUBND(v){ return provinceFold(v) === "ubnd xa"; }

function provinceTaskLeader(x){
    if(!x) return "";
    const off = String(x.officer_name ?? "").trim();
    const room = String(x.role ?? "").trim();
    if(provinceIsUBND(x.unit_name)) return provinceDedupeNames(off || room || "");
    return provinceDedupeNames(room || off || "");
}

function provinceDedupeNames(s){
    const seen = new Set(); const out = [];
    String(s ?? "").split(/[,;]/).forEach(part => {
        const v = String(part || "").trim();
        if(!v || v === "—") return;
        const k = provinceFold(v);
        if(!k || seen.has(k)) return;
        seen.add(k); out.push(v);
    });
    return out.join(", ");
}

async function provinceHandleUnitOther(sel){
    if(!sel || sel.value!=="__other__") return;
    const prev=sel.dataset.prev||"";
    const bodyHtml=`<div style="margin-top:4px"><input id="customProvUnitInput" type="text" placeholder="Nhập tên cơ quan..." maxlength="120" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none"></div>`;
    setTimeout(()=>document.getElementById("customProvUnitInput")?.focus(),120);
    const ok=await provinceConfirm({icon:"🏢", title:"Nhập cơ quan", message:"Vui lòng nhập tên cơ quan", bodyHtml, confirmText:"Thêm", cancelText:"Hủy", confirmClass:"btn-primary"});
    const custom=document.getElementById("customProvUnitInput")?.value.trim()||"";
    if(ok && custom){
        if(![...sel.options].some(o=>o.value===custom)){
            const opt=document.createElement("option"); opt.value=custom; opt.textContent=custom;
            const other=[...sel.options].find(o=>o.value==="__other__");
            if(other) sel.insertBefore(opt, other); else sel.appendChild(opt);
        }
        sel.value=custom; sel.dataset.prev=custom;
    } else {
        sel.value=prev||"";
    }
    provinceSyncRoleGroup(sel);
}

function provincePickDate(targetId){
    try{
        const txt=document.getElementById(targetId);
        if(txt && (txt.readOnly || txt.disabled)) return;
        const picker=document.getElementById(targetId+"_picker");
        if(!picker) return;
        // khởi tạo giá trị date picker từ text dd/mm/yyyy nếu có
        if(txt && txt.value){
            const d=provinceDeadlineDate(txt.value) || provinceCompletedDate(txt.value);
            if(d){ const iso=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; picker.value=iso; }
        }
        if(typeof picker.showPicker==="function") picker.showPicker();
        else picker.click();
    }catch(e){ try{ document.getElementById(targetId+"_picker")?.click(); }catch(_){} }
}

function provincePickerDate(iso, targetId){
    try{
        if(!iso) return;
        const el=document.getElementById(targetId);
        if(el && (el.readOnly || el.disabled)) return;
        const m=iso.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if(!m) return;
        const d=new Date(+m[1], +m[2]-1, +m[3]);
        const txt=`${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`;
        if(el){ el.value=txt; try{ dateMask(el); }catch(_){} try{ refreshPROVAutoStatus(); }catch(_){} }
    }catch(e){}
}

function provincePickAgency(name){
    const sel=document.getElementById("provinceOfficerFilter"); if(!sel) return;
    if(![...sel.options].some(o=>o.value===name)){ const opt=document.createElement("option"); opt.value=name; opt.textContent=name; sel.appendChild(opt); }
    sel.value=name;
    try{ if(typeof applyPROVFilters==="function") applyPROVFilters(); }catch(e){}
    try{ if(typeof renderProvinceAgencyList==="function") renderProvinceAgencyList(); }catch(e){}
}

function mttqKpiHeaders(json = false) {
    const h = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };
    if (json) { h['Content-Type'] = 'application/json'; h.Prefer = 'return=representation'; }
    return h;
}

function mttqKpiFold(value) { return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g, 'D').replace(/đ/g, 'd').toLowerCase().trim(); }

function mttqKpiParseDate(value) {
    const v = String(value || '').trim(), iso = v.match(/^(\d{4})-(\d{2})-(\d{2})/), dm = v.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
    const d = iso ? new Date(+iso[1], +iso[2] - 1, +iso[3]) : dm ? new Date(+dm[3], +dm[2] - 1, +dm[1]) : null;
    return d && !isNaN(d) ? d : null;
}

function mttqKpiDateDb(value) { const d = mttqKpiParseDate(value); return d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` : null; }

function mttqKpiDateDisplay(value) { const d = mttqKpiParseDate(value); return d ? `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` : ''; }

function mttqKpiUpcoming(task, days) { if (mttqKpiStatusKey(task) !== 'processing') return false; const due = mttqKpiParseDate(task.deadline), today = new Date(); today.setHours(0, 0, 0, 0); if (!due) return false; const end = new Date(today); end.setDate(end.getDate() + days); return due >= today && due <= end; }

function mttqKpiStatusKey(task) {
    const outcome = mttqKpiFold(task.outcome);
    if (outcome === 'truoc han') return 'early';
    if (outcome === 'dung han') return 'ontime';
    if (outcome === 'qua han') return 'late_done';
    if (outcome === 'khong hoan thanh') return 'failed';
    const due = mttqKpiParseDate(task.deadline), today = new Date(); today.setHours(0, 0, 0, 0);
    return due && due < today ? 'overdue' : 'processing';
}

function mttqKpiStatusLabel(key) { return ({ early: 'Hoàn thành trước hạn', ontime: 'Hoàn thành đúng hạn', late_done: 'Hoàn thành quá hạn', failed: 'Không hoàn thành', overdue: 'Quá hạn', processing: 'Đang thực hiện' })[key] || 'Đang thực hiện'; }

function mttqKpiIsDone(task) { return ['early', 'ontime', 'late_done'].includes(mttqKpiStatusKey(task)); }

function mttqKpiScore(task) { const n = Number(task.converted_score); return Number.isFinite(n) ? n : 0; }

function mttqKpiPersonName(task) { return MTTQ_KPI_PEOPLE.find(p => String(p.id) === String(task.person_id))?.name || task.person_name || 'Chưa gán cán bộ'; }

function mttqKpiCanEditTask(task) { if (!task || !CURRENT_USER) return false; if (isMTTQAdmin()) return true; // intentional: MTTQ admin sửa mọi nhiệm vụ
 return CURRENT_USER.role === 'staff' && CURRENT_USER.scope === 'mttq' && mttqKpiFold(mttqKpiPersonName(task)) === mttqKpiFold(CURRENT_USER.name); }

function mttqKpiOwnPersonId() { return MTTQ_KPI_PEOPLE.find(p => mttqKpiFold(p.name) === mttqKpiFold(CURRENT_USER?.name))?.id || null; }

function mttqKpiScopedTasks() {
    const person = document.getElementById('mttqKpiPersonFilter')?.value || 'all', month = document.getElementById('mttqKpiMonthFilter')?.value || 'all', year = document.getElementById('mttqKpiYearFilter')?.value || 'all';
    return MTTQ_KPI_TASKS.filter(x => (person === 'all' || String(x.person_id) === person) && (month === 'all' || String(x.task_month || '') === month) && (year === 'all' || String(x.task_year || '') === year));
}

async function loadMTTQKPIData(force = false) {
    if(DEMO_MODE){
        const snap = await getDemoSnapshot();
        MTTQ_KPI_PEOPLE = Array.isArray(snap.mttq_kpi_people) ? snap.mttq_kpi_people : [];
        MTTQ_KPI_CATALOG = Array.isArray(snap.mttq_kpi_catalog) ? snap.mttq_kpi_catalog : [];
        MTTQ_KPI_TASKS = Array.isArray(snap.mttq_kpi_tasks) ? snap.mttq_kpi_tasks : [];
        populateMTTQKPIFilters(); renderMTTQKPITable();
        const s=document.getElementById('mttqKpiSyncText'); if(s) s.textContent=`✅ [DEMO] ${MTTQ_KPI_TASKS.length} nhiệm vụ mẫu (không fetch Supabase)`;
        return;
    }
    const sync = document.getElementById('mttqKpiSyncText');
    try {
        const [peopleRes, catalogRes, taskRes] = await Promise.all([fetch(`${MTTQ_KPI_PEOPLE_API}?select=*&order=name.asc`, { headers: mttqKpiHeaders() }), fetch(`${MTTQ_KPI_CATALOG_API}?select=*&order=task_name.asc`, { headers: mttqKpiHeaders() }), fetch(`${MTTQ_KPI_TASKS_API}?select=*&order=deadline.asc,created_at.asc`, { headers: mttqKpiHeaders() })]);
        if (!peopleRes.ok || !catalogRes.ok || !taskRes.ok) throw new Error('Chưa có đủ 3 bảng KPI MTTQ. Hãy chạy SQL tạo bảng trước.');
        MTTQ_KPI_PEOPLE = await peopleRes.json(); MTTQ_KPI_CATALOG = await catalogRes.json(); MTTQ_KPI_TASKS = await taskRes.json();
        populateMTTQKPIFilters(); renderMTTQKPITable();
        if (sync) sync.textContent = `Đã cập nhật lúc ${new Date().toLocaleTimeString('vi-VN')} · ${MTTQ_KPI_TASKS.length} nhiệm vụ`;
    } catch (e) {
        if (sync) sync.textContent = '⚠️ Chưa kết nối được dữ liệu KPI MTTQ';
        if (force || !MTTQ_KPI_TASKS.length) showToast('error', 'Không tải được KPI MTTQ', e.message);
    }
}

function resetMTTQKPIFilters() { ['mttqKpiSearch', 'mttqKpiPersonFilter', 'mttqKpiMonthFilter', 'mttqKpiYearFilter', 'mttqKpiStatusFilter'].forEach(id => { const el = document.getElementById(id); if (el) el.value = id === 'mttqKpiSearch' ? '' : id.includes('Filter') && !id.includes('Status') ? 'all' : id === 'mttqKpiStatusFilter' ? 'all' : el.value; }); renderMTTQKPITable(); }

function openMTTQKPIWorkspace(el) {
    if (!canAccessMTTQKPI()) return showToast('error', 'Không có quyền', 'Chỉ Admin và cán bộ MTTQ được truy cập workspace này.');
    ['officeWorkspace', 'bchWorkspace', 'ttbtvWorkspace', 'provinceWorkspace', 'action100Workspace', 'nqWorkspace'].forEach(id => document.getElementById(id)?.classList.remove('open'));
    const ws = document.getElementById('mttqKpiWorkspace'); if (!ws) return; ws.classList.add('open'); document.querySelectorAll('.sidebar-item').forEach(x => x.classList.remove('active')); (el || document.getElementById('mttqKpiSidebarItem'))?.classList.add('active'); loadMTTQKPIData(false);
    try{ vpSaveLastWs("mttqKpiWorkspace"); }catch(e){}
}

function openMTTQKPIEdit(id = '') {
    const x = id ? MTTQ_KPI_TASKS.find(r => String(r.id) === String(id)) : null;
    if (x && !mttqKpiCanEditTask(x)) return showToast('error', 'Không có quyền sửa', 'Bạn chỉ được sửa nhiệm vụ có tên mình.');
    if (!x && !canAccessMTTQKPI()) return showToast('error', 'Không có quyền', 'Chỉ Admin và cán bộ MTTQ được nhập nhiệm vụ.');
    MTTQ_KPI_EDIT_ID = id || null; populateMTTQKPIFilters();
    document.getElementById('mttqKpiEditTitle').textContent = x ? 'Cập nhật nhiệm vụ KPI MTTQ' : 'Thêm nhiệm vụ KPI MTTQ';
    const set = (id, value) => { const el = document.getElementById(id); if (el) el.value = value ?? ''; };
    set('mttqKpiPerson', x?.person_id || (CURRENT_USER?.scope === 'mttq' && !isMTTQAdmin() ? mttqKpiOwnPersonId() : MTTQ_KPI_PEOPLE[0]?.id) || ''); set('mttqKpiTaskName', x?.task_name); set('mttqKpiAssigner', x?.assigner); set('mttqKpiDeadline', mttqKpiDateDisplay(x?.deadline)); set('mttqKpiOutcome', x?.outcome || ''); set('mttqKpiQualityErrors', x?.quality_errors ?? 0); set('mttqKpiProduct', x?.product); set('mttqKpiLevel', x?.level || 1); set('mttqKpiFactor', x?.conversion_factor ?? 1); set('mttqKpiAxis', x?.kpi_axis); set('mttqKpiNote', x?.note); const personField = document.getElementById('mttqKpiPerson'); if (personField) personField.disabled = !isMTTQAdmin();
    const _tk = document.getElementById('mttqKpiTaskName'); if (_tk) { const _isAdminMTTQ = CURRENT_USER && CURRENT_USER.role === 'admin';
        if (x) { _tk.readOnly = !_isAdminMTTQ; _tk.style.background = _isAdminMTTQ ? "#fff" : "#f1f5f9"; _tk.title = _isAdminMTTQ ? "" : "Chỉ Admin được sửa Nội dung nhiệm vụ."; } else { _tk.readOnly = false; _tk.style.background = "#fff"; _tk.title = ""; } }
    const _dl = document.getElementById('mttqKpiDeadline'); if (_dl) { const _isAdminDl = CURRENT_USER && CURRENT_USER.role === 'admin';
        if (x) { _dl.readOnly = !_isAdminDl; _dl.style.background = _isAdminDl ? "#fff" : "#f1f5f9"; _dl.title = _isAdminDl ? "" : "Chỉ Admin được sửa Hạn hoàn thành."; } else { _dl.readOnly = false; _dl.style.background = "#fff"; _dl.title = ""; } }
    smoothOpenModal('mttqKpiEditModal'); focusFirstEditable('mttqKpiEditModal');
}

function closeMTTQKPIEdit() { smoothCloseModal('mttqKpiEditModal'); MTTQ_KPI_EDIT_ID = null; }

function mttqKpiBuildPayload() {
    const deadlineRaw = document.getElementById('mttqKpiDeadline')?.value.trim() || '', deadline = mttqKpiDateDb(deadlineRaw), outcome = document.getElementById('mttqKpiOutcome')?.value || '', errors = Math.max(0, Number(document.getElementById('mttqKpiQualityErrors')?.value || 0)), level = Number(document.getElementById('mttqKpiLevel')?.value || 1), factor = Number(document.getElementById('mttqKpiFactor')?.value || 1), progress = ['Trước hạn', 'Đúng hạn'].includes(outcome) ? 1 : outcome === 'Quá hạn' ? 0.75 : 0, quantity = outcome === 'Không hoàn thành' ? 0 : 1, quality = Math.max(0, 1 - 0.25 * errors);
    const d = mttqKpiParseDate(deadlineRaw), personId = isMTTQAdmin() ? (document.getElementById('mttqKpiPerson')?.value || null) : mttqKpiOwnPersonId();
    return { person_id: personId, task_name: document.getElementById('mttqKpiTaskName')?.value.trim() || '', assigner: document.getElementById('mttqKpiAssigner')?.value.trim() || '', deadline, outcome, product: document.getElementById('mttqKpiProduct')?.value.trim() || '', quality_errors: errors, level, conversion_factor: factor, quantity_score: quantity, quality_score: quality, progress_score: progress, converted_score: Number((factor * ((quantity + quality + progress) / 3)).toFixed(6)), kpi_axis: document.getElementById('mttqKpiAxis')?.value.trim() || '', note: document.getElementById('mttqKpiNote')?.value.trim() || '', report_status: outcome ? '✓ Đã tính vào báo cáo' : '', task_month: d?.getMonth() + 1 || null, task_quarter: d ? Math.ceil((d.getMonth() + 1) / 3) : null, task_year: d?.getFullYear() || null, updated_at: new Date().toISOString() };
}

async function saveMTTQKPITask() {
    const current = MTTQ_KPI_EDIT_ID ? MTTQ_KPI_TASKS.find(x => String(x.id) === String(MTTQ_KPI_EDIT_ID)) : null; if (current && !mttqKpiCanEditTask(current)) return showToast('error', 'Không có quyền sửa', 'Bạn chỉ được sửa nhiệm vụ có tên mình.'); if (!current && !canAccessMTTQKPI()) return showToast('error', 'Không có quyền', 'Chỉ Admin và cán bộ MTTQ được thêm nhiệm vụ.');
    const payload = mttqKpiBuildPayload();
    if (current && CURRENT_USER?.role !== 'admin' && payload.task_name !== String(current.task_name||"").trim()) {
        showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ."); payload.task_name = current.task_name || "";
        const _tk2 = document.getElementById('mttqKpiTaskName'); if (_tk2) _tk2.value = payload.task_name;
    }
    if (current && CURRENT_USER?.role !== 'admin' && payload.deadline !== String(current.deadline||"").trim()) {
        showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành."); payload.deadline = current.deadline || "";
        const _dl2 = document.getElementById('mttqKpiDeadline'); if (_dl2) _dl2.value = mttqKpiDateDisplay(payload.deadline);
        // rebuild derived month/quarter/year từ deadline cũ
        const _d = mttqKpiParseDate(payload.deadline); payload.task_month = _d?.getMonth()+1 || null; payload.task_quarter = _d ? Math.ceil((_d.getMonth()+1)/3) : null; payload.task_year = _d?.getFullYear() || null;
    }
    if (!payload.person_id || !payload.task_name || !payload.deadline) return showToast('error', 'Thiếu thông tin', 'Cần chọn cán bộ, nhập tên nhiệm vụ và hạn dd/mm/yyyy.');
    const url = MTTQ_KPI_EDIT_ID ? `${MTTQ_KPI_TASKS_API}?id=eq.${encodeURIComponent(MTTQ_KPI_EDIT_ID)}` : MTTQ_KPI_TASKS_API;
    try { const r = await fetch(url, { method: MTTQ_KPI_EDIT_ID ? 'PATCH' : 'POST', headers: mttqKpiHeaders(true), body: JSON.stringify(payload) }); if (!r.ok) throw new Error(await r.text()); closeMTTQKPIEdit(); await loadMTTQKPIData(true); writeActivity(MTTQ_KPI_EDIT_ID ? 'Sửa KPI MTTQ' : 'Thêm KPI MTTQ', { task: payload.task_name }); showToast('success', MTTQ_KPI_EDIT_ID ? 'Đã cập nhật KPI' : 'Đã thêm nhiệm vụ KPI'); } catch (e) { showToast('error', 'Không lưu được KPI', e.message); }
}

async function deleteMTTQKPITask(id) {
    const task = MTTQ_KPI_TASKS.find(x => String(x.id) === String(id)); if (!task || !mttqKpiCanEditTask(task) || !confirm(`Xóa nhiệm vụ "${task.task_name || 'KPI'}"?`)) return;
    try { const r = await fetch(`${MTTQ_KPI_TASKS_API}?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE', headers: mttqKpiHeaders() }); if (!r.ok) throw new Error(await r.text()); await loadMTTQKPIData(true); writeActivity('Xóa KPI MTTQ', { task: task.task_name }); showToast('success', 'Đã xóa nhiệm vụ KPI'); } catch (e) { showToast('error', 'Không xóa được KPI', e.message); }
}

function ppPersonRow(label, role) { return `<div class="pp-person" style="padding:6px;border:none;border-radius:8px;margin:6px 0;background:#fff"><div style="display:grid;grid-template-columns:120px minmax(0,1fr) 110px 120px 100px 1fr 88px;gap:6px;align-items:center"><span style="font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${label}">${label}</span><input data-k="name" placeholder="Tên" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="deadline" title="Hạn hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="deadline" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="finish" title="Ngày hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="finish" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><input data-k="product" placeholder="Sản phẩm" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"><textarea data-k="reason" placeholder="Lý do quá hạn" rows="1" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;resize:none"></textarea><span data-k="status" style="text-align:center;font-size:12px;padding:4px 6px;border-radius:6px;background:#f1f5f9"></span></div></div>`; }

function ppLeaderOptionsHtml(){ try{ const escFn = (typeof esc==='function'?esc:(s)=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')); let names=[]; const addNames=(arr)=>{ if(!Array.isArray(arr)) return; arr.forEach(o=>{ const n=String(o.name||o.title||'').trim(); if(n && n!=='vp admin' && n!=='VP Admin') names.push(n);});}; try{ addNames(window.BCH_OFFICERS||[]); addNames(window.TTBTV_OFFICERS||[]); addNames(window.PROV_OFFICERS||[]); }catch(e){} if(!names.length){ try{ const c1=JSON.parse(localStorage.getItem('bch_officers_cache')||'[]'); const c2=JSON.parse(localStorage.getItem('ttbtv_officers_cache')||'[]'); const c3=JSON.parse(localStorage.getItem('province_officers_cache')||'[]'); addNames(c1); addNames(c2); addNames(c3);}catch(e){} } names=[...new Set(names.filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi')); if(!names.length) return '<option value="">-- Chưa có dữ liệu --</option><option value="__other__">Khác (nhập tên...)</option>'; return names.map(n=>' <option value="'+escFn(n)+'">'+escFn(n)+'</option>').join('')+'<option value="__other__">Khác (nhập tên...)</option>'; }catch(e){ return '<option value="__other__">Khác (nhập tên...)</option>'; } }

function ppPersonRowLite(label, role){ const isLeader = role==='ldchutri'||role==='ldphoihop'; const nameField = isLeader ? `<input data-k="name" placeholder="Nguyễn Văn A - CVP" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px">` : `<input data-k="name" placeholder="Tên" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px">`; return `<div class="pp-person" style="padding:6px;border:none;border-radius:8px;margin:6px 0;background:#fff"><div style="display:grid;grid-template-columns:120px minmax(0,1fr) 110px 120px 100px 1fr 88px;gap:6px;align-items:center"><span style="font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${label}">${label}</span>`+nameField+`<div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="deadline" title="Hạn hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="deadline" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="finish" title="Ngày hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="finish" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><input data-k="product" placeholder="Sản phẩm" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"><textarea data-k="reason" placeholder="Lý do quá hạn" rows="1" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;resize:none"></textarea><span data-k="status" style="text-align:center;font-size:12px;padding:4px 6px;border-radius:6px;background:#f1f5f9"></span></div></div>`; }

function ppNhiemVuRow(withExtra){ const extra = withExtra ? '<div style="display:flex;gap:6px;margin-top:6px"><div style="flex:3;min-width:0"><div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:2px">Sản phẩm</div><textarea data-k="product" placeholder="Nhập sản phẩm..." onmouseover="this.title=this.value" rows="2" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;resize:vertical;min-height:80px"></textarea></div><div style="flex:2;min-width:0"><div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:2px">Lý do quá hạn</div><textarea data-k="reason" placeholder="Nhập lý do..." onmouseover="this.title=this.value" rows="2" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;resize:vertical;min-height:80px"></textarea></div></div>' : ''; return `<div class="pp-person pp-nhiemvu" style="padding:6px;border:none;border-radius:8px;margin:6px 0;background:#fff"><div style="display:grid;grid-template-columns:140px 140px 76px 92px 96px;gap:6px;margin-bottom:2px"><span style="font-size:11px;font-weight:600;color:#64748b;text-align:center;white-space:nowrap">Hạn hoàn thành</span><span style="font-size:11px;font-weight:600;color:#64748b;text-align:center;white-space:nowrap">Ngày hoàn thành</span><span style="font-size:11px;font-weight:600;color:#64748b;text-align:center;white-space:nowrap">Còn lại</span><span style="font-size:11px;font-weight:600;color:#64748b;text-align:center;white-space:nowrap">Tiến độ</span><span style="font-size:11px;font-weight:600;color:#64748b;text-align:center;white-space:nowrap">Trạng thái</span></div><div style="display:grid;grid-template-columns:140px 140px 76px 92px 96px;gap:6px;align-items:center"><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="deadline" title="Hạn hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="deadline" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="finish" title="Ngày hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="finish" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><span data-k="remaining" style="text-align:center;font-size:12px">-</span><input data-k="progress" placeholder="Tiến độ" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"><span data-k="status" style="text-align:center;font-size:12px;padding:4px 6px;border-radius:6px;background:#f1f5f9">-</span></div>${extra}</div>`; }

function ppAgencyOptionsHtml(){ return `<optgroup label="HĐND"><option value="HĐND">HĐND</option><option value="Ban Kinh tế - Ngân sách">Ban Kinh tế - Ngân sách</option><option value="Ban Văn hóa - Xã hội">Ban Văn hóa - Xã hội</option></optgroup><optgroup label="UBND"><option value="UBND xã">UBND xã</option></optgroup><optgroup label="Các cơ quan tham mưu giúp việc"><option value="Các cơ quan tham mưu giúp việc">Các cơ quan tham mưu giúp việc</option><option value="Văn phòng Đảng ủy">Văn phòng Đảng ủy</option><option value="UBKT">UBKT</option><option value="Ban Xây dựng Đảng">Ban Xây dựng Đảng</option></optgroup><optgroup label="Trung tâm Chính trị"><option value="Trung tâm Chính trị">Trung tâm Chính trị</option></optgroup><optgroup label="MTTQ"><option value="MTTQ">MTTQ</option></optgroup><option value="__other__">Khác (nhập tên cơ quan...)</option>`; }

function ppAgencyOptionsFullHtml(){ return `<optgroup label="UBND xã:"><option value="Văn phòng HĐND &amp; UBND">Văn phòng HĐND &amp; UBND</option><option value="Phòng Văn hóa - Xã hội">Phòng Văn hóa - Xã hội</option><option value="Phòng Kinh tế hạ tầng">Phòng Kinh tế hạ tầng</option><option value="Phòng Nông nghiệp &amp; Môi trường">Phòng Nông nghiệp &amp; Môi trường</option><option value="Trung tâm PV HCC">Trung tâm PV HCC</option><option value="Trung tâm Dịch vụ tổng hợp">Trung tâm Dịch vụ tổng hợp</option><option value="BQL dự án đầu tư xây dựng">BQL dự án đầu tư xây dựng</option><option value="Trạm Y tế">Trạm Y tế</option></optgroup><optgroup label="Các cơ quan TM giúp việc"><option value="Văn phòng Đảng ủy">Văn phòng Đảng ủy</option><option value="UBKT">UBKT</option><option value="Ban Xây dựng Đảng">Ban Xây dựng Đảng</option></optgroup><optgroup label="Trung tâm chính trị"><option value="Trung tâm chính trị">Trung tâm chính trị</option></optgroup><optgroup label="MTTQ và các HC CT-XH:"><option value="MTTQ">MTTQ</option><option value="Đoàn thanh niên">Đoàn thanh niên</option><option value="Hội Phụ nữ">Hội Phụ nữ</option><option value="Hội CCB">Hội CCB</option><option value="Hội Nông dân">Hội Nông dân</option><option value="Công đoàn">Công đoàn</option><option value="Công an xã">Công an xã</option></optgroup><option value="__other__">Khác (nhập tên cơ quan...)</option>`; }

function ppPersonRowPCM(label){ return `<div class="pp-person" style="padding:6px;border:none;border-radius:8px;margin:6px 0;background:#fff"><div style="display:grid;grid-template-columns:120px minmax(0,1fr) 110px 120px 100px 1fr 88px;gap:6px;align-items:center"><span style="font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${label}">${label}</span><select data-k="name" data-prev="" onchange="ppHandleAgencyOtherChange(this)" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fffbeb">${ppAgencyOptionsFullHtml()}</select><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="deadline" title="Hạn hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="deadline" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><div style="position:relative;width:100%;box-sizing:border-box"><input type="date" lang="vi" data-k="finish" title="Ngày hoàn thành" class="date-ddmmyyyy" style="width:100%;box-sizing:border-box;padding:5px 26px 5px 5px;border:1px solid #cbd5e1;border-radius:6px"><button type="button" class="pp-date-btn" data-picker-for="finish" onclick="ppOpenDatePicker(this)" title="Chọn ngày" style="position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08);transition:all .15s" onmouseover="this.style.background='#e0f2fe';this.style.borderColor='#7dd3fc'" onmouseout="this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)';this.style.borderColor='#cbd5e1'" title="Chọn ngày">📅</button></div><input data-k="product" placeholder="Sản phẩm" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"><textarea data-k="reason" placeholder="Lý do quá hạn" rows="1" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px;resize:none"></textarea><span data-k="status" style="text-align:center;font-size:12px;padding:4px 6px;border-radius:6px;background:#f1f5f9"></span></div></div>`; }

function ppPCMBlock() { return `<div class="pp-pcm" style="margin:6px 0 6px 16px;padding:8px;border:none;background:#fffbfd;border-radius:8px"><div style="font-size:12px;font-weight:700;color:#c2185b;margin-bottom:4px">LĐ PCM <button class="pp-pcm-remove" onclick="this.closest('.pp-pcm').remove();ppUpdateAll()" style="float:right;background:#607d8b;color:#fff;border:1px solid #546e7a;border-radius:6px;padding:2px 6px">X</button></div>${ppPersonRowPCM('Tên PCM')}${ppPersonRowLite('LĐ phòng', 'ldphong')}${ppPersonRowLite('CV PCM', 'cvpcm')}</div>`; }

function ppAgencyBlock(isFirst) { const isCT = !!isFirst; const toggleBtn = `<button class="pp-agency-toggle${isCT ? ' open' : ''}" onclick="ppToggleAgency(this)">${isCT ? 'Thu gọn' : 'Mở rộng'}</button>`; const contentStart = `<div class="pp-agency-content"${isCT ? '' : ' style="display:none"'}>`; const contentEnd = `</div>`; const deleteBtn = isCT ? '' : `<button class="pp-agency-remove" onclick="ppRemoveAgency(this)" style="background:#fee2e2;color:#dc2626;border:1px solid #fecaca;padding:6px 10px;border-radius:8px;font-weight:700;cursor:pointer">− Xóa nhiệm vụ</button>`; const headerAttrs = 'style="display:flex;gap:8px;align-items:center;cursor:pointer" onclick="if(!event.target.closest(\'button\')) ppToggleAgency(this.querySelector(\'.pp-agency-toggle\'))" title="Click để Thu gọn/Mở rộng"'; return `<div class="pp-agency" data-type="${isCT ? 'chutri' : 'phoihop'}" style="margin:10px 0;padding:10px;border:none;border-radius:10px;background:${isCT ? '#eff6ff' : '#fff7ed'};border-left:4px solid ${isCT ? '#3b82f6' : '#f59e0b'}"><div ${headerAttrs}><span class="pp-agency-label" data-k="agencyTypeLabel" style="padding:8px 12px;border-radius:8px;font-weight:700;font-size:13px;background:${isCT ? '#dbeafe' : '#ffedd5'};color:${isCT ? '#1e40af' : '#9a3412'};border:1px solid ${isCT ? '#93c5fd' : '#fed7aa'}">${isCT ? 'Nhiệm vụ 1' : 'Nhiệm vụ ' + (isCT ? 1 : 2)}</span>${toggleBtn}${deleteBtn}<span class="pp-agency-collapsed-info" style="display:none;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc;color:#334155;white-space:nowrap;max-width:260px;overflow:hidden;text-overflow:ellipsis"></span></div>${contentStart}<div style="margin-top:8px"><label style="font-size:12px;font-weight:700;color:#1e293b;margin-bottom:4px;display:block">Nhiệm vụ cụ thể</label><textarea placeholder="Nhập nội dung nhiệm vụ cụ thể..." data-k="agencyTask" onmouseover="this.title=this.value" rows="2" style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #94a3b8;border-radius:8px;background:#fff;font-size:14px;resize:vertical;min-height:60px"></textarea>${ppNhiemVuRow(isCT)}</div><button type="button" onclick="ppToggleAgencyGroup(this)" class="pp-show-agency-btn" style="margin-top:8px;background:#e0f2fe;color:#0c4a6e;border:1px solid #bae6fd;padding:6px 12px;border-radius:8px;font-weight:700;cursor:pointer">Hiện cơ quan</button><div class="pp-agency-group" style="display:none"><div style="display:flex;gap:12px;margin-top:10px"><div style="flex:1"><label style="font-size:12px;font-weight:700;color:#1e293b;margin-bottom:4px;display:block">Cơ quan chủ trì</label><select data-k="agencyOther" onchange="ppHandleAgencyOtherChange(this);ppSyncAgencyLeader(this)" data-prev="" style="width:100%;padding:10px;border:1px solid #f59e0b;border-radius:8px;background:#fffbeb;display:block;font-size:14px">${ppAgencyOptionsHtml()}</select></div><div style="flex:1;display:none"><label style="font-size:12px;font-weight:700;color:#1e293b;margin-bottom:4px;display:block">Cơ quan phối hợp</label><select data-k="agencyPhoiHop" onchange="ppHandleAgencyOtherChange(this)" data-prev="" style="width:100%;padding:10px;border:1px solid #38bdf8;border-radius:8px;background:#f0f9ff;display:block;font-size:14px">${ppAgencyOptionsFullHtml()}</select></div></div><div class="pp-agency-body" style="margin-top:12px;padding:8px;background:rgba(255,255,255,0.7);border-radius:8px;border:1px solid #cbd5e1"><div class="pp-person-head">${ppPersonHeadHtml()}</div>${ppPersonRowLite('Lãnh đạo phòng', 'ldchutri')}${ppPersonRowLite('Lãnh đạo phòng', 'ldphoihop').replace('class="pp-person"', 'class="pp-person" style="display:none"')}${ppPersonRowLite('Chuyên viên tham mưu', 'cv')}</div></div>${contentEnd}</div>`; }

function ppPersonHeadHtml(){ const c = 'font-size:11px;font-weight:700;color:#64748b;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis'; return `<div style="display:grid;grid-template-columns:120px minmax(0,1fr) 110px 120px 100px 1fr 88px;gap:6px;padding:3px 6px;background:#f1f5f9;border-radius:6px;position:sticky;top:54px;z-index:2"><span style="${c};text-align:left">Vai trò</span><span style="${c}">Tên</span><span style="${c}">Hạn hoàn thành</span><span style="${c}">Ngày hoàn thành</span><span style="${c}">Sản phẩm</span><span style="${c}">Lý do</span><span style="${c}">Trạng thái</span></div>`; }

function ppEnsureEnterNav(){ const tree = document.getElementById('provincePlanTree'); if (!tree || tree._enterNav) return; tree._enterNav = true; tree.addEventListener('keydown', (e) => { if (e.key !== 'Enter' || e.shiftKey) return; const el = e.target; if (!el || el.tagName === 'TEXTAREA' || el.isContentEditable) return; if (el.tagName !== 'INPUT' && el.tagName !== 'SELECT') return; if (el.type === 'date') return; e.preventDefault(); const task = el.closest('.pp-task'); if (!task) return; const fields = [...task.querySelectorAll('input:not([type=hidden]), select, textarea')].filter(f => !f.disabled && !f.readOnly && f.type !== 'date' && f.offsetParent !== null); const nx = fields[fields.indexOf(el) + 1]; if (nx) { nx.focus(); try { if (nx.select) nx.select(); } catch (_) {} } }); }

function ppEnhanceAgency(ag){ if (!ag || ag._enhanced) return; ag._enhanced = true; try { const body = ag.querySelector('.pp-agency-body'); if (body && !body.querySelector(':scope > .pp-person-head')) { const h = document.createElement('div'); h.className = 'pp-person-head'; h.innerHTML = ppPersonHeadHtml(); body.insertBefore(h, body.firstChild); } } catch (e) {} ppEnsureEnterNav(); }

function ppAgencyBadge(ag){ try { const rows = [...ag.querySelectorAll('.pp-person')]; const real = rows.filter(r => ['name', 'deadline', 'finish'].some(k => (r.querySelector(`[data-k=${k}]`)?.value || '').trim())); const head = ag.firstElementChild; if (!head) return; let b = head.querySelector('.pp-agency-badge'); if (!b) { b = document.createElement('span'); b.className = 'pp-agency-badge'; b.style.cssText = 'padding:4px 10px;border-radius:999px;font-size:11px;font-weight:800;white-space:nowrap'; const remove = head.querySelector('.pp-agency-remove'); if (remove) remove.insertAdjacentElement('afterend', b); else head.appendChild(b); } if (ag.dataset.type !== 'phoihop' || !real.length) { b.style.display = 'none'; return; } const statuses = real.map(ppPersonStrictStatus); const judged = statuses.filter(s => s !== '-'); const done = judged.length && judged.every(s => s === 'trước hạn' || s === 'đúng hạn' || s === 'HT quá hạn'); const overdue = judged.some(s => s === 'quá hạn' || s === 'HT quá hạn'); const label = overdue && !done ? 'Quá hạn' : done ? 'Hoàn thành' : 'Đang xử lý'; b.style.display = ''; b.textContent = label; const style = label === 'Quá hạn' ? ['#feecec', '#c62f35', '#f7bfc2'] : label === 'Hoàn thành' ? ['#e9f9ef', '#137a42', '#bce8cc'] : ['#e6f7fb', '#08758a', '#b8e8f0']; b.style.background = style[0]; b.style.color = style[1]; b.style.border = '1px solid ' + style[2]; } catch (e) {} }

function ppRefreshAgencyTitles(task) { if (!task) return; const ags = [...task.querySelectorAll('.pp-agency')]; ags.forEach((ag, i) => { const isCT = i === 0; ag.dataset.type = isCT ? 'chutri' : 'phoihop'; ag.style.background = isCT ? '#eff6ff' : '#fff7ed'; ag.style.borderLeftColor = isCT ? '#3b82f6' : '#f59e0b'; ppEnhanceAgency(ag); ppAgencyBadge(ag); const lb = ag.querySelector('[data-k=agencyTypeLabel]'); if (lb) { const label = 'Nhiệm vụ ' + (i+1); lb.textContent=label; lb.style.background = isCT ? '#dbeafe' : '#ffedd5'; lb.style.color = isCT ? '#1e40af' : '#9a3412'; lb.style.borderColor = isCT ? '#93c5fd' : '#fed7aa'; } const head = ag.firstElementChild; if(head){ let del=head.querySelector('.pp-agency-remove'); if(i===0){ if(del) del.remove(); } else { if(!del){ del=document.createElement('button'); del.className='pp-agency-remove'; del.setAttribute('onclick','ppRemoveAgency(this)'); del.style.cssText='background:#fee2e2;color:#dc2626;border:1px solid #fecaca;padding:6px 10px;border-radius:8px;font-weight:700;cursor:pointer'; del.textContent='− Xóa nhiệm vụ'; const tg=head.querySelector('.pp-agency-toggle'); if(tg) tg.insertAdjacentElement('afterend', del); else head.appendChild(del); } }
        try{
            let info=head.querySelector('.pp-agency-collapsed-info');
            if(!info){
                info=document.createElement('span');
                info.className='pp-agency-collapsed-info';
                info.style.cssText='display:none;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc;color:#334155;white-space:nowrap;max-width:260px;overflow:hidden;text-overflow:ellipsis';
                const tg2=head.querySelector('.pp-agency-toggle');
                if(tg2) head.insertBefore(info, tg2.nextSibling ? tg2.nextSibling.nextSibling || tg2.nextSibling : null);
            }
            if(i>=1){
                const agSel2=ag.querySelector('[data-k=agencyOther]');
                const agName2=(agSel2?.value||'').trim();
                const allDl2=[...ag.querySelectorAll('.pp-nhiemvu [data-k=deadline], .pp-person [data-k=deadline]')];
                const dlEl2=allDl2.find(el=> (el.value||'').trim()) || ag.querySelector('[data-k=deadline]');
                const dlVal2=(dlEl2?.value||'').trim();
                let disp2='';
                if(dlVal2){ if(typeof ppDispDate==='function') disp2=ppDispDate(dlVal2)||''; if(!disp2 && typeof ppDateDisplayVal==='function') disp2=ppDateDisplayVal(dlVal2)||dlVal2; else if(!disp2) disp2=dlVal2; }
                let txt2=''; if(agName2 && disp2) txt2=agName2+' - '+disp2; else txt2=agName2||disp2||'';
                if(txt2){ info.textContent=txt2; info.title=txt2; info.style.display='inline-flex'; info.style.alignItems='center'; } else { info.style.display='none'; }
            } else { if(info) info.style.display='none'; }
        }catch(e){}
    } }); }

function ppTaskBlock(stt) { return `<div class="pp-task" data-id="" style="margin:12px 0;padding:12px;border:none;border-radius:12px;background:#f8fafc;border-left:5px solid #c7d2fe;position:relative"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;position:sticky;top:0;z-index:3;background:#f8fafc;padding:6px 0 8px;margin:-4px 0 4px;cursor:pointer" onclick="if(event.target.closest('button')) return; const _b=this.querySelector('button[onclick=&quot;ppToggleTask(this)&quot;]'); if(_b) ppToggleTask(_b)"><div style="display:flex;gap:8px;align-items:center;min-width:0;flex:1"><button onclick="ppToggleTask(this)" style="padding:6px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#e2e8f0;flex:0 0 auto">▼</button><b class="pp-task-title" data-stt="${stt}" title="Click để mở rộng/thu gọn">Nhiệm vụ <span class="pp-stt">${stt}</span></b></div><div style="display:flex;gap:8px;align-items:center;margin-left:auto;flex:0 0 auto"><span class="pp-summary-eye" style="display:none;cursor:pointer;padding:4px 8px;border-radius:999px;font-size:12px;border:1px solid #cbd5e1;background:#fff;box-shadow:0 1px 4px rgba(15,23,42,.08);align-items:center;justify-content:center" title="Di chuột để xem tóm tắt ngay">👁</span><span class="pp-task-status" style="display:none;padding:4px 10px;border-radius:999px;font-size:11px;font-weight:800;border:1px solid #e2e8f0;background:#f1f5f9;color:#64748b;white-space:nowrap;align-items:center;justify-content:center"></span><button class="pp-save-btn" onclick="event.stopPropagation(); ppSaveOne(this)" style="background:#10b981;color:#fff;padding:6px 12px;border:1px solid #0da271;border-radius:8px;font-weight:700">Lưu</button><button class="pp-edit-btn" onclick="event.stopPropagation(); ppEditTask(this)" style="background:#3b82f6;color:#fff;padding:6px 10px;border:1px solid #2563eb;border-radius:8px">Sửa</button><button class="pp-delete-btn" onclick="event.stopPropagation(); ppDeleteTask(this)" style="background:#ef4444;color:#fff;padding:6px 10px;border:1px solid #dc2626;border-radius:8px">Xóa</button></div></div><div class="pp-task-body" style="margin-top:8px"><div style="display:flex;gap:8px"><div style="flex:1"><label style="font-size:12px;font-weight:600">Văn bản tỉnh <button onclick="ppAddDoc(this,'tinh')" style="padding:2px 6px;border-radius:6px;background:#673ab7;color:#fff">+VB</button></label><div class="pp-docs-tinh"><div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div></div></div><div style="flex:1"><label style="font-size:12px;font-weight:600">Văn bản xã <button onclick="ppAddDoc(this,'xa')" style="padding:2px 6px;border-radius:6px;background:#673ab7;color:#fff">+VB</button></label><div class="pp-docs-xa"><div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div></div></div></div><div class="pp-agencies" style="margin-top:8px">${ppAgencyBlock(true)}</div><button onclick="ppAddAgency(this)" style="margin-top:8px;background:#2196F3;color:#fff;padding:8px 14px;border-radius:8px;font-weight:700">+ Nhiệm vụ</button></div></div`; }

function ppShortDoc(s){
  const t=String(s||'').trim(); if(!t) return '';
  const docType='(?:\\bCV\\b|\\bQĐ\\b|\\bKH\\b|\\bTB\\b|\\bBC\\b|Công văn|Chỉ thị|Thông báo|Quyết định|Kế hoạch|Nghị quyết|Báo cáo|Tờ trình)';
  const direct=t.match(new RegExp(docType+'[^\\n]{0,64}ngày\\s*\\d{1,2}\\/\\d{1,2}\\/\\d{4}','i'));
  if(direct){
    const d0=direct[0].match(/\d{1,2}\/\d{1,2}\/\d{4}/); const cv0=[...direct[0].matchAll(new RegExp(docType+'[^\\d]{0,8}\\d+\\S*','gi'))];
    if(d0 && cv0.length) return (cv0[cv0.length-1][0].trim().replace(/\s+/g,' ').replace(/[,;]+$/,'')+' ngày '+d0[0]).slice(0,52);
    return direct[0].trim().replace(/\s+/g,' ').replace(/,\s*ngày/,' ngày').slice(0,52);
  }
  const direct2=t.match(/ngày\s*\d{1,2}\/\d{1,2}\/\d{4}/i);
  if(direct2){
    const idx=t.indexOf(direct2[0]); const before=t.slice(Math.max(0, idx-44), idx).trim();
    const cvAll2=[...before.matchAll(new RegExp(docType+'[^\\d]{0,8}\\d+\\S*','gi'))];
    if(cvAll2.length){ const cv=cvAll2[cvAll2.length-1][0].trim().replace(/\s+/g,' ').replace(/[,;]+$/,''); return (cv+' '+direct2[0].trim()).replace(/\s+/g,' ').slice(0,52); }
    return direct2[0].trim().replace(/\s+/g,' ').slice(0,28);
  }
  const d=t.match(/\d{1,2}\/\d{1,2}\/\d{4}/);
  const cvAll=[...t.matchAll(new RegExp(docType+'[^\\d]{0,8}\\d+\\S*','gi'))];
  if(d && cvAll.length){ const cv=cvAll[cvAll.length-1][0].trim().replace(/\s+/g,' ').replace(/[,;]+$/,''); return (cv+' ngày '+d[0]).slice(0,52); }
  if(d) return ('ngày '+d[0]).slice(0,28);
  const m=t.match(new RegExp(docType+'[^\\n]{0,40}','i'));
  if(m) return m[0].trim().replace(/\s+/g,' ').slice(0,38);
  return t.slice(0,36);
}

function ppBuildTaskTitle(task, stt){
  try{
    const vbTinhRaw = [...task.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d=>(d.textContent||'').trim()).filter(Boolean).join(', ');
    const vbXaRaw = [...task.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d=>(d.textContent||'').trim()).filter(Boolean).join(', ');
    const vbTinh = ppShortDoc(vbTinhRaw);
    const vbXa = ppShortDoc(vbXaRaw);
    const agencies = [...task.querySelectorAll('.pp-agency [data-k=agencyOther]')].map(s=>s.value.trim()).filter(Boolean);
    const pcmNames = [...task.querySelectorAll('.pp-agency[data-type="phoihop"] .pp-pcm-list .pp-person [data-k=name], .pp-agency:not(:first-child) .pp-pcm-list [data-k=name]')].map(el=> (el.value||el.textContent||'').trim()).filter(v=>v && v!=='__other__');
    const deadlines = [...task.querySelectorAll('.pp-person [data-k=deadline]')].map(i=>i.value.trim()).filter(Boolean);
    const han = ppDispDate(deadlines[0]||'');
    const parts=[];
    if(vbTinh) parts.push(vbTinh);
    if(vbXa) parts.push(vbXa);
    if(agencies.length) parts.push(agencies.slice(0,3).join(', ').slice(0,42));
    if(pcmNames.length) parts.push('PCM: '+[...new Set(pcmNames)].slice(0,2).join(', ').slice(0,32));
    if(han) parts.push('Hạn '+han);
    const body = parts.length ? parts.join(' | ') : 'Hãy nhập nội dung cụ thể';
    const disp = body.slice(0,110)+(body.length>110?'…':'');
    return {disp, full:body, vbTinh:vbTinhRaw, vbXa:vbXaRaw, agencies, han, pcmNames};
  }catch(e){ return {disp:'Nhiệm vụ '+(stt||''), full:'Nhiệm vụ '+(stt||'')}; }
}

function ppDocItem() { return `<div style="display:flex;gap:4px;align-items:center;margin-top:4px"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" title="Xóa VB" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px;font-weight:700">×</button></div>`; }

function ppSyncAgencyLeader(sel) {
    try {
        if (!sel || (sel.getAttribute && sel.getAttribute('data-k') !== 'agencyOther')) return;
        const ag = sel.closest('.pp-agency'); if (!ag) return;
        const v = String(sel.value || '').trim();
        const lb = ag.querySelector('[data-k=agencyLeaderLabel]');
        const inp = ag.querySelector('[data-k=agencyLeader]');
        if (!lb || !inp) return;
        const leadLabel = (v === 'UBND xã') ? 'Lãnh đạo UBND' : 'Lãnh đạo phòng';
        if (v === 'UBND xã') { lb.textContent = 'Lãnh đạo UBND'; inp.placeholder = 'Nhập tên lãnh đạo UBND...'; }
        else { lb.textContent = 'Lãnh đạo phòng'; inp.placeholder = 'Nguyễn Văn A - CVP'; }
        const leadRow = [...ag.querySelectorAll('.pp-person')].find(r => { const t = (r.querySelector('span')?.textContent || '').trim(); return t === 'Lãnh đạo UBND' || t === 'Lãnh đạo phòng'; });
        if (leadRow) { const s = leadRow.querySelector('span'); if (s) { s.textContent = leadLabel; s.title = leadLabel; } }
    } catch (e) {}
}

function ppPersonStrictStatus(p) {
    // Giống Văn phòng: nhập đủ Ngày hoàn thành + Hạn hoàn thành thì chốt hoàn thành theo ngày, không treo Quá hạn.
    const get = k => p.querySelector(`[data-k=${k}]`)?.value?.trim() || '';
    const deadline = get('deadline'), finish = get('finish');
    const dl = ppParseDate(deadline), fin = ppParseDate(finish);
    if (fin && dl) {
        const a = new Date(fin.getFullYear(), fin.getMonth(), fin.getDate()).getTime();
        const b = new Date(dl.getFullYear(), dl.getMonth(), dl.getDate()).getTime();
        if (a < b) return 'trước hạn';
        if (a === b) return 'đúng hạn';
        return 'HT quá hạn';
    }
    if (fin) return 'đúng hạn';
    const today = new Date(); today.setHours(0, 0, 0, 0);
    if (dl && dl < today) return 'quá hạn';
    return '-';
}

function ppTaskHeaderStatus(task) {
    if (!task) return;
    // tính lại trạng thái từng person theo logic chặt chẽ
    const persons = [...task.querySelectorAll('.pp-person')];
    const statuses = persons.map(ppPersonStrictStatus);
    // cập nhật lại UI từng person status (đồng bộ với ppUpdateAll)
    persons.forEach((row, i) => {
        const st = row.querySelector('[data-k=status]'); const rem = row.querySelector('[data-k=remaining]');
        const s = statuses[i];
        row.style.borderColor = (s === 'quá hạn') ? '#fca5a5' : '';
        if (st) {
            st.textContent = s;
            if (s === 'quá hạn') st.style.background = '#ff9999';
            else if (s === 'trước hạn') st.style.background = '#00ffff';
            else if (s === 'đúng hạn') st.style.background = '#00ff00';
            else if (s === 'HT quá hạn') st.style.background = '#fbbf24';
            else st.style.background = '#f1f5f9';
        }
        if (rem) {
            const dl = ppParseDate(row.querySelector('[data-k=deadline]')?.value || '');
            const fin = ppParseDate(row.querySelector('[data-k=finish]')?.value || '');
            if (dl && fin) rem.textContent = Math.ceil((dl - fin) / 86400000);
            else if (dl && !fin) {
                const today = new Date(); today.setHours(0, 0, 0, 0);
                const d = new Date(dl.getFullYear(), dl.getMonth(), dl.getDate());
                const diff = Math.ceil((d - today) / 86400000);
                rem.textContent = diff > 0 ? diff : diff === 0 ? 0 : diff;
            } else rem.textContent = '-';
        }
    });
    // Bỏ qua dòng person trống (placeholder PCM/chưa nhập) khi gom trạng thái nhiệm vụ
    const isEmptyPerson = (row) => !['name', 'deadline', 'finish'].some(k => (row.querySelector(`[data-k=${k}]`)?.value || '').trim());
    const active = persons.map((row, i) => statuses[i]).filter((s, i) => !isEmptyPerson(persons[i]));
    const judged = active.filter(t => t !== '-');
    let key = 'doing';
    if (judged.some(t => t === 'quá hạn')) key = 'overdue';
    else if (judged.length && judged.every(t => t === 'trước hạn' || t === 'đúng hạn' || t === 'HT quá hạn')) key = 'done';
    else key = 'doing';
    const map = { doing: { label: 'Đang xử lý', bg: '#e6f7fb', color: '#08758a', border: '#b8e8f0', left: '#56B4E9' }, done: { label: 'Hoàn thành', bg: '#e9f9ef', color: '#137a42', border: '#bce8cc', left: '#009E73' }, overdue: { label: 'Quá hạn', bg: '#feecec', color: '#c62f35', border: '#f7bfc2', left: '#D55E00' } };
    const m = map[key] || map.doing;
    const badge = task.querySelector('.pp-task-status');
    if (badge) {
        badge.textContent = m.label;
        badge.style.background = m.bg;
        badge.style.color = m.color;
        badge.style.borderColor = m.border;
        // di chuyển badge sang trái nút Lưu khi thu gọn (đẹp hơn) - hỗ trợ cả DOM cũ
        const saveBtn = task.querySelector('button[onclick="ppSaveOne(this)"]');
        const actions = saveBtn?.parentElement;
        if (actions && badge.parentElement !== actions) actions.insertBefore(badge, saveBtn);
        const body = task.querySelector('.pp-task-body');
        const collapsed = body && body.style.display === 'none';
        badge.style.display = 'inline-flex';
        badge.style.alignItems = 'center';
        badge.style.justifyContent = 'center';
        // Hien Trang thai o nhiem vu lon nhat, an ten co quan - han
        try{
            let info = task.querySelector('.pp-task-agency-info');
            if(!info){
                info = document.createElement('span');
                info.className = 'pp-task-agency-info';
                info.style.cssText = 'display:none;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc;color:#334155;white-space:nowrap;max-width:280px;overflow:hidden;text-overflow:ellipsis';
                if(badge.nextSibling) badge.parentElement.insertBefore(info, badge.nextSibling);
                else badge.parentElement.appendChild(info);
            }
            // An ten co quan - han hoan thanh o nhiem vu lon nhat
            { let _info=task.querySelector('.pp-task-agency-info'); if(_info) _info.style.display='none'; }
        }catch(e){}
        const eye = task.querySelector('.pp-summary-eye');
        if (eye) {
            eye.style.display = collapsed ? 'inline-flex' : 'none';
            eye.style.alignItems = 'center';
            eye.style.justifyContent = 'center';
            if (!eye._bound) {
                eye._bound = true;
                const showEyeTip = (e) => {
                    if (e) e.stopPropagation();
                    const sum = task.querySelector('.pp-summary');
                    if (!sum) return;
                    const tip = sum.querySelector('.pp-summary-tip'); if (!tip) return;
                    if (sum._showTimer) { clearTimeout(sum._showTimer); sum._showTimer = null; }
                    let portal = document.getElementById('ppFixedTip');
                    if (!portal) {
                        portal = document.createElement('div');
                        portal.id = 'ppFixedTip';
                        portal.style.cssText = 'position:fixed;z-index:99999;display:none;max-width:520px;pointer-events:none';
                        document.body.appendChild(portal);
                        portal.addEventListener('mouseenter', () => { portal._hover = true; });
                        portal.addEventListener('mouseleave', () => { portal._hover = false; setTimeout(() => { if (!portal._hover && !portal._sumHover) { portal.style.display = 'none'; portal.style.opacity = '0'; portal.style.visibility = 'hidden'; } }, 120); });
                        portal.addEventListener('wheel', (ev) => { ev.stopPropagation(); }, { passive: false });
                    }
                    portal.innerHTML = tip.innerHTML;
                    portal.className = tip.className;
                    const isLong = (tip.innerText || '').length > 400 || tip.scrollHeight > 260;
                    const pe = isLong ? 'auto' : 'none';
                    portal.style.cssText = 'position:fixed;z-index:99999;display:block;opacity:0;visibility:hidden;pointer-events:' + pe + ';max-width:min(520px,92vw);max-height:min(72vh,560px);overflow:auto;overscroll-behavior:contain';
                    const r = eye.getBoundingClientRect();
                    let th = portal.offsetHeight, tw = portal.offsetWidth;
                    const vh = window.innerHeight, vw = window.innerWidth;
                    const maxH = Math.min(560, vh - 16);
                    if (th > maxH) { portal.style.maxHeight = maxH + 'px'; portal.style.overflow = 'auto'; th = maxH; }
                    let top = r.bottom + 10, left = r.left - tw - 12;
                    if (left < 8) { left = r.right + 12; if (left + tw > vw - 12) left = Math.max(8, vw - tw - 12); }
                    const needFlip = top + th + 8 > vh;
                    if (needFlip) {
                        const tf = r.top - th - 10;
                        if (tf >= 8) top = tf; else { top = Math.max(8, vh - th - 8); portal.style.maxHeight = (vh - 16) + 'px'; portal.style.overflow = 'auto'; }
                    }
                    if (left + tw > vw - 12) left = vw - tw - 12;
                    if (left < 8) left = 8;
                    portal.style.left = left + 'px';
                    portal.style.top = top + 'px';
                    portal.style.opacity = '1';
                    portal.style.visibility = 'visible';
                    portal.style.display = 'block';
                    portal.style.pointerEvents = pe;
                    portal._isLong = isLong;
                    portal._sumHover = true;
                    portal._sumRect = r;
                    sum._portal = portal;
                };
                // Tat tooltip khi di chuot vao nhiem vu: chi click moi hien, khong hover
                eye.addEventListener('click', showEyeTip);
                eye.addEventListener('mouseleave', () => {
                    const p = document.getElementById('ppFixedTip');
                    if (p && p._isLong && p._hover) return;
                    setTimeout(() => { const p2 = document.getElementById('ppFixedTip'); if (p2 && !p2._hover) { p2.style.display = 'none'; p2.style.opacity = '0'; p2.style.visibility = 'hidden'; } }, 140);
                });
            }
            eye.style.display = collapsed ? 'inline-flex' : 'none';
        }
    }
    const body2 = task.querySelector('.pp-task-body');
    const isCollapsed = body2 && body2.style.display === 'none';
    task.style.borderLeftColor = m.left;
    task.style.boxShadow = isCollapsed ? '' : '0 4px 14px rgba(99,102,241,.18)';
    task.style.background = isCollapsed ? (key === 'overdue' ? '#fff7f7' : key === 'done' ? '#f0fdf4' : '#f8fafc') : '#f8fafc';
    task.dataset.statusKey = key;
    try { if (typeof ppSyncTaskRoleUI === 'function') ppSyncTaskRoleUI(task); } catch (e) { }
}

function ppCloseCal() { const p = document.getElementById('ppCalPop'); if (p) p.remove(); try { document.removeEventListener('pointerdown', ppCalOutside, true); } catch (e) {} try { document.removeEventListener('keydown', ppCalEsc, true); } catch (e) {} try { window.removeEventListener('scroll', ppCloseCal, true); } catch (e) {} ppCalState = null; }

function ppCalOutside(e) { const p = document.getElementById('ppCalPop'); if (!p) return; if (p.contains(e.target)) return; if (e.target.closest && e.target.closest('.pp-date-btn')) return; ppCloseCal(); }

function ppCalEsc(e) { if (e && e.key === 'Escape') ppCloseCal(); }

function ppRenderCal() {
    const st = ppCalState;
    ppCloseCal();
    ppCalState = st;
    if (!st || !st.inp) return;
    const pop = document.createElement('div');
    pop.id = 'ppCalPop';
    pop.style.cssText = 'position:fixed;z-index:99999;background:#fff;border:1px solid #cbd5e1;border-radius:12px;box-shadow:0 12px 32px rgba(15,23,42,.18);padding:10px;width:252px;font-size:13px;color:#0f172a;';
    const wd = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
    let h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">';
    h += '<button type="button" data-nav="-1" style="border:1px solid #e2e8f0;background:#f8fafc;border-radius:8px;padding:4px 10px;cursor:pointer;font-weight:700">‹</button>';
    h += '<b>Tháng ' + (st.m + 1) + '/' + st.y + '</b>';
    h += '<button type="button" data-nav="1" style="border:1px solid #e2e8f0;background:#f8fafc;border-radius:8px;padding:4px 10px;cursor:pointer;font-weight:700">›</button></div>';
    h += '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;text-align:center">';
    for (let i = 0; i < 7; i++) h += '<span style="font-size:11px;font-weight:700;color:#64748b;padding:4px 0">' + wd[i] + '</span>';
    const lead = (new Date(st.y, st.m, 1).getDay() + 6) % 7;
    const dim = new Date(st.y, st.m + 1, 0).getDate();
    const now = new Date();
    for (let i = 0; i < lead; i++) h += '<span></span>';
    for (let d = 1; d <= dim; d++) {
        const isT = (d === now.getDate() && st.m === now.getMonth() && st.y === now.getFullYear());
        const isS = st.selDate && d === st.selDate.getDate() && st.m === st.selDate.getMonth() && st.y === st.selDate.getFullYear();
        const bg = isS ? '#6d28d9' : (isT ? '#e0e7ff' : '#fff');
        const fg = isS ? '#fff' : (isT ? '#4338ca' : '#0f172a');
        h += '<button type="button" data-day="' + d + '" style="border:1px solid ' + (isS ? '#6d28d9' : '#eef2f7') + ';background:' + bg + ';color:' + fg + ';border-radius:8px;padding:5px 0;cursor:pointer;font-weight:' + ((isS || isT) ? '800' : '500') + '">' + d + '</button>';
    }
    h += '</div>';
    h += '<div style="display:flex;gap:6px;margin-top:8px"><button type="button" data-act="today" style="flex:1;border:1px solid #e2e8f0;background:#f8fafc;border-radius:8px;padding:5px 0;cursor:pointer;font-size:12px">Hôm nay</button><button type="button" data-act="clear" style="flex:1;border:1px solid #fecaca;background:#fef2f2;color:#dc2626;border-radius:8px;padding:5px 0;cursor:pointer;font-size:12px">Xóa</button></div>';
    pop.innerHTML = h;
    pop.addEventListener('click', function (e) {
        if (!ppCalState) return;
        const nav = e.target.closest('[data-nav]');
        if (nav) { ppCalState.m += (+nav.getAttribute('data-nav')); if (ppCalState.m < 0) { ppCalState.m = 11; ppCalState.y--; } if (ppCalState.m > 11) { ppCalState.m = 0; ppCalState.y++; } ppRenderCal(); return; }
        const act = e.target.closest('[data-act]');
        if (act) {
            if (act.getAttribute('data-act') === 'today') { const t = new Date(); ppCalState.m = t.getMonth(); ppCalState.y = t.getFullYear(); ppRenderCal(); return; }
            ppCalState.inp.value = ''; ppCloseCal(); try { ppUpdateAll(); } catch (err) {} return;
        }
        const day = e.target.closest('[data-day]');
        if (day) {
            const dd = (+day.getAttribute('data-day'));
            const val = String(dd).padStart(2, '0') + '/' + String(ppCalState.m + 1).padStart(2, '0') + '/' + ppCalState.y;
            const ref = ppCalState.inp;
            const cb = ppCalState.onPick;
            ppCloseCal();
            if (typeof cb === 'function') { try { cb(val, ref); } catch (err) {} }
            else {
                ref.value = val;
                try { ppUpdateAll(); } catch (err) {}
                try { ref.focus({ preventScroll: true }); } catch (err2) { try { ref.focus(); } catch (_) {} }
            }
        }
    });
    document.body.appendChild(pop);
    const r = (st.btn && document.body.contains(st.btn)) ? st.btn.getBoundingClientRect() : st.inp.getBoundingClientRect();
    const pw = 252;
    const ph = pop.offsetHeight || 300;
    let left = r.left;
    if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
    if (left < 8) left = 8;
    let top = r.bottom + 6;
    if (top + ph > window.innerHeight - 8) top = Math.max(8, r.top - ph - 6);
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    document.addEventListener('pointerdown', ppCalOutside, true);
    document.addEventListener('keydown', ppCalEsc, true);
    window.addEventListener('scroll', ppCloseCal, true);
}

function ppUpdateAll() { ppNormalizeDateInputs(); document.querySelectorAll('#provincePlanTree .pp-person').forEach(row => { const s = ppPersonStrictStatus(row); const rem = row.querySelector('[data-k=remaining]'), st = row.querySelector('[data-k=status]'); if (st) { st.textContent = s; st.style.background = s === 'quá hạn' ? '#ff9999' : s === 'trước hạn' ? '#00ffff' : s === 'đúng hạn' ? '#00ff00' : s === 'HT quá hạn' ? '#fbbf24' : '#f1f5f9'; } if (rem) { const dl = ppParseDate(row.querySelector('[data-k=deadline]')?.value || ''); const fin = ppParseDate(row.querySelector('[data-k=finish]')?.value || ''); if (dl && fin) rem.textContent = Math.ceil((dl - fin) / 86400000); else if (dl && !fin) { const today = new Date(); today.setHours(0, 0, 0, 0); const d = new Date(dl.getFullYear(), dl.getMonth(), dl.getDate()); rem.textContent = Math.ceil((d - today) / 86400000); } else rem.textContent = '-'; } }); document.querySelectorAll('#provincePlanTree .pp-task').forEach((t,i)=>{ try{ ppRefreshAgencyTitles(t); }catch(e){} ppTaskHeaderStatus(t); try{ const te=t.querySelector('.pp-task-title'); if(te){ const b=ppBuildTaskTitle(t, (i+1)); te.textContent=b.disp; te.removeAttribute('title'); } }catch(e){} }); try { renderPROVKPIs(); } catch (e) { } }

function ppUpdateSTT() { document.querySelectorAll('#provincePlanTree .pp-task').forEach((t, i) => { const e = t.querySelector('.pp-stt'); if (e) e.textContent = i + 1; const te = t.querySelector('.pp-task-title'); if (te) { te.dataset.stt = i + 1; const b = ppBuildTaskTitle(t, i+1); te.textContent = b.disp; te.removeAttribute('title'); } if (t.querySelectorAll('.pp-agency').length) ppRefreshAgencyTitles(t); }); }

function provincePlanAddTask() { if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được thêm nhiệm vụ Tỉnh giao.'); const tree = document.getElementById('provincePlanTree'); if (!tree) return; tree.insertAdjacentHTML('afterbegin', ppTaskBlock(1)); const task = tree.firstElementChild; try{ const agOther=task.querySelector('.pp-agency [data-k=agencyOther]'); if(agOther){ const v='UBND xã'; if([...agOther.options].some(o=>o.value===v)) agOther.value=v; else { const opt=document.createElement('option'); opt.value=v; opt.textContent=v; const other=[...agOther.options].find(o=>o.value==='__other__'); if(other) agOther.insertBefore(opt, other); else agOther.appendChild(opt); agOther.value=v; } agOther.dataset.prev=v; try { ppSyncAgencyLeader(agOther); } catch (e9) {} } const leaderSel = [...task.querySelectorAll('.pp-agency .pp-person')].find(row=> ['Lãnh đạo UBND', 'Lãnh đạo phòng'].includes((row.querySelector('span')?.textContent||'').trim()))?.querySelector('[data-k=name]'); if(leaderSel){ const v2='Chu Chính Sơn'; if(leaderSel.tagName==='SELECT'){ if(v2 && ![...leaderSel.options].some(o=>o.value===v2)){ const opt2=document.createElement('option'); opt2.value=v2; opt2.textContent=v2; const other2=[...leaderSel.options].find(o=>o.value==='__other__'); if(other2) leaderSel.insertBefore(opt2, other2); else leaderSel.appendChild(opt2); } leaderSel.value=v2; leaderSel.dataset.prev=v2; } else { leaderSel.value=v2; } } }catch(e){} ppSyncTaskRoleUI(task); ppUpdateSTT(); try { task.scrollIntoView({ behavior: 'smooth', block: 'center' }); const nh = task.querySelector('[data-k=nhiemvu]') || task.querySelector('[data-k=agencyTask]'); if (nh) { nh.focus(); try { const r = document.createRange(); if (nh.getAttribute && nh.getAttribute('data-k') === 'agencyTask') { const len=nh.value.length; try{ nh.setSelectionRange(len,len);}catch(_){} } else { r.selectNodeContents(nh); r.collapse(false); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); } } catch (e) { try { nh.focus(); } catch (_e) { } } } } catch (e) { } }

function ppRenderViewMode() {
    const tree = document.getElementById('provincePlanTree'); if (!tree) return;
    if (!ppIsAdmin()) {
        tree.querySelectorAll('[contenteditable]').forEach(e => e.setAttribute('contenteditable', 'false'));
        tree.querySelectorAll('input, textarea').forEach(e => e.readOnly = true);
    }
    ppSyncAllProvinceRoleUI();
}

function ppSerializePerson(row) { const g = k => row.querySelector(`[data-k=${k}]`)?.value?.trim() || ''; return { name: g('name'), deadline: g('deadline'), finish: g('finish'), progress: g('progress'), product: g('product'), reason: g('reason') }; }

function ppPersonIsBlank(p){ return !["name","deadline","finish","progress","product","reason"].some(k=>{ const v=String((p||{})[k]||"").trim(); return v && v!=="__other__"; }); }

function ppSerializeAgency(ag) { const persons = [...ag.querySelectorAll('.pp-person')].map(ppSerializePerson).filter(p=>!ppPersonIsBlank(p)); const pcmList = [...ag.querySelectorAll('.pp-pcm')].map(pcm => ({ persons: [...pcm.querySelectorAll('.pp-person')].map(ppSerializePerson).filter(p=>!ppPersonIsBlank(p)) })); const t = ag.dataset.type || 'phoihop'; const compat = t === 'UBND' ? 'chutri' : t === 'khac' ? 'phoihop' : t; const _ph = ag.querySelector('[data-k=agencyPhoiHop]')?.value?.trim() || ''; return { agency: ag.querySelector('[data-k=agencyOther]')?.value?.trim() || ag.querySelector('[data-k=agency]')?.value || '', agencyPhoiHop: (_ph === "0" || _ph === "__other__") ? "" : _ph, agencyLeader: ag.querySelector('[data-k=agencyLeader]')?.value?.trim() || '', type: compat, agencyTask: ag.querySelector('[data-k=agencyTask]')?.value || '', persons, pcmList }; }

async function provinceMigrateOldToBlocks() {
    if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được chuyển.');
    const fmt = (s) => {
        s = String(s || '').trim();
        if (!s) return '';
        let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (m) return `${m[3]}/${m[2]}/${m[1]}`;
        // already dd/mm/yyyy or other
        const dm = s.match(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/);
        if (dm) return `${dm[1].padStart(2, '0')}/${dm[2].padStart(2, '0')}/${dm[3]}`;
        return s;
    };
    let oldTasks = PROV_TASKS && PROV_TASKS.length ? PROV_TASKS : null;
    try {
        if (!oldTasks || !oldTasks.length) {
            const raw = await provinceFetch(PROV_TASKS_API);
            oldTasks = raw.map(normalizePROVTask);
        }
    } catch (e) { return showToast('error', 'Không tải được dữ liệu cũ', e.message); }
    if (!oldTasks.length) return showToast('info', 'Không có dữ liệu cũ', 'province_tasks trống.');
    // fetch existing blocks
    let existing = [];
    try {
        const r = await fetch(PROVINCE_PLAN_API, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
        if (r.ok) existing = await r.json();
    } catch { }
    const existSet = new Set(existing.map(x => String(x.nhiem_vu || '').trim()));
    const toMigrate = oldTasks.filter(x => x.task_name && !existSet.has(x.task_name.trim()));
    if (!toMigrate.length) return showToast('info', 'Không có gì để chuyển', 'Tất cả nhiệm vụ cũ đã có trong khối mới.');
    if (!confirm(`Chuyển ${toMigrate.length} nhiệm vụ từ province_tasks sang province_plan_blocks?\nTrường thiếu sẽ bỏ qua.\nKhối mới sẽ giữ nguyên ${existing.length} khối hiện có và thêm mới.`)) return;
    let ok = 0, fail = 0;
    for (let i = 0; i < toMigrate.length; i++) {
        const x = toMigrate[i];
        const vanTinh = [x.source_doc, x.issuing_authority, x.source_form].filter(s => String(s || '').trim()).join('\n') || String(x.source_doc || '').trim();
        const vanXa = [x.source_group].filter(s => String(s || '').trim()).join('\n');
        const mota = String(x.implementation_detail || x.note || x.product || '').trim();
        const agencyName = String(x.unit_name || x.role || '').trim() || '—';
        const onePerson = {
            name: String(x.officer_name || '').trim(),
            deadline: fmt(x.deadline),
            finish: fmt(x.completed_date),
            progress: String(x.progress || '').trim(),
            product: String(x.product || x.result || '').trim(),
            reason: String(x.overdue_reason || '').trim()
        };
        const payload = {
            stt: existing.length + ok + 1,
            van_ban_tinh: vanTinh,
            van_ban_xa: vanXa,
            nhiem_vu: String(x.task_name || '').trim(),
            blocks: { mota, agencies: [{ agency: agencyName, type: 'chutri', agencyTask: String(x.task_name || '').trim(), persons: [onePerson], pcmList: [] }] }
        };
        try {
            const r = await fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks`, { method: 'POST', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(payload) });
            if (!r.ok) throw new Error(await r.text());
            ok++;
        } catch (e) { console.warn('migrate fail', x.task_name, e); fail++; }
    }
    showToast(fail ? 'warning' : 'success', `Đã chuyển ${ok}/${toMigrate.length}`, fail ? `Lỗi ${fail} nhiệm vụ` : '');
    writeActivity('Tỉnh giao - Chuyển dữ liệu cũ', { migrated: ok, failed: fail, total: toMigrate.length });
    // reload tree
    if (ok) provincePlanLoad();
}

async function provinceExportTreeToOldList() {
    if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được xuất.');
    const tree = document.getElementById('provincePlanTree');
    if (!tree) return showToast('error', 'Không tìm thấy cây', 'Không có dữ liệu cây thư mục.');
    const tasks = [...tree.querySelectorAll('.pp-task')];
    if (!tasks.length) return showToast('info', 'Cây trống', 'Không có nhiệm vụ trong cây để xuất.');
    // đếm số dòng sẽ tạo (mỗi person = 1 dòng cũ)
    let totalRows = 0;
    const preview = [];
    tasks.forEach(t => {
        const nh = t.querySelector('[data-k=nhiemvu]')?.innerText.trim() || t.querySelector('[data-k=agencyTask]')?.value.trim() || '';
        const agencies = [...t.querySelectorAll('.pp-agency')].map(ag => ppSerializeAgency(ag));
        agencies.forEach(ag => {
            const agTask = ag.agencyTask || nh;
            (ag.persons || []).forEach(p => { if (p.name || agTask) { totalRows++; if (preview.length < 3) preview.push(`${ag.agency || '—'} → ${p.name || '—'}: ${agTask.slice(0, 40)}`); } });
            (ag.pcmList || []).forEach(pcm => (pcm.persons || []).forEach(p => { if (p.name || agTask) { totalRows++; if (preview.length < 3) preview.push(`PCM ${p.name || '—'}: ${agTask.slice(0, 40)}`); } }));
        });
    });
    if (!totalRows) return showToast('info', 'Không có dữ liệu', 'Cây chưa có người phụ trách để xuất.');
    const ok = await provinceConfirm({ icon: '📤', title: 'Xuất sang danh sách kiểu cũ', message: `Xuất ${totalRows} dòng từ cây thư mục sang danh sách kiểu cũ ở trên?`, bodyHtml: `<div style="font-size:12px;color:#475569;line-height:1.6">Chỉ lấy các trường khớp kiểu cũ: <b>Nhiệm vụ, Cơ quan, Lãnh đạo, Hạn, Ngày HT, Tiến độ, Sản phẩm, Lý do</b> + VB tỉnh/xã → nguồn. Danh sách cũ sẽ <b>giữ nguyên</b> và thêm mới.<br><div style="margin-top:8px;padding:8px 10px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px">${preview.map(s => `• ${esc(s)}`).join('<br>')}${totalRows > 3 ? `<br>• … và ${totalRows - 3} dòng nữa` : ''}</div></div>`, confirmText: `Xuất ${totalRows} dòng`, cancelText: 'Hủy', confirmClass: 'btn-primary' });
    if (!ok) return false;
    const toDb = (s) => {
        s = String(s || '').trim(); if (!s) return null;
        // dd/mm/yyyy -> yyyy-mm-dd
        const m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
        if (m) return `${m[3]}-${String(m[2]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`;
        const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
        try { const d = dateToDb(s); return d; } catch { return null; }
    };
    let okCount = 0, failCount = 0;
    for (const t of tasks) {
        const nh = t.querySelector('[data-k=nhiemvu]')?.innerText.trim() || '';
        const mota = t.querySelector('[data-k=mota]')?.innerText.trim() || '';
        const vbTinh = [...t.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d => d.innerText.trim()).filter(Boolean).join('\n');
        const vbXa = [...t.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d => d.innerText.trim()).filter(Boolean).join('\n');
        const vLines = vbTinh.split('\n').filter(Boolean);
        const sourceDoc = vLines[0] || vbTinh || '';
        const issuingAuthority = vLines[1] || '';
        const sourceForm = vLines[2] || '';
        const sourceGroup = vbXa || '';
        const agencies = [...t.querySelectorAll('.pp-agency')].map(ag => ppSerializeAgency(ag));
        for (const ag of agencies) {
            const agTask = (ag.agencyTask || nh || '').trim();
            const agencyName = (ag.agency || '').trim();
            const allPersons = [...(ag.persons || [])];
            (ag.pcmList || []).forEach(pcm => (pcm.persons || []).forEach(p => allPersons.push(p)));
            for (const p of allPersons) {
                if (!p.name && !agTask) continue;
                const deadline = dateToDb(p.deadline) || null;
                const completedDate = dateToDb(p.finish) || null;
                if (!agTask) continue;
                if (!deadline) continue;
                const dbRow = {
                    officer_name: p.name || '', task_name: agTask, product: p.product || '', specialist_name: p.name || '',
                    amount: '', source_doc: sourceDoc, deadline: deadline, result: p.product || '',
                    note: mota || '', phat_sinh: false, role: agencyName || '', unit_name: agencyName || '',
                    completed_date: completedDate, status: '', staff_note: '', admin_note: '',
                    source_form: sourceForm || '', issuing_authority: issuingAuthority || '', implementation_detail: mota || '', overdue_reason: p.reason || '',
                    progress: p.progress || '', attachment_path: '', attachment_name: '', attachment_type: '', attachment_size: 0,
                    source_sheet: "province_plan", source_row: Math.floor(Math.random()*2147483647), source_group: sourceGroup, updated_at: new Date().toISOString()
                };
                try {
                    const r = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks`, { method: 'POST', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(dbRow) });
                    if (!r.ok) throw new Error(await r.text());
                    okCount++;
                } catch (e) { console.warn('export fail', agTask, p.name, e); failCount++; }
            }
        }
    }
    showToast(failCount ? 'warning' : 'success', `Đã xuất ${okCount}/${totalRows}`, failCount ? `Lỗi ${failCount} dòng` : 'Danh sách kiểu cũ đã được cập nhật ở trên.');
    writeActivity('Tỉnh giao - Xuất cây sang danh sách cũ', { exported: okCount, failed: failCount, total: totalRows });
    if (okCount) { try { await loadPROVData(true); } catch {} }
}

async function provincePlanLoad() {
    // Unified: try province_tasks (source_sheet=province_plan) first — officer_name is leader
    try {
        const flatUrl = `${SUPABASE_URL}/rest/v1/province_tasks?select=*&source_sheet=eq.province_plan&order=created_at.asc`;
        const flatR = await fetch(flatUrl, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
        if (flatR.ok) {
            const flatRows = await flatR.json();
            const hasBlocks = Array.isArray(flatRows) && flatRows.length && flatRows.some(r=>{ try{ const n=JSON.parse(r.note||''); return n && n.blocks && Array.isArray(n.blocks.agencies);}catch{return false;}});
            if (hasBlocks) {
                const tree = document.getElementById('provincePlanTree'); if (!tree) return; tree.innerHTML = '';
                flatRows.sort((a,b)=> (Date.parse(a.created_at||'')||0)-(Date.parse(b.created_at||'')||0));
                flatRows.forEach((row,i)=>{
                    tree.insertAdjacentHTML('beforeend', ppTaskBlock(i+1)); const task=tree.lastElementChild; task.dataset.id=row.id||''; task.dataset.createdAt=row.created_at||row.createdAt||row.updated_at||'';
                    let blocks=null; try{ const n=JSON.parse(row.note||''); blocks=n.blocks||null; }catch{}
                    const nhEl=task.querySelector('[data-k=nhiemvu]'); if(nhEl) nhEl.innerText=row.task_name||'';
                    const moEl=task.querySelector('[data-k=mota]'); if(moEl) moEl.innerText=blocks?.mota||row.implementation_detail||'';
                    const vbTraw=[row.source_doc, row.issuing_authority, row.source_form].filter(s=>String(s||'').trim()).join('\n');
                    const vbsT=(vbTraw||'').split('\n').filter(Boolean); const vbsX=(row.source_group||'').split('\n').filter(Boolean);
                    const listT=task.querySelector('.pp-docs-tinh'); const listX=task.querySelector('.pp-docs-xa');
                    if(listT){ listT.innerHTML=''; vbsT.forEach(v=>{ listT.insertAdjacentHTML('beforeend', `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff">${esc(v)}</div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`); }); if(!vbsT.length) listT.innerHTML=`<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`; }
                    if(listX){ listX.innerHTML=''; vbsX.forEach(v=>{ listX.insertAdjacentHTML('beforeend', `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff">${esc(v)}</div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`); }); if(!vbsX.length) listX.innerHTML=`<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`; }
                    const ags=(blocks&&Array.isArray(blocks.agencies))?blocks.agencies:[]; const wrap=task.querySelector('.pp-agencies');
                    if(wrap && ags.length){ wrap.innerHTML=''; ags.forEach((ag,idx)=>{ const isFirst=idx===0||ag.type==='chutri'||ag.type==='UBND'; wrap.insertAdjacentHTML('beforeend', ppAgencyBlock(isFirst)); const el=wrap.lastElementChild;
                        const other=el.querySelector('[data-k=agencyOther]'); if(other){ if(other.tagName==='SELECT'){ if(ag.agency){ other.value=ag.agency; if(other.value!==ag.agency){ const opt=document.createElement('option'); opt.value=ag.agency; opt.textContent=ag.agency; const otherOpt=[...other.options].find(o=>o.value==='__other__'); if(otherOpt) other.insertBefore(opt,otherOpt); else other.appendChild(opt); other.value=ag.agency; } } } else other.value=ag.agency||''; }
                        const other2=el.querySelector('[data-k=agencyPhoiHop]'); if(other2){ if(other2.tagName==='SELECT'){ if(ag.agencyPhoiHop){ other2.value=ag.agencyPhoiHop; if(other2.value!==ag.agencyPhoiHop){ const opt2=document.createElement('option'); opt2.value=ag.agencyPhoiHop; opt2.textContent=ag.agencyPhoiHop; const otherOpt2=[...other2.options].find(o=>o.value==='__other__'); if(otherOpt2) other2.insertBefore(opt2,otherOpt2); else other2.appendChild(opt2); other2.value=ag.agencyPhoiHop; } } } else other2.value=ag.agencyPhoiHop||''; }
                        const at=el.querySelector('[data-k=agencyTask]'); if(at) at.value=ag.agencyTask||''; const al=el.querySelector('[data-k=agencyLeader]'); if(al) al.value=ag.agencyLeader||''; try{ const ao=el.querySelector('[data-k=agencyOther]'); if(ao) ppSyncAgencyLeader(ao); }catch{}
                        const pers=(ag.persons||[]).filter(p=>!ppPersonIsBlank(p)); const pRows=[...el.querySelectorAll('.pp-person')].filter(r=>r.style.display!=='none');
                        pers.forEach((p,pi)=>{ const row=pRows[pi]; if(!row) return; ['name','deadline','finish','progress','product','reason'].forEach(k=>{ const inp=row.querySelector(`[data-k=${k}]`); if(!inp) return; const v=p[k]||''; if(inp.tagName==='SELECT'){ if(v && ![...inp.options].some(o=>o.value===v)){ const opt=document.createElement('option'); opt.value=v; opt.textContent=v; const other=[...inp.options].find(o=>o.value==='__other__'); if(other) inp.insertBefore(opt,other); else inp.appendChild(opt); } inp.value=v; } else inp.value= inp.type==='date'? ppDateInputVal(v):v; }); });
                        const pcmList=ag.pcmList||[]; const pcmWrap=el.querySelector('.pp-pcm-list'); if(pcmWrap){ pcmWrap.innerHTML=''; if(pcmList.length) pcmWrap.style.display=''; pcmList.forEach(grp=>{ pcmWrap.insertAdjacentHTML('beforeend', ppPCMBlock()); const blk=pcmWrap.lastElementChild; const rows2=blk.querySelectorAll('.pp-person'); (grp.persons||[]).filter(p=>!ppPersonIsBlank(p)).forEach((p,pi)=>{ const r2=rows2[pi]; if(!r2) return; ['name','deadline','finish','progress','product','reason'].forEach(k=>{ const inp=r2.querySelector(`[data-k=${k}]`); if(inp){ const v= inp.type==='date'? ppDateInputVal(p[k]||''):(p[k]||''); if(inp.tagName==='SELECT'&&v&&![...inp.options].some(o=>o.value===v)){ const opt=document.createElement('option'); opt.value=v; opt.textContent=v; const other=[...inp.options].find(o=>o.value==='__other__'); if(other) inp.insertBefore(opt,other); else inp.appendChild(opt); } inp.value=v; } }); }); }); }
                    }); }
                });
                ppUpdateSTT(); ppUpdateAll(); ppRenderViewMode(); try{ applyProvincePlanTreeFilter(); }catch(e){} try{ rebuildPROVAgencyFilter(); }catch(e){}
                tree.querySelectorAll('.pp-task').forEach(t=>{ const body=t.querySelector('.pp-task-body'); const btn=t.querySelector('button[onclick="ppToggleTask(this)"]'); if(body&&btn&&body.style.display!=='none') window.ppToggleTask(btn); }); try{ applyProvincePlanTreeFilter(); }catch(e){} return;
            }
        }
    }catch(e){ console.warn('provincePlanLoad flat fallback', e); }
    try {
        const r = await fetch(PROVINCE_PLAN_API, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }); if (!r.ok) throw new Error(await r.text()); const rows = await r.json(); const tree = document.getElementById('provincePlanTree'); if (!tree) return; tree.innerHTML = ''; if (rows.length) {
            rows.sort((a, b) => { const da = Date.parse(a.created_at || '') || 0, db = Date.parse(b.created_at || '') || 0; if (db !== da) return db - da; const sa = Number(a.stt) || 0, sb = Number(b.stt) || 0; if (sb !== sa) return sb - sa; return String(b.id || '').localeCompare(String(a.id || '')); });
            rows.forEach((row, i) => {
                tree.insertAdjacentHTML('beforeend', ppTaskBlock(i + 1)); const task = tree.lastElementChild; task.dataset.id = row.id || ''; task.dataset.createdAt = row.created_at || row.createdAt || row.updated_at || ''; const nh = task.querySelector('[data-k=nhiemvu]'); if (nh) nh.innerText = row.nhiem_vu || ''; const mo = task.querySelector('[data-k=mota]'); if (mo) mo.innerText = row.mota || row.blocks?.[0]?.mota || ''; const vbsT = (row.van_ban_tinh || '').split('\n').filter(Boolean); const vbsX = (row.van_ban_xa || '').split('\n').filter(Boolean); const listT = task.querySelector('.pp-docs-tinh'); const listX = task.querySelector('.pp-docs-xa'); if (listT) { listT.innerHTML = ''; vbsT.forEach((v, idx) => { listT.insertAdjacentHTML('beforeend', `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff">${esc(v)}</div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`); }); if (!vbsT.length) listT.innerHTML = `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`; } if (listX) { listX.innerHTML = ''; vbsX.forEach(v => { listX.insertAdjacentHTML('beforeend', `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff">${esc(v)}</div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`); }); if (!vbsX.length) listX.innerHTML = `<div style="display:flex;gap:4px;align-items:center"><div contenteditable="true" data-placeholder="VD: CV 1297, ngày 15/7/2026" style="flex:1;min-height:28px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;background:#fff"></div><button onclick="if(!ppIsAdmin()){showToast('error','Không có quyền','Chỉ Admin được xóa văn bản.')}else{this.parentElement.remove()}" style="background:#fff;border:1px solid #e11d48;color:#e11d48;border-radius:6px;padding:2px 6px">×</button></div>`; }
                // restore agencies if structured
                const raw = row.blocks || []; const isObj = raw && !Array.isArray(raw) && raw.agencies; const motaRaw = isObj ? raw.mota : raw[0]?.mota || row.mota || ``; if (mo) mo.innerText = motaRaw; const ags = isObj ? raw.agencies : raw; const wrap = task.querySelector('.pp-agencies'); if (wrap && ags.length && ags[0].agency !== undefined) {
                    wrap.innerHTML = ''; ags.forEach((ag, idx) => {
                        const isFirst = idx === 0 || ag.type === 'chutri' || ag.type === 'UBND'; wrap.insertAdjacentHTML('beforeend', ppAgencyBlock(isFirst)); const el = wrap.lastElementChild; const other = el.querySelector('[data-k=agencyOther]'); if (other) { if (other.tagName === 'SELECT') { if (ag.agency) { other.value = ag.agency; if (other.value !== ag.agency) { const opt = document.createElement('option'); opt.value = ag.agency; opt.textContent = ag.agency; const otherOpt = [...other.options].find(o => o.value === '__other__'); if (otherOpt) other.insertBefore(opt, otherOpt); else other.appendChild(opt); opt.selected = true; other.value = ag.agency; } } else { if (other.options.length) other.selectedIndex = 0; } } else { other.value = ag.agency || ''; } } const other2 = el.querySelector('[data-k=agencyPhoiHop]'); if (other2) { if (other2.tagName === 'SELECT') { if (ag.agencyPhoiHop) { other2.value = ag.agencyPhoiHop; if (other2.value !== ag.agencyPhoiHop) { const opt2 = document.createElement('option'); opt2.value = ag.agencyPhoiHop; opt2.textContent = ag.agencyPhoiHop; const otherOpt2 = [...other2.options].find(o => o.value === '__other__'); if (otherOpt2) other2.insertBefore(opt2, otherOpt2); else other2.appendChild(opt2); opt2.selected = true; other2.value = ag.agencyPhoiHop; } } } else { other2.value = ag.agencyPhoiHop || ''; } } const at = el.querySelector('[data-k=agencyTask]'); if (at) at.value = ag.agencyTask || ''; const al = el.querySelector('[data-k=agencyLeader]'); if (al) al.value = ag.agencyLeader || ''; try { const ao = el.querySelector('[data-k=agencyOther]'); if (ao) ppSyncAgencyLeader(ao); } catch (e2) {} // restore persons
                        const pers = (ag.persons || []).filter(p=>!ppPersonIsBlank(p)); const pRows = [...el.querySelectorAll('.pp-person')].filter(r=>r.style.display!=='none'); pers.forEach((p, idx) => { const row = pRows[idx]; if (!row) return;['name', 'deadline', 'finish', 'progress', 'product', 'reason'].forEach(k => { const inp = row.querySelector(`[data-k=${k}]`); if (!inp) return; const v = p[k] || ''; if(inp.tagName==='SELECT'){ if(v && ![...inp.options].some(o=>o.value===v)){ const opt=document.createElement('option'); opt.value=v; opt.textContent=v; const other=[...inp.options].find(o=>o.value==='__other__'); if(other) inp.insertBefore(opt, other); else inp.appendChild(opt); } inp.value=v; if(inp.value!==v) inp.value='__other__'; } else { inp.value = inp.type === 'date' ? ppDateInputVal(v) : v; } }); }); const pcmList = ag.pcmList || []; const pcmWrap = el.querySelector('.pp-pcm-list'); if (pcmWrap) { pcmWrap.innerHTML = ''; if(pcmList && pcmList.length) pcmWrap.style.display=''; pcmList.forEach(grp => { pcmWrap.insertAdjacentHTML('beforeend', ppPCMBlock()); const blk = pcmWrap.lastElementChild; const rows2 = blk.querySelectorAll('.pp-person'); (grp.persons || []).filter(p=>!ppPersonIsBlank(p)).forEach((p, idx) => { const r2 = rows2[idx]; if (!r2) return;['name', 'deadline', 'finish', 'progress', 'product', 'reason'].forEach(k => { const inp = r2.querySelector(`[data-k=${k}]`); if (inp) { const v = inp.type === 'date' ? ppDateInputVal(p[k] || '') : (p[k] || ''); if(inp.tagName==='SELECT' && v && ![...inp.options].some(o=>o.value===v)){ const opt=document.createElement('option'); opt.value=v; opt.textContent=v; const other=[...inp.options].find(o=>o.value==='__other__'); if(other) inp.insertBefore(opt,other); else inp.appendChild(opt); } inp.value=v; } }); }); }); }
                    });
                }
            });
        } else { tree.insertAdjacentHTML('beforeend', ppTaskBlock(1)); } ppUpdateSTT(); ppUpdateAll(); ppRenderViewMode(); try { applyProvincePlanTreeFilter(); } catch (e) { }
        try { rebuildPROVAgencyFilter(); } catch (e) {}
        // F5 thu gọn tất cả nhiệm vụ
        tree.querySelectorAll('.pp-task').forEach(t => {
            const body = t.querySelector('.pp-task-body'); const btn = t.querySelector('button[onclick="ppToggleTask(this)"]');
            if (body && btn && body.style.display !== 'none') {
                // gọi toggle để thu gọn và sinh pp-summary + portal
                window.ppToggleTask(btn);
            }
        }); try { applyProvincePlanTreeFilter(); } catch (e) { }
    } catch (e) { const tree = document.getElementById('provincePlanTree'); if (tree && !tree.children.length) { tree.insertAdjacentHTML('beforeend', ppTaskBlock(1)); const t = tree.querySelector('.pp-task'); const body = t?.querySelector('.pp-task-body'); const btn = t?.querySelector('button[onclick="ppToggleTask(this)"]'); if (body && btn && body.style.display !== 'none') window.ppToggleTask(btn); } }
}

async function ppSaveOne(btn, options = {}) {
    const task = btn?.closest('.pp-task'); if (!task) return false;
    if (!ppCanEditProvinceTask(task)) { showToast('error', 'Không có quyền', 'Chỉ Admin hoặc cơ quan phụ trách/phối hợp được lưu Tỉnh giao.'); return false; }
    // Chỉ Admin được sửa Nội dung nhiệm vụ (toàn hệ thống) - chặn cả bypass
    const tree = document.getElementById('provincePlanTree');
    const idx = [...tree.querySelectorAll('.pp-task')].indexOf(task);
    const stt = idx + 1;
    let nh = task.querySelector('[data-k=nhiemvu]')?.innerText.trim() || task.querySelector('[data-k=agencyTask]')?.value.trim() || '';
    let mota = task.querySelector('[data-k=mota]')?.innerText.trim() || '';
    let vbT = [...task.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d => d.innerText.trim()).filter(Boolean).join('\n');
    let vbX = [...task.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d => d.innerText.trim()).filter(Boolean).join('\n');
    let agencies = [...task.querySelectorAll('.pp-agency')].map(ppSerializeAgency);
    // enforce first = chutri
    agencies.forEach((a, i) => a.type = i === 0 ? 'chutri' : 'phoihop');
    // Nếu không phải Admin, giữ nguyên Nội dung nhiệm vụ / Mô tả / VB / agencyTask từ DB
    if (!ppIsAdmin() && task.dataset.id) {
        try {
            let cur=null;
            try{
                const flatRes = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?select=task_name,note,source_doc,source_group,source_form,issuing_authority&id=eq.${encodeURIComponent(task.dataset.id)}&source_sheet=eq.province_plan`, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if(flatRes.ok){
                    const arr=await flatRes.json(); const f=Array.isArray(arr)?arr[0]:arr;
                    if(f && f.note){
                        try{ const n=JSON.parse(f.note||''); if(n && n.blocks){ cur={nhiem_vu: f.task_name, blocks: n.blocks, van_ban_tinh: [f.source_doc, f.issuing_authority, f.source_form].filter(Boolean).join('\n'), van_ban_xa: f.source_group||''}; } }catch{}
                    }
                }
            }catch{}
            if(!cur){
                const curRes = await fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks?select=nhiem_vu,blocks,van_ban_tinh,van_ban_xa&id=eq.${encodeURIComponent(task.dataset.id)}`, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (curRes.ok) {
                    const curArr = await curRes.json();
                    cur = Array.isArray(curArr) ? curArr[0] : curArr;
                }
            }
            if (cur) {
                    const curNh = String(cur.nhiem_vu || "").trim();
                    const curMota = String(cur.blocks?.mota || "").trim();
                    const curVbT = String(cur.van_ban_tinh || "").trim();
                    const curVbX = String(cur.van_ban_xa || "").trim();
                    if (curNh && curNh !== nh) { showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ — đã giữ nguyên."); const el = task.querySelector('[data-k=nhiemvu]'); if (el) el.innerText = curNh; }
                    if (curMota && curMota !== mota) { const el = task.querySelector('[data-k=mota]'); if (el) el.innerText = curMota; }
                    nh = curNh || nh; mota = curMota || mota; vbT = curVbT || vbT; vbX = curVbX || vbX;
                    if (Array.isArray(cur.blocks?.agencies)) {
                        let _deadlineChanged = false;
                        agencies = agencies.map((ag, i) => {
                            const cAg = cur.blocks.agencies[i];
                            if (cAg) {
                                const _ag = { ...ag, agency: cAg.agency || ag.agency, agencyTask: cAg.agencyTask || ag.agencyTask, type: cAg.type || ag.type };
                                if (Array.isArray(cAg.persons) && Array.isArray(_ag.persons)) {
                                    _ag.persons = _ag.persons.map((p, pi) => {
                                        const cP = cAg.persons[pi];
                                        if (cP && String(p.deadline||"").trim() !== String(cP.deadline||"").trim()) _deadlineChanged = true;
                                        return cP ? { ...p, deadline: cP.deadline || p.deadline } : p;
                                    });
                                }
                                if (Array.isArray(cAg.pcmList) && Array.isArray(_ag.pcmList)) {
                                    _ag.pcmList = _ag.pcmList.map((pcm, pci) => {
                                        const cPcm = cAg.pcmList[pci];
                                        if (cPcm && Array.isArray(cPcm.persons)) {
                                            const _persons = pcm.persons.map((p, pi) => {
                                                const cP = cPcm.persons[pi];
                                                if (cP && String(p.deadline||"").trim() !== String(cP.deadline||"").trim()) _deadlineChanged = true;
                                                return cP ? { ...p, deadline: cP.deadline || p.deadline } : p;
                                            });
                                            return { ...pcm, persons: _persons };
                                        }
                                        return pcm;
                                    });
                                }
                                return _ag;
                            }
                            return ag;
                        });
                        if (_deadlineChanged) showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành — đã giữ nguyên hạn cũ cho các dòng.");
                    }
            }
        } catch {}
    } else if (!ppIsAdmin() && !task.dataset.id) {
        return showToast('error', 'Không có quyền', 'Chỉ Admin được tạo nhiệm vụ mới.');
    }
    const preview = (nh || '').slice(0, 70);
    const ok = await provinceConfirm({ icon: '💾', title: task.dataset.id ? 'Cập nhật nhiệm vụ' : 'Tạo nhiệm vụ mới', message: `Nhiệm vụ ${stt}: "${preview || 'Chưa nhập'}" — ${task.dataset.id ? 'cập nhật' : 'tạo mới'} trên Supabase?`, bodyHtml: `<div style="font-size:12px;color:#475569">Sẽ ghi <b>${agencies.length} cơ quan</b> · <b>${[...task.querySelectorAll('.pp-person')].length} người</b> vào DB. <br><span style="color:#0ea5e9">Thống nhất: lưu vào <b>province_tasks</b> (officer_name = Lãnh đạo).</span></div>`, confirmText: task.dataset.id ? 'Cập nhật' : 'Tạo mới', cancelText: 'Hủy', confirmClass: 'btn-primary' });
    if (!ok) return false;
    // Unified: 1 block = 1 row province_tasks, officer_name = Lãnh đạo, note.blocks = full tree
    const primaryAg = agencies[0] || {}; const primaryPerson = (primaryAg.persons||[])[0] || {};
    // Lãnh đạo UBND là agencyLeader của agency đầu, nếu không có thì lấy tên person đầu
    const leaderUBND = String(primaryAg.agencyLeader||primaryPerson.name||'').trim() || 'Chưa phân công';
    const leaderPhong = String((agencies[1]&&agencies[1].agencyLeader)||'').trim();
    const flatPayload = {
        officer_name: leaderUBND,
        task_name: nh || primaryAg.agencyTask || 'Nhiệm vụ Tỉnh giao',
        unit_name: String(primaryAg.agency||'').trim(),
        role: leaderPhong,
        specialist_name: String(primaryPerson.name||leaderUBND).trim(),
        deadline: (function(){ try{ return dateToDb(primaryPerson.deadline)||null; }catch{ return null; }})(),
        completed_date: (function(){ try{ return dateToDb(primaryPerson.finish)||null; }catch{ return null; }})(),
        product: String(primaryPerson.product||'').trim(),
        result: String(primaryPerson.product||'').trim(),
        progress: String(primaryPerson.progress||'').trim(),
        overdue_reason: String(primaryPerson.reason||'').trim(),
        source_doc: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[0]||'',
        source_group: String(vbX||'').trim(),
        source_form: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[2]||'',
        issuing_authority: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[1]||'',
        implementation_detail: String(mota||'').trim(),
        note: JSON.stringify({blocks:{mota, agencies}}),
        amount: String(nh||'').trim(),
        source_sheet: "province_plan",
        source_row: Math.floor(Math.random()*2147483647),
        status: (function(){ try{ const tmp={officer_name:leaderUBND, deadline: primaryPerson.deadline, completed_date: primaryPerson.finish, result: primaryPerson.product, progress: primaryPerson.progress, attachment_path:''}; return provinceStatusLabel(provinceStatusFor(tmp)); }catch{ return 'Đang triển khai'; }})(),
        updated_at: new Date().toISOString()
    };
    // deadline là NOT NULL ở DB: nếu trống thì lưu "" thay vì null
    if(!flatPayload.deadline) flatPayload.deadline = "";
    const id = task.dataset.id;
    const origText = btn.textContent; btn.disabled = true; btn.textContent = '⏳ Lưu...';
    try {
        let r; let isFlat = false;
        // Thử unified trước (province_tasks)
        if (id) {
            // PATCH thử province_tasks trước
            r = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?id=eq.${encodeURIComponent(id)}&source_sheet=eq.province_plan`, { method: 'PATCH', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(flatPayload) });
            const tx = await r.text(); let j=null; try{ j=JSON.parse(tx); }catch{}
            const saved = Array.isArray(j)?j[0]:j;
            if (r.ok && saved && saved.id) { isFlat=true; task.dataset.id=saved.id; if(!options.silent) showToast('success','Đã lưu',`Nhiệm vụ ${stt} đã lưu (province_tasks).`); writeActivity('Tỉnh giao - Lưu 1 nhiệm vụ', {stt, id: task.dataset.id, unified:true}); try{ await loadPROVData(true); }catch{} return true; }
            // Fallback PATCH blocks nếu không phải flat row
            r = await fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify({stt, van_ban_tinh: vbT, van_ban_xa: vbX, nhiem_vu: nh, blocks:{mota, agencies}}) });
        } else {
            r = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks`, { method: 'POST', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(flatPayload) });
            isFlat=true;
        }
        if (!r.ok) throw new Error(await r.text());
        const j = await r.json(); const saved = Array.isArray(j) ? j[0] : j;
        if (!saved || !saved.id) throw new Error(`Máy chủ không cập nhật bản ghi ${isFlat?'province_tasks':'province_plan_blocks'} (id=${id || 'mới'}). Hãy tải lại dữ liệu rồi thử lại.`);
        if (saved && saved.id) task.dataset.id = saved.id;
        if (!options.silent) showToast('success', 'Đã lưu', `Nhiệm vụ ${stt} đã lưu.`);
        writeActivity('Tỉnh giao - Lưu 1 nhiệm vụ', { stt, id: task.dataset.id, unified:isFlat });
        try{ if(isFlat) await loadPROVData(true); }catch{}
        return true;
    } catch (e) { showToast('error', 'Không lưu được', e.message); return false; }
    finally { btn.disabled = false; btn.textContent = origText; }
}

async function provincePlanSave() {
    if (!ppIsAdmin()) { showToast('error', 'Không có quyền', 'Chỉ Admin được lưu Tỉnh giao.'); return false; }
    const tree = document.getElementById('provincePlanTree'); if (!tree) return false;
    const tasks = [...tree.querySelectorAll('.pp-task')];
    const okAll = await provinceConfirm({ icon: '✅', title: 'Xác nhận lưu toàn bộ', message: `Lưu ${tasks.length} nhiệm vụ về Supabase?`, bodyHtml: `<div style="font-size:12px;color:#475569">Thống nhất: sẽ <b>xóa toàn bộ nhiệm vụ Tỉnh giao dạng cây cũ (province_plan)</b> và ghi lại ${tasks.length} nhiệm vụ vào <b>province_tasks</b> (officer_name = Lãnh đạo).<br>Nếu DB chưa sẵn sàng, sẽ fallback về <b>province_plan_blocks</b>.</div>`, confirmText: `Lưu ${tasks.length} nhiệm vụ`, cancelText: 'Hủy', confirmClass: 'btn-primary' });
    if (!okAll) return false;
    // Build flat payloads (1 row per block)
    const flatRows = tasks.map((t,i)=>{
        const nh=t.querySelector('[data-k=nhiemvu]')?.innerText.trim()||t.querySelector('[data-k=agencyTask]')?.value.trim()||'';
        const mota=t.querySelector('[data-k=mota]')?.innerText.trim()||'';
        const vbT=[...t.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean).join('\n');
        const vbX=[...t.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean).join('\n');
        const agencies=[...t.querySelectorAll('.pp-agency')].map(ag=>ppSerializeAgency(ag));
        const primaryAg=agencies[0]||{}; const primaryPerson=(primaryAg.persons||[])[0]||{};
        const leaderUBND=String(primaryAg.agencyLeader||primaryPerson.name||'').trim()||'Chưa phân công';
        const leaderPhong=String((agencies[1]&&agencies[1].agencyLeader)||'').trim();
        return {
            officer_name: leaderUBND, task_name: nh||primaryAg.agencyTask||'Nhiệm vụ Tỉnh giao', unit_name: String(primaryAg.agency||'').trim(), role: leaderPhong,
            specialist_name: String(primaryPerson.name||leaderUBND).trim(),
            deadline: (function(){ try{ return dateToDb(primaryPerson.deadline)||''; }catch{ return ''; }})(),
            completed_date: (function(){ try{ return dateToDb(primaryPerson.finish)||null; }catch{ return null; }})(),
            product: String(primaryPerson.product||'').trim(), result: String(primaryPerson.product||'').trim(), progress: String(primaryPerson.progress||'').trim(), overdue_reason: String(primaryPerson.reason||'').trim(),
            source_doc: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[0]||'', source_group: String(vbX||'').trim(), source_form: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[2]||'', issuing_authority: String(vbT||'').split('\n').map(s=>s.trim()).filter(Boolean)[1]||'',
            implementation_detail: String(mota||'').trim(), note: JSON.stringify({blocks:{mota, agencies}}), amount: String(nh||'').trim(),
            source_sheet: "province_plan", source_row: Math.floor(Math.random()*2147483647), status: "Đang triển khai", updated_at: new Date().toISOString(), attachment_path:"", attachment_name:"", attachment_type:"", attachment_size:0, attachment_approved:false, attachment_approved_at:null, attachment_approved_by:"", staff_note:"", admin_note:"", phat_sinh:false
        };
    }).map(r=>{ if(!r.deadline) r.deadline=""; return r; });
    // Try unified save first
    try {
        const del = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?source_sheet=eq.province_plan`, { method: 'DELETE', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
        // Supabase PostgREST DELETE needs id filter; dùng source_sheet filter có thể bị chặn RLS, thử id=neq...
        let delOk = del.ok;
        if(!delOk){
            // Fallback: xóa bằng id neq dummy
            const del2 = await fetch(`${SUPABASE_URL}/rest/v1/province_tasks?id=neq.00000000-0000-0000-0000-000000000000&source_sheet=eq.province_plan`, { method: 'DELETE', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
            delOk = del2.ok;
            if(!delOk && del2.status!==404) throw new Error(await del2.text());
        }
        for(const row of flatRows){
            let r=await fetch(`${SUPABASE_URL}/rest/v1/province_tasks`, {method:'POST', headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`, 'Content-Type':'application/json', Prefer:'return=representation'}, body:JSON.stringify(row)});
            let tx=await r.text();
            if(!r.ok && tx && (tx.includes('source_doc')||tx.includes('source_group')||tx.includes('source_form')||tx.includes('issuing_authority')||tx.includes('note')||tx.includes('blocks'))){
                // Fallback khi DB thiếu cột: bỏ cột lỗi
                try{ const p={...row}; ['source_doc','source_group','source_form','issuing_authority'].forEach(k=>{ if(tx.includes(k)) delete p[k]; }); r=await fetch(`${SUPABASE_URL}/rest/v1/province_tasks`, {method:'POST', headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`, 'Content-Type':'application/json', Prefer:'return=representation'}, body:JSON.stringify(p)}); tx=await r.text(); }catch{}
            }
            if(!r.ok) throw new Error(tx||`HTTP ${r.status}`);
            const j=JSON.parse(tx||'[]'); const saved=Array.isArray(j)?j[0]:j; if(!saved||!saved.id) throw new Error('Máy chủ không trả về bản ghi đã lưu (province_tasks).');
        }
        showToast('success','Đã lưu',`Đã lưu ${flatRows.length} nhiệm vụ vào province_tasks (thống nhất).`); writeActivity('Tỉnh giao - Lưu Kế hoạch', {count: flatRows.length, unified:true}); try{ await loadPROVData(true); }catch{} try{ await provincePlanLoad(); }catch{} return true;
    } catch(e){
        console.warn('provincePlanSave unified fail, fallback blocks', e);
        // Fallback to old blocks table
        try{
            const payload=tasks.map((t,i)=>{ const nh=t.querySelector('[data-k=nhiemvu]')?.innerText.trim()||t.querySelector('[data-k=agencyTask]')?.value.trim()||''; const mota=t.querySelector('[data-k=mota]')?.innerText.trim()||''; const vbT=[...t.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean).join('\n'); const vbX=[...t.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d=>d.innerText.trim()).filter(Boolean).join('\n'); const agencies=[...t.querySelectorAll('.pp-agency')].map(ag=>ppSerializeAgency(ag)); return {stt:i+1, van_ban_tinh:vbT, van_ban_xa:vbX, nhiem_vu:nh, blocks:{mota, agencies}, province_task_id:null}; });
            const del=await fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks?id=neq.00000000-0000-0000-0000-000000000000`, {method:'DELETE', headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`}}); if(!del.ok && del.status!==404) throw new Error(await del.text());
            for(const row of payload){ const r=await fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks`, {method:'POST', headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`, 'Content-Type':'application/json', Prefer:'return=representation'}, body:JSON.stringify(row)}); if(!r.ok) throw new Error(await r.text()); const j=await r.json(); if(!(Array.isArray(j)?j[0]:j)?.id) throw new Error('Máy chủ không trả về bản ghi đã lưu.'); }
            showToast('success','Đã lưu',`Đã lưu ${payload.length} nhiệm vụ (fallback blocks).`); writeActivity('Tỉnh giao - Lưu Kế hoạch', {count: payload.length, fallback:true}); return true;
        }catch(e2){ showToast('error','Không lưu được', e2.message); return false; }
    }
}

function ppPastePlain(e) {
    const el = e.target.closest('[contenteditable="true"], input, textarea');
    if (!el) return;
    if (el.isContentEditable) {
        const raw = (e.clipboardData || window.clipboardData)?.getData('text/plain');
        if (raw !== undefined) {
            e.preventDefault();
            const text = String(raw || '');
            if (document.queryCommandSupported && document.queryCommandSupported('insertText')) {
                document.execCommand('insertText', false, text);
            } else {
                const sel = window.getSelection();
                if (sel && sel.rangeCount) {
                    sel.deleteFromDocument();
                    sel.getRangeAt(0).insertNode(document.createTextNode(text));
                    try { sel.collapseToEnd(); } catch (_) { }
                } else { el.innerText += (el.innerText ? '\n' : '') + text; }
            }
            ppUpdateAll();
        }
    }
}

function provinceConfirm(opts) { return new Promise(res => { PROVINCE_CONFIRM_RESOLVE = res; openProvinceConfirm(opts); }); }
