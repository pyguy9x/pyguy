// js/dev-map.js - Ban do nhanh (AUTO-GEN boi tools/gen-dev-map.js 2026-09-28), khong import vao prod, chi tra cuu IDE
// Dung: Grep tu khoa → Read file + offset theo ban do nay. MODULE_MAP: ham da tach khoi legacy.js
// legacy.js hien tai: 6733 dong (goc 12359); modules: utils/auth/ttbtv/prov-bch/pp-mttq + store.js
// NOTE: Dạng classic script (window globals) để node --check pass và không lỗi browser khi load thường

var SECTION_MAP = [
  { id: "L1", range: "8-1173", key: "safeLSSet 8, safeLSGet 9, readCache 10, writeCache 11, _obfOfficers 14" },
  { id: "L2", range: "1179-4532", key: "foldHonorText 1179, isLeadershipPosition 1184, updateGlobalHonors 1194, openHonorBestTasks 1290, openHonorLeaderTasks 1299" },
  { id: "L3", range: "4553-5266", key: "resetPROVDrillFilters 4553, renderPROVAddTaskRow 4556, renderPROVDrill 4592, closePROVDrill 4637, renderPROVCurrentAttachment 4649" },
  { id: "L4", range: "5267-5876", key: "exportWorkspaceExcel 5267, focusFirstEditable 5410, fillSelect 5466, resetVPUBDrillFilters 5479, renderVPUBDrill 5480" },
  { id: "L5", range: "6127-6716", key: "ppNormalizeDateInputs 6127, vpubWrapDateInput 6139, setupTTBTVDateFields 6192, bchWrapDateInput 6202, bchDateDisplay 6237" }
];

var MODULE_MAP = [
  { file: "js/store.js", lines: 18, funcs: 0 },
  { file: "js/modules/utils.js", lines: 863, funcs: 60, range: "6-862" },
  { file: "js/modules/auth.js", lines: 1336, funcs: 79, range: "7-1335" },
  { file: "js/modules/ttbtv.js", lines: 2192, funcs: 142, range: "5-2191" },
  { file: "js/modules/prov-bch.js", lines: 1864, funcs: 75, range: "9-1863" },
  { file: "js/modules/pp-mttq.js", lines: 1178, funcs: 85, range: "5-1177" }
];

var SUPABASE_TABLES = ["officers","tt_btv_officers","province_officers","action_100_days_officers","office_officers","tasks","tt_btv_tasks","province_tasks","province_plan_blocks","action_100_days_tasks","vpub_tasks","office_tasks","department_tasks","mttq_kpi_people","mttq_kpi_catalog","mttq_kpi_tasks","activity_logs"];

var CACHE_KEYS = ["vp_tasks_cache","bch_officers_cache","bch_tasks_cache","ttbtv_officers_cache","ttbtv_tasks_cache","province_officers_cache","province_tasks_cache","vpub_tasks_cache","action100_tasks_cache"];

var QUICK_GREP = {
  saveEditTask: "Grep saveEditTask -> Read js/legacy.js 868/30",
  mergeDepartmentAndOffice: "Grep mergeDepartmentAndOffice -> Read js/legacy.js 1957/30",
  renderOfficeDrillRows: "Grep renderOfficeDrillRows -> Read js/legacy.js 3080/30",
  homeFilteredTasks: "Grep homeFilteredTasks -> Read js/legacy.js 1442/30",
  renderBCHTable: "Grep renderBCHTable -> Read js/legacy.js 3711/30",
  renderBCHDrill: "Grep renderBCHDrill -> Read js/legacy.js 3538/30",
  uploadBCHTaskFile: "Grep uploadBCHTaskFile -> Read js/modules/prov-bch.js 449/30",
  resetBCHFilters: "Grep resetBCHFilters -> Read js/modules/prov-bch.js 703/30",
  renderTTBTVTable: "Grep renderTTBTVTable -> Read js/legacy.js 4127/30",
  renderPROVDrill: "Grep renderPROVDrill -> Read js/legacy.js 4592/30",
  renderPROVTable: "Grep renderPROVTable -> Read js/legacy.js 4683/30",
  loadMTTQKPIData: "Grep loadMTTQKPIData -> Read js/modules/pp-mttq.js 299/30",
  provincePlanLoad: "Grep provincePlanLoad -> Read js/modules/pp-mttq.js 888/30",
  applyTokenMultiScope: "Grep applyTokenMultiScope -> Read js/modules/auth.js 1097/30",
  userCan: "Grep userCan -> Read js/modules/auth.js 1136/30",
  _obfToken: "Grep _obfToken -> Read js/modules/auth.js 7/30",
  initAuth: "Grep initAuth -> Read js/modules/auth.js 314/30",
  loadData: "Grep loadData -> Read js/legacy.js 2025/30"
};

// Export cho ca 2 moi truong
if (typeof window !== 'undefined') {
  window.DEV_MAP = { SECTION_MAP, MODULE_MAP, SUPABASE_TABLES, CACHE_KEYS, QUICK_GREP };
}
if (typeof globalThis !== 'undefined') {
  globalThis.DEV_MAP = { SECTION_MAP, MODULE_MAP, SUPABASE_TABLES, CACHE_KEYS, QUICK_GREP };
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SECTION_MAP, MODULE_MAP, SUPABASE_TABLES, CACHE_KEYS, QUICK_GREP };
}
