// js/email.js — gửi thông báo deadline qua email
// Dùng window.showToast(type, title, message) từ legacy.js

const SUPABASE_URL = window.SUPABASE_URL || window.SUPABASE_CONFIG?.url || "https://zipvocbtmilyeuhqqrur.supabase.co";

function _t(type, title, message) {
  if (typeof window.showToast === 'function') window.showToast(type, title, message);
}

function canSendDeadlineEmail(task) {
  if (task.status === "\u0051u\u00e1 h\u1ea1n") return true;
  const rawDeadline = task.due || task.deadline || task.han || task.ngayHetHan;
  if (!rawDeadline) return false;
  const deadline = new Date(`${rawDeadline}T00:00:00`);
  if (Number.isNaN(deadline.getTime())) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const daysRemaining = Math.round((deadline - today) / 86400000);
  return daysRemaining >= 0 && daysRemaining <= 3;
}

window.handleSendWithSavedEmail = async function (rawTask) {
  if (!rawTask) {
    _t("error", "Lỗi", "Không tìm thấy dữ liệu nhiệm vụ.");
    return;
  }
  if (!canSendDeadlineEmail(rawTask)) {
    _t("error", "Chỉ gửi được", "Chỉ gửi thông báo cho nhiệm vụ quá hạn hoặc sắp đến hạn trong 3 ngày.");
    return;
  }

  const lastSent = Number(localStorage.getItem("deadline_email_last_sent") || 0);
  const remaining = 10000 - (Date.now() - lastSent);
  if (remaining > 0) {
    _t("error", "Chờ thêm", `Vui lòng chờ ${Math.ceil(remaining / 1000)} giây trước khi gửi tiếp.`);
    return;
  }

  const taskData = {
    task_name: rawTask.task_name || rawTask.task || rawTask.name || rawTask.ten || rawTask.title || "",
    owner: rawTask.owner || rawTask.owner_name || rawTask.phuTrach || rawTask.nguoiPhuTrach || "",
    deadline: rawTask.deadline || rawTask.due || rawTask.han || rawTask.ngayHetHan || "",
    attachment_link: rawTask.attachment_link || rawTask.attachment_path || rawTask.fileUrl || "",
    admin_note: rawTask.admin_note || rawTask.ghiChu || rawTask.note || ""
  };

  let email = localStorage.getItem("user_email") || localStorage.getItem("deadline_email");
  if (!email) {
    email = (prompt("Nhập email nhận thông báo:") || "").trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      _t("error", "Email không hợp lệ", "Vui lòng nhập email đúng định dạng.");
      return;
    }
    localStorage.setItem("user_email", email);
  }

  try {
    const anonKey = window.SUPABASE_CONFIG?.anonKey || "";
    const response = await fetch(`${SUPABASE_URL}/functions/v1/send-email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(anonKey ? { apikey: anonKey, Authorization: `Bearer ${anonKey}` } : {})
      },
      body: JSON.stringify({ ...taskData, to_email: email })
    });
    if (!response.ok) {
      const details = await response.text();
      throw new Error(details || `HTTP ${response.status}`);
    }
    localStorage.setItem("deadline_email_last_sent", String(Date.now()));
    if (typeof window.writeActivity === "function") window.writeActivity("Gửi thông báo email", { task: taskData.task_name, email });
    _t("success", "Đã gửi", "Đã gửi thông báo qua email.");
  } catch (error) {
    _t("error", "Gửi thất bại", `Không gửi được email: ${error.message || "Lỗi kết nối"}`);
  }
};

window.sendDeadlineEmail = function (id) {
  let savedUser = null;
  try { savedUser = JSON.parse(localStorage.getItem("vp_demo_user") || "null"); } catch (e) { savedUser = null; }
  if (!savedUser || savedUser.role !== "admin") {
    _t("error", "Không có quyền", "Chỉ Admin được gửi thông báo.");
    return Promise.resolve();
  }
  const task = window.DATA && window.DATA[id];
  try {
    return window.handleSendWithSavedEmail(task);
  } catch (error) {
    _t("error", "Lỗi", `Không thể gửi email: ${error.message || "Lỗi không xác định"}`);
    return Promise.resolve();
  }
};