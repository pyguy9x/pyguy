# SPLIT_PLAN — tách js/legacy.js (giữ nguyên logic, chỉ tách)

Nguồn: LEGACY_MAP.md. Không sửa logic, không đổi API, không đổi hành vi.

## Thứ tự tách

1. `js/modules/store.js` trước (globals dùng chung)
2. `js/modules/utils.js` (nhóm 2: 60 hàm)
3. `js/modules/auth.js` (nhóm 1: 80 hàm)

## 1. js/modules/store.js

Chứa: `CURRENT_USER`, `SUPABASE_URL`, `SUPABASE_KEY`, `STORAGE_BUCKET`, `MAX_FILE_BYTES`, `ALLOWED_EXTENSIONS`, `STAFF_TOKENS`, `MTTQ_TOKENS`, `MTTQ_ADMIN_TOKEN`, `DEPARTMENT_TOKENS`, `STAFF_ACTION100_TOKENS`, `BCH_FULL_TOKENS`, `BCH_BROAD_TOKENS`, `TTBTV_ALLOWED_TOKENS`, `DEMO_MODE`, `BACKUP_TABLES`, `ACTIVITY_LOG_ROWS`, `editingDataIndex`.

```js
// Phase 1 (giữ logic, classic script): gắn window
window.CURRENT_USER = window.CURRENT_USER || null;
window.SUPABASE_URL = window.SUPABASE_URL || "";
window.SUPABASE_KEY = window.SUPABASE_KEY || "";
window.STORAGE_BUCKET = window.STORAGE_BUCKET || "";
window.STAFF_TOKENS = window.STAFF_TOKENS || [];
window.MTTQ_TOKENS = window.MTTQ_TOKENS || [];
window.MTTQ_ADMIN_TOKEN = window.MTTQ_ADMIN_TOKEN || "";
window.DEPARTMENT_TOKENS = window.DEPARTMENT_TOKENS || [];
window.STAFF_ACTION100_TOKENS = window.STAFF_ACTION100_TOKENS || [];
window.BCH_FULL_TOKENS = window.BCH_FULL_TOKENS || [];
window.BCH_BROAD_TOKENS = window.BCH_BROAD_TOKENS || [];
window.TTBTV_ALLOWED_TOKENS = window.TTBTV_ALLOWED_TOKENS || [];

// Phase 2 (ES module): export
export { CURRENT_USER, SUPABASE_URL, SUPABASE_KEY, STORAGE_BUCKET };
export { STAFF_TOKENS, MTTQ_TOKENS, MTTQ_ADMIN_TOKEN, DEPARTMENT_TOKENS };
export { STAFF_ACTION100_TOKENS, BCH_FULL_TOKENS, BCH_BROAD_TOKENS, TTBTV_ALLOWED_TOKENS };
export function setCurrentUser(u) { CURRENT_USER = u; window.CURRENT_USER = u; }
```

Import: không import ai. Export: toàn bộ biến trên.
`legacy.js` + `utils.js` + `auth.js` đọc từ `store.js` (phase 1: dùng `window.*` trực tiếp, không cần import).

## 2. js/modules/utils.js (60 hàm, rời rạc — không phải 1 block)

Ranges chính (LEGACY_MAP nhóm 2): 8–11, 29–60, 80–177, 218–260, 262–365, 389–517, 851, 1058–1098, 2153–2331, 2881–2893, 9367–9540, 9963–9979, 10674–10677, 11162–11295, 11379–11380.

Hàm: `safeLSSet, safeLSGet, readCache, writeCache, _obfOfficers, _deobfOfficers, writeOfficersCache, readOfficersCache, demoMaskName, demoMaskText, demoEnsureNames, isDemoWriteBlocked, showDemoBanner, demoMaskProvinceInputs, getDemoSnapshot, debounce, getTimeRange, isDateInTimeRange, getCreationDate, parseDeadlineAny, writeActivity, renderActivityLog, deleteActivityLog, filterActivityLog, openActivityLog, setBackupStatus, openBackupModal, closeBackupModal, backupData, restoreBackup, showToast, safeFileName, encodePath, parseDate, formatDate, dateToDb, dateMask, requireValidDate, dayDiff, hasMeaningfulProduct, calculateTaskStatus, statusBadgeClass, urgencyInfo, canonicalStatus, dbStatus, normalizeTask, alertHTML, exportWorkspaceExcelDo, exportWorkspaceExcel, setupVPUBDateFields, ppParseDate, ppDateInputVal, ppDateDisplayVal, ppDispDate, ppNormalizeDateInputs, vpubWrapDateInput, setupTTBTVDateFields, setupBCHDateFields, ppNorm, ppInitials`.

```js
// Phase 1: dùng global từ store.js, không import. Cuối file gắn window nếu cần.
window.safeLSSet = safeLSSet; // ... (chỉ các hàm legacy.js/index.html gọi trực tiếp qua onclick)
// Phase 2:
import { CURRENT_USER, SUPABASE_URL, SUPABASE_KEY, DEMO_MODE } from './store.js';
export { safeLSSet, safeLSGet, readCache, writeCache, debounce, parseDate, formatDate, showToast, backupData, restoreBackup, exportWorkspaceExcel };
export * from './store.js'; // không — chỉ import cái cần, tránh re-export vòng
```

Import cần: `CURRENT_USER, SUPABASE_*, DEMO_*` (cho backup/activity/demo). Export: 60 hàm trên.
Lưu ý: `writeActivity/openActivityLog/backupData/restoreBackup` dùng `CURRENT_USER` mutable → phải đọc `window.CURRENT_USER` (phase 1) hoặc `import { getCurrentUser }` (phase 2), không copy giá trị.

## 3. js/modules/auth.js (80 hàm, rời rạc)

Ranges chính (LEGACY_MAP nhóm 1): 13–27, 205–213, 519–850, 863–868, 1999, 3582–3633, 4523–4531, 5083–5129, 5923–5954, 6322–6435, 7932–7937, 8155–8272, 10134, 10527–10544, 11378–11454, 12021–12344.

Hàm: `_obfToken, _deobfToken, _readStoredToken, getBchViewTier, isBchPrivilegedViewer, userScopeLabel, userRoleLabel, canAccess*, isMTTQAdmin, syncUserWorkspaceVisibility, canAddVPUBTask, syncVPUBQuickAddBtn, syncAction100OverdueLabel, setLoggedInUser, resolveWorkspaceToken, loginWithToken, logoutUser, initAuth, canEditTask` + role/prov/bch/ttbtv/action100/pp-scope helpers + `fetchServerOverrides, getTokenMultiScopeMap, setTokenMultiScopeMap, saveServerOverrides, isNGNUser, isUBNDTaskForNGN, canNGNEditTask, userHasExtraScope, computeDefaultPerms, getEffectivePerms, applyTokenMultiScope, userCan, openSetRoleModal, closeSetRole*, confirmSetRolePassword, loadSetRoleTokens, renderSetRoleTable, collectSetRoleOverrides, saveSetRole, clearSetRoleOverrides`.

```js
// Phase 1: dùng global từ store.js + hàm utils.js (safeLS*). Thứ tự script: store → utils → auth.
window.setLoggedInUser = setLoggedInUser; window.loginWithToken = loginWithToken;
window.logoutUser = logoutUser; window.initAuth = initAuth; window.userCan = userCan;
// Phase 2:
import { CURRENT_USER, SUPABASE_URL, SUPABASE_KEY, setCurrentUser } from './store.js';
import { safeLSGet, safeLSSet, showToast } from './utils.js';
export { setLoggedInUser, loginWithToken, logoutUser, initAuth, userCan, getEffectivePerms };
```

Import cần: từ `store.js` (tokens + setter), từ `utils.js` (`safeLSGet/Set, showToast`). Export: hàm auth dùng chéo (login/logout/initAuth/userCan/canEdit*).
Lưu ý giữ nguyên: `setLoggedInUser` là nơi duy nhất gán `CURRENT_USER` → mọi module khác chỉ đọc.

## Quy tắc tách (giữ nguyên logic)

- Copy-paste nguyên thân hàm + đúng thứ tự ranges trên, không refactor, không đổi tên.
- Phase 1: `<script src="js/modules/store.js">` → `utils.js` → `auth.js` → `js/legacy.js` (xóa dần hàm đã tách khỏi legacy.js).
- Kiểm tra sau mỗi bước: `git diff --name-only`, mở index.html test login/token/phân quyền.
