// /api/admin.js - xác thực token qua Supabase (4 bảng chính), không hardcode token thật trong source
// Token thật lưu ở 4 bảng: officers, tt_btv_officers, province_officers, office_officers (giữ nguyên data cũ, chỉ thêm nếu thiếu)
// Fallback demo: ADM-MAUA-adm (giữ theo yêu cầu), còn lại phải nằm trong DB hoặc env TOKENS_JSON (không commit)

async function queryOfficer(url, key, table, token) {
  try {
    const q = encodeURIComponent(token);
    // office_officers không có cột unit, mttq_kpi_people không có cột token -> xử lý riêng
    let select = "id,name,token,title,unit";
    if (table === "office_officers") select = "id,name,token,title";
    if (table === "mttq_kpi_people") return null; // bảng này không có token, bỏ qua ở server
    const r = await fetch(`${url}/rest/v1/${table}?select=${select}&token=eq.${q}&limit=1`, {
      headers: { apikey: key, Authorization: `Bearer ${key}` }
    });
    if (!r.ok) return null;
    const arr = await r.json();
    const row = Array.isArray(arr) ? arr[0] : arr;
    if (row && String(row.token || "").trim() === token) return row;
  } catch {}
  return null;
}

function tryEnvTokens(token) {
  // Cho phép cấu hình token tạm qua env (Vercel) dạng JSON: {"YOUR_TOKEN":"Tên hiển thị",...}
  // Không hardcode token trong source, chỉ đọc env khi DB chưa có - suy scope từ name
  try {
    const raw = process.env.TOKENS_JSON || process.env.DEPARTMENT_TOKENS_JSON || "";
    if (!raw) return null;
    const map = JSON.parse(raw);
    if (map && typeof map === "object" && map[token]) {
      const name = String(map[token]).trim();
      const isNGN = name === "Nguyễn Giang Nam";
      if (name === "CV nhập liệu") return { id: "data-entry-cv", name, role: "staff", scope: "data_entry", isNGN };
      if (name === "VPUB") return { id: "department-vpub-maua", name, role: "department", scope: "vpub", isNGN };
      if (name === "Trần Văn Hùng" && String(token).includes("MTTQ")) return { id: "mttq-" + token.slice(-10), name, role: "staff", scope: "mttq", title: "Cán bộ MTTQ", unit: "MTTQ", mttqAdmin: true, isNGN };
      if (String(name).includes("MTTQ")) return { id: "mttq-" + token.slice(-10), name, role: "staff", scope: "mttq", title: "Cán bộ MTTQ", unit: "MTTQ", mttqAdmin: false, isNGN };
      if (String(token).startsWith("CQ-")) return { id: "department-" + token.slice(8).toLowerCase(), name, role: "department", scope: "action100", isNGN };
      return { id: "env-" + token.slice(-10), name, role: "staff", scope: "office", isNGN };
    }
  } catch {}
  return null;
}

async function getRoleOverrides(supaUrl, supaKey) {
  try {
    const r = await fetch(`${supaUrl}/rest/v1/role_overrides?select=token,perms`, { headers: { apikey: supaKey, Authorization: `Bearer ${supaKey}` } });
    if (!r.ok) return null;
    const arr = await r.json();
    if (!Array.isArray(arr)) return null;
    const map = {};
    arr.forEach(row => { if (row.token && row.perms && typeof row.perms === 'object') map[row.token] = row.perms; });
    return map;
  } catch { return null; }
}
async function getRoleOverrideForToken(supaUrl, supaKey, token) {
  try {
    const q = encodeURIComponent(token);
    const r = await fetch(`${supaUrl}/rest/v1/role_overrides?select=perms&token=eq.${q}&limit=1`, { headers: { apikey: supaKey, Authorization: `Bearer ${supaKey}` } });
    if (!r.ok) return null;
    const arr = await r.json();
    const row = Array.isArray(arr) ? arr[0] : null;
    return row && row.perms && typeof row.perms === 'object' ? row.perms : null;
  } catch { return null; }
}
async function saveRoleOverrides(supaUrl, supaKey, overrides, adminToken) {
  try {
    const rows = Object.entries(overrides).map(([token, perms]) => ({ token, perms, updated_by: adminToken || 'admin', updated_at: new Date().toISOString() }));
    if (!rows.length) {
      return { ok: true };
    }
    const r = await fetch(`${supaUrl}/rest/v1/role_overrides?on_conflict=token`, { method: 'POST', headers: { apikey: supaKey, Authorization: `Bearer ${supaKey}`, 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(rows) });
    if (!r.ok) { const t = await r.text(); return { ok: false, error: t || r.statusText }; }
    return { ok: true };
  } catch (e) { return { ok: false, error: String(e?.message || e) }; }
}
async function deleteRoleOverrides(supaUrl, supaKey, tokens) {
  try {
    if (!tokens || !tokens.length) {
      const r = await fetch(`${supaUrl}/rest/v1/role_overrides?token=not.is.null`, { method: 'DELETE', headers: { apikey: supaKey, Authorization: `Bearer ${supaKey}` } });
      if (!r.ok) { const t = await r.text(); return { ok: false, error: t }; }
      return { ok: true };
    }
    for (const tok of tokens) {
      const q = encodeURIComponent(tok);
      await fetch(`${supaUrl}/rest/v1/role_overrides?token=eq.${q}`, { method: 'DELETE', headers: { apikey: supaKey, Authorization: `Bearer ${supaKey}` } });
    }
    return { ok: true };
  } catch (e) { return { ok: false, error: String(e?.message || e) }; }
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { token, action, overrides } = req.body || {};
    const supaUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supaKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (action === 'get_role_overrides') {
      if (!supaUrl || !supaKey) return res.status(200).json({ overrides: {}, note: 'no supabase config' });
      const map = await getRoleOverrides(supaUrl, supaKey);
      if (map === null) return res.status(200).json({ overrides: {}, error: 'role_overrides table missing - run SQL to create' });
      return res.status(200).json({ overrides: map });
    }
    if (action === 'save_role_overrides') {
      const t = String(token || '').trim();
      const isAdminTok = t === 'ADM-MAUA-adm' || (process.env.ADMIN_TOKEN && t === process.env.ADMIN_TOKEN);
      if (!isAdminTok) return res.status(403).json({ error: 'Chỉ Admin được lưu Set role' });
      if (!supaUrl || !supaKey) return res.status(500).json({ error: 'Missing Supabase config' });
      const ov = overrides && typeof overrides === 'object' ? overrides : {};
      const existing = await getRoleOverrides(supaUrl, supaKey) || {};
      const toDelete = Object.keys(existing).filter(k => !(k in ov));
      if (toDelete.length) await deleteRoleOverrides(supaUrl, supaKey, toDelete);
      const saveRes = await saveRoleOverrides(supaUrl, supaKey, ov, t);
      if (!saveRes.ok) return res.status(500).json({ error: saveRes.error || 'save failed' });
      return res.status(200).json({ ok: true, saved: Object.keys(ov).length, deleted: toDelete.length });
    }
    if (action !== 'login') return res.status(400).json({ error: 'Invalid action' });
    if (!token) return res.status(400).json({ error: 'Missing token' });
    const t = String(token).trim();

    // 1) ADMIN - lấy từ Vercel Env (giữ fallback demo theo yêu cầu)
    if (process.env.ADMIN_TOKEN && t === process.env.ADMIN_TOKEN) {
      return res.status(200).json({ id: "demo-admin", name: "Quản trị hệ thống", role: "admin", scope: "all" });
    }
    if (t === "ADM-MAUA-adm") {
      return res.status(200).json({ id: "demo-admin", name: "Quản trị hệ thống", role: "admin", scope: "all" });
    }

    // 2) Tra cứu DB qua REST (dùng SERVICE_ROLE_KEY, không xóa data cũ)
    if (supaUrl && supaKey) {
      const tables = [
        { tbl: "officers", scope: "bch" },
        { tbl: "tt_btv_officers", scope: "ttbtv" },
        { tbl: "province_officers", scope: "province" },
        { tbl: "office_officers", scope: "office" },
        { tbl: "action_100_days_officers", scope: "action100" }
      ];
      for (const { tbl, scope } of tables) {
        const row = await queryOfficer(supaUrl, supaKey, tbl, t);
        if (row) {
          const name = String(row.name || "").trim();
          const isNGN = name === "Nguyễn Giang Nam";
          let userObj = null;
          if (name === "CV nhập liệu") {
            userObj = { id: `cv-${row.id}`, name: name || "CV nhập liệu", role: "staff", scope: "data_entry", title: String(row.title || "").trim(), unit: String(row.unit || "").trim(), isNGN };
          } else if (scope === "mttq") {
            const isAdmin = name === "Trần Văn Hùng";
            userObj = { id: `mttq-${row.id}`, name, role: "staff", scope: "mttq", title: String(row.title || "").trim() || "Cán bộ MTTQ", unit: String(row.unit || "").trim() || "MTTQ", mttqAdmin: isAdmin, isNGN };
          } else if (String(t).startsWith("CQ-")) {
            const deptScope = name === "VPUB" ? "vpub" : "action100";
            userObj = { id: `department-${row.id}`, name, role: "department", scope: deptScope, title: String(row.title || "").trim(), unit: String(row.unit || "").trim(), isNGN };
          } else {
            const bchTier = scope === "bch" && ["Hà Đức Anh","Phạm Xuân Sơn","Chu Chính Sơn"].includes(name) ? "full" : (scope === "bch" ? "broad" : undefined);
            userObj = { id: `${scope}-${row.id}`, name, role: "staff", scope, title: String(row.title || "").trim(), unit: String(row.unit || "").trim(), isNGN, ...(bchTier ? {bchTier} : {}) };
          }
          if (userObj) {
            try {
              const perms = await getRoleOverrideForToken(supaUrl, supaKey, t);
              if (perms && typeof perms === 'object' && Object.keys(perms).length) {
                userObj._perms = perms;
                const extra = Object.keys(perms).filter(ws => { const p = perms[ws]; return p && (p.v || p.a || p.e || p.d); });
                if (extra.length) userObj._extraScopes = extra;
              }
            } catch {}
            return res.status(200).json(userObj);
          }
        }
      }
    }

    // 3) Fallback env TOKENS_JSON (không hardcode trong source) cho giai đoạn chưa seed DB
    const envUser = tryEnvTokens(t);
    if (envUser) {
      try {
        const perms = await getRoleOverrideForToken(supaUrl, supaKey, t);
        if (perms && typeof perms === 'object' && Object.keys(perms).length) {
          envUser._perms = perms;
          const extra = Object.keys(perms).filter(ws => { const p = perms[ws]; return p && (p.v || p.a || p.e || p.d); });
          if (extra.length) envUser._extraScopes = extra;
        }
      } catch {}
      return res.status(200).json(envUser);
    }

    // Trả 200 thay vì 401 để không spam lỗi đỏ trong Console (F12) khi auto-revalidate ở localhost
    // Client vẫn check `fresh.role` để phân biệt thành công/thất bại, không đổi logic xác thực
    return res.status(200).json({ error: 'Token không hợp lệ' });
  } catch (e) {
    console.error("api/admin error:", e);
    return res.status(500).json({ error: 'Internal error', detail: String(e?.message || e) });
  }
}
