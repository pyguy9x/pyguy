# Mobile Skin — bản di động `/mobile` (xem + sửa full)

Route `mobile/index.html` (shell + CSS inline) + `mobile/app.js` (logic), vercel.json headers
`must-revalidate` cho `/mobile`. Script dùng đường dẫn TUYỆT ĐỐI (`/mobile/app.js`,
`/js/config.js`) — relative sẽ 404 khi URL không có `/` cuối. Đổi JS phải bump `?v=`.

## 1. HTML (`mobile/index.html`)

- `#gate`: nhập token → `mLogin()`. `#app` (ẩn tới khi login): `#appbar` (☰ `mToggleMenu()`,
  `#wsTitle`, Đăng xuất), `#drawer` (`#dUser/#dRole`, `#navList` VIẾT SẴN 6 nút để không
  bao giờ trắng menu), `#scrim`, `#mView` (mọi view render bằng JS), `#mToast`.
- CSS inline mobile-first: appbar/drawer trượt, pills + search sticky, card, badge
  (`b-done/b-proc/b-over/b-reg/b-plan/b-early`), form touch 44px+, `.savebar` sticky đáy,
  `.donut` conic + `.wbar` thanh tỉ lệ ở trang chủ.

## 2. JS (`mobile/app.js`)

- P1 core: `SB_URL/SB_KEY` từ `SUPABASE_CONFIG`, `esc/fold`, ngày `pDate/fmtD/toDb`
  (ISO + `dd/mm/yyyy`), `sbGet` (timeout 25s) / `sbMut` (POST/PATCH) / DELETE inline,
  `writeAct` → `activity_logs`, `toast` + bẫy `error/unhandledrejection` hiện toast
  (không bao giờ trắng trang mà không rõ lý do).
- Auth: `/api/admin` `{action:'login'}` + fallback `mResolveToken` đọc trực tiếp 5 bảng
  officers (y như desktop) + fallback admin cục bộ. Nhớ phiên `vp_mobile_user/token`.
  `initMRestore()` PHẢI gọi cuối file (gọi sớm dính TDZ `WS`).
- RBAC mirror desktop: `MWS` map id mobile→desktop, `mDefPerms` (=`computeDefaultPerms`),
  `mUserCan` (=`userCan`), `mBchTier` (full 3 tên / broad), `mCanView` (=`sync...Visibility`:
  data_entry→ttbtv/prov/a100/vpub; mttq→không có gì; bch→tier; department→bch/ttbtv/prov/
  a100(+vpub nếu scope action100/vpub); mặc định trừ VP), `mCan(a)` (+NGN bch/ttbtv,
  department→ttbtv, rule `canAddVPUBTask`; VP không có Thêm), `mCanEdit` (userCan/mOwns/
  data_entry ttbtv-prov/NGN), `openWs` chặn dept mở bch/ttbtv/vpub như desktop.
- 6 workspace `WS` (vp đầu tiên): `table/offTable/st/title/meta/blob/detail`.
  Status: `stCore` (BCH/TTBTV/Tỉnh), `stA100` (+regular/planned), `stVPcalc` (VP, chữ
  desktop → key qua `keyVP`). List: pill Tổng/Hoàn thành/Đang TH/Quá hạn + search +
  cards (`mRenderCards` lọc client, `onclick` dùng attr nháy đơn + JSON id).
- Trang chủ: donut conic tổng + thanh tỉ lệ từng workspace + "Sắp đến hạn của bạn"
  (7 ngày, `mOwns`, chạm `goDetail` mở chi tiết).
- Form: `FED` (sửa) / `FAD` (thêm), type ro/text/area/date/list(datalist),
  `lock:1` chỉ admin, `lock:2` +admin/data_entry (Tỉnh), `adm` ẩn non-admin.
  `mkPatch`/`mkAdd` bám payload desktop (BCH/TTBTV/Tỉnh/KH100/VPUB/VP-office).
  Lưu → PATCH/POST → `writeAct` → tải lại → về chi tiết/danh sách.
- Xóa: chỉ admin (VP bị chặn để khỏi lệch 2 bảng). Gia hạn: admin + quá hạn, prompt
  ngày → PATCH `deadline` (`deadline_date` với VP).

## 3. Quy ước khi bảo trì

- Không đổi: tên trạng thái desktop, payload PATCH/POST, schema Supabase, logic merge VP
  (`mergeVP` ưu tiên `office_tasks`, thêm/sửa VP chỉ chạm `office_tasks`).
- Chưa có mobile: upload file (xem tên file), Thêm/Xóa VP, KPI MTTQ, cây Tỉnh giao.
- Thêm workspace: 1 entry `WS` + `MWS` + `FED/FAD` + nhánh `mkPatch/mkAdd` + nút `#navList`.
- Sửa xong: `node --check mobile/app.js`, bump `?v=mobile/app.js`, 1 dòng `CHANGES.md`.
