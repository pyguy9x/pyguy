# BCH New Skin — mẫu áp dụng cho workspace khác

Skin đã chốt cho BCH (giữ nguyên data/logic, chỉ đổi bố cục). Muốn áp cho workspace X
(TT/BTV, Tỉnh giao, VPUB...): copy từng khối dưới, đổi tiền tố `bch` → tiền tố workspace đó.

## 1. HTML (`index.html`, trong section workspace)

- Thanh tổng: `.bch-summarybar` gồm 4 pill drill (`bchSumTotal/Done/Processing/Overdue`,
  mỗi pill `onclick="openBCHStatusPopup('<mode>')"`) + dải 12 nút tháng `#bchMonthStrip`
  (`onclick="setBCHMonth(n)"`, nút `Cả năm` → `setBCHMonth(null)`).
- 2 panel `.bch-panels`: thẻ tỉ lệ (3 thanh `bchRateDone/Processing/Overdue` gồm
  `...Bar` + `...Count` + `...Label`) và thẻ tiến độ (6 ô `.bch-kpi` tái dùng ID KPI cũ
  `bchTotal/Done/Processing/OverdueCount` + ô mới `bchDueTodayCount`
  (ô `bchFileCount` đang ẩn theo yêu cầu; hàm `openBCHFilePopup()` vẫn giữ).
- Giữ khối filter cũ trong DOM nhưng `display:none` (JS cũ vẫn đọc ID).
- Khung `.bch-main`: aside `.bch-leaders` (`#bchLeaderSearch` + `#bchLeaderList`) + bảng mới
  `.bch-new-table` 7 cột STT/Nhiệm vụ/Cán bộ/Hạn/Còn lại/Trạng thái/Thao tác, hàng lọc
  `bchFTask/bchFLeader/bchFDeadline(+nút 📅 #bchFDeadlinePicker)/bchFStatus` đồng bộ vào
  filter cũ rồi gọi `applyBCHFilters()`.
- Chân bảng `.bch-pagination`: `#bchPagInfo`, `#bchPagBtns`, `#bchPageSize`.

## 2. JS (`js/legacy.js`)

- State: `BCH_MONTH` (mặc định tháng hiện tại → F5 tự chọn), `BCH_PAGE/SIZE`,
  `BCH_DL_Q/BCH_DL_DATE` (lọc Hạn theo ngày, parse `dd-mm-yyyy` lẫn ISO).
- `bchScopeRows()`: lọc theo mọi điều kiện TRỪ trạng thái → KPI thẻ + drill cùng phạm vi.
- `getBCHRowsByMode()` chạy trên scope; popup drill gắn hậu tố tên cán bộ đang chọn.
- `renderBCHTable()`: cắt trang client, cột Còn lại (`bchRemainingText`), cột Thao tác
  (Sửa/Gia hạn), STT theo trang; `bchGotoPage/bchSetPageSize`.
- `renderBCHLeaderList()`: đếm NV theo người, click set filter cán bộ.
- `renderBCHKPIs()`: pill tổng LUÔN toàn workspace; thẻ/tỉ lệ theo scope; đồng bộ nút tháng.
- Ô Hạn hiện `dd-mm-yyyy` qua `bchDispDate()` (parse ISO + dd/mm/yyyy + chuỗi tiếng Việt).

## 3. CSS (`css/style.css`, scope `#bchWorkspace` / `.bch-*`)

- Nền `#f3f5f9`, card trắng `radius 16px`; pill pastel; thanh tỉ lệ xanh lá/dương/đỏ;
  6 thẻ tiến độ pastel (total/done/processing/overdue/duetoday/withfile).
- Bảng `width 100%`, `table-layout fixed`, tỉ lệ `4/33/12/14/10/15/12`, cell `14px 12px`,
  Hạn đỏ + wrap, badge giữ nguyên màu logic cũ; nút 📅 absolute đè mép phải ô lọc.
- `.bch-table-wrap { min-height: 420px }` chống nhảy khi chuyển trang;
  nút trang `28px` căn giữa; responsive `≤1200px` xếp chồng panel + ẩn cột lãnh đạo.

## 4. Quy ước khi port

- Không đổi: tên trạng thái, màu badge, popup Sửa/Gia hạn/drill, schema Supabase.
- Mọi ID mới phải có trong HTML trước khi JS chạy; hàm vẽ chart cũ tự guard `null`.
