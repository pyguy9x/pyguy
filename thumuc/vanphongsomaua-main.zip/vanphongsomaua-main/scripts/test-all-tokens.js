#!/usr/bin/env node
// scripts/test-all-tokens.js
// Kiểm thử toàn bộ token trên dữ liệu test (in-memory test_*, không đụng data gốc)
// Mỗi token thử thêm/sửa trong từng workspace, check rule và lỗi

const fs=require('fs'), path=require('path');

// ===== Token lists (từ user) =====
const BCH_TOKENS = [
"CB-MAUA-HDA-62F311","CB-MAUA-PXS-BBD61F","CB-MAUA-CCS-D13D0C","CB-MAUA-TQT-2B13B6","CB-MAUA-LVT-E1906F","CB-MAUA-NTK-CBB13F","CB-MAUA-DNC-832D52","CB-MAUA-TDT-FA2CCC","CB-MAUA-DMC-724CD3","CB-MAUA-LQL-CCB54F","CB-MAUA-TVH-850D07","CB-MAUA-TTL-7092CD","CB-MAUA-HMC-B31E6F","CB-MAUA-TTH-4116B2","CB-MAUA-TNC-E94A7D","CB-MAUA-NTT-36EE60","CB-MAUA-TVH-5B194D","CB-MAUA-PTO-B60D0B","CB-MAUA-DKV-D6DB6A","CB-MAUA-PVM-17DE3B","CB-MAUA-TXP-178AF7","CB-MAUA-LCC-7396FB","CB-MAUA-DTH-3C8D4D","CB-MAUA-NHV-D3FAF0","CB-MAUA-NTH-EE8DC5","CB-MAUA-QTT-A85967","CB-MAUA-PQM-E1C078","CB-MAUA-TTD-317846","CB-MAUA-VTD-95CBFB"
];
const DEPT_TOKENS = [
"CQ-MAUA-BANXDD","CQ-MAUA-UBKT","CQ-MAUA-CBCONGAN","CQ-MAUA-CBQUANSU","CQ-MAUA-HDND","CQ-MAUA-TTCT","CQ-MAUA-KTHT","CQ-MAUA-PVH","CQ-MAUA-HCC","CB-MAUA-LTT-8DH46R","CQ-MAUA-DVTH-CVE61","CB-MAUA-TAT-3F8CH1","CQ-MAUA-DTXD-8LX74F","CB-MAUA-DNC-5OP3FG","CQ-MAUA-NNMT-CV","CQ-MAUA-TYTLD","CQ-MAUA-TYTCV","CB-MAUA-NGN-88KQBY","CQ-MAUA-CV","CB-MAUA-TTH-4116B2"
];

// Gộp unique
const ALL_TOKENS = [...new Set(["ADM-MAUA-adm", ...BCH_TOKENS, ...DEPT_TOKENS])];

// BCH tiers (theo js/legacy.js cũ)
const BCH_FULL = new Set(["CB-MAUA-HDA-62F311","CB-MAUA-PXS-BBD61F","CB-MAUA-CCS-D13D0C"]);
const BCH_BROAD = new Set(["CB-MAUA-TQT-2B13B6","CB-MAUA-LVT-E1906F","CB-MAUA-NTK-CBB13F","CB-MAUA-DNC-832D52","CB-MAUA-TDT-FA2CCC","CB-MAUA-DMC-724CD3","CB-MAUA-LQL-CCB54F","CB-MAUA-TVH-850D07","CB-MAUA-TTL-7092CD","CB-MAUA-HMC-B31E6F","CB-MAUA-TTH-4116B2","CB-MAUA-TNC-E94A7D","CB-MAUA-NTT-36EE60","CB-MAUA-TVH-5B194D","CB-MAUA-PTO-B60D0B","CB-MAUA-DKV-D6DB6A","CB-MAUA-PVM-17DE3B","CB-MAUA-TXP-178AF7","CB-MAUA-LCC-7396FB"]);

// Mock maps for name (để test, không cần chính xác, chỉ cần phân biệt)
const TOKEN_NAMES = {
"ADM-MAUA-adm":"Quản trị hệ thống",
"CQ-MAUA-BANXDD":"Ban Xây dựng Đảng","CQ-MAUA-UBKT":"UBKT","CQ-MAUA-CBCONGAN":"Công an xã","CQ-MAUA-CBQUANSU":"Quân sự xã","CQ-MAUA-HDND":"HDND","CQ-MAUA-TTCT":"Trung tâm Chính trị","CQ-MAUA-KTHT":"Phòng Kinh Tế hạ tầng","CQ-MAUA-PVH":"Phòng văn hóa","CQ-MAUA-HCC":"Trung tâm PV HCC","CB-MAUA-LTT-8DH46R":"Lê Trường Thịnh","CQ-MAUA-DVTH-CVE61":"Trung tâm Dịch vụ tổng hợp","CB-MAUA-TAT-3F8CH1":"Trần Anh Tráng","CQ-MAUA-DTXD-8LX74F":"BQL dự án đầu tư xây dựng","CB-MAUA-DNC-5OP3FG":"Phòng NN và MT","CQ-MAUA-NNMT-CV":"Phòng NN và MT","CQ-MAUA-TYTLD":"Trạm Y tế","CQ-MAUA-TYTCV":"Trạm Y tế","CB-MAUA-NGN-88KQBY":"Nguyễn Giang Nam","CQ-MAUA-CV":"CV nhập liệu","CB-MAUA-TTH-4116B2":"Trần Thị Hương"
};
// BCH names (đánh số)
BCH_TOKENS.forEach((t,i)=>{ if(!TOKEN_NAMES[t]) TOKEN_NAMES[t]=`BCH User ${i+1}`; });

function getBchTier(t){ if(BCH_FULL.has(t)) return "full"; if(BCH_BROAD.has(t)) return "broad"; if(BCH_TOKENS.includes(t)) return "bch_only"; return ""; }
function resolveUser(token){
  const t=String(token).trim();
  if(t==="ADM-MAUA-adm") return {id:"demo-admin",name:"Quản trị hệ thống",role:"admin",scope:"all",_rawToken:t,bchTier:"full",isNGN:false};
  const name=TOKEN_NAMES[t]||t;
  const tier=getBchTier(t);
  if(tier==="full"||tier==="broad"||tier==="bch_only"){
    return {id:"bch-"+t.slice(-6),name,role:"staff",scope:"bch",_rawToken:t,bchTier:tier,isNGN:t==="CB-MAUA-NGN-88KQBY"};
  }
  if(t==="CQ-MAUA-CV") return {id:"data-entry-cv",name:"CV nhập liệu",role:"staff",scope:"data_entry",_rawToken:t,isNGN:false};
  if(DEPT_TOKENS.includes(t)){
    if(t==="CB-MAUA-NGN-88KQBY") return {id:"staff100-ngn",name:"Nguyễn Giang Nam",role:"staff",scope:"action100",_rawToken:t,isNGN:true};
    if(t==="CB-MAUA-LTT-8DH46R"||t==="CB-MAUA-TAT-3F8CH1"||t==="CB-MAUA-DNC-5OP3FG") return {id:"staff100-"+t.slice(-6),name,role:"staff",scope:"action100",_rawToken:t,isNGN:false};
    const scope = t==="CQ-VPUB-MAUA" ? "vpub" : "action100";
    return {id:"department-"+t.slice(8).toLowerCase(),name,role:"department",scope,_rawToken:t,isNGN:false};
  }
  return null;
}

// ===== Rule checks (mirror js/legacy.js) =====
function canAccessOfficeData(user){
  if(!user) return false;
  if(user.role==="admin") return true;
  if(user.role==="staff" && user.scope==="office") return true;
  if(getBchTier(user._rawToken)==="full") return true;
  return false;
}
function canEditOfficeTask(user, task){ if(!user) return false; if(user.scope==="data_entry") return false; return user.role==="admin" || (user.role==="staff" && user.name===task.owner); }
function canEditBCHTask(user, task){ if(!user) return false; if(user.scope==="data_entry") return false; return user.role==="admin" || (user.role==="staff" && user.name===task.officer_name); }
function canEditTTBTVTask(user, task){
  if(!user) return false;
  if(user.scope==="data_entry") return true;
  if(!!user.isNGN) return true;
  if(user.role==="admin") return true;
  if(user.role==="staff" && user.name===task.officer_name) return true;
  // department action100: check role/scope
  if(user.role==="department" || user.scope==="action100"){
    const norm=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d").replace(/Đ/g,"D").toLowerCase().trim();
    const nm=norm(user.name); if(nm){
      const vals=[task.role,task.unit_name].map(norm).filter(Boolean);
      for(const a of vals){ if(a===nm||a.includes(nm)||nm.includes(a)) return true; }
    }
  }
  return false;
}
function canEditPROVTask(user, task){
  if(!user) return false;
  if(user.scope==="data_entry") return true;
  return user.role==="admin" || (user.role==="staff" && user.scope==="province" && String(user.name).trim()===String(task.officer_name).trim());
}
function normalize(s){return String(s||"").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");}
function canEditAction100(user, task){
  if(!user||!task) return false;
  if(user.scope==="data_entry") return true;
  if(user.role==="admin") return true;
  if(user.scope==="action100" || user.role==="department"){
    // department: name phải khớp cơ quan phụ trách
    if(normalize(user.name)===normalize(task.officer_name)) return true;
    if(user.role==="department"){
      const agencyVals=[task.commune_leader,task.unit_name,task.role].map(normalize).filter(Boolean);
      const nm=normalize(user.name);
      for(const a of agencyVals){ if(a===nm||a.includes(nm)||nm.includes(a)) return true; }
    }
  }
  if(user.role==="staff" && normalize(user.name)===normalize(task.officer_name)) return true;
  if(user.role==="department" && user.scope==="vpub"){
    return String(user.name).trim().toLowerCase()===String(task.unit||"").trim().toLowerCase();
  }
  return false;
}
function canAddOffice(user){ if(!user) return false; if(user.role==="admin") return true; if(user.role==="staff" && user.scope==="office") return true; if(getBchTier(user._rawToken)==="full") return true; return false; }
function canAddBCH(user){ return !!user && (user.role==="admin" || (user.role==="staff" && user.scope==="bch")); }
function canAddTTBTV(user){ return !!user && (user.role==="admin" || !!user.isNGN || (user.role==="staff" && ["ttbtv","data_entry"].includes(user.scope)) || user.role==="department"); }
function canAddPROV(user){ return !!user && (user.role==="admin" || (user.role==="staff" && ["province","data_entry"].includes(user.scope))); }
function canAddAction100(user){ return !!user && (user.role==="admin" || user.scope==="action100" || user.scope==="data_entry" || user.scope==="vpub" || user.role==="department"); }
function canAddVPUB(user){ return !!user && (user.role==="admin" || user.scope==="vpub" || user.scope==="data_entry" || user._rawToken==="CQ-MAUA-CV"); }

// ===== In-memory test DB (không đụng data gốc) =====
let testDB={};
let idSeq=100000;
function resetDB(){
  testDB={
    test_office_tasks:[], test_tasks:[], test_tt_btv_tasks:[], test_province_tasks:[], test_province_plan_blocks:[], test_action_100_days_tasks:[], test_vpub_tasks:[]
  };
  idSeq=100000;
}
function nextId(){ return String(idSeq++); }
function apiAdd(user, table, payload){
  let can=false;
  if(table==="test_office_tasks") can=canAddOffice(user);
  else if(table==="test_tasks") can=canAddBCH(user);
  else if(table==="test_tt_btv_tasks") can=canAddTTBTV(user);
  else if(table==="test_province_tasks") can=canAddPROV(user);
  else if(table==="test_province_plan_blocks") can=canAddPROV(user);
  else if(table==="test_action_100_days_tasks") can=canAddAction100(user);
  else if(table==="test_vpub_tasks") can=canAddVPUB(user);
  if(!can) return {ok:false,status:403,error:`Không có quyền thêm ${table}`};
  if(table!=="test_province_plan_blocks" && !payload.task_name) return {ok:false,status:400,error:"Thiếu task_name"};
  if(table==="test_province_plan_blocks" && payload.stt==null) return {ok:false,status:400,error:"Thiếu stt"};
  const row={id:nextId(),...payload,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};
  testDB[table].push(row);
  return {ok:true,status:201,data:row};
}
function apiEdit(user, table, id, patch){
  const arr=testDB[table]; const idx=arr.findIndex(r=>String(r.id)===String(id));
  if(idx===-1) return {ok:false,status:404,error:"Không tìm thấy id"};
  const row=arr[idx];
  let can=false;
  if(table==="test_office_tasks") can=canEditOfficeTask(user,row);
  else if(table==="test_tasks") can=canEditBCHTask(user,row);
  else if(table==="test_tt_btv_tasks") can=canEditTTBTVTask(user,row);
  else if(table==="test_province_tasks") can=canEditPROVTask(user,row);
  else if(table==="test_province_plan_blocks") can=canAddPROV(user);
  else if(table==="test_action_100_days_tasks") can=canEditAction100(user,row);
  else if(table==="test_vpub_tasks") can=canEditAction100(user,row);
  if(!can) return {ok:false,status:403,error:`Không có quyền sửa ${table} id=${id}`};
  Object.assign(row,patch,{updated_at:new Date().toISOString()});
  return {ok:true,status:200,data:row};
}
function apiDelete(user, table, id){
  const arr=testDB[table]; const idx=arr.findIndex(r=>String(r.id)===String(id));
  if(idx===-1) return {ok:false,status:404,error:"Không tìm thấy"};
  let can=user.role==="admin";
  if(table==="test_action_100_days_tasks" && user.scope==="data_entry") can=true;
  if(!can) return {ok:false,status:403,error:`Không có quyền xóa ${table}`};
  arr.splice(idx,1); return {ok:true};
}

const TABLES=[
  {name:"test_office_tasks",label:"Văn phòng"},
  {name:"test_tasks",label:"BCH"},
  {name:"test_tt_btv_tasks",label:"TT/BTV"},
  {name:"test_province_tasks",label:"Tỉnh giao"},
  {name:"test_province_plan_blocks",label:"Kế hoạch Tỉnh"},
  {name:"test_action_100_days_tasks",label:"KH 100 ngày"},
  {name:"test_vpub_tasks",label:"VPUB"},
];

function makePayload(table,user){
  const owner=user.name;
  const base={task_name:`[TEST-${Date.now()}] ${table} by ${user._rawToken}`,officer_name:owner,owner,commune_leader:owner,unit_name:owner,role:owner,unit:owner};
  if(table==="test_office_tasks") return {...base,task:"NV VP test",due:"2026-09-30",deadline_date:"2026-09-30"};
  if(table==="test_tasks") return {...base,deadline:"2026-09-30",status:"Đang triển khai"};
  if(table==="test_tt_btv_tasks") return {...base,deadline:"2026-09-30",status:"Đang triển khai",ubnd_source:"Test",role:user.name};
  if(table==="test_province_tasks") return {...base,deadline:"2026-09-30",status:"Đang triển khai"};
  if(table==="test_province_plan_blocks") return {stt:9999,van_ban_tinh:"[TEST] VB",van_ban_xa:"[TEST] VBX",nhiem_vu:"[TEST] NV",blocks:{mota:"test",agencies:[{agency:"UBND xã"}]}};
  if(table==="test_action_100_days_tasks") return {...base,deadline:"2026-09-30",product:"Test",officer_name:owner};
  if(table==="test_vpub_tasks") return {...base,unit:owner,deadline:"2026-09-30",product:"Test",field:"Test"};
  return base;
}

let results=[], errors=[];
console.log(`=== TEST TOÀN BỘ TOKEN (${ALL_TOKENS.length} token) trên test_* (không đụng data gốc) ===`);
console.log(`Thời gian: ${new Date().toISOString()}`);
for(const token of ALL_TOKENS){
  const user=resolveUser(token);
  if(!user){ console.log(`SKIP ${token} không resolve`); continue; }
  for(const tbl of TABLES){
    resetDB();
    const payload=makePayload(tbl.name,user);
    const addRes=apiAdd(user,tbl.name,payload);
    const addStatus=addRes.ok?"PASS":(addRes.status===403?"BLOCKED":"FAIL");
    let editRes={ok:false,error:"skip"}, editStatus="SKIP", editId=null;
    if(addRes.ok){ editId=addRes.data.id; editRes=apiEdit(user,tbl.name,editId,{task_name:"[EDITED] "+payload.task_name}); editStatus=editRes.ok?"PASS":(editRes.status===403?"BLOCKED":"FAIL"); }
    // Cross-edit: tạo task của người khác, thử sửa bằng token hiện tại (phải BLOCKED nếu không phải admin/data_entry/isNGN)
    if(addRes.ok){
      const other={...user,name:"Người Khác",_rawToken:"OTHER",role:"staff",scope:user.scope};
      // admin tạo task của người khác
      const admin=resolveUser("ADM-MAUA-adm");
      const otherPayload=makePayload(tbl.name,{...other,name:"Người Khác"});
      // reset và tạo lại để test cross
      resetDB();
      const adminRow=apiAdd(admin,tbl.name,otherPayload);
      if(adminRow.ok){
        const cross=apiEdit(user,tbl.name,adminRow.data.id,{task_name:"[CROSS]"});
        const allowed = user.role==="admin" || user.scope==="data_entry" || !!user.isNGN;
        if(cross.ok && !allowed){
          errors.push({token,table:tbl.name,step:"cross-edit",detail:`${token} (${user.role}/${user.scope}) sửa được task của người khác ở ${tbl.label} -> LỖI`});
        }
        apiDelete(admin,tbl.name,adminRow.data.id);
      }
      // khôi phục row của user để test delete
      const re=apiAdd(user,tbl.name,payload);
      editId=re.ok?re.data.id:null;
    }
    // Delete (chỉ admin)
    let delRes={ok:false}, delStatus="SKIP";
    if(addRes.ok && editId){
      // cần tạo lại vì đã reset
      resetDB();
      const r2=apiAdd(user,tbl.name,payload);
      if(r2.ok){ delRes=apiDelete(user,tbl.name,r2.data.id); delStatus=delRes.ok?"PASS":(delRes.status===403?"BLOCKED":"FAIL"); }
    } else if(!addRes.ok){
      const admin=resolveUser("ADM-MAUA-adm");
      const tmp=apiAdd(admin,tbl.name,makePayload(tbl.name,admin));
      if(tmp.ok){
        const crossDel=apiDelete(user,tbl.name,tmp.data.id);
        if(crossDel.ok && user.role!=="admin" && !(tbl.name==="test_action_100_days_tasks" && user.scope==="data_entry")){
          errors.push({token,table:tbl.name,step:"cross-delete",detail:`${token} xóa được row của admin ở ${tbl.label}`});
        }
        apiDelete(admin,tbl.name,tmp.data.id);
      }
    }
    results.push({token,user:`${user.name}(${user.role}/${user.scope}${user.bchTier?"/"+user.bchTier:""})`,table:tbl.name,label:tbl.label,add:addStatus,edit:editStatus,del:delStatus,addErr:addRes.error||"",editErr:editRes.error||""});
    resetDB();
  }
}

// Ghi báo cáo
const reportPath=path.join(__dirname,'..','TEST_ALL_TOKENS_REPORT.md');
let md=`# Báo cáo Test Toàn Bộ Token (test_* cô lập, không đụng data gốc)\n\n`;
md+=`**Thời gian:** ${new Date().toLocaleString("vi-VN")}\n\n`;
md+=`**Tổng token:** ${ALL_TOKENS.length} (ADM + 29 BCH + 20 Dept)  \n`;
md+=`**Tổng bảng:** ${TABLES.length}  \n`;
md+=`**Tổng case:** ${results.length}\n\n`;
md+=`## Ma trận: Token × Workspace (ADD / EDIT / DEL)\n\n`;
md+=`| Token | User | Workspace | ADD | EDIT | DEL |\n`;
md+=`|---|---|---|---|---|---|\n`;
for(const r of results){
  md+=`| ${r.token} | ${r.user} | ${r.label} | ${r.add} | ${r.edit} | ${r.del} |\n`;
}
md+=`\n## Lỗi phát hiện\n\n`;
if(errors.length===0) md+=`- Không phát hiện cross-edit/delete bất thường. Các trường hợp data_entry / isNGN được phép cross-edit là đúng thiết kế.\n`;
else errors.forEach(e=> md+=`- **${e.token} ${e.table} ${e.step}**: ${e.detail}\n`);
md+=`\n## Ghi chú rule\n\n`;
md+=`- Văn phòng: chỉ admin, staff office, BCH full được ADD; EDIT chỉ owner/admin; data_entry không được sửa Văn phòng.\n`;
md+=`- BCH: chỉ admin + staff bch được ADD; EDIT chỉ owner/admin.\n`;
md+=`- TT/BTV: admin, isNGN, staff ttbtv/data_entry, department action100 được ADD; EDIT: data_entry/isNGN/admin/owner/department khớp cơ quan.\n`;
md+=`- Tỉnh giao: admin, staff province/data_entry được ADD/EDIT.\n`;
md+=`- KH100/VPUB: admin, action100, vpub, data_entry, department được ADD; EDIT kiểm tra khớp tên cơ quan.\n`;
md+=`- DELETE: chỉ admin (trừ action100 data_entry được xóa) - đúng.\n`;
md+=`- Dữ liệu test đã reset sau mỗi case, không để lại test data.\n`;
fs.writeFileSync(reportPath,md,'utf8');
console.log(`\nĐã ghi báo cáo: ${reportPath}`);
console.log(`Số lỗi cross: ${errors.length}`);
if(errors.length){ console.log(errors); process.exit(1); } else { console.log("✓ PASS - không có lỗi phân quyền nghiêm trọng"); process.exit(0); }
