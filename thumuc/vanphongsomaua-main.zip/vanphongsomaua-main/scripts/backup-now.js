#!/usr/bin/env node
// Tạo bản sao lưu hiện tại (17 bảng) - chạy trước khi sửa
const fs = require('fs');
const path = require('path');

const SUPABASE_URL = "https://zipvocbtmilyeuhqqrur.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InppcHZvY2J0bWlseWV1aHFxcnVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQyNTY0NjgsImV4cCI6MjA5OTgzMjQ2OH0.-LUZdiukACGQS7pR71HNFmxmDkDGNi2x3Rs6KM9nN5s";

const BACKUP_TABLES = [
    "officers","tt_btv_officers","province_officers","action_100_days_officers","office_officers",
    "tasks","tt_btv_tasks","province_tasks","province_plan_blocks","action_100_days_tasks",
    "vpub_tasks","office_tasks","department_tasks","mttq_kpi_people","mttq_kpi_catalog","mttq_kpi_tasks","activity_logs"
];

async function fetchTable(table){
    const headers = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };
    const all=[];
    let offset=0;
    for(;;){
        const url = `${SUPABASE_URL}/rest/v1/${table}?select=*&order=id.asc&limit=1000&offset=${offset}`;
        const r = await fetch(url, { headers });
        if(!r.ok){
            const txt = await r.text().catch(()=>"");
            throw new Error(`fetch ${table} ${r.status} ${txt.slice(0,300)}`);
        }
        const chunk = await r.json();
        if(!Array.isArray(chunk) || chunk.length===0) break;
        all.push(...chunk);
        if(chunk.length<1000) break;
        offset+=1000;
    }
    return all;
}

(async()=>{
    console.log("=== BACKUP NOW: 17 bảng ===");
    const payload = { exported_at: new Date().toISOString(), app:"vanphongtonghop", version:2, tables:{}, skipped:[] };
    let total=0;
    for(const t of BACKUP_TABLES){
        try{
            console.log(`Đang đọc ${t} ...`);
            const rows = await fetchTable(t);
            payload.tables[t]=rows;
            total+=rows.length;
            console.log(`  -> ${rows.length} dòng`);
        }catch(e){
            console.warn(`  ! skip ${t}: ${e.message}`);
            payload.skipped.push({ table:t, error:String(e.message) });
            payload.tables[t]=[];
        }
    }
    payload.total_rows = total;
    const ts = new Date().toISOString().replace(/[:.]/g,"-").slice(0,19);
    const fname = `backup-vpdu-${ts}.json`;
    const outPath = path.join(__dirname, '..', fname);
    fs.writeFileSync(outPath, JSON.stringify(payload,null,2), 'utf8');
    console.log(`\n✓ Đã tạo backup: ${outPath}`);
    console.log(`  Tổng: ${total} dòng, skipped: ${payload.skipped.length}`);
    if(payload.skipped.length) console.log(payload.skipped);
})();
