#!/usr/bin/env node
// scripts/seed-tokens.js
// Đẩy token thật từ source cũ lên 4 bảng Supabase (officers, tt_btv_officers, province_officers, office_officers, action_100_days_officers)
// Yêu cầu: giữ nguyên giá trị, không xóa data cũ (chỉ INSERT nếu chưa tồn tại)
// Chạy: SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/seed-tokens.js

const fs = require('fs');

// Token nguồn (giữ nguyên giá trị đã thông báo) - đọc từ backup cũ hoặc hardcode ở đây CHỈ khi chạy seed, không commit token mới
// Để tránh lộ khi đọc source web, file này chỉ chạy server-side, không được bundle ra client.
// Nếu lo lộ, hãy set TOKENS_JSON env thay vì hardcode.

const SEED_TOKENS = [
  // BCH full
  { token: "CB-MAUA-HDA-62F311", name: "Chu Chính Sơn", title: "TUV", unit: "BCH", table: "officers" },
  { token: "CB-MAUA-PXS-BBD61F", name: "Phạm Xuân Sơn", title: "", unit: "BCH", table: "officers" },
  { token: "CB-MAUA-CCS-D13D0C", name: "Chu Chính Sơn", title: "", unit: "BCH", table: "officers" },
  // BCH broad (19)
  { token: "CB-MAUA-TQT-2B13B6", name: "Trần Quốc Tuấn", title: "", unit: "BCH", table: "officers" },
  { token: "CB-MAUA-LVT-E1906F", name: "Lê Văn Tuấn", title: "", unit: "BCH", table: "officers" },
  // ... thêm đủ 29 token BCH vào đây, giữ nguyên
  // Văn phòng staff (7)
  { token: "CB-MAUA-PVM-7KQ2A1", name: "Phạm Văn Mạnh", title: "Chuyên viên", unit: "Văn phòng Đảng ủy", table: "office_officers" },
  // Department CQ-* -> action100 / vpub (dùng action_100_days_officers)
  { token: "CQ-MAUA-VPDU", name: "VPDU", title: "VPDU", unit: "VPDU", table: "action_100_days_officers" },
  { token: "CQ-MAUA-UBND", name: "UBND", title: "UBND", unit: "UBND", table: "action_100_days_officers" },
  { token: "CQ-MAUA-UBNDXA", name: "UBND xã", title: "UBND xã", unit: "UBND xã", table: "action_100_days_officers" },
  { token: "CQ-MAUA-BANXDD", name: "Ban Xây dựng Đảng", title: "", unit: "Ban Xây dựng Đảng", table: "action_100_days_officers" },
  { token: "CQ-MAUA-MTTQ", name: "MTTQ", title: "", unit: "MTTQ", table: "action_100_days_officers" },
  { token: "CQ-MAUA-HDND", name: "HDND", title: "", unit: "HDND", table: "action_100_days_officers" },
  { token: "CQ-MAUA-CBCONGAN", name: "Công an xã", title: "", unit: "Công an xã", table: "action_100_days_officers" },
  { token: "CQ-MAUA-CBQUANSU", name: "Quân sự xã", title: "", unit: "Quân sự xã", table: "action_100_days_officers" },
  { token: "CQ-MAUA-UBKT", name: "UBKT", title: "", unit: "UBKT", table: "action_100_days_officers" },
  { token: "CQ-MAUA-TTCT", name: "Trung tâm Chính trị", title: "", unit: "Trung tâm Chính trị", table: "action_100_days_officers" },
  { token: "CQ-MAUA-KTHT", name: "Phòng Kinh Tế hạ tầng", title: "", unit: "Phòng Kinh Tế hạ tầng", table: "action_100_days_officers" },
  { token: "CQ-MAUA-PVH", name: "Phòng văn hóa", title: "", unit: "Phòng văn hóa", table: "action_100_days_officers" },
  { token: "CQ-MAUA-HCC", name: "Trung tâm PV HCC", title: "", unit: "Trung tâm PV HCC", table: "action_100_days_officers" },
  { token: "CQ-MAUA-DVTH-CVE61", name: "Trung tâm Dịch vụ tổng hợp", title: "", unit: "Trung tâm Dịch vụ tổng hợp", table: "action_100_days_officers" },
  { token: "CQ-MAUA-DTXD-8LX74F", name: "BQL dự án đầu tư xây dựng", title: "", unit: "BQL dự án đầu tư xây dựng", table: "action_100_days_officers" },
  { token: "CQ-MAUA-NNMT-CV", name: "Phòng NN và MT", title: "", unit: "Phòng NN và MT", table: "action_100_days_officers" },
  { token: "CQ-MAUA-TYTLD", name: "Trạm Y tế", title: "Trạm Y tế", unit: "Trạm Y tế", table: "action_100_days_officers" },
  { token: "CQ-MAUA-TYTCV", name: "Trạm Y tế", title: "Trạm Y tế", unit: "Trạm Y tế", table: "action_100_days_officers" },
  { token: "CQ-MAUA-UBNDXA2", name: "UBND xã", title: "", unit: "UBND xã", table: "action_100_days_officers" },
  { token: "CQ-VPUB-MAUA", name: "VPUB", title: "VPUB", unit: "VPUB", table: "action_100_days_officers" },
  { token: "CQ-MAUA-CV", name: "CV nhập liệu", title: "CV nhập liệu", unit: "CV", table: "action_100_days_officers" },
  // STAFF_ACTION100 (4)
  { token: "CB-MAUA-LTT-8DH46R", name: "Lê Trường Thịnh", title: "", unit: "LTT", table: "action_100_days_officers" },
  { token: "CB-MAUA-TAT-3F8CH1", name: "Trần Anh Tráng", title: "", unit: "TAT", table: "action_100_days_officers" },
  { token: "CB-MAUA-DNC-5OP3FG", name: "Phòng NN và MT", title: "", unit: "DNC", table: "action_100_days_officers" },
  { token: "CB-MAUA-NGN-88KQBY", name: "Nguyễn Giang Nam", title: "", unit: "NGN", table: "action_100_days_officers" },
  // MTTQ (10) -> dùng officers hoặc mttq_kpi_people tùy bạn, ở đây seed vào office_officers để /api/admin tìm thấy
];

async function main() {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY;
  if (!url || !key) {
    console.error("Thiếu SUPABASE_URL hoặc SUPABASE_SERVICE_ROLE_KEY");
    process.exit(1);
  }
  let inserted = 0, skipped = 0, failed = 0;
  for (const t of SEED_TOKENS) {
    try {
      // Kiểm tra đã tồn tại chưa (không xóa data cũ)
      const q = encodeURIComponent(t.token);
      const check = await fetch(`${url}/rest/v1/${t.table}?select=id&token=eq.${q}&limit=1`, {
        headers: { apikey: key, Authorization: `Bearer ${key}` }
      });
      if (check.ok) {
        const arr = await check.json();
        if (Array.isArray(arr) && arr.length > 0) { skipped++; continue; }
      }
      // Insert - office_officers không có cột unit
      const payload = t.table === "office_officers"
        ? { name: t.name, token: t.token, title: t.title || "" }
        : { name: t.name, token: t.token, title: t.title || "", unit: t.unit || "" };
      const ins = await fetch(`${url}/rest/v1/${t.table}`, {
        method: "POST",
        headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", Prefer: "return=minimal" },
        body: JSON.stringify(payload)
      });
      if (ins.ok) inserted++; else { failed++; console.error(`Insert ${t.token} -> ${t.table} fail ${ins.status} ${await ins.text()}`); }
    } catch (e) { failed++; console.error(`Error ${t.token}`, e); }
  }
  console.log(`Seed xong: inserted=${inserted}, skipped (đã có)=${skipped}, failed=${failed}`);
  console.log("Lưu ý: không xóa data cũ, chỉ thêm mới. Kiểm tra lại trong Supabase Dashboard.");
}

main();
