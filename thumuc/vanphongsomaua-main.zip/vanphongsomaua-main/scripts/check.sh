#!/bin/bash
# scripts/check.sh - check nhanh legacy.js (không tốn token loop)
set -e
echo "== node --check =="
node --check js/legacy.js && echo "✓ syntax pass" || (echo "✗ syntax fail"; exit 1)
echo "== grep SUPABASE_KEY drift =="
grep -n "SUPABASE_KEY\|SUPABASE_URL\|SUPABASE_CONFIG" js/legacy.js js/config.js | head -20
echo "== git diff --check =="
git diff --check || echo "✓ no whitespace errors"
echo "== size =="
wc -l js/legacy.js | awk '{print "legacy.js lines:", $1}'
echo "== map =="
grep -n "SECTION_MAP\|BACKUP_TABLES" js/dev-map.js | head -5
echo "done"
