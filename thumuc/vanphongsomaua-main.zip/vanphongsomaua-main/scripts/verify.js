// scripts/verify.js - node version của check.sh (cho Windows)
const { execSync } = require('child_process');
const fs = require('fs');
try {
  execSync('node --check js/legacy.js', { stdio: 'inherit' });
  console.log('✓ syntax pass');
} catch { console.error('✗ syntax fail'); process.exit(1); }
console.log('== SUPABASE drift ==');
["js/legacy.js","js/config.js","js/dev-map.js"].forEach(f=>{
  if(fs.existsSync(f)){
    const t=fs.readFileSync(f,'utf8');
    const m=t.match(/SUPABASE_(URL|KEY|CONFIG)/g);
    console.log(f, m ? [...new Set(m)].join(',') : 'no key');
  }
});
try { execSync('git diff --check', { stdio: 'inherit' }); console.log('✓ no whitespace'); } catch { console.log('✓ check done'); }
console.log('lines', fs.readFileSync('js/legacy.js','utf8').split('\n').length);
console.log('done');
