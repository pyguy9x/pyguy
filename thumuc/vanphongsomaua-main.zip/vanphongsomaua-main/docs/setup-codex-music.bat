@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Cai Codex + DeepSeek - profile music

echo ===========================================
echo  Cai Codex 0.80.0 + DeepSeek profile music
echo ===========================================
echo.

REM 1. Check npm
where npm >nul 2>&1
if %errorlevel% neq 0 (
  echo [LOI] Chua co Node.js / npm
  echo Cai Node.js tu: https://nodejs.org roi chay lai file nay
  pause
  exit /b
)

echo [1/4] Cai codex-cli 0.80.0 (ban cuoi ho tro DeepSeek truc tiep)...
call npm install -g @openai/codex@0.80.0
if %errorlevel% neq 0 (
  echo [LOI] Cai codex that bai
  pause
  exit /b
)

REM 2. Tao folder .codex
if not exist "%USERPROFILE%\.codex" mkdir "%USERPROFILE%\.codex"

REM 3. Nhap key
echo.
set /p DEEPSEEK_KEY=Nhap DEEPSEEK_API_KEY cua ban (sk-...): 
if "%DEEPSEEK_KEY%"=="" (
  echo [LOI] Chua nhap key
  pause
  exit /b
)
echo [2/4] Luu DEEPSEEK_API_KEY...
setx DEEPSEEK_API_KEY "%DEEPSEEK_KEY%" >nul
set DEEPSEEK_API_KEY=%DEEPSEEK_KEY%
set OPENAI_API_KEY=

REM 4. Tao config.toml
echo [3/4] Cau hinh %USERPROFILE%\.codex\config.toml ...

REM Neu chua co config.toml thi tao moi file toi thieu
if not exist "%USERPROFILE%\.codex\config.toml" (
  echo # Codex config - tao tu setup bat > "%USERPROFILE%\.codex\config.toml"
  echo model = "gpt-5" >> "%USERPROFILE%\.codex\config.toml"
  echo. >> "%USERPROFILE%\.codex\config.toml"
)

REM Xoa cau hinh deepseek cu neu co de tranh duplicate key
powershell -Command "$p='%USERPROFILE%\.codex\config.toml'; $c=Get-Content $p -Raw; $c=$c -replace '(?ms)\[model_providers\.deepseek\].*?(?=\n\[|\z)',''; $c=$c -replace '(?ms)\[models\.\"deepseek-v4-flash\"\].*?(?=\n\[|\z)',''; $c=$c -replace '(?ms)\[profiles\.music\].*?(?=\n\[|\z)',''; Set-Content $p $c -Encoding utf8"

REM Them cau hinh moi vao cuoi file
echo. >> "%USERPROFILE%\.codex\config.toml"
echo [model_providers.deepseek] >> "%USERPROFILE%\.codex\config.toml"
echo name = "DeepSeek" >> "%USERPROFILE%\.codex\config.toml"
echo base_url = "https://api.deepseek.com/v1" >> "%USERPROFILE%\.codex\config.toml"
echo env_key = "DEEPSEEK_API_KEY" >> "%USERPROFILE%\.codex\config.toml"
echo wire_api = "chat" >> "%USERPROFILE%\.codex\config.toml"
echo. >> "%USERPROFILE%\.codex\config.toml"
echo [models."deepseek-v4-flash"] >> "%USERPROFILE%\.codex\config.toml"
echo id = "deepseek-v4-flash" >> "%USERPROFILE%\.codex\config.toml"
echo model_provider = "deepseek" >> "%USERPROFILE%\.codex\config.toml"
echo context_window = 128000 >> "%USERPROFILE%\.codex\config.toml"
echo max_output_tokens = 8192 >> "%USERPROFILE%\.codex\config.toml"
echo. >> "%USERPROFILE%\.codex\config.toml"
echo [profiles.music] >> "%USERPROFILE%\.codex\config.toml"
echo model_provider = "deepseek" >> "%USERPROFILE%\.codex\config.toml"
echo model = "deepseek-v4-flash" >> "%USERPROFILE%\.codex\config.toml"

REM Tao them file music.config.toml de chay duoc ca ban Codex moi neu can
echo [4/4] Tao profile file music.config.toml ...
echo model_provider = "deepseek" > "%USERPROFILE%\.codex\music.config.toml"
echo model = "deepseek-v4-flash" >> "%USERPROFILE%\.codex\music.config.toml"

echo.
echo ===========================================
echo  XONG! Test ngay:
echo ===========================================
echo  codex --version
call codex --version
echo.
echo  codex -p music "hello"
call codex -p music "hello"
echo.
echo  Neu thay "Xin chao" la ok!
echo  - codex         : chay model mac dinh
echo  - codex -p music: chay DeepSeek $2
echo ===========================================
pause
