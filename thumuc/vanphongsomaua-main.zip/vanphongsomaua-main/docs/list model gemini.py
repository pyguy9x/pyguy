import requests
API_KEY = "AQ.Ab8RN6KXN60Tddx4Ig4r6CLUzngyqOAfYA65msvzAnwL5KaAog" # Điền Key vào đây
url = f"https://generativelanguage.googleapis.com/v1beta/models?key={API_KEY}"
response = requests.get(url)
models = response.json().get('models', [])
for m in models:
    print(m['name'])