# Plan: Sửa bộ lọc workspace Tỉnh giao — Filter ↔ Chart ↔ Popup đồng bộ

## Mô tả vấn đề

Workspace "Tỉnh giao" trong [legacy.js](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js) có **5 bộ lọc chính** trên workspace:
- `#provinceSearch` — tìm kiếm nội dung
- `#provinceOfficerFilter` — lọc cơ quan
- `#provinceStatusFilter` — lọc trạng thái
- `#provinceTimeFilter` — lọc thời gian
- `#provinceMonthStrip` / `PROV_MONTH` — lọc theo tháng đáo hạn

Khi thay đổi bộ lọc, `applyPROVFilters()` được gọi → cập nhật `PROV_FILTERED` → gọi `renderPROVKPIs()`, `renderPROVTable()`, `renderPROVCharts()`. Tuy nhiên, khi bấm vào số liệu (KPI, chart, pill) để mở popup, một số hàm **bỏ qua bộ lọc hiện tại** và lấy dữ liệu từ toàn bộ `PROV_TASKS` hoặc `getPROVTreeRows(null)`.

---

## Các lỗi phát hiện

### Lỗi 1: `openPROVStatusPopup()` bỏ qua tất cả bộ lọc workspace
> **Vị trí**: [legacy.js L7641-7654](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7641-L7654)

```js
function openPROVStatusPopup(mode = "all", el = null) {
    // ...
    renderPROVDrill(getPROVRowsByMode(mode), meta[0], meta[1]);
}
```

`getPROVRowsByMode(mode)` (L7631-7639) lấy **toàn bộ dữ liệu** từ `getPROVTreeRows(mode)` hoặc `PROV_TASKS` theo status, **không áp dụng** search/officer/time/month filters.

**Ảnh hưởng**: Khi đang lọc "Tháng 6" + cơ quan "UBND xã", bấm KPI "Hoàn thành" sẽ hiện popup với **tất cả** nhiệm vụ hoàn thành, không chỉ tháng 6 + UBND xã.

Hàm này được gọi từ:
- KPI cards: `provinceTotalCount`, `provinceDoneCount`, `provinceProcessingCount`, `provinceOverdueCount` (index.html L2441-2454)
- Summary pills: `provinceSumTotal`, `provinceSumDone`, `provinceSumProcessing`, `provinceSumOverdue` (index.html L2398-2401)
- Chart 1 status drill: `drillPROVChart("status", label)` → `openPROVStatusPopup(key)` (L7461-7463)

---

### Lỗi 2: `drillPROVChart("officer", label)` bỏ qua bộ lọc
> **Vị trí**: [legacy.js L7465-7476](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7465-L7476)

```js
if (kind === "officer") {
    const treeRows = getPROVTreeRows(null) || [];  // ← toàn bộ, không lọc
    // ...
    renderPROVDrill(treeRows.filter(r => ...));
}
```

Khi bấm chart 4 (cơ quan), popup mở với **tất cả** nhiệm vụ của cơ quan đó, bỏ qua filter search/status/time/month.

---

### Lỗi 3: `drillPROVChart("document", label)` bỏ qua bộ lọc
> **Vị trí**: [legacy.js L7477-7501](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7477-L7501)

```js
if (kind === "document") {
    // tree path: lấy getPROVTreeRows(null), không lọc
    // fallback path: lấy PROV_TASKS, không lọc
}
```

---

### Lỗi 4: `drillPROVChart("deadline", label)` bỏ qua bộ lọc
> **Vị trí**: [legacy.js L7528-7553](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7528-L7553)

```js
if (kind === "deadline") {
    // tree path: buildPROVDeadlineCategories() đếm toàn bộ cây, không lọc
    // fallback: PROV_TASKS, không lọc
}
```

---

### Lỗi 5: `drillPROVChart("leader", label)` bỏ qua bộ lọc
> **Vị trí**: [legacy.js L7502-7520](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7502-L7520)

---

### Lỗi 6: Chart 3 (Deadline) và Chart 4 (Cơ quan) dùng tree trực tiếp, bỏ qua `PROV_FILTERED`
> **Vị trí**: [legacy.js L7335-7370](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7335-L7370)

Chart 3 gọi `buildPROVDeadlineCategories()` đếm **toàn bộ** `.pp-task` trong cây (chỉ bỏ `display:none`), nhưng `applyProvincePlanTreeFilter()` chỉ ẩn theo bộ lọc cây, **không ẩn theo `PROV_MONTH`** hay các filter workspace khác.

Chart 4 tương tự: quét `.pp-agency` trong cây, chỉ bỏ task ẩn, nhưng không lọc theo `PROV_FILTERED`.

> [!IMPORTANT]
> Các chart 2, 3, 4 khi có cây thư mục (`provincePlanTree`) đều đọc trực tiếp DOM cây, không dùng `PROV_FILTERED`. Cần thống nhất: **khi có filter, chart phải dùng `PROV_FILTERED`** thay vì quét DOM cây.

---

### Lỗi 7: Performance chart + drill bỏ qua filter
> **Vị trí**: [legacy.js L7372-7390](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js#L7372-L7390)

`buildPROVPerfAgencies()` (L7392) quét toàn bộ cây. Drill callback (L7378-7390) lấy `getPROVTreeRows(null)` không lọc.

---

## Proposed Changes

### [MODIFY] [legacy.js](file:///D:/Minh/non-drive/vanphongso/vanphongsomaua/js/legacy.js) — 7 sửa đổi

#### Sửa 1: `openPROVStatusPopup()` — áp dụng bộ lọc workspace (L7641-7654)

Thay vì gọi `getPROVRowsByMode(mode)` (lấy toàn bộ), sẽ lọc từ `PROV_FILTERED`:

```js
// TRƯỚC:
renderPROVDrill(getPROVRowsByMode(mode), meta[0], meta[1]);

// SAU:
const filtered = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : getPROVRowsByMode("all");
const rows = mode === "all" ? filtered : filtered.filter(x => provinceStatusGroup(x.statusKey || provinceStatusFor(x)) === mode);
renderPROVDrill(rows, meta[0], meta[1]);
```

---

#### Sửa 2: `drillPROVChart("status")` — dùng `PROV_FILTERED` (L7461-7463)

```js
// TRƯỚC:
if (kind === "status") {
    const key = label === "Hoàn thành" ? "done" : label === "Quá hạn" ? "overdue" : "processing";
    openPROVStatusPopup(key); return;
}

// SAU (không đổi, vì openPROVStatusPopup đã sửa ở Sửa 1)
```

Không cần sửa thêm — `openPROVStatusPopup` đã được sửa.

---

#### Sửa 3: `drillPROVChart("officer")` — lọc từ `PROV_FILTERED` (L7465-7476)

```js
// TRƯỚC:
const treeRows = getPROVTreeRows(null) || [];
renderPROVDrill(treeRows.filter(r => ...));

// SAU:
const src = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : (getPROVTreeRows(null) || PROV_TASKS);
renderPROVDrill(src.filter(r => {
    const agencies = String(r.unit_name || '').split(',').map(s => provinceFold(provinceAgencyLabel(s))).filter(Boolean);
    return agencies.some(a => a === wanted || a.includes(wanted) || wanted.includes(a));
}), `Số nhiệm vụ - ${label}`, "👤");
```

---

#### Sửa 4: `drillPROVChart("document")` — lọc từ `PROV_FILTERED` (L7477-7501)

Thay `getPROVTreeRows(null)` và `PROV_TASKS` bằng `PROV_FILTERED` làm nguồn.

---

#### Sửa 5: `drillPROVChart("deadline")` — lọc từ `PROV_FILTERED` (L7528-7553)

Thay `buildPROVDeadlineCategories()` toàn bộ cây bằng logic deadline trên `PROV_FILTERED`.

---

#### Sửa 6: `drillPROVChart("leader")` — lọc từ `PROV_FILTERED` (L7502-7520)

Tương tự pattern: dùng `PROV_FILTERED` thay `getPROVTreeRows(null)`.

---

#### Sửa 7: `renderPROVCharts()` — Chart 2, 3, 4 dùng `PROV_FILTERED` thay DOM cây (L7305-7370)

**Chart 2** (văn bản): Khi có cây, quét DOM `.pp-task` visible → đổi sang dùng `useRows` (đã lọc).
**Chart 3** (deadline): Khi có cây, gọi `buildPROVDeadlineCategories()` quét toàn bộ → đổi sang tính trên `useRows`.
**Chart 4** (cơ quan): Khi có cây, quét DOM `.pp-agency` visible → đổi sang dùng `useRows`.

> [!WARNING]
> Sửa 7 cần cẩn thận: khi **không có bộ lọc nào đang active**, vẫn phải giữ nguyên hành vi cũ (đọc cây DOM). Chỉ khi có filter mới chuyển sang `useRows` = `PROV_FILTERED`.

---

#### Sửa 8: `renderPROVCharts()` — `useRows` bỏ qua `provinceTimeFilter` (L7296)

```js
// TRƯỚC:
const useRows = (document.getElementById("provinceSearch")?.value
  || document.getElementById("provinceOfficerFilter")?.value
  || (document.getElementById("provinceStatusFilter")?.value || "all") !== "all"
  || (typeof PROV_MONTH!=="undefined" && PROV_MONTH)) ? PROV_FILTERED : base;

// SAU — thêm check provinceTimeFilter:
const timeFilterActive = (document.getElementById("provinceTimeFilter")?.value || "all") !== "all";
const useRows = (document.getElementById("provinceSearch")?.value
  || document.getElementById("provinceOfficerFilter")?.value
  || (document.getElementById("provinceStatusFilter")?.value || "all") !== "all"
  || timeFilterActive
  || (typeof PROV_MONTH!=="undefined" && PROV_MONTH)) ? PROV_FILTERED : base;
```

**Ảnh hưởng**: Khi chỉ lọc `provinceTimeFilter` = "Tuần này" mà không có filter khác, tất cả chart đều dùng `base` (toàn bộ data) thay vì `PROV_FILTERED`. Cần thêm `timeFilterActive` vào điều kiện.

---

#### Sửa 9: `applyPROVFilters()` — `PROV_MONTH` lọc theo `firstDL` (chỉ người đầu tiên) gây lệch với cây (L7137)

```js
// TRƯỚC (L7137):
if (typeof PROV_MONTH !== "undefined" && PROV_MONTH) {
  const d = provinceDeadlineDate(x.deadline); // x.deadline = firstDL = deadline người đầu tiên
  if (!d || (d.getMonth()+1)!==PROV_MONTH) return false;
}

// SAU — khi là tree row, kiểm tra tất cả deadline trong task element:
if (typeof PROV_MONTH !== "undefined" && PROV_MONTH) {
  if (x._isTree && x._taskEl) {
    const anyMatch = [...x._taskEl.querySelectorAll('.pp-person [data-k=deadline]')]
      .some(el => { const d2 = ppParseDate(el.value); return d2 && (d2.getMonth()+1) === PROV_MONTH; });
    if (!anyMatch) return false;
  } else {
    const d = provinceDeadlineDate(x.deadline);
    if (!d || (d.getMonth()+1)!==PROV_MONTH) return false;
  }
}
```

**Ảnh hưởng**: Khi task có 3 người với deadline tháng 4, 5, 6 → lọc tháng 5 → `firstDL` = tháng 4 → bị loại khỏi `PROV_FILTERED` → bảng và chart không hiển thị, nhưng **cây thư mục vẫn hiển thị** (do cây dùng `.some()`). Cần đồng bộ logic.

---

## Nguyên tắc an toàn

> [!CAUTION]
> - **KHÔNG** sửa data (PROV_TASKS, PROV_OFFICERS, Supabase data) — chỉ sửa logic hiển thị.
> - **KHÔNG** thêm file, dependency mới.
> - **KHÔNG** đổi tên hàm, biến public — giữ backward compatible.
> - Mọi popup vẫn hoạt động bình thường khi **không có filter** (fallback về toàn bộ data).

---

## Verification Plan

### Automated Tests
```bash
node --check js/legacy.js
```

### Manual Verification

1. **Test filter → KPI click**:
   - Chọn tháng 6 trên `#provinceMonthStrip`
   - Chọn cơ quan "UBND xã" trên `#provinceOfficerFilter`
   - Bấm KPI "Hoàn thành" → popup chỉ hiện nhiệm vụ hoàn thành tháng 6 + UBND xã
   
2. **Test filter → Chart 1 (Status) click**:
   - Có filter active → bấm vùng "Quá hạn" trên chart → popup chỉ hiện quá hạn trong scope đã lọc

3. **Test filter → Chart 4 (Cơ quan) click**:
   - Lọc tháng 3 → bấm chart cơ quan → popup chỉ hiện NV tháng 3 của cơ quan đó

4. **Test filter → Chart 3 (Deadline) click**:
   - Lọc trạng thái "Đang xử lý" → bấm "Quá hạn" chart → popup chỉ hiện NV đang xử lý + quá hạn

5. **Test không filter**:
   - Xóa tất cả filter → bấm KPI/chart → popup hiện toàn bộ (hành vi cũ)

6. **Test pill (summary)**:
   - Pills `provinceSumTotal/Done/Processing/Overdue` — vẫn hiện tổng toàn workspace (KHÔNG lọc theo filter), nhưng khi bấm vào pill mà có filter đang active → popup phải lọc theo filter

---

## Tóm tắt thay đổi

| # | Hàm | Dòng | Vấn đề | Fix |
|---|------|------|--------|-----|
| 1 | `openPROVStatusPopup` | 7654 | Dùng `getPROVRowsByMode` (toàn bộ) | Dùng `PROV_FILTERED` + lọc status |
| 2 | `drillPROVChart("officer")` | 7466 | Dùng `getPROVTreeRows(null)` | Dùng `PROV_FILTERED` |
| 3 | `drillPROVChart("document")` | 7480 | Dùng `getPROVTreeRows(null)` | Dùng `PROV_FILTERED` |
| 4 | `drillPROVChart("deadline")` | 7531 | Dùng `buildPROVDeadlineCategories()` toàn bộ | Dùng `PROV_FILTERED` |
| 5 | `drillPROVChart("leader")` | 7505 | Dùng `getPROVTreeRows(null)` | Dùng `PROV_FILTERED` |
| 6 | `renderPROVCharts` chart 3 | 7338 | `buildPROVDeadlineCategories()` quét toàn cây | Dùng `useRows` khi có filter |
| 7 | `renderPROVCharts` chart 2,4 | 7305,7359 | Quét DOM cây toàn bộ | Dùng `useRows` khi có filter |
| 8 | `renderPROVCharts` useRows | 7296 | Thiếu check `provinceTimeFilter` | Thêm `timeFilterActive` |
| 9 | `applyPROVFilters` PROV_MONTH | 7137 | `firstDL` chỉ lấy người đầu tiên | Dùng `.some()` check tất cả deadline |

> [!NOTE]
> Summary pills (`provinceSumTotal`, v.v.) được thiết kế luôn hiện **tổng toàn workspace** (không lọc tháng) — giữ nguyên. Chỉ sửa hành vi popup khi **bấm vào**.
