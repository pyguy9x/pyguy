- 22/09/2026: Token `CB-MAUA-VPDU` (Văn phòng Đảng ủy, scope office) sửa được nhiệm vụ của mình ở Tỉnh giao + BTV + KH100 ngày (khớp VPDU/van phong dang uy + userCan edit); js/legacy.js.
- 22/09/2026: Fix mobile `mLogin is not defined` (relative `app.js`→`/app.js` 404 ở URL `/mobile`) → script tuyệt đối `/mobile/app.js`, `/js/config.js`; mobile/index.html.
- 22/09/2026: Popup Thêm TT/BTV xếp đúng thứ tự (Nguồn giao→...→Lãnh đạo→Chuyên viên tham mưu→Kết quả→Tệp→Ghi chú), chỉ reorder HTML giữ nguyên ID/data/logic; index.html.
- 22/09/2026: Popup Cập nhật TT/BTV chuyển Lãnh đạo phụ trách + Lãnh đạo UBND + Cơ quan chủ trì xuống dưới Nhiệm vụ thường xuyên; index.html.
- 22/09/2026: Số trong thanh tỉ lệ BCH/BTV nền tối pill (trước trắng trên nền xám khó đọc); css/style.css.
- 22/09/2026: Ghi `mobile-skin.md` (kiến trúc + RBAC + payload + quy ước bảo trì bản mobile).
- 22/09/2026: Cột Trạng thái BCH rộng 15→18% (Nhiệm vụ 33→30%), badge được xuống dòng; BTV badge tóm tắt/chi tiết cũng xuống dòng; css/style.css.
- 22/09/2026: Mobile dùng chung RBAC desktop (userCan/defaults/tier BCH full-broad/Set role/_extraScopes, chặn dept mở BCH-TTBTV-VPUB); mobile/app.js.
- 22/09/2026: Mobile trang chủ thêm "Sắp đến hạn của bạn" (7 ngày, theo phụ trách, chạm mở chi tiết); mobile/app.js.
- 22/09/2026: Mobile khóa VP Đảng ủy: chỉ Admin + token Văn phòng (xem/sửa, ẩn menu + tổng với token khác); mobile/app.js.
- 22/09/2026: Fix mobile báo token sai oan (thiếu dự phòng như desktop) → thêm `mResolveToken` đọc trực tiếp Supabase; mobile/app.js.
- 22/09/2026: Mobile thêm workspace VP Đảng ủy (gộp department+office như desktop, xem/sửa/gia hạn; không thêm/xóa) → tổng khớp 1027; mobile/index.html mobile/app.js.
- 22/09/2026: Fix mobile `Cannot access WS before initialization` (session cũ restore giữa chừng file) → `initMRestore()` gọi cuối file; mobile/app.js.
- 22/09/2026: Mobile không trắng trang nữa: menu tĩnh, bẫy lỗi toàn cục hiện toast, timeout 25s, lỗi tải hiện rõ + nút Thử lại; mobile/index.html mobile/app.js.
- 22/09/2026: Mobile trang chủ thêm biểu đồ donut tổng + thanh tỉ lệ từng workspace (CSS thuần); mobile/index.html mobile/app.js.
- 22/09/2026: Bản mobile `/mobile` (xem + sửa full 5 workspace: pill trạng thái, tìm kiếm, thẻ, chi tiết, Sửa/Thêm/Xóa/Gia hạn, menu drawer toggle); mobile/index.html mobile/app.js vercel.json.
- 22/09/2026: Fix logo vẫn hiện khi thu gọn (`.sidebar-brand display:flex !important` đè) → rule ẩn thêm `!important`; css/style.css.
- 22/09/2026: Thu gọn ẩn hẳn khối `.sidebar-brand`, mở rộng hiện như cũ; css/style.css.
- 22/09/2026: Fix gốc thu gọn: workspace `fixed left:280px` không theo menu → `left` bám rail (78px, laptop 70px/232px), panel phủ kín sát menu; css/style.css.
- 22/09/2026: Thu gọn sidebar ẩn hẳn logo, nội dung mọi workspace sát mép (`padding-left:8px`); index.html css/style.css.
- 22/09/2026: Fix thu gọn sidebar: init chạy ngay (legacy nạp động hụt DOMContentLoaded), bump cache css/js, icon riêng 🗂️🚩📍📌 thay ✓, title ẩn hẳn + divider, nội dung sát menu; index.html js/main.js js/legacy.js css/style.css.
- 22/09/2026: Sidebar có nút thu gọn (`#sbToggle`, `sb-collapsed` icon-only + title tooltip, nhớ trạng thái), gọn cho laptop 1366x768 (`232px`, paddings chữ nhỏ); index.html js/legacy.js css/style.css.
- 22/09/2026: BCH thêm nút Quý I-IV xen giữa các tháng (`setBCHQuarter`, lọc theo quý hạn, `Cả năm` xóa cả tháng+quý); index.html js/legacy.js css/style.css.
- 22/09/2026: Nút +Thêm nhiệm vụ BCH mở popup Thêm riêng (`bchAddModal`, đủ trường như Cập nhật + Lãnh đạo/Chuyên viên/Ghi chú Admin), lưu qua `stageNewBCHModalTask`/`confirmNewBCHTask`; index.html js/legacy.js.
- 22/09/2026: Nút +Thêm nhiệm vụ mở popup Thêm nhiệm vụ TT/BTV riêng (`ttbtvAddModal`, đủ trường như Cập nhật + Lãnh đạo UBND/Ghi chú Admin), lưu qua `stageNewTTBTVModalTask`/`confirmNewTTBTVTask`; index.html js/legacy.js.
- 22/09/2026: Popup Cập nhật TT/BTV xếp lại: Nguồn giao (+UBND) dưới Nhiệm vụ, Chuyên viên sau Kết quả thực hiện; index.html.
- 22/09/2026: BTV thêm bộ lọc trên danh sách: ô tìm nội dung nhiệm vụ (`ttbtvFTask`→`ttbtvSearch`) + lọc trạng thái (`ttbtvFStatus`→`ttbtvStatusFilter`); index.html css/style.css.
- 22/09/2026: BTV giữ list cơ quan trái + bảng gom nhóm theo Nguồn giao như cũ (5 cột STT/Nguồn giao/Tổng NV/LĐ UBND/LĐ phụ trách, fallback `Chưa rõ cơ quan chủ trì` khớp popup); index.html js/legacy.js.
- 22/09/2026: BTV cột trái chuyển sang gom nhóm theo Nguồn giao như cũ (sort `ttbtvDocDate`, click toggle lọc `TTBTV_SRC_Q`), bỏ list cơ quan (`Chưa rõ cơ quan` lệch popup); index.html js/legacy.js.
- 22/09/2026: BTV port BCH-new-skin: trái hiện tên cơ quan (đếm NV, click lọc agency), bảng 7 cột cột Cán bộ→Nguồn giao + pill/tháng/panels/phân trang; index.html js/legacy.js css/style.css.
- 18/09/2026: Popup Tổng NV Văn phòng đổi textbox tên cán bộ thành nút `🧹 Xóa bộ lọc` (`resetOfficeDrillFilters`); index.html js/legacy.js.
- 18/09/2026: Popup Tổng NV Văn phòng lọc thời gian/quý/tháng theo Hạn hoàn thành (`_dueDate||parseDate(due)`), có lọc xếp Hạn cũ→mới; js/legacy.js.
- 18/09/2026: Popup Tổng NV Văn phòng thêm lọc thời gian/quý/tháng (`#officeDrillTimeFilter` theo ngày tạo, Tháng sau theo hạn + `#officeDrillQuarterFilter`/`#officeDrillMonthFilter`); index.html js/legacy.js.
- 18/09/2026: Popup Tổng NV Văn phòng thêm ô `👤 Lọc tên cán bộ` (`#officeDrillOfficerNameFilter`, `officeFold` includes `owner`) + dropdown sẵn có; index.html js/legacy.js.
- 18/09/2026: Văn phòng thêm bộ lọc Tên cán bộ dòng mới (`#officeOfficerNameFilter` text, `bchFold` includes `owner`, debounce 280ms) + `applyFilters`/`resetFilters`; index.html js/legacy.js.
- 15/09/2026: Set role mở rộng 24 checkbox quyền (Xem/Thêm/Sửa/Xóa × 6 workspace) - auto-detect quyền hiện có theo role+scope, đánh dấu cam khi admin sửa khác mặc định; lưu cấu trúc `{token:{ws:{v,a,e,d}}}`; áp dụng qua `userCan(user, action, wsId)` + `_perms` gắn vào user khi login; index.html js/legacy.js css/style.css.
- 15/09/2026: Set role lưu server `role_overrides` (Supabase) để áp dụng mọi trình duyệt: `api/admin.js` thêm `get/save_role_overrides`, login trả `_perms`/`_extraScopes` cho token; `js/legacy.js` đồng bộ `fetch/saveServerOverrides`, `applyTokenMultiScope` ưu tiên `_perms` từ server; tạo bảng `role_overrides(token pk, perms jsonb)` trong `supabase_seed_tokens.sql`; api/admin.js js/legacy.js supabase_seed_tokens.sql.
- 15/09/2026: Set role áp dụng vào `canEditAction100Task`/`deleteAction100Task`: khi admin tick "Sửa"/"Xóa" VPUB/KH100 cho token (vd `CB-MAUA-NGN-88KQBY`) → bypass check khớp tên/cơ quan trong workspace đó, sửa được mọi nhiệm vụ. Token khác không tick → vẫn check như cũ; js/legacy.js.
- 15/09/2026: Thêm mục 🔐 Set role trong Tiện ích (chỉ Admin): popup liệt kê token từ 5 bảng officers + Admin, checkbox 6 workspace (VP/BCH/TT-BTV/Tỉnh/KH100/VPUB), tick thêm để cấp quyền truy cập sidebar; lưu `localStorage` `vp_token_multiscope` (không đụng DB); index.html js/legacy.js css/style.css.
- 10/09/2026: BTV ngày `dd/mm/yyyy` + nút 📅 lịch popup dùng chung (4 ô thêm/sửa, chọn ngày tự cập nhật trạng thái), danh sách hiển thị Hạn/Ngày HT `dd/mm/yyyy` (giữ nguyên hạn dạng câu chữ); js/legacy.js js/main.js (`legacy.js?v=20260910-11`).
- 10/09/2026: Hiện trạng thái Thường xuyên ở VPUB (BTV đã đủ): badge + chip nhóm + bộ lọc, ô tick Admin trong popup sửa để gán/bỏ (lưu cột `status`); js/legacy.js index.html css/style.css js/main.js (`legacy.js?v=20260910-10`).
- 10/09/2026: Token `CQ-MAUA-CV` đăng nhập chỉ hiện Trang chủ + các menu được sửa (Tỉnh giao, TT/BTV, KH100, VPUB), ẩn VP Đảng ủy/BCH/KPI MTTQ/Tiện ích/Báo cáo; js/legacy.js js/main.js (`legacy.js?v=20260910-9`).
- 10/09/2026: Nhiệm vụ mới thêm lên đầu mọi danh sách drill-down: hàm chung `sortNewestFirst` (ngày tạo rồi `id` giảm dần) cho KPI trang chủ (`showHomeDrill`/`showStatsDrill`), drill VPUB, và chế độ Mới nhất của Văn phòng/BCH/TT-BTV/Tỉnh giao (thay vì `updated_at`); js/legacy.js js/main.js (`legacy.js?v=20260910-8`).
- 10/09/2026: Token `CQ-MAUA-CV` đăng nhập chỉ hiện mỗi Nhiệm vụ VPUB ở sidebar (ẩn mọi menu khác, nhóm tự bung sẵn); js/legacy.js js/main.js (`legacy.js?v=20260910-7`).
- 10/09/2026: Sidebar gom Nhiệm vụ VPUB + KPI MTTQ vào nhóm cha thu/mở `🏢 Các cơ quan khác` (`openOtherWorkspace`, giữ phân quyền cũ, tự ẩn nhóm khi cả 2 mục đều ẩn); index.html js/legacy.js js/main.js (`legacy.js?v=20260910-6`).
- 10/09/2026: Sửa lỗi không lưu được nhiệm vụ VPUB (PGRST204): body POST gửi `ubndSource` camelCase không có trong bảng, map tường minh sang `ubnd_source` + 12 cột snake_case đúng schema; js/legacy.js js/main.js (`legacy.js?v=20260910-5`).
- 10/09/2026: Drill-down KPI VPUB: bấm KPI mở popup `vpubDrillModal` liệt kê nhiệm vụ theo trạng thái (hạn `dd/mm/yyyy`), bấm dòng mở form sửa; nút `+ Thêm nhiệm vụ` mở popup `vpubAddTaskModal` đủ 13 trường (menu, lịch dùng chung), lưu xong tự đóng + reset; index.html js/legacy.js js/main.js (`legacy.js?v=20260910-4`).
- 10/09/2026: VPUB mở rộng nhóm: tách STT (`1.` `2.`...) ra cột riêng cố định 2.6em căn phải, tiêu đề nhiệm vụ thẳng hàng nhau; js/legacy.js css/style.css index.html (`style.css?v=20260910-3`, `legacy.js?v=20260910-3`).
- 10/09/2026: Sửa nút `+ Thêm nhiệm vụ` VPUB bị lệch (hiện nút bằng display mặc định như 2 nút cạnh, thay vì `inline-flex`); bump `legacy.js?v=20260910-2`; js/legacy.js js/main.js.
- 10/09/2026: VPUB ngày tháng `dd/mm/yyyy` + nút 📅 (lịch popup dùng chung, tự cập nhật trạng thái ở form sửa), danh sách hiển thị Hạn/Ngày HT `dd/mm/yyyy`; Lãnh đạo xã phụ trách thành menu 3 tên + Khác ở form thêm/sửa; js/legacy.js.
- 10/09/2026: Thêm nút `+ Thêm nhiệm vụ` cho VPUB (`vpubQuickAddBtn`, chỉ hiện ở mode VPUB + đúng quyền form, bấm mở workspace và cuộn tới form thêm); index.html js/legacy.js; node --check pass.
- 10/09/2026: VPUB thêm Nguồn giao + Nguồn giao UBND ở form thêm và popup sửa (lưu cột `source`/`ubnd_source`, ẩn ở KH100, search được); cần SQL `alter table public.vpub_tasks add column if not exists ubnd_source text default 'Chưa rõ'`; index.html js/legacy.js.
- 10/09/2026: Căn đều card nhiệm vụ khi mở rộng nhóm VPUB: lề thụt đều 24px + viền nhấn, ô toggle cho wrap, badge không co; css/style.css index.html (`style.css?v=20260910-2`).
- 10/09/2026: VPUB bỏ 4 cột Hạn/Còn lại/Trạng thái/Thao tác: thead 6 cột theo mode (`syncAction100Head`), dòng nhóm 6 ô; js/legacy.js; node --check pass.
- 10/09/2026: Sửa vỡ layout nhóm nguồn giao VPUB: thêm CSS `#action100Workspace .ttbtv-source-*` y hệt TT/BTV + bump `style.css?v=20260910`; css/style.css index.html.
- 10/09/2026: VPUB nhóm gộp collapsible theo nguồn giao (`vpubSourceGroupsHtml` + `vpubToggleSourceGroup`, tái dùng style TT/BTV), bấm dòng mở sửa; js/legacy.js; node --check pass.
- 10/09/2026: Migrate `vpub_tasks` từ Supabase mới vào project hiện tại: upsert 55 dòng theo `id` (54 mới + 1 ghi đè), bỏ 3 cột thừa nguồn, `""` về `null` cho cột ngày; backup đích trong thư mục temp.
- 10/09/2026: Thêm `vercel.json` headers `max-age=0, must-revalidate` cho HTML/JS/CSS: F5 luôn kiểm tra bản mới (304 dùng cache nên vẫn mượt), khỏi bump `?v` tay; `sw.js` no-store.
- 10/09/2026: Bump cache JS `main.js`/`legacy.js` lên `?v=20260910` để nhận nút 📅 + lịch popup cây Tỉnh giao sau F5; index.html js/main.js.
- 10/09/2026: Cây Tỉnh giao nút 📅 mở lịch popup tự vẽ (`ppCalPop`: chuyển tháng, Hôm nay/Xóa, ghi `dd/mm/yyyy`), thay lịch native hay lỗi; js/legacy.js; node --check pass.
- 10/09/2026: Cây Tỉnh giao ô Hạn/Ngày HT giữ `dd/mm/yyyy` + nút 📅 mở date picker (`ppOpenDatePicker`), non-admin vẫn khóa nút Hạn; js/legacy.js; node --check pass.
- 10/09/2026: Cây Tỉnh giao Admin sửa được Hạn/Ngày HT: `ppNormalizeDateInputs` giữ input gõ dở + `ppSyncTaskRoleUI` unlock admin cả khi thu gọn; js/legacy.js; node --check pass.
- 10/09/2026: Token Admin `ADM-MAUA-adm` mở full mọi trường cây Tỉnh giao (`ppIsAdmin` check token lưu + `ppScope100*` bypass admin); js/legacy.js; node --check pass.
- 09/09/2026: Token `CQ-MAUA-TVH1-MTTQ` là Admin KPI MTTQ riêng: quản lý mọi nhiệm vụ trong MTTQ nhưng không có quyền Admin toàn hệ thống.
- 09/09/2026: Thêm scope token MTTQ: 10 token cán bộ theo tên viết tắt, giới hạn sửa/xóa đúng nhiệm vụ của mình và cho phép thêm nhiệm vụ; api/admin.js, js/legacy.js, index.html.
- 09/09/2026: Biểu đồ KPI MTTQ chuyển sang dạng cột/thanh ngang, giữ drill-down theo cán bộ và trạng thái; js/legacy.js.
- 09/09/2026: KPI MTTQ thêm drill-down cho danh sách/biểu đồ, biểu đồ cột chồng theo cán bộ và thẻ sắp đến hạn 3/7 ngày; index.html, js/legacy.js, css/style.css.
- 09/09/2026: Sửa lỗi chữ tiếng Việt trong KPI MTTQ: nạp lại dữ liệu Unicode và bổ sung fallback font/subset Vietnamese; index.html, css/style.css.
- 09/09/2026: Đồng bộ Excel KPI MTTQ vào Supabase: 10 cán bộ, 128 danh mục, 145 nhiệm vụ; giữ 4 nhiệm vụ chưa có hạn và khóa nguồn sheet/dòng để chống trùng.
- 09/09/2026: Thêm workspace KPI MTTQ độc lập, giao diện nhập/sửa/xóa nhiệm vụ và bộ lọc; index.html, js/legacy.js, css/style.css.
- 09/09/2026: Bỏ nhãn Cơ quan phụ trách, chỉ giữ tên cơ quan cụ thể in đậm trong chi tiết Tỉnh giao; js/legacy.js.
- 09/09/2026: Tô đậm cả nhãn và tên cơ quan cụ thể trong chi tiết nhiệm vụ Tỉnh giao; js/legacy.js.
- 09/09/2026: Tô đậm nhãn Cơ quan phụ trách trong chi tiết nhiệm vụ mở rộng danh sách cũ Tỉnh giao; js/legacy.js.
- 09/09/2026: VPUB lưu độc lập `leader` (Lãnh đạo xã) và `office_leader` (Lãnh đạo cơ quan), không ghi đè lẫn nhau; js/legacy.js.
- 09/09/2026: Sửa lỗi VPUB không lưu Lãnh đạo xã phụ trách và cho phép token `CQ-MAUA-CV` cập nhật Tên nhiệm vụ; js/legacy.js.
- 09/09/2026: Sửa trạng thái TT/BTV: có Ngày hoàn thành thì so sánh đúng với Hạn, không báo Quá hạn khi đã nhập đủ ngày; js/legacy.js.
- 09/09/2026: Biểu đồ Thời hạn xử lý Tỉnh giao gộp Còn hạn và Chưa rõ hạn thành một nhóm, drill-down lọc cả hai loại; js/legacy.js.
- 09/09/2026: Biểu đồ Số nhiệm vụ Tỉnh giao đếm tổng nhiệm vụ theo từng cơ quan trong cây, không theo tên lãnh đạo; js/legacy.js.
- 09/09/2026: Biểu đồ Số nhiệm vụ Tỉnh giao khớp theo cây thư mục, click mở popup drill-down; js/legacy.js.
- 09/09/2026: Biểu đồ Thời hạn xử lý Tỉnh giao đếm theo từng người trong cây thư mục, click mở popup drill-down; js/legacy.js.
- 09/09/2026: Làm nổi bật nút Xóa lọc riêng trong bộ lọc Tỉnh giao; index.html css/style.css.
- 09/09/2026: Khi lọc cơ quan Tỉnh giao, tiêu đề nhiệm vụ mở rộng hiển thị Nội dung nhiệm vụ của cơ quan đã lọc; bỏ lọc vẫn hiển thị nhiệm vụ chính; js/legacy.js.
- 09/09/2026: Sửa click Danh sách chi tiết Tỉnh giao: tìm cây theo data-id, mở nhiệm vụ/cơ quan trước rồi mới cuộn đúng vị trí; không đổi dữ liệu; js/legacy.js.
- 09/09/2026: Hoàn tác mở khối cơ quan tự động khi click nhiệm vụ Tỉnh giao vì không cuộn ổn định; giữ hành vi cuộn/mở nhiệm vụ cũ; js/legacy.js.
- 09/09/2026: Chuẩn hóa và gộp `Văn phòng Đảng Ủy` vào `Văn phòng Đảng ủy` trong cơ quan Tỉnh giao; js/legacy.js.
- 09/09/2026: Biểu đồ Tỉnh giao đổi Hiệu suất Top 10 từ cán bộ sang cơ quan, gồm cơ quan chủ trì và phối hợp; index.html js/legacy.js.
- 09/09/2026: Đổi tiêu đề Tỉnh giao từ Danh sách kiểu cũ thành Danh sách chi tiết; index.html.
- 09/09/2026: Thêm tiêu đề lớn phân tách Danh sách kiểu cũ và Cây thư mục Tỉnh giao; index.html css/style.css.
- 09/09/2026: Lọc cơ quan Tỉnh giao đồng bộ với cây thư mục, giữ các nhiệm vụ phù hợp hiển thị để bấm từ danh sách cũ truy cập đúng cây; js/legacy.js.
- 09/09/2026: Bộ lọc cơ quan Tỉnh giao cập nhật sau khi cây tải xong, chỉ lấy Cơ quan phụ trách/phối hợp, không lấy tên lãnh đạo; js/legacy.js.
- 09/09/2026: Bộ lọc Tỉnh giao đổi từ Tất cả cán bộ sang Tất cả cơ quan, gồm cả cơ quan chủ trì và phối hợp; index.html js/legacy.js.
- 09/09/2026: Danh sách cũ Tỉnh giao lấy đủ toàn bộ cơ quan chính/phối hợp từ từng nhiệm vụ cây, không còn thiếu cơ quan như Công an xã; js/legacy.js.
- 09/09/2026: Nguồn giao khi mở rộng nhiệm vụ cũ Tỉnh giao chia hai cột Văn bản của tỉnh/Văn bản của xã và đổi nền vùng mở rộng nổi bật hơn; js/legacy.js css/style.css.
- 09/09/2026: Nguồn giao khi mở rộng nhiệm vụ cũ Tỉnh giao phân biệt rõ `Văn bản của tỉnh` và `Văn bản của xã`; js/legacy.js.
- 09/09/2026: Bỏ bullet ở cột Nguồn giao khi danh sách kiểu cũ Tỉnh giao chưa mở rộng; chi tiết vẫn giữ bullet; js/legacy.js.
- 09/09/2026: Bỏ nhãn `Nguồn giao:` ở dòng nhóm danh sách cũ Tỉnh giao, giữ nguyên phần chi tiết mở rộng; js/legacy.js.
- 09/09/2026: Định dạng Nguồn giao danh sách cũ Tỉnh giao xuống dòng, thêm bullet cho từng văn bản; js/legacy.js.
- 09/09/2026: Chi tiết nhiệm vụ mở rộng trong danh sách cũ Tỉnh giao hiển thị toàn bộ văn bản tỉnh/xã của nhiệm vụ chính ở Nguồn giao; js/legacy.js css/style.css.
- 09/09/2026: Nguồn giao danh sách cũ Tỉnh giao gom toàn bộ văn bản tỉnh và văn bản xã trong nhiệm vụ chính; js/legacy.js.
- 09/09/2026: Nguồn giao danh sách cũ Tỉnh giao lấy văn bản tỉnh cụ thể từ nhiệm vụ chính, fallback `Văn bản của tỉnh`; không ghi ngược dữ liệu; js/legacy.js.
- 09/09/2026: Danh sách cũ Tỉnh giao cố định Nguồn giao là `Văn bản của tỉnh`, không thay đổi dữ liệu nguồn; js/legacy.js.
- 09/09/2026: Danh sách cũ Tỉnh giao hiển thị theo nhóm mở rộng giống TT/BTV, chỉ đổi giao diện và giữ nguyên dữ liệu cũ/cây thư mục; index.html js/legacy.js css/style.css.
- 08/09/2026: Cấp quyền token `CQ-MAUA-CV` xóa nhiệm vụ trong workspace VPUB; js/legacy.js; node --check pass.
- 08/09/2026: Đồng bộ cột Cơ quan phối hợp VPUB với trường popup và lưu đúng `field`; cột Lãnh đạo lấy đúng `leader`; js/legacy.js; node --check pass.
- 08/09/2026: Popup VPUB đổi Cơ quan phối hợp thành dropdown dùng cùng danh sách Cơ quan phụ trách; index.html js/legacy.js; node --check pass.
- 08/09/2026: Trường ngày tháng VPUB chuyển sang nhập `dd/mm/yyyy`, tự định dạng và chuyển đổi đúng khi lưu; js/legacy.js; node --check pass.
- 08/09/2026: Mục Khác của dropdown lãnh đạo VPUB đổi sang tiêu đề và hướng dẫn nhập tên lãnh đạo; js/legacy.js; node --check pass.
- 08/09/2026: VPUB thêm menu Cơ quan phụ trách và Lãnh đạo cơ quan phụ trách ở form thêm/cập nhật; lưu đúng giá trị cơ quan khi chỉnh sửa; js/legacy.js index.html; node --check pass.
- 07/09/2026: TT/BTV đặt giá trị mặc định `Chưa rõ` cho textbox Nguồn giao của UBND ở form thêm và popup cập nhật (không dùng placeholder); js/legacy.js; node --check pass.
- 07/09/2026: Khôi phục banner sidebar về "Văn phòng số Mậu A / Văn phòng Đảng ủy"; index.html; node --check pass.
- 07/09/2026: Bump cache JS `main.js`/`legacy.js` từ v20260906 lên v20260907 để trình duyệt nhận UI TT/BTV mới sau F5; index.html js/main.js; node --check pass.
- 07/09/2026: Popup Tất cả nhiệm vụ TT/BTV giới hạn tên nhiệm vụ tối đa 6 dòng, hover hiện tooltip đầy đủ; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: Cột Lãnh đạo UBND TT/BTV lấy và gộp trực tiếp từ `ubnd_leader`; chi tiết nhiệm vụ cũng hiển thị đúng trường này; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: TT/BTV popup Cập nhật thêm trường Lãnh đạo UBND (`ubnd_leader`); bỏ cột Thao tác vì bấm dòng để xem/sửa; js/legacy.js index.html; node --check pass.
- 07/09/2026: Bỏ nền/nút tròn SVG nhóm TT/BTV; đổi thứ tự cột thành STT → Nguồn giao → Tổng nhiệm vụ → Lãnh đạo UBND → Lãnh đạo phụ trách → Thao tác; index.html js/legacy.js css/style.css; node --check pass.
- 07/09/2026: Dòng nhóm TT/BTV bấm trực tiếp để mở/thu gọn; nút mở rộng đổi sang icon SVG plus/minus, có aria-label; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: Nút mở rộng nhóm TT/BTV đổi thành nút tròn đẹp hơn; tiêu đề nhiệm vụ căn thẳng hàng, ellipsis và tooltip hiện đầy đủ nội dung; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: Thống kê nhóm TT/BTV hiển thị tổng nhiệm vụ kèm đếm Hoàn thành/Đang triển khai/Quá hạn/Thường xuyên theo từng nguồn giao; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: TT/BTV mở rộng nhóm đổi màu dòng (nền chàm + viền trái + nút −) để dễ phân biệt; js/legacy.js css/style.css; node --check pass.
- 07/09/2026: Fix mất cột Nguồn giao TT/BTV (CSS cũ display:none c-amount → hiện lại 28% cho bảng nhóm); css/style.css; git diff --check pass.
- 07/09/2026: TT/BTV sắp xếp cột theo yêu cầu: STT → Tổng nhiệm vụ → Nguồn giao → Lãnh đạo UBND (để trống) → Lãnh đạo phụ trách → Thao tác; index.html js/legacy.js; node --check pass.
- 07/09/2026: TT/BTV chi tiết đổi `ttbtv-task-meta` sang grid 5 cột, thẳng hàng và responsive; danh sách chính giữ thứ tự STT → Nguồn giao; css/style.css; node --check pass.
- 07/09/2026: Danh sách TT/BTV nhóm theo Nguồn giao, hiển thị tổng nhiệm vụ + lãnh đạo UBND/phòng ban; click accordion xem từng nhiệm vụ và mở popup sửa; js/legacy.js index.html css/style.css; node --check pass.
- 07/09/2026: Nhật ký hoạt động thêm lọc Có nội dung nhiệm vụ, Chỉ dòng của Admin và menu lọc Thao tác; index.html js/legacy.js; node --check pass.
- 07/09/2026: Fix mất focus toàn bộ token/workspace: CSS pointer-events/user-select toàn cục + document capture pointerdown/mousedown + giữ focusFirstEditable; js/legacy.js css/style.css CONTEXT.md; node --check pass.
- 07/09/2026: Thu gọn form Thêm nhiệm vụ TT/BTV, giữ nguyên grid nhưng giảm padding/gap/chiều cao textarea và nút lưu; css/style.css; node --check pass.
- 07/09/2026: Form Thêm nhiệm vụ TT/BTV làm lại bố cục grid 4 cột, card field, responsive mobile, nhóm textarea và nút lưu nổi bật; css/style.css; node --check pass.
- 07/09/2026: Popup Thêm nhiệm vụ TT/BTV đổi Lãnh đạo phụ trách sang menu danh sách cán bộ như popup Cập nhật + Khác (Nhập tên); js/legacy.js; node --check pass.
- 07/09/2026: Form Thêm nhiệm vụ VPUB đổi Đơn vị sang menu KT/VH/CA/QS/HCC/DVTH/VP + Khác (Nhập tên), dùng dialog xác nhận; js/legacy.js; node --check pass.
- 07/09/2026: TT/BTV thêm Cơ quan chủ trì → Khác (Nhập tên) ở form thêm/sửa, nhập qua dialog xác nhận; js/legacy.js index.html; node --check pass.
- 07/09/2026: TT/BTV thêm `ubnd_source` bắt buộc; CV được sửa Ghi chú cán bộ; thêm trường Nguồn giao của UBND ở form thêm/sửa; js/legacy.js index.html; node --check pass.
- 07/09/2026: Khóa CV Nhập liệu sửa Nội dung + Hạn hoàn thành ở TT/BTV, Tỉnh bảng cũ, KH100/VPUB (UI readonly + payload giữ giá trị cũ, chỉ Admin); js/legacy.js; node --check pass.
- 07/09/2026: Fix CV Nhập liệu ko vào được workspace (api/admin trả nhầm role department → staff/data_entry đồng bộ local, qua gate TT/BTV + Tỉnh + VPUB); api/admin.js; node --check pass.
- 07/09/2026: Fix đơ input popup Sửa TT/BTV (tooltip ẩn opacity 0 vẫn chặn click z 99999 → pointer-events none khi ẩn, auto khi hiện); css/style.css; git diff --check pass.
- 07/09/2026: Mở quyền CQ-MAUA-CV sửa hết trừ Văn phòng + BCH (Tỉnh bảng cũ full nghiệp vụ + cây 5 trường/agency, KH100/VPUB full trừ Ghi chú Admin, không xóa KH100/VPUB); js/legacy.js; node --check pass.
- 07/09/2026: Fix mất focus CQ-MAUA-CV (auto-focus không giật khi user đã bấm ô nhập + ẩn tooltip hover khi mở modal + chặn pointerdown); js/legacy.js; node --check pass.
- 07/09/2026: TT/BTV thêm trạng thái Thường xuyên (key regular, chỉ Admin gán/bỏ qua checkbox, giữ nguyên logic auto cũ); js/legacy.js index.html css/style.css; node --check pass.
- 04/09/2026: Bỏ nút + Thêm người ở cây Tỉnh giao (giữ lưới 2 hàng, date-picker, Enter, badge); js/legacy.js; node --check pass.
- 04/09/2026: Token TT/BTV sửa được Lãnh đạo phụ trách nhiệm vụ của mình; js/legacy.js; node --check pass.
- 04/09/2026: Bộ lọc thời gian VP Đảng ủy lọc theo ngày tạo (Hôm nay hiện NV tạo hôm nay, trước đó lọc nhầm theo Hạn); js/legacy.js; node --check pass.
- 04/09/2026: Popup sửa TT/BTV: Lãnh đạo phụ trách thêm tùy chọn Khác (dialog đẹp + xác nhận); js/legacy.js; node --check pass.
- 04/09/2026: Token TT/BTV sửa được Nguồn giao nhiệm vụ của mình (mở readOnly + lưu patch); js/legacy.js; node --check pass.
- 04/09/2026: Xóa nhãn (không bắt buộc) ở Nguồn giao form sửa TT/BTV (đổi *); index.html; git diff --check pass.
- 04/09/2026: TT/BTV Nguồn giao bắt buộc khi thêm/sửa (validate + nhãn *); js/legacy.js; node --check pass.
- 04/09/2026: Bảng BCH: cột Nhiệm vụ 34%→27%, cột Trạng thái 12% + min 140px (hết che); css/style.css; git diff --check pass.
- 04/09/2026: Cột Kết quả BCH lấy theo Sản phẩm (fallback Kết quả cũ); js/legacy.js; node --check pass.
- 04/09/2026: Nút Mở rộng/Thu gọn agency màu chàm + thêm nút cho Nhiệm vụ chính (thu gọn được); js/legacy.js css/style.css; node --check pass.
- 04/09/2026: Textarea cây Tỉnh giao min-height 80px; js/legacy.js; node --check pass.
- 04/09/2026: Chỉ Admin thêm/xóa văn bản tỉnh/xã ở cây Tỉnh giao (khóa nút × dòng VB + chặn ppAddDoc/ppRemoveDoc); js/legacy.js; node --check pass.
- 04/09/2026: Bỏ toàn bộ viền khung cây Tỉnh giao (chỉ giữ thanh màu trạng thái trái), khử viền đen focus, chống cache CSS/JS (v=20260905); js/legacy.js css/style.css js/main.js index.html; node --check pass.
- 04/09/2026: Bỏ viền pp-person + pp-agency (border:none, giữ nền phân biệt); js/legacy.js; node --check pass.
- 04/09/2026: Viền pp-agency đổi sang #8895b3; js/legacy.js; node --check pass.
- 04/09/2026: Viền pp-person Quá hạn đỏ nhạt #fca5a5 (dòng sửa được giữ viền xanh); js/legacy.js; node --check pass.
- 04/09/2026: Viền pp-person đổi sang #8895b3; js/legacy.js; node --check pass.
- 04/09/2026: Bỏ viền person + viền xám agency, fix borderColor đè mất màu trạng thái khi thu gọn, chống cache JS (v=20260904); js/legacy.js js/main.js index.html; node --check pass.
- 04/09/2026: Bỏ viền đen nút trong cây Tỉnh giao (khai báo border đồng màu nền cho ▼/Lưu/Sửa/Xóa/X); js/legacy.js; node --check pass.
- 04/09/2026: Phân tầng viền cây Tỉnh giao: task chàm 2px + bóng khi mở rộng, pcm hồng nhạt nhất, bỏ viền xám đen; js/legacy.js; node --check pass.
- 04/09/2026: Token CQ-VPUB-MAUA thêm alias UBND xã (sửa được nhiệm vụ chính UBND xã); js/legacy.js; node --check pass.
- 04/09/2026: Cây Tỉnh giao đánh dấu mục sửa được: agency + dòng person viền/bóng xanh nhạt (#6ee7b7); js/legacy.js; node --check pass.
- 04/09/2026: Token CQ-VPUB-MAUA sửa được nhiệm vụ Văn phòng HĐND & UBND trong cây Tỉnh giao (alias VPUB + mở scope vpub, chỉ 5 trường trong agency khớp); js/legacy.js; node --check pass.
- 04/09/2026: Cây Tỉnh giao dễ nhập liệu: person lưới 2 hàng + tiêu đề cột sticky, ô ngày date-picker (tương thích dd/mm/yyyy cũ), Enter chuyển ô, nút + Thêm người, badge x/y hoàn thành trên thanh agency; js/legacy.js; node --check pass.
- 04/09/2026: Bỏ trạng thái undefined ở biểu đồ Tỷ lệ theo trạng thái (gom về Đang triển khai); js/legacy.js; node --check pass.
- 04/09/2026: Trang chủ đổi nhãn biểu đồ: Văn phòng → Văn phòng Đảng ủy, VPUB → VP HĐND&UBND (bar + Top cơ quan + lọc nhanh); js/legacy.js index.html; node --check pass.
- 04/09/2026: Cột Trạng thái Tỉnh giao: nhiệm vụ hoàn thành ghi gọn Hoàn thành (chi tiết giữ trong tooltip); js/legacy.js; node --check pass.
- 04/09/2026: Nhãn thu gọn cây Tỉnh giao: toàn bộ đúng/trước hạn → Hoàn thành (bỏ qua dòng person trống khi gom trạng thái); js/legacy.js; node --check pass.
- 04/09/2026: Cây Tỉnh giao chốt trạng thái theo ngày như Văn phòng: đủ Ngày HT + Hạn thì hoàn thành (trước/đúng/HT quá hạn), hết treo Quá hạn; js/legacy.js; node --check pass.
- 04/09/2026: Xóa bch_officers khỏi api/admin.js + BACKUP_TABLES (bảng không tồn tại, nhánh lookup luôn null); api/admin.js js/legacy.js; node --check pass.
- 04/09/2026: Sao lưu đủ data (14 bảng): đọc phân trang limit/offset (fix cắt 1000 dòng), bỏ qua bảng lỗi thay vì sập, restore xóa id=not.is.null (tương thích uuid); js/legacy.js; node --check pass.
- 04/09/2026: Vinh danh BCH theo nhiệm vụ hoàn thành nhiều nhất trong quý (lọc done>0, popup chỉ hiện NV hoàn thành, đổi nhãn); js/legacy.js index.html; node --check pass.
- 04/09/2026: Cây Tỉnh giao sắp xếp mặc định theo ngày tạo mới nhất lên đầu (fallback stt/id); js/legacy.js; node --check pass.
- 04/09/2026: Ẩn 2 nút Xuất sang danh sách kiểu cũ + Xác nhận lưu Supabase ở thẻ Kế hoạch Tỉnh giao (chỉ giữ + Nội dung); index.html; node --check pass.
- 04/09/2026: Danh sách cũ Tỉnh giao hiển thị theo cây mới (bảng/KPI/biểu đồ/drill/lọc ưu tiên getPROVTreeRows, click cuộn tới cây); js/legacy.js; node --check pass.
- 04/09/2026: Bỏ form Thêm nhiệm vụ trong popup Tỉnh giao (nút + Thêm mở cây mới provincePlanAddTask); js/legacy.js; node --check pass.
- 04/09/2026: Hiệu suất Top10 + tròn Số NV Tỉnh giao theo từng cán bộ (buildPROVPerfPersons, click drill đúng người); js/legacy.js; node --check pass.
- 04/09/2026: Vinh danh cá nhân VP theo tháng (subtitle Vinh danh trong tháng); js/legacy.js; node --check pass.
- 04/09/2026: Gỡ SW vps-maua-v1 treo F5 (sw.js killer + gỡ dự phòng khi tải trang); sw.js js/legacy.js; node --check pass.
# Nhật ký sửa file - (opencode tự cập nhật)

## 2026-08-21 - Kế hoạch Tỉnh giao cây + chi tiết cơ quan + tóm tắt
- Việc: thêm Mô tả ngắn, Nhiệm vụ cụ thể/Cơ quan, Tên cơ quan khác song song, LĐ UBND↔LĐCQ, serialize toàn bộ person/PCM để F5 không mất, tóm tắt thu gọn thêm Hạn, sửa lỗi mota column PGRST204
- File: `index.html`, `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-21 - Kế hoạch Tỉnh giao dạng cây thư mục
- Việc: thay bảng rowspan bằng cây thư mục thu gọn/mở rộng, mỗi người 1 dòng trạng thái riêng, VB tỉnh/xã +VB/×, Cơ quan UBND 3 vị trí/khác 2 vị trí, LĐ PCM tùy biến +/-, lưu province_plan_blocks
- File: `index.html`, `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-21 - TT/BTV + KH100 phân quyền + UI focus + sidebar
- Việc: Cảnh báo chỉ Admin; KH100 non-admin chỉ sửa 3 trường; TT/BTV thêm token DMC-Đinh Mạnh Cường và cho sửa Ghi chú khi khớp tên (bỏ scope check); focus viền #6d28d9 đậm; Báo cáo xuống cuối menu
- File: `js/legacy.js`, `css/style.css`, `index.html`
- Test: node --check js/legacy.js (pass)

## 2026-08-21 - Sửa Trạng thái + Số ngày còn lại KH 100 ngày
- Việc: bỏ `x.status` cũ, luôn dùng `action100Label(action100Status(x))` nên Quá hạn hiển thị đúng; thêm `action100RemainingDays/Text` (có completed: deadline-completed, không: today-deadline) cho form thêm/sửa
- File: `js/legacy.js`
- Test: node --check js/legacy.js (pass)

# Nhật ký sửa file (opencode tự cập nhật)

> Quy tắc: Sau mỗi task, thêm 1 dòng mới lên đầu. Quá 10 dòng thì xóa dòng cũ nhất hoặc chuyển vào archive.md
> Format: Ngày - Việc - File - Test

## 2026-08-21 - Sửa lỗi xóa nhiệm vụ Văn phòng bị hiện lại sau F5
- Việc: deleteOfficeTask chỉ xóa office_tasks nên nhiệm vụ merge/department-only còn gốc department_tasks → load lại hiện lại; thêm bước DELETE department_tasks theo sheet_name+row_number (kèm console.log), bỏ qua với office-only
- File: `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Thêm nút Dừng gửi email trong popup cảnh báo
- Việc: thêm nút 'Dừng gửi' cạnh 'Gửi tất cả'; dùng flag DAILY_WARN_STOPPED để dừng vòng lặp gửi email ngay lập tức, khôi phục nút gửi
- File: `js/legacy.js`, `index.html`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Popup cảnh báo: ẩn quá hạn, mỗi task 1 email, sidebar Tiện ích
- Việc: thêm mục 'Cảnh báo' vào sidebar Tiện ích; popup chỉ hiện sắp đến hạn, mỗi task 1 ô email, sort theo workspace; ẩn quá hạn; sendDailyWarnEmails gửi theo email từng task
- File: `js/legacy.js`, `index.html`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Cảnh báo sắp đến hạn + Popup + Gửi email hàng loạt
- Việc: mở rộng checkDailyOverdueAlert kiểm tra cả sắp đến hạn 3 ngày; toast clickable mở popup danh sách; popup có bảng tóm tắt + ô email + nút gửi; sendDailyWarnEmails gửi tuần tự qua Edge Function
- File: `js/legacy.js`, `index.html`, `css/style.css`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Cảnh báo nhiệm vụ quá hạn hàng ngày 7h sáng
- Việc: thêm hàm checkDailyOverdueAlert() đếm quá hạn 6 workspace (Văn phòng/BCH/TT-BTV/Tỉnh giao/KH100/VPUB); toast warning màu vàng; ghi nhật ký; chạy 1 lần/ngày qua localStorage
- File: `js/legacy.js`, `css/style.css`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Sửa biểu đồ tròn "Theo cơ quan chủ trì" TT/BTV
- Việc: dùng (role||unit_name) làm tên cơ quan (sửa tên trống/sai); bỏ giới hạn slice(0,7) để tổng các cơ quan khớp đúng tổng nhiệm vụ TT/BTV; đồng bộ bộ lọc khi bấm vào một lát cắt
- File: `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-20 - Admin toàn quyền sửa ghi chú (cán bộ + Admin) mọi workspace
- Việc: sửa readOnly của staff_note cho Admin tại Văn phòng, BCH, TT/BTV, Tỉnh giao, KH 100 ngày/VPUB; Admin giờ sửa được cả ghi chú cán bộ và ghi chú Admin; cập nhật help text tương ứng
- File: `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Đồng bộ "Cơ quan (đơn vị tham mưu)" Tỉnh giao: list ↔ popup sửa
- Việc: bỏ fallback `|| role` khi lưu trường Cơ quan (đơn vị tham mưu) ở popup Cập nhật; giờ lưu đúng giá trị nhập (hoặc rỗng), danh sách hiển thị khớp hệt popup
- File: `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Đóng modal xác nhận sau khi thêm nhiệm vụ Tỉnh giao/BCH
- Việc: thêm `smoothCloseModal("addConfirmModal")` sau khi thêm thành công ở Tỉnh giao và BCH (tránh double-add); thêm guard `PENDING_PROV_TASK` ở đầu `stageNewPROVTask` để không mở modal mới khi đang xử lý
- File: `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Ngăn chặn thêm nhiệm vụ KH 100 ngày đôi khi
- Việc: thêm kiểm tra `PENDING_ACTION100_ADD_TASK` ở đầu `prepareAction100AddTask`; nếu đã có nhiệm vụ đang xử lý thì hiện toast cảnh báo và không mở modal mới; ngăn chặn bấm xác nhận twice
- File: `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Tooltip nhiệm vụ cuộn được: không bị che lại nội dung
- Việc: bỏ `max-height: 260px` và `pointer-events: none` trong CSS tooltip `.task-tip-popup`; thêm delay 200ms trước khi ẩn tooltip + listeners `mouseenter`/`mouseleave` trên tooltip; người dùng có thể hover ô nhiệm vụ, di chuột vào tooltip và lăn chuột để đọc nội dung đầy đủ
- File: `css/style.css`, `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Bảng Tỉnh giao: chỉ giữ 11 cột theo yêu cầu
- Việc: bỏ 3 cột Hình thức cụ thể hóa, Lãnh đạo phòng chuyên môn, Chuyên viên; giữ STT, Nhiệm vụ cụ thể, Thẩm quyền ban hành, Cơ quan (đơn vị tham mưu), Lãnh đạo(UBND), Hạn, Ngày hoàn thành, Thời gian còn lại, Tiến độ, Trạng thái, Sản phẩm; giữ min-width 210px + cuộn ngang
- File: `index.html`, `js/legacy.js`, `css/style.css`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Điều chỉnh chiều rộng cột bảng Tỉnh giao
- Việc: cột Nhiệm vụ cụ thể rộng nhất (min 420px, tối đa 640px); các cột khác tăng min-width (170px form/auth/unit/leader, 220px sản phẩm...) để không bị nhỏ; bảng width max-content + overflow-x auto giữ thanh cuộn ngang; không cần vừa khít 1920x1080, ưu tiên hiển thị đủ nội dung
- File: `css/style.css`
- Test: git diff --check (pass)

## 2026-08-20 - Sửa cột danh sách Nhiệm vụ Tỉnh giao khớp tiêu đề + cuộn ngang
- Việc: dựng lại đúng 14 cột đúng thứ tự (STT→Sản phẩm): task_name, source_form, issuing_authority, unit_name, officer_name, role, specialist_name, deadline, completed_date, thời gian còn lại (provinceRemainingText), progress, status, product; thêm class prov-wide (min-width từng cột) để có thanh cuộn ngang khi nội dung dài; hover tooltip cho ô chuyên viên/sản phẩm/nhiệm vụ
- File: `index.html`, `js/legacy.js`, `css/style.css`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Thêm trường "Nguồn giao" cho TT/BTV
- Việc: thêm ô nhập "Nguồn giao" (không bắt buộc) ở form Thêm và popup Cập nhật nhiệm vụ TT/BTV; lưu vào cột amount, hiển thị ở cột "Nguồn giao" danh sách chính; giữ nguyên dữ liệu cũ từ DB
- File: `index.html`, `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Sửa tooltip nhiệm vụ TT/BTV: đúng class task-tip, bỏ title gốc
- Việc: đổi class bch-task-tip→task-tip để khớp handler có sẵn; bỏ title gốc "Click để xem chi tiết nhiệm vụ" trên row (trước đó che mất popup nội dung); hiện popup nội dung đầy đủ khi hover tên nhiệm vụ
- File: `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Tooltip nhiệm vụ TT/BTV: bỏ tooltip đếm, thêm tooltip hover nhiệm vụ
- Việc: bỏ tooltip "Tổng nhiệm vụ:xx" (về text thường); hover tên nhiệm vụ hiện popup nội dung đầy đủ dạng fixed body (không bị che bởi overflow table), z-index cao
- File: `index.html`, `css/style.css`, `js/legacy.js`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Đẹp tooltip "xx nhiệm vụ đang hiển thị" TT/BTV
- Việc: biến dòng đếm thành tooltip khi hover (CSS-only, data-tooltip) với chữ lớn sáng sủa, đúng bộ lọc, bo tròn + bóng đổ + mũi tên
- File: `index.html`, `css/style.css`
- Test: node --check js/legacy.js + git diff --check (pass)

## 2026-08-20 - Nút xuất CSV danh sách quá hạn popup TT/BTV
- Việc: thêm nút "⬇️ Xuất CSV" bên trái nút "Đóng" ở popup TTBTV Drill (áp dụng mọi chế độ: quá hạn/đang xử lý/hoàn thành/tất cả); xuất đúng danh sách đang lọc+sắp xếp ra CSV (Excel mở được, có BOM UTF-8)
- File: `index.html`, `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-19 - Log nhật ký Admin trên mọi workspace + nút Thêm nhiệm vụ theo quyền
- Việc: thêm writeActivity (Thêm/Sửa/Xóa nhiệm vụ, Xóa file, Duyệt file) cho BCH, TT/BTV, Tỉnh giao, KH100/VPUB; nút "Thêm nhiệm vụ" chỉ hiện cho ai có quyền thêm trong workspace tương ứng; khi bấm tự mở workspace + scroll tới form thêm
- File: `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-19 - Popup TT/BTV: danh sách cố định Cơ quan chủ trì, tooltip KPI
- Việc: danh sách Cơ quan chủ trì popup/drill/add dùng list cứng 10 cơ quan; tooltip KPI cards + chart tròn TT/BTV; check CQ-MAUA-CV TRƯỚC DEPARTMENT_TOKENS; mở office workspace → redirect TT/BTV; cột Cơ quan chủ trì dùng x.role/x.unit_name;补齐 done label cho biểu đồ
- File: `js/legacy.js`, `index.html`
- Test: node --check js/legacy.js (pass)

## 2026-08-19 - Đổi placeholder trường Kết quả thực hiện ở mọi popup
- Việc: đổi placeholder trường 'Kết quả thực hiện' ở popup edit + form thêm của mọi workspace (Văn phòng, BCH, TT/BTV, Tỉnh giao, KH 100 ngày/VPUB) thành 'Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp...'
- File: `index.html`, `js/legacy.js`
- Test: node --check js/legacy.js (pass)

## 2026-08-19 - CQ-MAUA-CV: thêm/sửa/xóa chỉ trong BTV; lọc & tìm trong popup KPI TT/BTV
- Việc: CQ-MAUA-CV (data_entry) chỉ được thêm/sửa/xóa nhiệm vụ trong workspace TT/BTV, không quyền ở BCH/Tỉnh/100ngày/Văn phòng/Nhật ký; thêm popup KPI TT/BTV bộ lọc Cơ quan chủ trì (role), Lãnh đạo phụ trách (officer_name) + ô tìm mọi nội dung + nút Xóa lọc. BTV: CQ-MAUA-CV không được sửa Ghi chú của Admin (chỉ Admin).
- File: `js/legacy.js`, `index.html`
- Test: node --check js/legacy.js (pass), git diff --check (pass)

## 2026-08-19 - Nút Gia hạn chỉ hiện với nhiệm vụ Quá hạn
- Việc: sửa điều kiện hiện nút Gia hạn ở cột Thao tác popup Văn phòng từ độ trễ ngày (urgency) sang trạng thái text `Quá hạn`; chỉ Admin
- File: `js/legacy.js` dòng renderOfficeDrillRows
- Test: node --check js/legacy.js (pass)

## 2026-08-19 - Tìm kiếm & xem chi tiết nhiệm vụ VP Đảng ủy
- Việc: thêm ô tìm kiếm mọi nội dung (tên, cán bộ, vai trò, ghi chú, sản phẩm) tại workspace VP + lọc thời gian + hiện kết quả dưới ô tìm; click kết quả mở popup chi tiết nhiệm vụ
- File: `index.html`, `js/legacy.js` (officePerformanceRows, renderOfficePerformanceResults), `css/style.css`
- Test: node --check js/legacy.js (pass)

## 2026-08-18 - Tối ưu token opencode & DeepSeek
- Việc: Tách CONTEXT.md 230 dòng (100k token) -> bản gọn 12k token (1%), fix opencode.json sai JSON làm không ignore được archive.md
- File: `opencode.json`, `CONTEXT.md` -> `CONTEXT_GON.md`, `archive.md`, `AGENTS.md`
- Test: `Read CONTEXT.md` -> 12.1K (1%) - $0.00 OK - Build 9.7s
- Chi phí trước: 40M token -> $2.00, Sau: $0.00/request

## 2026-08-18 - Xác nhận thêm nhiệm vụ Tỉnh/BCH/BTV
- Việc: Thêm popup xác nhận #addConfirmModal trước khi ghi Supabase, z-index 999999 để luôn nổi trên cùng
- File: `js/legacy.js` hàm `openAddConfirm()`, `stageNewPROVTask()`, `confirmNewPROVTask()`, `index.html`
- Test: node --check js/legacy.js, git diff --check

## 2026-08-17 - Tươi lục trường Tỉnh giao + hover trang chủ
- Việc: Đổi thứ tự trường form Tỉnh giao (Nhiệm vụ, Hình thức cụ thể hóa source_form, Thẩm quyền ban hành issuing_authority, Cơ quan unit_name, Lãnh đạo officer_name, role, specialist_name, Hạn, Tiến độ progress, Sản phẩm product), hover tên nhiệm vụ dài hiện tooltip .task-tip-popup
- File: `js/legacy.js` renderPROVAddTaskRow, openPROVTaskDetail, `index.html`, `css/style.css`
- Test: node --check OK

## 2026-08-17 - Cập nhật VPUB và token CQ-VPUB-MAUA
- Việc: Thêm workspace Nhiệm vụ VPUB (12 trường), đơn vị KT,VH,CA,QS,HCC,DVTH,VP, token CQ-VPUB-MAUA xem BCH/TT/BTV/Tỉnh giao/KH100 ngày, tự thêm ở VPUB, không xem Văn phòng
- File: `js/legacy.js`, `index.html`, `token.txt`, bảng `public.vpub_tasks`
- Test: node --check js/legacy.js

## 2026-08-16 - Token cơ quan và bố cục workspace
- Việc: Thêm 8 token cơ quan scope action100 (VPDU,UBNDXA,BANXDD,MTTQ,HDND,CBCONGAN,CBQUANSU,UBKT) role department, tăng chiều cao biểu đồ Top 10 lên 330px desktop, click cán bộ mở drill-down danh sách nhiệm vụ
- File: `js/legacy.js`, `css/style.css`, `token.txt`
- Test: node --check js/legacy.js, git diff --check

## 2026-08-16 - KH Hành Động 100 Ngày - Hoàn thành
- Việc: Tạo menu/workspace riêng, kết nối 2 bảng action_100_days_officers + action_100_days_tasks, có KPI, tìm kiếm, lọc trạng thái, popup đủ trường
- File: `index.html`, `js/legacy.js`, `css/style.css`
- Test: node --check js/legacy.js

# Cách dùng với opencode:
# 1. @CHANGES.md hôm trước sửa file gì?
# 2. Sau khi xong task: "Ghi lại vào CHANGES.md"
- 09/09/2026: Biểu đồ Thời hạn xử lý Tỉnh giao đổi nhóm Còn hạn/Chưa rõ hạn thành Sắp đến hạn trong 7 ngày, áp dụng cùng điều kiện cho drill-down; js/legacy.js.
- 09/09/2026: Giữ hiển thị nhóm Sắp đến hạn trong 7 ngày trên biểu đồ Tỉnh giao kể cả khi số lượng bằng 0; js/legacy.js.
- 09/09/2026: Biểu đồ Tỉnh giao đổi Theo cơ quan tham mưu thành Theo tên lãnh đạo cơ quan, cập nhật đếm và drill-down; js/legacy.js, index.html.
- 09/09/2026: Hiển thị badge trạng thái của từng nhiệm vụ phối hợp cạnh nút Xóa nhiệm vụ khi khối chưa mở rộng; js/legacy.js.
- 09/09/2026: Danh sách chi tiết Tỉnh giao hiển thị badge trạng thái theo đúng cơ quan đang lọc, thay vì trạng thái tổng của nhiệm vụ; js/legacy.js.
- 09/09/2026: Các trường ngày của Tỉnh giao chuyển sang nhập `dd/mm/yyyy`, tự chuẩn hóa khi tải cây và vẫn lưu Supabase dạng `yyyy-mm-dd`; index.html, js/legacy.js.
