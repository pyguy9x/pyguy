# PROV SKIN — Layout bảng "Danh sách chi tiết" Tỉnh giao (bảng CŨ, đã lưu trữ)

> Snapshot trước khi chuyển sang bảng mới (flat rows). Nguồn: `index.html` ~dòng 2590-2618, `js/legacy.js` `renderPROVTable()` ~dòng 4683, `css/style.css` `#provinceWorkspace`.

## 1. Cấu trúc HTML (bảng cũ)

```html
<h2 class="province-section-title">📋 Danh sách chi tiết</h2>
<div class="bch-main">
  <aside class="bch-leaders" id="provinceAgencyPanel">   <!-- sidebar cơ quan -->
    <input id="provinceLeaderSearch" placeholder="Tìm cơ quan..." oninput="renderProvinceAgencyList()">
    <div class="bch-leader-list" id="provinceLeaderList"></div>
  </aside>
  <div class="bch-table-card" id="provinceOldCard">
    <div class="bch-table-head">
      <div><b id="provinceShownCount">0</b> nhiệm vụ đang hiển thị</div>
      <div id="provinceDataHint">Theo dõi nhiệm vụ do Tỉnh giao</div>
    </div>
    <div class="bch-table-wrap">
      <table class="bch-table">
        <thead>
          <tr>
            <th class="c-stt">STT</th>
            <th class="c-amount">Nguồn giao <button class="prov-eye-btn" onclick="provShowFullTask(this)">👁</button></th>
            <th class="c-task">Tổng nhiệm vụ</th>
            <th class="c-officer">Lãnh đạo phụ trách</th>
            <th class="c-title">Cơ quan tham mưu</th>
          </tr>
        </thead>
        <tbody id="provinceTableBody"></tbody>
      </table>
      <div class="bch-empty" id="provinceEmpty">Không có nhiệm vụ phù hợp.</div>
    </div>
    <div class="bch-note">💡 Bấm vào một nhiệm vụ để xem hoặc cập nhật chi tiết theo quyền tài khoản.</div>
  </div>
</div>
```

## 2. Hành vi render (bảng cũ) — `renderPROVTable(rows)`

- Nhóm rows theo **Nguồn giao** = gộp `source_doc` + `source_group` (split theo dòng, dedupe), fallback `"Văn bản của tỉnh"`.
- Mỗi nhóm sinh **2 `<tr>`**:
  1. `<tr class="ttbtv-source-row">` — header nhóm, click để toggle:
     - `c-stt`: số thứ tự nhóm
     - `c-amount`: nguồn giao (preview, `task-tip` popup)
     - `c-task`: nút `+` toggle (`ttbtv-source-toggle`) + `<b>N nhiệm vụ</b>` + `ttbtv-status-summary` (đếm done/processing/overdue)
     - `c-officer`: gộp tên lãnh đạo (dedupe, `provinceTaskLeader`)
     - `c-title`: gộp `unit_name` (dedupe)
  2. `<tr id="province-source-N" class="ttbtv-source-detail" style="display:none">` — chi tiết nhóm, mặc định **thu gọn**:
     - `<td colspan="5"><div class="ttbtv-source-task-list">` chứa các card `ttbtv-source-task`, mỗi card 1 nhiệm vụ:
       - `ttbtv-task-main`: tiêu đề `N. task_name` (class `ttbtv-task-title task-tip`) + badge trạng thái (`provinceFilteredBadgeStatus`) + `prov-row-actions` (nút 👁 xem / ✏ sửa / 🗑 xóa — `prov-row-btn`)
       - `ttbtv-task-meta`: nguồn (VB tỉnh/xã), cơ quan, 👤 lãnh đạo, 📅 hạn, ✅ ngày HT, 📈 tiến độ, 📦 sản phẩm
- Click card → `openPROVTaskEdit(id)`; nút 👁 → `openPROVTaskDetail(id)` (popup `provinceDetailModal`); ✏ → `openPROVTaskEdit` (popup `provinceEditModal`); 🗑 → `deletePROVTaskById(id)`.
- Toggle nhóm: `ttbtvToggleSourceGroup(gid, btn)`.
- Footer: `provinceShownCount` = `rows.length`, `provinceEmpty` hiện khi rỗng, gọi `renderProvinceAgencyList()`.

## 3. CSS chính (bảng cũ)

```css
/* cột */
#provinceWorkspace .c-stt { /* ~4% center */ }
#provinceWorkspace .c-amount, .c-task, .c-officer, .c-title { /* css/style.css dòng 6088-6118 */ }
/* nhóm nguồn giao */
#provinceWorkspace .ttbtv-source-row { background:#fff; cursor:pointer }
#provinceWorkspace .ttbtv-source-row:hover { background:#f8fafc }
#provinceWorkspace .ttbtv-source-row.expanded { background:linear-gradient(135deg,#eef2ff,#e0e7ff); box-shadow:inset 4px 0 0 #4f46e5 }
#provinceWorkspace .ttbtv-source-toggle { width:22px;height:22px;color:#4f46e5 }
/* chi tiết nhóm */
#provinceWorkspace .ttbtv-source-detail td { padding:0!important; background:#eef2ff }
#provinceWorkspace .ttbtv-source-task-list { display:grid;gap:8px;padding:10px 14px 12px 58px;border-left:4px solid #6366f1;background:#eef2ff }
#provinceWorkspace .ttbtv-source-task { padding:10px 12px;border:1px solid #c7d2fe;border-radius:10px;background:#fff;cursor:pointer }
#provinceWorkspace .ttbtv-source-task:hover { border-color:#818cf8;box-shadow:0 5px 14px rgba(79,70,229,.16) }
/* nút dòng */
#provinceWorkspace .prov-row-actions { display:inline-flex;gap:4px }
#provinceWorkspace .prov-row-btn { padding:2px 7px;border-radius:8px;border:1px solid #cbd5e1;background:#fff }
#provinceWorkspace .prov-row-btn.danger:hover { background:#fee2e2 }
```

## 4. Bảng MỚI (từ 2026-09-25)

- **Flat**: mỗi nhiệm vụ = 1 `<tr>`, không nhóm nguồn, không thu/mở.
- Cột: `STT | Nhiệm vụ | Nguồn giao | Cơ quan | Lãnh đạo | Hạn HT | Ngày HT | Tiến độ | Sản phẩm | Trạng thái | ⚙`
- Click bất kỳ đâu trên dòng (trừ nút) → `openPROVTaskDetail(id)` (popup chi tiết).
- Cột ⚙ giữ nút ✏ sửa + 🗑 xóa theo quyền (`canEditPROVTask`).
- Badge trạng thái: `bch-badge done|processing|overdue` + `provinceFilteredBadgeStatus` khi lọc cơ quan.
