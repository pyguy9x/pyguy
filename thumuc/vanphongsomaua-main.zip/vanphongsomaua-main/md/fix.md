# fix.md — Tổng hợp lỗi đã sửa (02/09/2026)

| # | Lỗi | Đã sửa như nào | Tên file (dòng) |
|---|-----|----------------|-----------------|
| 1 | `Cannot read properties of undefined reading includes` khi filter/search | Guard `String(x._search\|\|"").includes` và `String(status).includes` | `js/legacy.js:2002,1508-1511,1621,2372,3265,4211,5265` |
| 2 | `Không thể chuẩn hóa nhiệm vụ vừa tạo` (Office) | `normalizeTask` alias `deadline`/`deadline_date`, nới ngưỡng 3→2, `confirmAddTask` fallback `task_name/officer/deadline` từ pending + tạo `fb` | `js/legacy.js:1759-1763,2751-2763` |
| 3 | Tương tự BCH/TTBTV/Tỉnh giao chuẩn hóa thiếu trường | Thêm fallback `raw.task_name/officer/deadline` + `fb` trước `normalize*Task` | `js/legacy.js:3549,4486,5625` |
| 4 | `office_officers` chưa tồn tại, `includes` sập + ghi không được | Tạo bảng `office_officers(id,name,token,title,unit)` giữ RLS + 4 policy permissive | `CONTEXT.md:121,132` + SQL (đã chạy) |
| 5 | `token.txt`/`token0.txt` lộ token, commit lên git | Thêm vào `.gitignore` | `.gitignore:4-8` |
| 6 | `localStorage` quota/Safari private throw, mất DATA | Thêm `safeLSSet/safeLSGet` + monkey-patch `localStorage.setItem` try/catch + fallback `writeCache` | `js/legacy.js:15-18` |
| 7 | `sendDeadlineEmail` crash khi `vp_demo_user` corrupt | Wrap `JSON.parse` trong try/catch | `js/email.js:87` |
| 8 | `BACKUP_TABLES` thiếu bảng mới → backup mất data | Thêm `office_officers`, `province_plan_blocks` → 14 bảng | `js/legacy.js:185-198` |
| 9 | RLS `42501` im lặng ở BCH/TTBTV/PROV → cache stale không báo | `bchFetch/ttbtvFetch/provinceFetch` ném lỗi kèm `(RLS chặn)` | `js/legacy.js:3192,4139,5193` |
| 10 | XSS persist `van_ban_tinh/xa` insertAdjacentHTML không esc | Đổi `${v}` → `${esc(v)}` | `js/legacy.js:7670` (2 chỗ listT/listX) |
| 11 | CSS duplicate z-index modal (999998 vs 999999) | Giữ canonical `6993` (add/delete/action100 999999), ghi chú duplicate 2243 | `css/style.css:6993` (ghi chú) |
| 12 | Chart `renderBarChart` luôn destroy/create | Giữ nguyên (ghi chú P2), đề xuất đổi sang `update()` như `renderChart:2143` | `js/legacy.js:2210` (deferred) |

## Gợi ý test thủ công

1. **Office Thêm nhiệm vụ**: Đăng nhập `ADM-MAUA-adm` → Văn phòng → Tất cả nhiệm vụ → `+ Thêm nhiệm vụ` → nhập nhiệm vụ `AB` (2 ký tự), Vai trò `PH`, Hạn `03/09/2026` → Xác nhận → Kiểm tra toast `Đã thêm` và dòng mới hiện trong `Tất cả nhiệm vụ`, không lỗi `Không thể chuẩn hóa`. Thử nhiệm vụ `1` ký tự phải bị chặn.
2. **BCH/TTBTV/Tỉnh**: Tương tự mỗi workspace → thêm nhiệm vụ ngắn 2 ký tự, check fallback không sập.
3. **Filter/search**: Gõ search rác `xyz` trong mỗi workspace → không crash `includes`, bảng trả `0` dòng. Xóa filter → hiện lại.
4. **RLS**: Tạm `ENABLE RLS` không policy trên `tasks` trên Supabase → reload BCH → phải thấy lỗi rõ `(RLS chặn)` thay vì im lặng dùng cache.
5. **localStorage quota**: DevTools → Application → Clear storage → thêm 10 nhiệm vụ liên tiếp → không throw `QuotaExceededError`.
6. **Email**: Xóa `vp_demo_user` corrupt `localStorage.setItem('vp_demo_user','{bad')` → bấm Gửi TB → không crash, toast `Không có quyền`.
7. **XSS**: Tạo `province_plan_blocks` với `van_ban_tinh = <img src=x onerror=alert(1)>` → reload Tỉnh giao cây → phải hiện text `<img...>` đã esc, không alert.
8. **Backup**: Admin → Sao lưu → kiểm tra file JSON có keys `office_officers` và `province_plan_blocks`.
9. **.gitignore**: `git status` không hiện `token.txt/token0.txt/log.txt`.
