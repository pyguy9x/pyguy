# Báo cáo Test Toàn Bộ Token (test_* cô lập, không đụng data gốc)

**Thời gian:** 00:09:26 15/9/2026

**Tổng token:** 49 (ADM + 29 BCH + 20 Dept)  
**Tổng bảng:** 7  
**Tổng case:** 343

## Ma trận: Token × Workspace (ADD / EDIT / DEL)

| Token | User | Workspace | ADD | EDIT | DEL |
|---|---|---|---|---|---|
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | Văn phòng | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | BCH | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | TT/BTV | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | Tỉnh giao | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | Kế hoạch Tỉnh | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | KH 100 ngày | PASS | PASS | PASS |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all/full) | VPUB | PASS | PASS | PASS |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | Văn phòng | PASS | PASS | BLOCKED |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-HDA-62F311 | BCH User 1(staff/bch/full) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | Văn phòng | PASS | PASS | BLOCKED |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-PXS-BBD61F | BCH User 2(staff/bch/full) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | Văn phòng | PASS | PASS | BLOCKED |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-CCS-D13D0C | BCH User 3(staff/bch/full) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TQT-2B13B6 | BCH User 4(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-LVT-E1906F | BCH User 5(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTK-CBB13F | BCH User 6(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-832D52 | BCH User 7(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TDT-FA2CCC | BCH User 8(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-DMC-724CD3 | BCH User 9(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-LQL-CCB54F | BCH User 10(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-850D07 | BCH User 11(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTL-7092CD | BCH User 12(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-HMC-B31E6F | BCH User 13(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTH-4116B2 | Trần Thị Hương(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TNC-E94A7D | BCH User 15(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTT-36EE60 | BCH User 16(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TVH-5B194D | BCH User 17(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-PTO-B60D0B | BCH User 18(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-DKV-D6DB6A | BCH User 19(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-PVM-17DE3B | BCH User 20(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TXP-178AF7 | BCH User 21(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-LCC-7396FB | BCH User 22(staff/bch/broad) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-DTH-3C8D4D | BCH User 23(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-NHV-D3FAF0 | BCH User 24(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-NTH-EE8DC5 | BCH User 25(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-QTT-A85967 | BCH User 26(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-PQM-E1C078 | BCH User 27(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-TTD-317846 | BCH User 28(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | BCH | PASS | PASS | BLOCKED |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | KH 100 ngày | BLOCKED | SKIP | SKIP |
| CB-MAUA-VTD-95CBFB | BCH User 29(staff/bch/bch_only) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-BANXDD | Ban Xây dựng Đảng(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-UBKT | UBKT(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-UBKT | UBKT(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-UBKT | UBKT(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-UBKT | UBKT(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-UBKT | UBKT(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-UBKT | UBKT(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-UBKT | UBKT(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-CBCONGAN | Công an xã(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-CBQUANSU | Quân sự xã(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HDND | HDND(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HDND | HDND(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HDND | HDND(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-HDND | HDND(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HDND | HDND(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HDND | HDND(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-HDND | HDND(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-TTCT | Trung tâm Chính trị(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-KTHT | Phòng Kinh Tế hạ tầng(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-PVH | Phòng văn hóa(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-HCC | Trung tâm PV HCC(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | BCH | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-DVTH-CVE61 | Trung tâm Dịch vụ tổng hợp(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | BCH | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CB-MAUA-TAT-3F8CH1 | Trần Anh Tráng(staff/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-DTXD-8LX74F | BQL dự án đầu tư xây dựng(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | BCH | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | TT/BTV | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CB-MAUA-DNC-5OP3FG | Phòng NN và MT(staff/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-NNMT-CV | Phòng NN và MT(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-TYTLD | Trạm Y tế(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CQ-MAUA-TYTCV | Trạm Y tế(department/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | Văn phòng | BLOCKED | SKIP | SKIP |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | BCH | BLOCKED | SKIP | SKIP |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | TT/BTV | PASS | PASS | BLOCKED |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | Tỉnh giao | BLOCKED | SKIP | SKIP |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | Kế hoạch Tỉnh | BLOCKED | SKIP | SKIP |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | KH 100 ngày | PASS | PASS | BLOCKED |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | VPUB | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | Văn phòng | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | BCH | BLOCKED | SKIP | SKIP |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | TT/BTV | PASS | PASS | BLOCKED |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | Tỉnh giao | PASS | PASS | BLOCKED |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | Kế hoạch Tỉnh | PASS | PASS | BLOCKED |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | KH 100 ngày | PASS | PASS | PASS |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | VPUB | PASS | PASS | BLOCKED |

## Lỗi phát hiện

- Không phát hiện cross-edit/delete bất thường. Các trường hợp data_entry / isNGN được phép cross-edit là đúng thiết kế.

## Ghi chú rule

- Văn phòng: chỉ admin, staff office, BCH full được ADD; EDIT chỉ owner/admin; data_entry không được sửa Văn phòng.
- BCH: chỉ admin + staff bch được ADD; EDIT chỉ owner/admin.
- TT/BTV: admin, isNGN, staff ttbtv/data_entry, department action100 được ADD; EDIT: data_entry/isNGN/admin/owner/department khớp cơ quan.
- Tỉnh giao: admin, staff province/data_entry được ADD/EDIT.
- KH100/VPUB: admin, action100, vpub, data_entry, department được ADD; EDIT kiểm tra khớp tên cơ quan.
- DELETE: chỉ admin (trừ action100 data_entry được xóa) - đúng.
- Dữ liệu test đã reset sau mỗi case, không để lại test data.
