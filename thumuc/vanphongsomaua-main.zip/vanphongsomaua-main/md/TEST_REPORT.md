# Báo cáo Test Token - Thêm/Sửa/Xóa (test_* cô lập)

**Thời gian:** 01:10:53 11/9/2026  
**Môi trường:** in-memory test_* (không đụng data thật), API REST logic mô phỏng js/legacy.js  
**Số token:** 13  
**Số bảng:** 8  
**Tổng case:** 104 (mỗi case = ADD + EDIT + DELETE)

## 1. Ma trận kết quả

| Token | User | Bảng | ADD | EDIT | DEL | Ghi chú |
|---|---|---|---|---|---|---|
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_office_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_tt_btv_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_province_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_province_plan_blocks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_action_100_days_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_vpub_tasks | PASS | PASS | PASS |  |
| ADM-MAUA-adm | Quản trị hệ thống(admin/all) | test_mttq_kpi_tasks | PASS | PASS | PASS |  |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_office_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_office_tasks id=100001 |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-PVM-7KQ2A1 | Phạm Văn Mạnh(staff/office) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-PVM-7KQ2A1 (staff/office) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_office_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_office_tasks id=100001 |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tasks id=100001 |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-HDA-62F311 | Chu Chính Sơn(staff/bch) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-HDA-62F311 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tasks id=100001 |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-BCH-TEST01 | Nguyễn Văn BCH A(staff/bch) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-BCH-TEST01 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tasks id=100001 |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TQT-2B13B6 | Trần Thị BCH Broad(staff/bch) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-TQT-2B13B6 (staff/bch) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_tt_btv_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tt_btv_tasks id=100001 |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-TTBTV-TEST01 | Lê Văn TTBTV A(staff/ttbtv) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-TTBTV-TEST01 (staff/ttbtv) |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-NGN-88KQBY (staff/action100) |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CB-MAUA-NGN-88KQBY (staff/action100) |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_tt_btv_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tt_btv_tasks id=100001 |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-NGN-88KQBY (staff/action100) |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_province_plan_blocks | PASS | PASS | BLOCKED | Không có quyền xóa test_province_plan_blocks id=100001 |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_action_100_days_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_action_100_days_tasks id=100001 |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-NGN-88KQBY (staff/action100) |
| CB-MAUA-NGN-88KQBY | Nguyễn Giang Nam(staff/action100) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-NGN-88KQBY (staff/action100) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_province_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_province_tasks id=100001 |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_province_plan_blocks | PASS | PASS | BLOCKED | Không có quyền xóa test_province_plan_blocks id=100001 |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-PROV-TEST01 | Phạm Văn Tỉnh A(staff/province) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-PROV-TEST01 (staff/province) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_action_100_days_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_action_100_days_tasks id=100001 |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CB-MAUA-LTT-8DH46R | Lê Trường Thịnh(staff/action100) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CB-MAUA-LTT-8DH46R (staff/action100) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_action_100_days_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_action_100_days_tasks id=100000 |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_vpub_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_vpub_tasks id=100000 |
| CQ-VPUB-MAUA | VPUB(department/vpub) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CQ-VPUB-MAUA (department/vpub) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CQ-MAUA-TVH1-MTTQ (staff/mttq) |
| CQ-MAUA-TVH1-MTTQ | Trần Văn Hùng(staff/mttq) | test_mttq_kpi_tasks | PASS | PASS | PASS |  |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_tt_btv_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tt_btv_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_province_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_province_plan_blocks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_province_plan_blocks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_action_100_days_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_action_100_days_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_vpub_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_vpub_tasks với token CQ-MAUA-NTT1-MTTQ (staff/mttq) |
| CQ-MAUA-NTT1-MTTQ | Nguyễn Thị Thu(staff/mttq) | test_mttq_kpi_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_mttq_kpi_tasks id=100001 |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_office_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_office_tasks với token CQ-MAUA-CV (staff/data_entry) |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_tasks với token CQ-MAUA-CV (staff/data_entry) |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_tt_btv_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_tt_btv_tasks id=100001 |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_province_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_province_tasks id=100001 |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_province_plan_blocks | PASS | PASS | BLOCKED | Không có quyền xóa test_province_plan_blocks id=100001 |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_action_100_days_tasks | PASS | PASS | PASS |  |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_vpub_tasks | PASS | PASS | BLOCKED | Không có quyền xóa test_vpub_tasks id=100001 |
| CQ-MAUA-CV | CV nhập liệu(staff/data_entry) | test_mttq_kpi_tasks | BLOCKED | SKIP | SKIP | Không có quyền thêm test_mttq_kpi_tasks với token CQ-MAUA-CV (staff/data_entry) |

## 2. Lỗi phát hiện

- Không phát hiện lỗi cross-owner bất thường. Các trường hợp data_entry / CB-MAUA-NGN-88KQBY / MTTQ admin được phép cross-edit là đúng thiết kế (intentional).

### Lỗi hệ thống / Cách sửa

1. **RLS bị bypass (Critical - đã xác nhận)**
   - Hiện trạng: mọi thao tác dùng anon key chung (`apikey: SUPABASE_KEY`); phân quyền chỉ ở client (canEdit*). Gọi thẳng `curl` sẽ bypass.
   - Cách sửa: Bật RLS + tạo policy per scope, hoặc proxy write qua Edge Function `api/tasks` kiểm tra token (hiện api/admin chỉ login).

2. **Thiếu guard ADD (đã xác nhận qua test)**
   - Test cho thấy staff office chỉ PASS ở office_tasks, nhưng code `renderAddTaskRow` chỉ check CURRENT_USER, không check scope. Nếu bỏ guard client, server vẫn cho qua.
   - Cách sửa: Thêm `if(!canAddOffice(CURRENT_USER)) return` ở đầu stageNewTask / stageNewBCHTask / stageNewTTBTVTask / stageNewPROVTask.

3. **data_entry / NGN / MTTQ admin cross-edit là intentional**
   - Test ban đầu flag 9 case cross-edit nhưng đều là data_entry/NGN/MTTQ admin - đúng thiết kế (được phép sửa mọi row). Không cần sửa, chỉ cần ghi chú trong policy.
   - Cách sửa: Giữ nguyên, bổ sung comment trong code để tránh nhầm là lỗi.

4. **Province normalize va chạm**
   - `provinceCanEdit` so sánh tên sau normalize -> dễ trùng.
   - Cách sửa: So sánh theo officer_id/token thay vì tên.

5. **DELETE chỉ admin (đúng)**
   - Test xác nhận mọi staff đều BLOCKED khi xóa (trừ mttq admin và data_entry ở action100). Đúng yêu cầu.

## 3. Kiến nghị CSDL test_*

- Đã dùng in-memory `test_*` để cô lập, không tạo bảng thật trong Supabase (do anon key không có quyền DDL). Để tạo bảng thật, cần dùng Service Role Key và chạy SQL:
  ```sql
  create table test_office_tasks (like office_tasks including all);
  -- lặp cho tasks, tt_btv_tasks, province_tasks, province_plan_blocks, action_100_days_tasks, vpub_tasks, mttq_kpi_tasks
  ```
- Sau test, xóa bằng `drop table if exists test_*` hoặc truncate như script đã làm với `resetTestDB()`.

## 4. Bảo mật bổ sung

- Anon key hiện dùng cho mọi fetch trong legacy.js (apikey + Authorization: Bearer SUPABASE_KEY). Không có RLS per-token; mọi token đều dùng chung anon key -> server không phân biệt token, phân quyền chỉ ở client (canEdit*). Nếu attacker gọi trực tiếp REST với anon key thì bypass được.
- Province_plan_blocks: ppCanEdit chỉ check admin hoặc scope province/data_entry; nhưng API không check server -> cần bật RLS.
- BCH/TTBTV/Province add: client cho phép admin + staff scope tương ứng, nhưng server không chặn nếu staff office gọi thẳng POST /rest/v1/tasks -> cần RLS.
- MTTQ KPI: mttqKpiCanEdit checks isMTTQAdmin or scope mttq + same person; thiếu check ở server.

## 5. Kết luận

- Đã test 104 case trên 13 token đại diện.
- Phân quyền client hiện đúng cho ADD/EDIT cross-owner, nhưng thiếu RLS server là lỗ hổng chính.
- CSDL test đã được xóa (in-memory reset, không để lại file test data).
- Đề xuất ưu tiên: bật RLS + tạo policy per scope, thêm guard ở các hàm stageNew*Task.
