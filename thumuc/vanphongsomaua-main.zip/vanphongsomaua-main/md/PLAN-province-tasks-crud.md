# PLAN: Bảng Tỉnh giao — Xem / Sửa / Xóa nhiệm vụ (Supabase `province_tasks`)

## 1. Hiện trạng (đã khảo sát code)

Nguồn dữ liệu: `GET {SUPABASE_URL}/rest/v1/province_tasks?select=*&order=id.asc` (fetch REST + anon key, không dùng SDK).

| Chức năng | Hàm hiện có | Vị trí |
|---|---|---|
| Load data | `loadPROVData()` | `js/modules/prov-bch.js:787` |
| Chuẩn hóa row | `normalizePROVTask()` | `js/modules/prov-bch.js:750` |
| Render bảng | `renderPROVTable()` | `js/legacy.js:4699` |
| Filter bảng | `applyPROVFilters()` | `js/modules/prov-bch.js:871` |
| Xem chi tiết | `openPROVTaskDetail()` | `js/modules/prov-bch.js:988` |
| Popup sửa | `openPROVTaskEdit()` | `js/modules/prov-bch.js:1186` |
| Lưu (POST/PATCH) | `savePROVTaskEdit()` | `js/modules/prov-bch.js:1673` |
| Xóa (DELETE) | `deletePROVTask()` | `js/modules/prov-bch.js:1508` |
| Phân quyền | `canEditPROVTask()` | `js/modules/auth.js:645` |

→ Cơ chế CRUD **đã có sẵn**, nhưng còn các lỗ hổng sau cần sửa.

## 2. Vấn đề phát hiện

1. **Cây thư mục che bảng DB**: `applyPROVFilters()` (dòng 878-895) và `getPROVRowsByMode()` ưu tiên `getPROVTreeRows()` — khi cây tồn tại, task từ `province_tasks` không hiển thị trên bảng chính → không bấm xem/sửa/xóa được.
2. **Không có nút thao tác trên dòng bảng**: phải click vào task → mở thẳng modal sửa (`openPROVTaskEdit`, `legacy.js:4734`); không có nút "xem nhanh" riêng.
3. **Edit làm mất field**: `savePROVTaskEdit()` build `dbRow` thiếu `source_group` (văn bản xã đang bị gộp vào `issuing_authority` — dòng 1720), thiếu `implementation_detail`, `overdue_reason` → PATCH ghi đè rỗng các cột này.
4. **Reload nặng sau lưu**: xóa cache + gọi `loadPROVData(true)` 2 lần + `setTimeout` 800ms (dòng 1802-1818) → chậm,闪烁; trong khi đã có row trả về từ `Prefer: return=representation`.
5. **Xóa chỉ từ modal edit**: `deletePROVTask()` phụ thuộc `PROV_EDIT_ID`; không xóa nhanh từ dòng bảng.
6. **ID cây là UUID**: logic match UUID→numeric id bằng so khớp text mơ hồ (dòng 1736-1757) → dễ tạo bản ghi trùng thay vì sửa.

## 3. Schema `province_tasks` (tham chiếu — lấy từ `normalizePROVTask`)

`id` (int, PK), `officer_name`, `task_name`, `product`, `amount`, `deadline`, `completed_date`, `result`, `progress`, `status`, `note`, `staff_note`, `admin_note`, `role`, `specialist_name`, `unit_name`, `source_form`, `issuing_authority`, `implementation_detail`, `overdue_reason`, `source_doc`, `source_group`, `source_sheet`, `source_row`, `phat_sinh` (bool), `attachment_path/name/type/size/approved/approved_at/approved_by`, `updated_at`.

Cột hiển thị bảng (theo `docs/cấu trúc tỉnh giao.txt`): STT, Nhiệm vụ, Hình thức cụ thể hóa, Thẩm quyền ban hành, Cơ quan tham mưu (cơ quan / LĐ UBND / LĐ phòng / chuyên viên), Hạn HT, Ngày HT, Thời gian còn lại, Tiến độ, Trạng thái, Sản phẩm, Ghi chú, Ghi chú Admin, Thao tác.

## 4. Các bước thực hiện

### Bước 1 — Ưu tiên bảng DB (fix #1)
- `applyPROVFilters()`: bỏ nhánh ưu tiên tree, luôn filter trên `PROV_TASKS` (giữ `getPROVTreeRows` cho chỗ khác nếu cần).
- `getPROVRowsByMode()`: tương tự, chỉ dùng `PROV_TASKS`.
- File: `js/modules/prov-bch.js`.

### Bước 2 — Xem (fix #2)
- `renderPROVTable()`: thêm cột/nút thao tác trên mỗi task: 👁 Xem (`openPROVTaskDetail(id)`) · ✏ Sửa (`openPROVTaskEdit(id)`) · 🗑 Xóa (`deletePROVTaskById(id)`).
- Nút ẩn theo quyền: chỉ hiện ✏/🗑 khi `canEditPROVTask(x)`.
- Giữ nguyên click task → mở modal sửa như cũ (không đổi hành vi).
- File: `js/legacy.js` (renderPROVTable) + `css/style.css` (style nút nhỏ).

### Bước 3 — Sửa (fix #3, #4, #6)
- `savePROVTaskEdit()`:
  - Thêm vào `dbRow`: `source_group: vbXa`, `implementation_detail`, `overdue_reason` (đọc từ input tương ứng trong modal; nếu modal chưa có input `implementation_detail`/`overdue_reason` thì giữ giá trị gốc của task — không ghi đè rỗng).
  - Bỏ `setTimeout` + lần `loadPROVData` thứ 2; dùng row trả về từ response để cập nhật `PROV_TASKS` (đã có sẵn dòng 1790-1800) rồi gọi thẳng `applyPROVFilters()` + `renderPROVKPIs()` + `renderPROVCharts()`.
  - Bỏ nhánh match UUID mơ hồ: nếu `PROV_EDIT_ID` là UUID (cây cũ) → báo lỗi rõ "Nhiệm vụ chưa có trong bảng, hãy dùng nút Thêm" thay vì âm thầm tạo mới.
- File: `js/modules/prov-bch.js`.

### Bước 4 — Xóa (fix #5)
- Tách `deletePROVTask()` thành `deletePROVTaskById(id)` nhận id trực tiếp; `deletePROVTask()` gọi lại với `PROV_EDIT_ID` (giữ API cũ cho modal).
- Confirm dialog: giữ `openDeleteTaskConfirm` (đã có, `legacy.js:627`), kèm lựa chọn xóa file đính kèm trong Storage.
- Sau DELETE: splice khỏi `PROV_TASKS`, cập nhật `localStorage province_tasks_cache`, `applyPROVFilters()`, `writeActivity(...)`, toast.
- Kiểm tra `canEditPROVTask` trước khi xóa.
- File: `js/modules/prov-bch.js`.

### Bước 5 — Supabase (RLS)
- Verify policy trên `province_tasks` cho anon key: SELECT/INSERT/UPDATE/DELETE (project đang dùng pattern RLS permissive `using (true)` — xem CONTEXT.md:145).
- Nếu thiếu: tạo migration SQL trong `supabase/migrations/` (không tự chạy, đưa user review).

## 5. Kiểm thử

1. Mở workspace Tỉnh giao → bảng hiển thị đúng rows từ `province_tasks` (kể cả khi cây thư mục tồn tại).
2. 👁 Xem: modal detail đủ 18 cột theo `docs/cấu trúc tỉnh giao.txt`.
3. ✏ Sửa: đổi task_name/deadline/status → Lưu → bảng + KPI + chart cập nhật ngay không cần F5; kiểm tra trên Supabase Dashboard `source_group`, `implementation_detail` không bị xóa.
4. 🗑 Xóa: confirm → row mất khỏi bảng + DB; xóa kèm file → file mất khỏi Storage.
5. Phân quyền: user không có quyền → chỉ thấy 👁, không thấy ✏/🗑.
6. `DEMO_MODE`: CRUD dùng snapshot, không gọi network (giữ nguyên hành vi hiện tại).

## 6. Ràng buộc

- Không tạo file mới (trừ migration SQL nếu cần ở Bước 5).
- Không đổi tên hàm/API hiện có, không đổi kiến trúc.
- Không thêm dependency.
- File thay đổi dự kiến: `js/modules/prov-bch.js`, `js/legacy.js`, `css/style.css`.
