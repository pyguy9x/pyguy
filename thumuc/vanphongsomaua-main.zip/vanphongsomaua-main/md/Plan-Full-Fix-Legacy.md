# Plan: Full Fix — legacy.js + index.html — Workspace Tỉnh giao & Toàn cục

> **Mục tiêu:** Fix triệt để 9 lỗi filter Tỉnh giao + 6 lỗi nền toàn cục trong `js/legacy.js` (11.668 dòng) + kiểm tra XSS trong `index.html`. Không sửa data, không thêm dependency, chỉ sửa logic hiển thị.
> **File duy nhất sửa:** `js/legacy.js`
> **Tham chiếu:** `index.html` để check `esc()` và ID tồn tại.

---

## I. Tổng quan 15 lỗi

### Nhóm A: 9 lỗi filter Tỉnh giao (đã có plan cũ, giữ nguyên)
Nguồn gốc: `plan-province-filters.md` của Claude Opus 4.6 Thinking

| # | Hàm | Dòng (cũ) | Vấn đề | Fix chuẩn |
|---|-----|-----------|--------|-----------|
| A1 | `openPROVStatusPopup` | 7682-7696 | Dùng `getPROVRowsByMode(mode)` lấy toàn bộ | Dùng `PROV_FILTERED` + lọc status |
| A2 | `drillPROVChart("status")` | 7461 | Gọi `openPROVStatusPopup` chưa filter | Kế thừa A1 |
| A3 | `drillPROVChart("officer")` | 7465 | `getPROVTreeRows(null)` toàn bộ | Dùng `PROV_FILTERED` |
| A4 | `drillPROVChart("document")` | 7479 | `getPROVTreeRows(null)` + `PROV_TASKS` | Dùng `PROV_FILTERED` |
| A5 | `drillPROVChart("leader")` | 7515 | `getPROVTreeRows(null)` | Dùng `PROV_FILTERED` |
| A6 | `drillPROVChart("deadline")` | 7550 | `buildPROVDeadlineCategories()` quét toàn cây | Dùng `PROV_FILTERED` khi có filter |
| A7 | `renderPROVCharts` chart 2,4 | 7307, 7359 | Quét DOM `.pp-task` visible, bỏ qua `PROV_MONTH` | Dùng `useRows = PROV_FILTERED` khi `hasAnyFilter` |
| A8 | `renderPROVCharts` useRows | 7295-7296 | Thiếu check `provinceTimeFilter` | Thêm `hasTimeFilter` vào điều kiện |
| A9 | `applyPROVFilters` PROV_MONTH | 7137, 7153 | `firstDL` chỉ lấy deadline đầu tiên, lệch với `.some()` của cây | Tree path dùng `.some()` check tất cả `[data-k=deadline]` |

**Code fix chuẩn cho A8-A9:**

```js
// A8 - TRƯỚC:
const rows = (PROV_FILTERED.length || (typeof PROV_MONTH!=="undefined" && PROV_MONTH) || ["all"].includes(...)) ? PROV_FILTERED : base;
const useRows = (search || officer || status!="all" || PROV_MONTH) ? PROV_FILTERED : base;

// A8 - SAU:
const hasTimeFilter = (document.getElementById("provinceTimeFilter")?.value || "all") !== "all";
const hasAnyFilter = document.getElementById("provinceSearch")?.value
  || document.getElementById("provinceOfficerFilter")?.value
  || (document.getElementById("provinceStatusFilter")?.value || "all") !== "all"
  || hasTimeFilter
  || (typeof PROV_MONTH!=="undefined" && PROV_MONTH);
const rows = (PROV_FILTERED.length || hasAnyFilter) ? PROV_FILTERED : base;
const useRows = hasAnyFilter ? PROV_FILTERED : base;

// A9 - TRƯỚC:
if (typeof PROV_MONTH !== "undefined" && PROV_MONTH) { const d = provinceDeadlineDate(x.deadline); ... }

// A9 - SAU:
if (typeof PROV_MONTH !== "undefined" && PROV_MONTH) {
  if (x._isTree && x._taskEl) {
    const anyMatch = [...x._taskEl.querySelectorAll('.pp-person [data-k=deadline]')]
      .some(el => { const d2 = ppParseDate(el.value); return d2 && (d2.getMonth()+1) === PROV_MONTH; });
    if (!anyMatch) return false;
  } else {
    const d = provinceDeadlineDate(x.deadline);
    if (!d || (d.getMonth()+1)!==PROV_MONTH) return false;
  }
}
```

---

### Nhóm B: 6 lỗi nền toàn cục (mới phát hiện qua scan)

#### B1: `getElementById().value` không check null — 40+ chỗ, crash khi workspace chưa render

**Vị trí:** L293-297, L326, L339-340, L397, L786, L907, L915, L1271, L1287-1326, L1982, L2503-2521, L2554-2559, L3445, L3455-3480, L4547, L4809, L4816, L6014, L6527, L6540, L7949, L8228, L9491, L9495

**Pattern lỗi:**
```js
document.getElementById("activityNameFilter").value.trim() // L293 - crash nếu null
document.getElementById("provinceEditAttachment").value = "" // L7949
```

**Fix:** Đổi toàn bộ sang optional chaining + fallback

```js
// TRƯỚC:
document.getElementById("activityNameFilter").value.trim().toLowerCase()

// SAU:
(document.getElementById("activityNameFilter")?.value || "").trim().toLowerCase()

// SET cũng phải check:
const el = document.getElementById("provinceEditAttachment");
if (el) el.value = "";
```

**Danh sách cần sửa ưu tiên (Tỉnh giao):**
- L7949 `provinceEditAttachment`
- L8228 `provinceEditCompleted`
- L6295, L10118 `_h` handler dùng `provinceConfirmOkBtn?.click()` đã có `?.` -> giữ nguyên mẫu

#### B2: `PROV_MONTH` dùng không `typeof` check — ReferenceError

**Vị trí:** L7229

```js
// TRƯỚC:
if (PROV_MONTH && rateRows !== null) {

// SAU:
if (typeof PROV_MONTH !== "undefined" && PROV_MONTH && rateRows !== null) {
```

Scan toàn file: mọi chỗ khác đã dùng `typeof PROV_MONTH !== "undefined"` -> đồng bộ.

#### B3: Function trùng tên `_h` 2 lần — bị ghi đè

**Vị trí:** L6295 và L10118

```js
function _h(e) { if (e.key === 'Enter') { ... } }
```

Cả 2 đều là handler Enter cho `provinceConfirmOkBtn`. Rename:

```js
// L6295 -> function _h_provinceConfirmEnter(e)
// L10118 -> function _h_provinceConfirmEnter2(e) hoặc gộp chung, xóa 1
```

**Fix đề xuất:** Xóa L10118, giữ L6295 vì logic giống hệt nhau.

#### B4: Performance — `querySelectorAll('.pp-task')` trong loop

**Vị trí:** L7307, L7360, L7395, L7416, L7440, L7495, L7529

Mỗi lần `renderPROVCharts()` quét toàn cây + bên trong lại quét `.pp-agency`, `.pp-person` -> O(n*m) = ~1000 DOM query với 200 task.

**Fix:** Đã fix trong A7: khi `hasAnyFilter` thì dùng `useRows` (đã là mảng JS), không quét DOM. Chỉ khi không filter mới quét DOM.

Thêm cache:
```js
let _provTreeCache = null;
function getPROVTreeRowsCached(mode) {
  if (hasAnyFilter) return PROV_FILTERED; // dùng luôn filtered
  if (!_provTreeCache) _provTreeCache = getPROVTreeRows(mode);
  return _provTreeCache;
}
```

#### B5: XSS tiềm ẩn — `innerHTML` với `task_name` không `esc()`

**Vị trí:** `provinceDetailBody`, `bchDetailBody`, `provinceDrillBody`

Check `index.html` L176k: `provinceDetailBody` render bằng `innerHTML` trong `openPROVTaskDetail()`.

**Code hiện tại L7599-7616:**
```js
document.getElementById("provinceDetailBody").innerHTML = `<div>...${val(x.task_name)}...</div>`;
```

`val()` đã là `esc(String(v||"—"))` -> đã an toàn. Nhưng một số chỗ `renderPROVDrill` dùng `${x.task_name}` trực tiếp không qua `esc()`.

**Fix:** Audit tất cả `innerHTML =` trong `renderPROVDrill`, `renderBCHDrill`, đảm bảo:
```js
// TRƯỚC:
`<div>${x.task_name}</div>`
// SAU:
`<div>${esc(x.task_name)}</div>`
```

#### B6: `console.log` debug còn sót (nếu có)

Scan không thấy nhiều, nhưng thêm ESLint rule:
```js
// Trước khi commit chạy:
node --check js/legacy.js
// + search:
grep -n "console\." js/legacy.js
```

---

## II. Thứ tự sửa an toàn (từ trên xuống dưới để tránh lệch dòng)

1. **B3** — Xóa duplicate `_h` L10118 (dễ nhất, ít ảnh hưởng dòng)
2. **B2** — Fix `PROV_MONTH` L7229
3. **A9** — `applyPROVFilters` L7137 (đã fix trong file bạn gửi, giữ nguyên)
4. **A8** — `useRows` L7295-7296 (fix `hasTimeFilter`, `hasAnyFilter`)
5. **A7** — Chart 2,3,4 L7307-7370 (dùng `hasAnyFilter ? useRows : DOM`)
6. **A1** — `openPROVStatusPopup` L7682-7696 (đã fix trong bản bạn upload, giữ)
7. **A3-A6** — `drillPROVChart` L7465-7591 (officer, document, leader, deadline)
8. **B1** — 40+ chỗ `getElementById().value` -> `?.value || ""` (làm cuối cùng vì nhiều dòng, tránh lệch số dòng các fix trên)
9. **B5** — Audit `esc()` cho `innerHTML`

---

## III. Verification Plan

### Automated
```bash
node --check js/legacy.js
# Không được có SyntaxError

# Check ReferenceError PROV_MONTH
grep -n "if (PROV_MONTH" js/legacy.js
# Phải = 0, tất cả phải là typeof check

# Check duplicate _h
grep -n "function _h" js/legacy.js
# Phải = 1

# Check getElementById().value không có ?.
grep -n 'getElementById([^)]*)\.value' js/legacy.js
# Phải = 0 sau khi fix B1
```

### Manual — Test case Tỉnh giao (quan trọng nhất)

1. **Filter -> KPI click:**
   - Chọn tháng 6 trên `#provinceMonthStrip`
   - Chọn cơ quan "UBND xã" trên `#provinceOfficerFilter`
   - Chọn `provinceTimeFilter = "Tuần này"`
   - Bấm KPI "Hoàn thành" -> popup chỉ hiện nhiệm vụ hoàn thành tháng 6 + UBND xã + tuần này

2. **Filter -> Chart 4 (Cơ quan) click:**
   - Lọc tháng 3 -> bấm chart cơ quan -> popup chỉ hiện NV tháng 3 của cơ quan đó
   - Số lượng trên chart 4 phải = `PROV_FILTERED` đếm theo cơ quan, không phải toàn cây

3. **Filter -> Chart 3 (Deadline) click:**
   - Lọc trạng thái "Đang xử lý" -> bấm "Quá hạn" chart -> popup chỉ hiện NV đang xử lý + quá hạn
   - Số `overdue` trên chart 3 phải thay đổi khi đổi `provinceTimeFilter`

4. **Không filter:**
   - Xóa tất cả filter -> bấm KPI/chart -> popup hiện toàn bộ (hành vi cũ, fallback)

5. **Multi-deadline:**
   - Task có 3 người deadline tháng 4,5,6 -> lọc tháng 5 -> phải hiện (do `.some()`), trước đây chỉ check người đầu tiên nên bị ẩn

6. **Crash test B1:**
   - Mở tab khác (ví dụ BCH) -> gọi `applyPROVFilters()` từ console -> không được crash `Cannot read properties of null`

---

## IV. File đính kèm để AI sửa

- `js/legacy.js` (11.668 dòng) — file chính cần sửa
- `index.html` (176k) — để check ID tồn tại và `esc()`
- `js/legacy.fixed.js` — bản đã fix 9 lỗi A (tham khảo)

**Nguyên tắc an toàn:**
- KHÔNG sửa data `PROV_TASKS`, `Supabase`
- KHÔNG thêm file, dependency
- KHÔNG đổi tên hàm public (trừ `_h` duplicate)
- Mọi popup vẫn hoạt động khi không có filter (fallback về `base`)

---

## V. Tóm tắt thay đổi cho AI

| # | Dòng | Hàm | Lỗi | Fix |
|---|------|-----|-----|-----|
| A1 | 7682 | `openPROVStatusPopup` | Dùng toàn bộ | Dùng `PROV_FILTERED` |
| A3 | 7465 | `drillPROVChart officer` | Toàn bộ | `PROV_FILTERED` |
| A4 | 7479 | `drillPROVChart document` | Toàn bộ | `PROV_FILTERED` |
| A5 | 7515 | `drillPROVChart leader` | Toàn bộ | `PROV_FILTERED` |
| A6 | 7550 | `drillPROVChart deadline` | Quét cây | `PROV_FILTERED` khi filter |
| A7 | 7307/7359 | `renderPROVCharts` 2,4 | Quét DOM | `useRows` khi `hasAnyFilter` |
| A7 | 7335 | `renderPROVCharts` 3 | Quét cây | `useRows` khi `hasAnyFilter` |
| A8 | 7295 | `useRows` | Thiếu `timeFilter` | Thêm `hasTimeFilter` |
| A9 | 7137 | `applyPROVFilters` | `firstDL` | `.some()` |
| B1 | 293+ | Nhiều chỗ | `getElementById().value` crash | `?.value || ""` + check tồn tại |
| B2 | 7229 | `rateRows` | `PROV_MONTH` không typeof | Thêm typeof check |
| B3 | 6295/10118 | `_h` | Trùng tên | Xóa 1, rename |
| B4 | 7307+ | `renderPROVCharts` | Performance DOM | Cache + dùng `useRows` |
| B5 | 7599+ | `openPROVTaskDetail` | XSS | Đảm bảo `esc()` |

> **Lưu ý:** File `legacy.js` bạn upload đã có A1, A3, A4, A5, A6, A9 được Sonnet fix rồi. AI chỉ cần fix nốt A7, A8, B1-B5 là đủ. Bản `legacy.fixed.js` đã fix A7,A8.

