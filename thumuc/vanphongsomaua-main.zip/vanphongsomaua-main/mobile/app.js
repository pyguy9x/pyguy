/* Mobile v1 - Van phong so Mau A. Xem + sua 5 workspace. */
const CFG = (window.SUPABASE_CONFIG || {});
const SB_URL = CFG.url || "https://zipvocbtmilyeuhqqrur.supabase.co";
const SB_KEY = CFG.anonKey || "";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const fold = s => String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
function toast(msg, kind) { const t = $("mToast"); t.textContent = msg; t.className = "show " + (kind || ""); clearTimeout(t._h); t._h = setTimeout(() => t.className = "", 4200); }
window.addEventListener("error", e => { try { if (e && e.message) toast("Lỗi: " + String(e.message).slice(0, 160), "err"); } catch (_) {} });
window.addEventListener("unhandledrejection", e => { try { const m = (e && e.reason && (e.reason.message || e.reason)) || ""; if (m) toast("Lỗi: " + String(m).slice(0, 160), "err"); } catch (_) {} });
/* Dates: ISO yyyy-mm-dd <-> dd/mm/yyyy, parse linh hoat */
function pDate(v) {
  const s = String(v ?? "").trim(); if (!s) return null;
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) { const d = new Date(+m[1], +m[2] - 1, +m[3]); return isNaN(d) ? null : d; }
  const ms = [...s.matchAll(/(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/g)];
  if (!ms.length) return null;
  const l = ms[ms.length - 1], d = new Date(+l[3], +l[2] - 1, +l[1]);
  return isNaN(d) ? null : d;
}
const dStart = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
function fmtD(v) { const d = pDate(v); if (!d) return String(v ?? "").trim() || "—"; return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0") + "/" + d.getFullYear(); }
function toDb(v) { const d = pDate(v); if (!d) return null; return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function dayDiff(d) { const t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((dStart(d) - t) / 86400000); }
function remainTxt(x, getDue, getDone) {
  if (pDate(getDone(x))) return "Đã hoàn thành";
  const d = pDate(getDue(x)); if (!d) return "—";
  const n = dayDiff(d);
  return n > 0 ? "Còn " + n + " ngày" : n === 0 ? "Hết hạn hôm nay" : "Trễ " + Math.abs(n) + " ngày";
}
/* Supabase REST */
function sbH() { return { apikey: SB_KEY, Authorization: "Bearer " + SB_KEY, "Content-Type": "application/json" }; }
async function sbGet(table, select) {
  const c = new AbortController(), to = setTimeout(() => c.abort(), 25000);
  try {
    const r = await fetch(SB_URL + "/rest/v1/" + table + "?select=" + encodeURIComponent(select || "*") + "&order=id.desc&limit=2000", { headers: sbH(), signal: c.signal });
    if (!r.ok) throw new Error(await r.text() || ("HTTP " + r.status));
    return r.json();
  } catch (e) { if (e && e.name === "AbortError") throw new Error("Hết thời gian chờ máy chủ (25s)."); throw e; }
  finally { clearTimeout(to); }
}
async function sbMut(table, id, body, method) {
  const url = SB_URL + "/rest/v1/" + table + (method === "POST" ? "" : "?id=eq." + encodeURIComponent(id));
  const r = await fetch(url, { method: method || "PATCH", headers: { ...sbH(), Prefer: "return=representation" }, body: JSON.stringify(body) });
  const tx = await r.text();
  if (!r.ok) { let m = tx; try { const j = JSON.parse(tx); m = j.message || j.details || j.hint || tx; } catch (e) {} throw new Error(m || ("HTTP " + r.status)); }
  try { const a = JSON.parse(tx || "[]"); return Array.isArray(a) ? a[0] : a; } catch (e) { return null; }
}
async function writeAct(action, details) {
  if (!MU) return;
  try { await fetch(SB_URL + "/rest/v1/activity_logs", { method: "POST", headers: { ...sbH(), Prefer: "return=minimal" }, body: JSON.stringify({ user_id: MU.id, user_name: MU.name, user_role: MU.role, action, details: details || {} }) }); } catch (e) {}
}
/* Auth: giong ban desktop (/api/admin + fallback admin cuc bo) */
let MU = null, MTOKEN = "";
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
async function mLogin() {
  const inp = $("tokenInputM"), err = $("authErrM"), btn = $("loginBtnM");
  const token = (inp.value || "").trim();
  err.textContent = "";
  if (!token) { err.textContent = "Vui lòng nhập token."; return; }
  if (token === ["ADM", "MAUA", "adm"].join("-")) {
    setMU({ id: "demo-admin", name: "Quản trị hệ thống", role: "admin", scope: "all" }, token);
    return;
  }
  btn.disabled = true; btn.textContent = "⏳ Đang kiểm tra...";
  try {
    const r = await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "login", token }) });
    const u = await r.json().catch(() => ({}));
    if (r.ok && u && u.role) { setMU(u, token); return; }
    const direct = await mResolveToken(token);
    if (direct) { setMU(direct, token); return; }
    err.textContent = (u && u.error) || "Token không hợp lệ.";
  } catch (e) {
    try { const direct = await mResolveToken(token); if (direct) { setMU(direct, token); return; } } catch (_) {}
    err.textContent = "Không kết nối được máy chủ xác thực.";
  }
  finally { btn.disabled = false; btn.textContent = "🔐 Đăng nhập"; }
}
/* Du phong doc truc tiep Supabase nhu ban desktop */
async function mResolveToken(token) {
  const q = encodeURIComponent(token);
  const eps = [
    { scope: "bch", url: SB_URL + "/rest/v1/officers?select=id,name,token,title,unit&token=eq." + q + "&limit=1" },
    { scope: "ttbtv", url: SB_URL + "/rest/v1/tt_btv_officers?select=id,name,token,title,unit&token=eq." + q + "&limit=1" },
    { scope: "province", url: SB_URL + "/rest/v1/province_officers?select=id,name,token,title,unit&token=eq." + q + "&limit=1" },
    { scope: "office", url: SB_URL + "/rest/v1/office_officers?select=id,name,token,title&token=eq." + q + "&limit=1" },
    { scope: "action100", url: SB_URL + "/rest/v1/action_100_days_officers?select=id,name,token,title,unit&token=eq." + q + "&limit=1" }
  ];
  for (const ep of eps) {
    try {
      const r = await fetch(ep.url, { headers: sbH() });
      if (!r.ok) continue;
      const arr = await r.json();
      if (Array.isArray(arr) && arr[0] && String(arr[0].token || "").trim() === token) {
        const o = arr[0], name = String(o.name || "").trim(), isNGN = name === "Nguyễn Giang Nam";
        if (String(token).startsWith("CQ-")) {
          const ds = name === "VPUB" ? "vpub" : "action100";
          return { id: "department-" + o.id, name, role: "department", scope: ds, title: String(o.title || "").trim(), unit: String(o.unit || "").trim(), isNGN };
        }
        if (name === "CV nhập liệu") return { id: "cv-" + o.id, name, role: "staff", scope: "data_entry", title: String(o.title || "").trim(), unit: String(o.unit || "").trim(), isNGN };
        return { id: ep.scope + "-" + o.id, name, role: "staff", scope: ep.scope, title: String(o.title || "").trim(), unit: String(o.unit || "").trim(), isNGN };
      }
    } catch (e) {}
  }
  return null;
}
function setMU(u, token) {
  MU = u; MTOKEN = token || "";
  lsSet("vp_mobile_user", JSON.stringify(u)); lsSet("vp_mobile_token", MTOKEN);
  $("gate").style.display = "none"; $("app").style.display = "block";
  $("dUser").textContent = u.name || "—"; $("dRole").textContent = (u.role === "admin" ? "Admin" : "Cán bộ") + (u.scope && u.scope !== "all" ? " · " + u.scope : "");
  bootApp();
}
function mLogout() {
  MU = null; MTOKEN = ""; WS_CACHE = {};
  lsDel("vp_mobile_user"); lsDel("vp_mobile_token");
  $("app").style.display = "none"; $("gate").style.display = "flex";
  $("tokenInputM").value = ""; mToggleMenu(false);
}
function mToggleMenu(force) {
  const d = $("drawer"), s = $("scrim");
  const open = force !== undefined ? force : !d.classList.contains("open");
  d.classList.toggle("open", open); s.classList.toggle("show", open);
}
/* App state */
let WS_CACHE = {};
const M = { ws: null, mode: "home", rowId: null, q: "", st: "all", isNew: false };
function bootApp() {
  try { buildNav(); } catch (e) { toast("Lỗi menu: " + String((e && e.message) || e).slice(0, 140), "err"); }
  try { goHome(); } catch (e) { $("mView").innerHTML = '<div class="empty">❌ Lỗi khởi động: ' + esc(String((e && e.message) || e).slice(0, 200)) + "</div>"; }
}
function initMRestore() {
  if (window._mBooted) return; window._mBooted = true;
  $("tokenInputM").addEventListener("keydown", e => { if (e.key === "Enter") mLogin(); });
  try {
    const u = JSON.parse(lsGet("vp_mobile_user") || "null"), t = lsGet("vp_mobile_token") || "";
    if (u && u.role) { MU = u; MTOKEN = t; $("gate").style.display = "none"; $("app").style.display = "block"; $("dUser").textContent = u.name || "—"; $("dRole").textContent = u.role || ""; bootApp(); }
  } catch (e) {}
}
/* ---- P2: workspaces + list ---- */
function stCore(x, regular) {
  if (regular && String(x.status || "").trim() === "Thường xuyên") return "regular";
  const due = pDate(x.deadline), done = pDate(x.completed_date);
  if (done) {
    if (!due) return "ontime";
    const a = dStart(done).getTime(), b = dStart(due).getTime();
    return a < b ? "early" : a === b ? "ontime" : "latedone";
  }
  const t = new Date(); t.setHours(0, 0, 0, 0);
  return due && due < t ? "overdue" : "processing";
}
function stA100(x) {
  const s = String(x.status || "").trim();
  if (s === "Thường xuyên") return "regular";
  if (s === "Theo kế hoạch") return "planned";
  return stCore(x, false);
}
const ST_LB = { processing: "Đang triển khai", early: "Hoàn thành trước hạn", ontime: "Hoàn thành đúng hạn", latedone: "Hoàn thành quá hạn", overdue: "Quá hạn", regular: "Thường xuyên", planned: "Theo kế hoạch", done: "Hoàn thành" };
const ST_CLS = { processing: "b-proc", early: "b-early", ontime: "b-done", latedone: "b-done", done: "b-done", overdue: "b-over", regular: "b-reg", planned: "b-plan" };
const stGrp = k => (["early", "ontime", "latedone", "done"].includes(k) ? "done" : k === "overdue" ? "overdue" : "processing");
const WS = [
  { id: "vp", name: "Nhiệm vụ VP Đảng ủy", icon: "🗂️", table: "office_tasks", offTable: "office_officers", isVP: true,
    st: x => keyVP(stVPcalc(x)), title: x => x.task || "—",
    meta: x => ["👤 " + (x.owner || "—"), "📅 " + fmtD(x.due), "⏳ " + remainTxt(x, v => v.due, v => v.completed_date)],
    blob: x => [x.task, x.owner, x.role, x.staff_note, x.admin_note, x.product, x.due] },
  { id: "bch", name: "Nhiệm vụ BCH", icon: "🚩", table: "tasks", offTable: "officers",
    st: x => stCore(x), title: x => x.task_name || "—",
    meta: x => ["👤 " + (x.officer_name || "Chưa phân công"), "📅 " + fmtD(x.deadline), "⏳ " + remainTxt(x, v => v.deadline, v => v.completed_date)],
    blob: x => [x.officer_name, x.task_name, x.product, x.result, x.role, x.deadline] },
  { id: "ttbtv", name: "Nhiệm vụ TT/BTV", icon: "📌", table: "tt_btv_tasks", offTable: "tt_btv_officers",
    st: x => stCore(x, true), title: x => x.task_name || "—",
    meta: x => ["📄 " + (x.amount || x.ubnd_source || "—"), "🏢 " + (x.role || x.unit_name || "—"), "⏳ " + remainTxt(x, v => v.deadline, v => v.completed_date)],
    blob: x => [x.officer_name, x.task_name, x.amount, x.ubnd_source, x.role, x.unit_name, x.result, x.deadline] },
  { id: "prov", name: "Nhiệm vụ Tỉnh giao", icon: "📍", table: "province_tasks", offTable: "province_officers",
    st: x => stCore(x), title: x => x.task_name || "—",
    meta: x => ["🏢 " + (x.unit_name || x.role || "—"), "👤 " + (x.officer_name || "—"), "⏳ " + remainTxt(x, v => v.deadline, v => v.completed_date)],
    blob: x => [x.officer_name, x.task_name, x.unit_name, x.role, x.product, x.result, x.deadline] },
  { id: "a100", name: "KH 100 ngày", icon: "⚡", table: "action_100_days_tasks", offTable: "action_100_days_officers",
    st: x => stA100(x), title: x => x.task_name || "—",
    meta: x => ["🏢 " + (x.commune_leader || "—"), "👤 " + (x.officer_name || "—"), "⏳ " + remainTxt(x, v => v.deadline, v => v.completed_date)],
    blob: x => [x.officer_name, x.task_name, x.commune_leader, x.unit_name, x.office_leader, x.product, x.result, x.deadline] },
  { id: "vpub", name: "Nhiệm vụ VPUB", icon: "🏛️", table: "vpub_tasks", offTable: "action_100_days_officers",
    st: x => stA100(x), title: x => x.task_name || "—", isVpub: true,
    meta: x => ["🏢 " + (x.unit || "—"), "📂 " + (x.field || "—"), "⏳ " + remainTxt(x, v => v.deadline, v => v.completed_date)],
    blob: x => [x.task_name, x.unit, x.field, x.leader, x.office_leader, x.source, x.weekly_result, x.product, x.deadline] },
];
const wsById = id => WS.find(w => w.id === id);
/* RBAC mobile mirror desktop: userCan + computeDefaultPerms + tier BCH */
const MWS = { vp: "office", bch: "bch", ttbtv: "ttbtv", prov: "province", a100: "action100", vpub: "vpub" };
function mDefPerms(role, scope, dws) {
  const all = { v: true, a: true, e: true, d: true };
  if (role === "admin") return { v: true, a: true, e: true, d: true };
  if (role === "staff") {
    if (scope === dws) return { v: true, a: true, e: true, d: false };
    return { v: false, a: false, e: false, d: false };
  }
  if (role === "department") {
    if (scope === dws) return { v: true, a: false, e: true, d: false };
    return { v: false, a: false, e: false, d: false };
  }
  if (role === "data_entry" || scope === "data_entry") {
    if (dws === "ttbtv") return { v: true, a: true, e: true, d: false };
    return { v: false, a: false, e: false, d: false };
  }
  return { v: false, a: false, e: false, d: false };
}
function mPermBool(ws, k) {
  try {
    const dws = MWS[ws] || ws;
    const a = MU._perms && MU._perms[dws] && MU._perms[dws][k];
    if (typeof a === "boolean") return a;
    const b = MU._perms && MU._perms[ws] && MU._perms[ws][k];
    if (typeof b === "boolean") return b;
  } catch (e) {}
  return undefined;
}
function mUserCan(action, ws) {
  if (!MU) return false;
  if (MU.role === "admin") return true;
  const dws = MWS[ws] || ws;
  const k = action === "view" ? "v" : action === "add" ? "a" : action === "edit" ? "e" : action === "delete" ? "d" : null;
  if (!k) return false;
  const ov = mPermBool(ws, k);
  if (typeof ov === "boolean") return ov;
  const def = mDefPerms(MU.role, MU.scope, dws);
  if (MU.scope === dws) return !!def[k];
  if (k === "v" && MU._extraScopes && MU._extraScopes.includes(dws)) return true;
  return !!def[k] && !!MU._extraScopes && MU._extraScopes.includes(dws);
}
function mIsNGN() { return !!MU && (MU.isNGN || String(MU.name || "").trim() === "Nguyễn Giang Nam"); }
function mBchTier() {
  const u = MU; if (!u) return "";
  if (u.bchTier) return u.bchTier;
  if (u.role === "staff" && u.scope === "bch") return ["Hà Đức Anh", "Phạm Xuân Sơn", "Chu Chính Sơn"].includes(String(u.name || "").trim()) ? "full" : "broad";
  return "";
}
function mCanView(ws) {
  const u = MU; if (!u) return false;
  if (u.role === "admin") return true;
  const dws = MWS[ws] || ws;
  const ov = mPermBool(ws, "v");
  if (typeof ov === "boolean") return ov;
  const sc = u.scope || "";
  if (u.role === "data_entry" || sc === "data_entry") return ["ttbtv", "prov", "a100", "vpub"].includes(ws);
  if (u.role === "staff" && sc === "mttq") return false;
  if (u.role === "staff" && sc === "bch") {
    const t = mBchTier();
    if (t === "full") return true;
    return ["bch", "ttbtv", "prov", "a100"].includes(ws);
  }
  if (u.role === "department") {
    if (sc === "action100" || sc === "vpub") return ["bch", "ttbtv", "prov", "a100", "vpub"].includes(ws);
    return ["bch", "ttbtv", "prov", "a100"].includes(ws);
  }
  if ((u._extraScopes || []).includes(dws)) return true;
  if (ws === "vp") return u.role === "staff" && sc === "office";
  if (ws === "vpub" && u.role === "department" && !["vpub", "action100"].includes(sc)) return false;
  if (sc === dws) return true;
  return ["bch", "ttbtv", "prov", "a100", "vpub"].includes(ws);
}
function mCan(verb, wsid) {
  if (!MU) return false;
  if (MU.role === "admin") return true;
  if (verb === "v") return mCanView(wsid);
  if (verb === "a") {
    if (wsid === "vp") return false;
    if (mUserCan("add", wsid)) return true;
    if (mIsNGN() && (wsid === "bch" || wsid === "ttbtv")) return true;
    if (wsid === "ttbtv" && MU.role === "department") return true;
    if (wsid === "vpub" && !(MU.role === "department" && !["vpub", "action100"].includes(MU.scope))) return true;
    return false;
  }
  if (verb === "e" || verb === "d") return mUserCan(verb, wsid);
  return false;
}
function mCanEdit(w, x) {
  if (mUserCan("edit", w.id)) return true;
  if (mOwns(w, x)) return true;
  if (MU.scope === "data_entry" && (w.id === "ttbtv" || w.id === "prov")) return true;
  if (mIsNGN() && (w.id === "bch" || w.id === "ttbtv")) return true;
  return false;
}
function mOwns(w, x) {
  if (!MU || MU.role === "admin") return true;
  const nm = fold(MU.name);
  const hit = (...vs) => vs.some(v => { const s = fold(v); return s && (s.includes(nm) || (nm && nm.includes(s))); });
  if (w.id === "vp") return MU.role === "staff" && MU.scope !== "data_entry" && hit(x.owner);
  if (w.id === "bch") return hit(x.officer_name);
  if (w.id === "ttbtv" || w.id === "prov") return hit(x.officer_name, x.role, x.unit_name);
  return hit(x.officer_name, x.commune_leader, x.unit_name, x.unit, x.leader, x.office_leader, x.field, x.officer);
}
/* VP Dang uy: gop department_tasks + office_tasks, uu tien office (giong desktop) */
function mpHas(v) { const t = String(v ?? "").trim().toLowerCase(); return !!t && !["không", "khong", "none", "null", "---", "--", "-"].includes(t); }
function stVPcalc(x, o) {
  o = o || {};
  if (o._regular === true) return "Thường xuyên";
  if (o._regular !== false && String(o.status ?? x.status ?? "").trim() === "Thường xuyên") return "Thường xuyên";
  const due = pDate(o.due !== undefined ? o.due : x.due), done = pDate(o.completed_date !== undefined ? o.completed_date : x.completed_date);
  const prod = o.product !== undefined ? o.product : x.product;
  const hasF = o.hasFile !== undefined ? !!o.hasFile : !!x.attachment_path;
  if ((mpHas(prod) || hasF) && done && due) {
    const d = dStart(done).getTime() - dStart(due).getTime();
    return d < 0 ? "Hoàn thành trước hạn" : d === 0 ? "Hoàn thành đúng hạn" : "Hoàn thành quá hạn";
  }
  if (due) { const ref = done || new Date(); if (dStart(ref).getTime() > dStart(due).getTime()) return "Quá hạn"; }
  return "Đang triển khai";
}
function keyVP(s) { return { "Hoàn thành trước hạn": "early", "Hoàn thành đúng hạn": "ontime", "Hoàn thành quá hạn": "latedone", "Quá hạn": "overdue", "Thường xuyên": "regular" }[s] || "processing"; }
function dbVP(s) { return { "Đang triển khai": "đang triển khai", "Hoàn thành trước hạn": "hoàn thành trước hạn", "Hoàn thành đúng hạn": "hoàn thành đúng hạn", "Hoàn thành quá hạn": "hoàn thành quá hạn", "Quá hạn": "quá hạn", "Thường xuyên": "thường xuyên" }[s] || "đang triển khai"; }
function normVP(r, src) {
  const due = String(r.deadline_date ?? r.deadline ?? r.due ?? "").trim();
  const taskText = String(r.task_name ?? r.task ?? "").trim();
  if (!taskText || taskText.length < 2 || !isNaN(taskText)) return null;
  const owner = String(r.officer_name ?? r.owner ?? r.sheet_name ?? "Chưa xác định").trim();
  return { id: r.id, owner, task: taskText, role: String(r.role ?? "").trim(), due, completed_date: String(r.completed_date ?? "").trim(), product: String(r.product ?? "").trim() || "Không", attachment_path: String(r.attachment_path ?? "").trim(), attachment_name: String(r.attachment_name ?? "").trim(), staff_note: String(r.staff_note ?? "").trim(), admin_note: String(r.note ?? r.admin_note ?? "").trim(), position: String(r.position ?? "").trim(), sheet_name: String(r.sheet_name ?? "").trim(), row_number: Number(r.row_number ?? 0) || 0, is_regular: r.is_regular === true, created_at: String(r.created_at ?? "").trim(), updated_at: String(r.updated_at ?? "").trim(), _source: src, _matchKey: fold(owner) + "||" + fold(taskText) };
}
function mergeVP(deps, offs) {
  const map = new Map();
  offs.forEach(x => { if (!x) return; const c = map.get(x._matchKey); if (!c || Number(x.id || 0) > Number(c.id || 0)) map.set(x._matchKey, x); });
  const used = new Set(), out = [];
  deps.forEach(dep => {
    if (!dep) return;
    const off = map.get(dep._matchKey);
    if (off) { used.add(off); out.push({ ...dep, id: off.id, task: off.task || dep.task, role: off.role || dep.role, due: off.due || dep.due, completed_date: off.completed_date || dep.completed_date, product: (off.product && off.product !== "Không") ? off.product : dep.product, admin_note: off.admin_note || "", staff_note: off.staff_note || "", attachment_path: off.attachment_path || "", attachment_name: off.attachment_name || "", created_at: off.created_at || dep.created_at || "" }); }
    else out.push({ ...dep });
  });
  offs.forEach(x => { if (x && !used.has(x)) out.push({ ...x }); });
  return out;
}
async function fetchVP() {
  const [depR, offR] = await Promise.all([sbGet("department_tasks", "*"), sbGet("office_tasks", "*")]);
  return mergeVP(depR.map(d => normVP(d, "department")).filter(Boolean), offR.map(o => normVP(o, "office")).filter(Boolean));
}
async function fetchWs(id, force) {
  const w = wsById(id);
  if (WS_CACHE[id] && !force) return WS_CACHE[id];
  const rows = id === "vp" ? await fetchVP() : await sbGet(w.table, "*");
  WS_CACHE[id] = rows;
  return rows;
}
async function fetchOff(w) {
  if (!w.offTable) return [];
  const ck = w.id + "_off";
  if (WS_CACHE[ck]) return WS_CACHE[ck];
  try { const r = await sbGet(w.offTable, "id,name,title"); WS_CACHE[ck] = r; return r; }
  catch (e) { return []; }
}
function buildNav() {
  document.querySelectorAll(".nav-it").forEach(b => b.classList.toggle("active", !b.dataset.w));
  document.querySelectorAll('.nav-it[data-w]').forEach(b => { b.style.display = mCan("v", b.dataset.w) ? "" : "none"; });
  refreshCounts();
}
async function refreshCounts() {
  await Promise.all(WS.filter(w => mCan("v", w.id)).map(async w => {
    try {
      const rows = await fetchWs(w.id);
      const el = $("cnt_" + w.id); if (el) el.textContent = rows.length;
    } catch (e) { const el = $("cnt_" + w.id); if (el) el.textContent = "!"; }
  }));
}
function goHome() {
  M.ws = null; M.mode = "home";
  document.querySelectorAll(".nav-it").forEach(b => b.classList.toggle("active", !b.dataset.w));
  $("wsTitle").textContent = "Trang chủ"; mToggleMenu(false);
  Promise.all(WS.filter(w => mCan("v", w.id)).map(async w => {
    let t = 0, d = 0, o = 0;
    try {
      const rows = await fetchWs(w.id);
      t = rows.length;
      rows.forEach(x => { const g = stGrp(w.st(x)); if (g === "done") d++; else if (g === "overdue") o++; });
    } catch (e) {}
    return { w, t, d, o };
  })).then(list => {
    if (M.mode !== "home") return;
    const T = list.reduce((a, x) => a + x.t, 0), D = list.reduce((a, x) => a + x.d, 0), O = list.reduce((a, x) => a + x.o, 0), P = T - D - O;
    const pc = n => T ? Math.round(n * 100 / T) : 0;
    const donut = "conic-gradient(#22c55e 0 " + pc(D) + "%, #3b82f6 " + pc(D) + "% " + pc(D + P) + "%, #ef4444 " + pc(D + P) + "% 100%)";
    const soon = [];
    WS.filter(w => mCan("v", w.id)).forEach(w => {
      (WS_CACHE[w.id] || []).forEach(x => {
        if (stGrp(w.st(x)) === "done" || !mOwns(w, x)) return;
        const d = pDate(w.id === "vp" ? x.due : x.deadline);
        if (!d) return;
        const n = dayDiff(d);
        if (n < 0 || n > 7) return;
        soon.push({ w, x, t: d.getTime(), n });
      });
    });
    soon.sort((a, b) => a.t - b.t);
    const soonHtml = '<div class="card"><b>⏳ Sắp đến hạn của bạn (' + soon.length + ')</b>' +
      (soon.length ? '<div style="margin-top:10px">' + soon.slice(0, 20).map(s => '<div class="card" style="margin:0 0 8px" onclick=\'goDetail(' + JSON.stringify(s.w.id) + ',' + JSON.stringify(String(s.x.id)) + ')\'><div class="row-top"><h3>' + esc(s.w.title(s.x)) + '</h3><span class="badge b-proc">' + (s.n === 0 ? "Hôm nay" : "Còn " + s.n + " ngày") + '</span></div><div class="meta"><span>' + esc(s.w.icon + " " + s.w.name) + '</span><span>📅 ' + esc(fmtD(s.w.id === "vp" ? s.x.due : s.x.deadline)) + '</span></div></div>').join("") + "</div>"
        : '<div class="sub">Không có nhiệm vụ nào đến hạn trong 7 ngày. 👌</div>') + "</div>";
    $("mView").innerHTML = '<h2 class="vt">Xin chào, ' + esc(MU.name || "") + '</h2>' +
      (list.length ? "" : '<div class="card">Bản mobile chưa có workspace cho token này (vd: KPI MTTQ xem ở bản đầy đủ).</div>') +
      '<div class="card"><div class="donut-wrap"><div class="donut" style="background:' + donut + '"><div class="donut-c"><b>' + T + '</b><small>nhiệm vụ</small></div></div>' +
      '<div class="legend"><span><span class="dot" style="background:#22c55e"></span>Hoàn thành ' + D + ' (' + pc(D) + '%)</span><span><span class="dot" style="background:#3b82f6"></span>Đang TH ' + P + ' (' + pc(P) + '%)</span><span><span class="dot" style="background:#ef4444"></span>Quá hạn ' + O + ' (' + pc(O) + '%)</span></div></div></div>' +
      soonHtml +
      '<div class="sub">Tỉ lệ theo workspace · chạm để mở</div>' +
      list.map(({ w, t, d, o }) => {
        const p = t - d - o, q = n => t ? Math.round(n * 100 / t) : 0;
        return '<div class="card" onclick="openWs(\'' + w.id + '\')"><div class="row-top"><b>' + w.icon + " " + esc(w.name) + '</b><span class="badge b-proc">' + t + ' NV</span></div>' +
          '<div class="wbar"><div class="seg done" style="width:' + q(d) + '%"></div><div class="seg proc" style="width:' + q(p) + '%"></div><div class="seg over" style="width:' + q(o) + '%"></div></div>' +
          '<div class="meta"><span>✅ ' + d + '</span><span>📌 ' + p + '</span><span>⏰ ' + o + '</span></div></div>';
      }).join("");
  }).catch(e => {
    if (M.mode !== "home") return;
    $("mView").innerHTML = '<div class="empty">❌ Lỗi tải dữ liệu: ' + esc(String((e && e.message) || e || "").slice(0, 200)) + '<br><button class="btn btn-g" style="display:block;max-width:220px;margin:14px auto 0" onclick="goHome()">Thử lại</button></div>';
  });
  $("mView").innerHTML = '<div class="spin">⏳ Đang tải...</div>';
}
async function openWs(id) {
  const w = wsById(id); if (!w) return;
  if (!mCan("v", id)) { toast("Không có quyền truy cập workspace này.", "err"); return; }
  if (MU.role === "department" && !["vpub", "action100"].includes(MU.scope) && ["bch", "ttbtv", "vpub"].includes(id)) { toast("Token cơ quan chỉ được truy cập KH 100 ngày.", "err"); return; }
  M.ws = id; M.mode = "list"; M.q = ""; M.st = "all"; M.rowId = null;
  document.querySelectorAll(".nav-it").forEach(b => b.classList.toggle("active", b.dataset.w === id));
  $("wsTitle").textContent = w.icon + " " + w.name; mToggleMenu(false);
  renderList();
}
async function renderList() {
  const w = wsById(M.ws); if (!w) return;
  $("mView").innerHTML = '<div class="spin">⏳ Đang tải ' + esc(w.name) + '...</div>';
  let rows;
  try { rows = await fetchWs(w.id); }
  catch (e) { $("mView").innerHTML = '<div class="empty">❌ Không tải được dữ liệu: ' + esc(String((e && e.message) || e || "").slice(0, 200)) + '<br><button class="btn btn-g" style="display:block;max-width:200px;margin:14px auto 0" onclick="renderList()">Thử lại</button></div>'; return; }
  rows.forEach(x => { x._g = stGrp(w.st(x)); x._k = w.st(x); x._s = fold((w.blob(x) || []).join(" ")); });
  const c = { all: rows.length, done: 0, processing: 0, overdue: 0 };
  rows.forEach(x => c[x._g]++);
  const q = fold(M.q);
  const list = rows.filter(x => (M.st === "all" || x._g === M.st) && (!q || x._s.includes(q)));
  const pill = (k, lb) => '<button class="pill' + (M.st === k ? " active" : "") + '" onclick="mSetSt(\'' + k + '\')">' + lb + " (" + c[k] + ")</button>";
  $("mView").innerHTML =
    '<div class="pills">' + pill("all", "Tổng") + pill("done", "✅ Hoàn thành") + pill("processing", "📌 Đang TH") + pill("overdue", "⏰ Quá hạn") + "</div>" +
    '<div class="searchbar"><input type="text" id="mQ" placeholder="🔎 Tìm kiếm..." value="' + esc(M.q) + '" oninput="M.q=this.value;mRenderCards()"></div>' +
    (mCan("a", w.id) ? '<div class="toolbar"><button class="btn btn-p" onclick="mAdd()">＋ Thêm nhiệm vụ</button></div>' : "") +
    '<div id="mCards"></div>';
  mRenderCards(list);
  const qi = $("mQ"); if (qi && M.q) { qi.focus(); qi.setSelectionRange(qi.value.length, qi.value.length); }
}
function mSetSt(k) { M.st = k; renderList(); }
function mRenderCards(pre) {
  const w = wsById(M.ws);
  const box = $("mCards"); if (!box) return;
  let list = pre;
  if (!list) {
    const rows = WS_CACHE[w.id] || [];
    const q = fold(($("mQ") || {}).value || "");
    list = rows.filter(x => (M.st === "all" || x._g === M.st) && (!q || (x._s || "").includes(q)));
  }
  if (!list.length) { box.innerHTML = '<div class="empty">Không có nhiệm vụ phù hợp.</div>'; return; }
  box.innerHTML = list.map(x => {
    const att = String(x.attachment_name || x.attachment_path || "").trim() ? " 📎" : "";
    return '<div class="card" onclick=\'mDetail(' + JSON.stringify(String(x.id)) + ')\'><div class="row-top"><h3>' + esc(w.title(x)) + att + '</h3><span class="badge ' + (ST_CLS[x._k] || "b-proc") + '">' + esc(ST_LB[x._k] || x._k) + '</span></div><div class="meta">' + w.meta(x).map(m => "<span>" + esc(m) + "</span>").join("") + "</div></div>";
  }).join("");
}
/* ---- P3: detail + edit/add + save ---- */
function mRow() { return (WS_CACHE[M.ws] || []).find(x => String(x.id) === String(M.rowId)); }
function mDetail(id) { M.rowId = id; M.mode = "detail"; M.isNew = false; renderDetail(); }
async function goDetail(wsId, id) {
  const w = wsById(wsId); if (!w || !mCan("v", wsId)) return;
  M.ws = wsId;
  document.querySelectorAll(".nav-it").forEach(b => b.classList.toggle("active", b.dataset.w === wsId));
  try { await fetchWs(wsId); } catch (e) {}
  M.rowId = id; M.mode = "detail"; M.isNew = false;
  mToggleMenu(false);
  renderDetail();
}
function kv(rid, rows) {
  return "<dl class=\"kv\">" + rows.map(([k, v]) => "<dt>" + esc(k) + "</dt><dd id=\"" + rid + "_" + k + "\">" + v + "</dd>").join("") + "</dl>";
}
function renderDetail() {
  const w = wsById(M.ws), x = mRow();
  if (!x) { toast("Không tìm thấy nhiệm vụ", "err"); openWs(M.ws); return; }
  $("wsTitle").textContent = w.icon + " Chi tiết";
  const info = w.detail(x);
  const canE = mCanEdit(w, x);
  const isAdm = MU.role === "admin";
  $("mView").innerHTML =
    '<div class="toolbar"><button class="btn btn-g" onclick="renderListMode()">‹ Danh sách</button></div>' +
    '<div class="card"><div class="row-top"><h3>' + esc(w.title(x)) + '</h3><span class="badge ' + (ST_CLS[x._k] || "b-proc") + '">' + esc(ST_LB[x._k] || "") + '</span></div>' +
    kv("d", info) + "</div>" +
    '<div class="toolbar">' +
    (canE ? '<button class="btn btn-p" onclick="mEdit()">✏️ Sửa</button>' : "") +
    (isAdm && x._g === "overdue" ? '<button class="btn btn-g" onclick="mExtend()">📅 Gia hạn</button>' : "") +
    (isAdm ? '<button class="btn btn-d" onclick="mDel()">🗑️ Xóa</button>' : "") + "</div>";
  M.mode = "detail";
}
function renderListMode() { M.mode = "list"; renderList(); }
/* Field defs: {k,lb,t,req,lock,adm} t=ro|text|area|date|list ; lock=1 (chi admin sua) */
const FED = {
  vp: [{ k: "owner", lb: "Cán bộ phụ trách", t: "ro" }, { k: "task", lb: "Nội dung nhiệm vụ", t: "area", req: 1, lock: 1 }, { k: "role", lb: "Vai trò (Chủ trì/Phối hợp)", t: "text", req: 1 }, { k: "due", lb: "Hạn hoàn thành", t: "date", lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  bch: [{ k: "officer_name", lb: "Lãnh đạo phụ trách", t: "ro" }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1, lock: 1 }, { k: "role", lb: "Vai trò/Cơ quan", t: "text", lock: 1 }, { k: "deadline", lb: "Hạn hoàn thành", t: "date", lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm / kết quả", t: "area" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  ttbtv: [{ k: "officer_name", lb: "Lãnh đạo phụ trách", t: "ro" }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1, lock: 1 }, { k: "role", lb: "Cơ quan chủ trì", t: "text", lock: 1 }, { k: "ubnd_leader", lb: "Lãnh đạo UBND", t: "text" }, { k: "amount", lb: "Nguồn giao", t: "text", lock: 1 }, { k: "ubnd_source", lb: "Nguồn giao của UBND", t: "text", lock: 1 }, { k: "specialist_name", lb: "Chuyên viên", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành", t: "date", lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "result", lb: "Kết quả thực hiện", t: "area" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  prov: [{ k: "officer_name", lb: "Lãnh đạo (UBND)", t: "text", lock: 2 }, { k: "task_name", lb: "Nhiệm vụ Tỉnh giao", t: "area", req: 1, lock: 1 }, { k: "unit_name", lb: "Cơ quan tham mưu", t: "text", lock: 2 }, { k: "role", lb: "Vai trò", t: "text", lock: 2 }, { k: "source_form", lb: "Hình thức cụ thể hóa", t: "text", lock: 2 }, { k: "issuing_authority", lb: "Thẩm quyền ban hành", t: "text", lock: 2 }, { k: "specialist_name", lb: "Chuyên viên", t: "text", lock: 2 }, { k: "deadline", lb: "Hạn hoàn thành", t: "date", lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "progress", lb: "Tiến độ", t: "text" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  a100: [{ k: "officer_name", lb: "Chuyên viên", t: "text" }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1, lock: 1 }, { k: "commune_leader", lb: "Cơ quan phụ trách", t: "text" }, { k: "office_leader", lb: "Lãnh đạo cơ quan", t: "text" }, { k: "unit_name", lb: "Cơ quan phối hợp", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành", t: "date", req: 1, lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "result", lb: "Kết quả", t: "area" }, { k: "admin_note", lb: "Ghi chú ADMIN", t: "area", adm: 1 }],
  vpub: [{ k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1, lock: 1 }, { k: "unit", lb: "Đơn vị", t: "text" }, { k: "field", lb: "Lĩnh vực", t: "text" }, { k: "leader", lb: "Lãnh đạo xã", t: "text" }, { k: "office_leader", lb: "Lãnh đạo cơ quan", t: "text" }, { k: "source", lb: "Nguồn giao", t: "text" }, { k: "ubnd_source", lb: "Nguồn giao UBND", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành", t: "date", req: 1, lock: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "result", lb: "Kết quả", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
};
const FAD = {
  bch: [{ k: "officer_name", lb: "Lãnh đạo phụ trách", t: "list", req: 1 }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1 }, { k: "role", lb: "Vai trò/Cơ quan", t: "text" }, { k: "specialist", lb: "Chuyên viên", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành *", t: "date", req: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "result", lb: "Kết quả thực hiện", t: "area" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  ttbtv: [{ k: "officer_name", lb: "Lãnh đạo phụ trách", t: "list", req: 1 }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1 }, { k: "role", lb: "Cơ quan chủ trì", t: "text" }, { k: "specialist", lb: "Chuyên viên", t: "text" }, { k: "amount", lb: "Nguồn giao *", t: "text", req: 1 }, { k: "ubnd_source", lb: "Nguồn giao của UBND *", t: "text", req: 1 }, { k: "ubnd_leader", lb: "Lãnh đạo UBND", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành *", t: "date", req: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "result", lb: "Kết quả thực hiện", t: "area" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  prov: [{ k: "officer_name", lb: "Lãnh đạo (UBND)", t: "list" }, { k: "task_name", lb: "Nhiệm vụ Tỉnh giao", t: "area", req: 1 }, { k: "unit_name", lb: "Cơ quan tham mưu", t: "text" }, { k: "role", lb: "Vai trò", t: "text" }, { k: "source_form", lb: "Hình thức cụ thể hóa", t: "text" }, { k: "issuing_authority", lb: "Thẩm quyền ban hành", t: "text" }, { k: "specialist_name", lb: "Chuyên viên", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành *", t: "date", req: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "progress", lb: "Tiến độ", t: "text" }, { k: "staff_note", lb: "Ghi chú cán bộ", t: "area" }, { k: "admin_note", lb: "Ghi chú Admin", t: "area", adm: 1 }],
  a100: [{ k: "officer_name", lb: "Chuyên viên", t: "list" }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1 }, { k: "commune_leader", lb: "Cơ quan phụ trách", t: "text" }, { k: "office_leader", lb: "Lãnh đạo cơ quan", t: "text" }, { k: "unit_name", lb: "Cơ quan phối hợp", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành *", t: "date", req: 1 }, { k: "completed_date", lb: "Ngày hoàn thành", t: "date" }, { k: "product", lb: "Sản phẩm", t: "area" }, { k: "result", lb: "Kết quả", t: "area" }, { k: "admin_note", lb: "Ghi chú ADMIN", t: "area", adm: 1 }],
  vpub: [{ k: "unit", lb: "Đơn vị *", t: "text", req: 1 }, { k: "field", lb: "Lĩnh vực", t: "text" }, { k: "task_name", lb: "Nhiệm vụ", t: "area", req: 1 }, { k: "source", lb: "Nguồn giao", t: "text" }, { k: "ubnd_source", lb: "Nguồn giao UBND", t: "text" }, { k: "leader", lb: "Lãnh đạo xã", t: "text" }, { k: "office_leader", lb: "Lãnh đạo cơ quan", t: "text" }, { k: "deadline", lb: "Hạn hoàn thành *", t: "date", req: 1 }, { k: "weekly_result", lb: "Kết quả tuần", t: "area" }, { k: "difficulties", lb: "Khó khăn", t: "area" }, { k: "proposal", lb: "Đề xuất", t: "area" }, { k: "note", lb: "Ghi chú", t: "area" }],
};
function lockedOf(w, f, isAdmin) {
  if (f.adm && !isAdmin) return "hide";
  if (!f.lock) return "";
  if (f.lock === 1) return isAdmin ? "" : "lock";
  if (f.lock === 2) return (isAdmin || (w.id === "prov" && MU.scope === "data_entry")) ? "" : "lock";
  return "";
}
function fieldHtml(w, f, val, offNames, dlId) {
  const v = val ?? "";
  if (f.t === "ro") return '<label class="f">' + esc(f.lb) + '</label><input type="text" value="' + esc(v) + '" readonly>';
  if (f.t === "list") return '<label class="f">' + esc(f.lb) + (f.req ? ' *' : "") + '</label><input type="text" data-f="' + f.k + '" list="' + dlId + '" value="' + esc(v) + '" placeholder="Chọn hoặc nhập...">';
  if (f.t === "area") return '<label class="f">' + esc(f.lb) + (f.req ? ' *' : "") + '</label><textarea data-f="' + f.k + '">' + esc(v) + '</textarea>';
  if (f.t === "date") return '<label class="f">' + esc(f.lb) + (f.req ? ' *' : "") + '</label><input type="text" data-f="' + f.k + '" inputmode="numeric" placeholder="dd/mm/yyyy" value="' + esc(v) + '">';
  return '<label class="f">' + esc(f.lb) + (f.req ? ' *' : "") + '</label><input type="text" data-f="' + f.k + '" value="' + esc(v) + '">';
}
async function mEdit() {
  const w = wsById(M.ws), x = mRow(); if (!x) return;
  const isAdmin = MU.role === "admin";
  const off = await fetchOff(w);
  const names = [...new Set((off || []).map(o => String(o.name || "").trim()).filter(Boolean))];
  const fs = FED[w.id].filter(f => lockedOf(w, f, isAdmin) !== "hide");
  M.mode = "form"; M.isNew = false;
  $("wsTitle").textContent = "✏️ Sửa";
  const disp = k => (k === "deadline" || k === "completed_date" || k === "due") ? fmtD(x[k]) : (x[k] ?? "");
  $("mView").innerHTML = '<h2 class="vt">' + esc(w.title(x)) + '</h2><div class="sub">' + esc(w.name) + ' · Trạng thái tự tính khi lưu</div>' +
    '<datalist id="dl_off">' + names.map(n => "<option value=\"" + esc(n) + "\">").join("") + "</datalist>" +
    fs.map(f => {
      const lk = lockedOf(w, f, isAdmin);
      let h = fieldHtml(w, f, disp(f.k), names, "dl_off");
      if (lk === "lock") h = h.replace('data-f="' + f.k + '"', 'data-f="' + f.k + '" readonly').replace("<textarea", "<textarea readonly").replace("<input type=\"text\"", "<input type=\"text\" readonly");
      return h;
    }).join("") +
    '<div style="height:76px"></div><div class="savebar"><button class="btn btn-g" onclick="renderDetail()">Hủy</button><button class="btn btn-p" id="mSaveBtn" onclick="mSave()">💾 Lưu</button></div>';
  window.scrollTo(0, 0);
}
async function mAdd() {
  const w = wsById(M.ws); if (!w || !mCan("a", w.id)) return;
  const isAdmin = MU.role === "admin";
  const off = await fetchOff(w);
  const names = [...new Set((off || []).map(o => String(o.name || "").trim()).filter(Boolean))];
  const fs = FAD[w.id].filter(f => !(f.adm && !isAdmin));
  M.mode = "form"; M.isNew = true;
  $("wsTitle").textContent = "➕ Thêm · " + w.name;
  $("mView").innerHTML = '<h2 class="vt">Thêm nhiệm vụ mới</h2><div class="sub">' + esc(w.name) + '</div>' +
    '<datalist id="dl_off">' + names.map(n => "<option value=\"" + esc(n) + "\">").join("") + "</datalist>" +
    fs.map(f => fieldHtml(w, f, f.k === "ubnd_source" ? "Chưa rõ" : "", names, "dl_off")).join("") +
    '<div style="height:76px"></div><div class="savebar"><button class="btn btn-g" onclick="renderListMode()">Hủy</button><button class="btn btn-p" id="mSaveBtn" onclick="mSave()">💾 Thêm</button></div>';
  window.scrollTo(0, 0);
}
function mVals() {
  const o = {};
  document.querySelectorAll("#mView [data-f]").forEach(el => { o[el.getAttribute("data-f")] = (el.value || "").trim(); });
  return o;
}
async function mSave() {
  const w = wsById(M.ws), isAdmin = MU.role === "admin";
  const btn = $("mSaveBtn"); if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang lưu..."; }
  try {
    if (M.isNew) {
      const v = mVals();
      const body = mkAdd(w, v);
      if (!body) throw new Error("Thiếu Nhiệm vụ hoặc Hạn hoàn thành.");
      await sbMut(w.table, null, body, "POST");
      await writeAct("Thêm nhiệm vụ " + w.name, { task: v.task_name });
      await fetchWs(w.id, true);
      toast("Đã thêm nhiệm vụ", "ok"); renderListMode();
    } else {
      const x = mRow(); if (!x) throw new Error("Mất nhiệm vụ.");
      if (!mCanEdit(w, x)) throw new Error("Không có quyền sửa nhiệm vụ này.");
      const v = mVals();
      const patch = mkPatch(w, x, v, isAdmin);
      await sbMut(w.table, x.id, patch, "PATCH");
      await writeAct("Sửa nhiệm vụ " + w.name, { task: x.task_name || v.task_name, id: x.id });
      await fetchWs(w.id, true);
      const nx = mRow(); if (nx) { nx._k = w.st(nx); nx._g = stGrp(nx._k); }
      toast("Đã lưu thay đổi", "ok"); renderDetail();
    }
  } catch (e) { toast("Lỗi: " + (e.message || e).slice(0, 160), "err"); if (btn) { btn.disabled = false; btn.textContent = M.isNew ? "💾 Thêm" : "💾 Lưu"; } }
}
function needTask(v) {
  if (!v.task_name) return null;
  const dl = toDb(v.deadline);
  if (!dl) return null;
  return dl;
}
function mkAdd(w, v) {
  const dl = needTask(v); if (!dl) return null;
  const cd = v.completed_date ? (toDb(v.completed_date) || null) : null;
  const now = new Date().toISOString(), adm = MU.role === "admin" ? (v.admin_note || "") : "";
  if (w.id === "bch") return { officer_name: v.officer_name, task_name: v.task_name, product: v.result || "", amount: v.specialist || "", deadline: dl, result: v.result || "", note: "", phat_sinh: false, role: v.role || "", completed_date: cd, status: ST_LB[stCore({ deadline: dl, completed_date: cd, result: v.result })], staff_note: v.staff_note || "", admin_note: adm, attachment_path: "", attachment_name: "", attachment_type: "", attachment_size: 0, attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "", updated_at: now };
  if (w.id === "ttbtv") return { officer_name: v.officer_name, task_name: v.task_name, product: "", specialist_name: v.specialist || "", amount: v.amount || "", ubnd_source: v.ubnd_source || "", source_doc: "", deadline: dl, result: v.result || "", note: "", phat_sinh: false, role: v.role || "", unit_name: v.role || "", completed_date: cd, status: ST_LB[stCore({ deadline: dl, completed_date: cd, result: v.result }, true)], staff_note: v.staff_note || "", admin_note: adm, ubnd_leader: v.ubnd_leader || "", attachment_path: "", attachment_name: "", attachment_type: "", attachment_size: 0, attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "", source_sheet: "APP_MOBILE", source_row: Math.floor(1e8 + Math.random() * 1.8e9), source_group: "", updated_at: now };
  if (w.id === "prov") return { officer_name: v.officer_name || "Chưa phân công", task_name: v.task_name, product: v.product || "", specialist_name: v.specialist_name || "", amount: "", source_doc: "", deadline: dl, result: v.product || "", note: v.staff_note || "", phat_sinh: false, role: v.role || "", unit_name: v.unit_name || v.role || "", completed_date: cd, status: ST_LB[stCore({ deadline: dl, completed_date: cd, result: v.product })], staff_note: v.staff_note || "", admin_note: adm, source_form: v.source_form || "", issuing_authority: v.issuing_authority || "", implementation_detail: "", overdue_reason: "", progress: v.progress || "", attachment_path: "", attachment_name: "", attachment_type: "", attachment_size: 0, attachment_approved: false, attachment_approved_at: null, attachment_approved_by: "", source_sheet: "APP_MOBILE", source_row: Math.floor(1e8 + Math.random() * 1.8e9), source_group: "", updated_at: now };
  if (w.id === "a100") return { officer_name: v.officer_name || "", task_name: v.task_name, deadline: dl, completed_date: cd, commune_leader: v.commune_leader || "", office_leader: v.office_leader || "", unit_name: v.unit_name || "", role: v.office_leader || "", specialist_name: v.officer_name || "", product: v.product || "", result: v.result || "", staff_note: v.result || "", admin_note: adm, updated_at: now };
  return { unit: v.unit, field: v.field || "", task_name: v.task_name, source: v.source || "", ubnd_source: v.ubnd_source || "", leader: v.leader || "", office_leader: v.office_leader || "", start_date: null, deadline: dl, weekly_result: v.weekly_result || "", difficulties: v.difficulties || "", proposal: v.proposal || "", status: "Đang triển khai", note: v.note || "" };
}
function mkPatch(w, x, v, isAdmin) {
  const cd = v.completed_date ? (toDb(v.completed_date) || null) : null;
  const now = new Date().toISOString();
  const entryProv = w.id === "prov" && MU.scope === "data_entry";
  const owns = mOwns(w, x);
  if (w.id === "vp") {
    const dueDb = toDb(v.due) || "";
    const effDue = (isAdmin && dueDb) ? dueDb : String(x.due || "");
    const st = stVPcalc(x, { due: effDue, completed_date: cd, product: v.product, hasFile: !!x.attachment_path });
    const p = { completed_date: cd, product: v.product || "Không", staff_note: v.staff_note || "", role: v.role || "", status: dbVP(st), updated_at: now };
    if (!p.role) throw new Error("Vui lòng nhập vai trò Chủ trì / Phối hợp.");
    if (isAdmin) { p.task_name = v.task || x.task; p.deadline_date = dueDb; p.note = v.note || ""; }
    return p;
  }
  if (w.id === "bch") {
    const p = { completed_date: cd, product: v.product || "Không", updated_at: now };
    if (isAdmin) { p.task_name = v.task_name || x.task_name; p.role = v.role || ""; p.deadline = toDb(v.deadline) || ""; p.admin_note = v.admin_note || ""; }
    if (owns || isAdmin) p.staff_note = v.staff_note || "";
    return p;
  }
  if (w.id === "ttbtv") {
    const p = { completed_date: cd, result: v.result || "", updated_at: now };
    if (isAdmin) { p.task_name = v.task_name || x.task_name; p.role = v.role || ""; p.deadline = toDb(v.deadline) || ""; p.ubnd_leader = v.ubnd_leader || ""; p.specialist_name = v.specialist_name || ""; p.ubnd_source = v.ubnd_source || ""; p.amount = v.amount || ""; p.admin_note = v.admin_note || ""; }
    if (owns || isAdmin) p.staff_note = v.staff_note || "";
    return p;
  }
  if (w.id === "prov") {
    const p = { deadline: String(x.deadline ?? ""), completed_date: cd, product: v.product || "", result: v.product || "Chưa điền", progress: v.progress || "", updated_at: now };
    if (isAdmin || entryProv) {
      p.officer_name = v.officer_name || "Chưa phân công"; p.role = v.role || ""; p.unit_name = v.unit_name || ""; p.specialist_name = v.specialist_name || ""; p.source_form = v.source_form || ""; p.issuing_authority = v.issuing_authority || "";
      if (isAdmin) { p.task_name = v.task_name || x.task_name; if (v.deadline) p.deadline = toDb(v.deadline) || ""; p.admin_note = v.admin_note || ""; }
    }
    if (owns || isAdmin) p.staff_note = v.staff_note || "";
    return p;
  }
  if (w.id === "a100") {
    const p = { officer_name: v.officer_name || "", commune_leader: v.commune_leader || "", office_leader: v.office_leader || "", unit_name: v.unit_name || "", role: v.office_leader || "", specialist_name: v.officer_name || "", completed_date: cd, product: v.product || "", result: v.result || "", staff_note: v.result || "", admin_note: v.admin_note || "", updated_at: now };
    if (isAdmin) { p.task_name = v.task_name || x.task_name; p.deadline = toDb(v.deadline) || x.deadline; }
    else { p.task_name = x.task_name; p.deadline = x.deadline; }
    return p;
  }
  const p = { officer_name: v.officer_name || x.officer_name || "", unit: v.unit || "", field: v.field || "", leader: v.leader || "", office_leader: v.office_leader || "", source: v.source || "", ubnd_source: v.ubnd_source || "", completed_date: cd, product: v.product || "", result: v.result || "", staff_note: v.result || "", weekly_result: v.result || "", admin_note: v.admin_note || "", note: v.admin_note || "", updated_at: now };
  if (isAdmin) { p.task_name = v.task_name || x.task_name; p.deadline = toDb(v.deadline) || x.deadline; }
  else { p.task_name = x.task_name; p.deadline = x.deadline; }
  return p;
}
async function mDel() {
  const w = wsById(M.ws), x = mRow();
  if (!x || MU.role !== "admin") return;
  if (w.id === "vp") { toast("Xóa VP ở bản đầy đủ (đồng bộ 2 bảng).", "err"); return; }
  if (!confirm("Xóa nhiệm vụ này?")) return;
  try {
    const r = await fetch(SB_URL + "/rest/v1/" + w.table + "?id=eq." + encodeURIComponent(x.id), { method: "DELETE", headers: sbH() });
    if (!r.ok) throw new Error(await r.text());
    await writeAct("Xóa nhiệm vụ " + w.name, { task: x.task_name, id: x.id });
    await fetchWs(w.id, true);
    toast("Đã xóa", "ok"); renderListMode();
  } catch (e) { toast("Lỗi xóa: " + (e.message || e).slice(0, 140), "err"); }
}
async function mExtend() {
  const w = wsById(M.ws), x = mRow();
  if (!x || MU.role !== "admin") return;
  const s = prompt("Nhập hạn mới (dd/mm/yyyy):", fmtD(x.deadline));
  if (!s) return;
  const dl = toDb(s);
  if (!dl) { toast("Ngày chưa đúng", "err"); return; }
  try {
    const dk = w.id === "vp" ? "deadline_date" : "deadline";
    await sbMut(w.table, x.id, { [dk]: dl, updated_at: new Date().toISOString() }, "PATCH");
    await writeAct("Gia hạn nhiệm vụ " + w.name, { task: x.task_name, id: x.id, deadline: dl });
    await fetchWs(w.id, true);
    toast("Đã gia hạn", "ok"); renderDetail();
  } catch (e) { toast("Lỗi: " + (e.message || e).slice(0, 140), "err"); }
}
/* Detail info per ws */
wsById("vp").detail = x => [["Cán bộ", x.owner || "—"], ["Vai trò", x.role || "—"], ["Hạn", fmtD(x.due)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Sản phẩm", x.product || "—"], ["Tệp", x.attachment_name || "—"], ["Ghi chú CB", x.staff_note || "—"], ["Ghi chú Admin", x.admin_note || "—"]];
wsById("bch").detail = x => [["Lãnh đạo", x.officer_name || "—"], ["Vai trò", x.role || "—"], ["Hạn", fmtD(x.deadline)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Sản phẩm", x.product || "—"], ["Tệp", x.attachment_name || "—"], ["Ghi chú CB", x.staff_note || "—"], ["Ghi chú Admin", x.admin_note || "—"]];
wsById("ttbtv").detail = x => [["Lãnh đạo", x.officer_name || "—"], ["Cơ quan", x.role || x.unit_name || "—"], ["Nguồn giao", x.amount || "—"], ["Nguồn UBND", x.ubnd_source || "—"], ["LĐ UBND", x.ubnd_leader || "—"], ["Chuyên viên", x.specialist_name || "—"], ["Hạn", fmtD(x.deadline)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Kết quả", x.result || "—"], ["Ghi chú CB", x.staff_note || "—"], ["Ghi chú Admin", x.admin_note || "—"]];
wsById("prov").detail = x => [["Lãnh đạo", x.officer_name || "—"], ["Cơ quan", x.unit_name || x.role || "—"], ["Hạn", fmtD(x.deadline)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Sản phẩm", x.product || "—"], ["Tiến độ", x.progress || "—"], ["Ghi chú CB", x.staff_note || "—"], ["Ghi chú Admin", x.admin_note || "—"]];
wsById("a100").detail = x => [["Chuyên viên", x.officer_name || "—"], ["CQ phụ trách", x.commune_leader || "—"], ["LĐ cơ quan", x.office_leader || "—"], ["CQ phối hợp", x.unit_name || "—"], ["Hạn", fmtD(x.deadline)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Sản phẩm", x.product || "—"], ["Kết quả", x.result || "—"], ["Ghi chú", x.admin_note || "—"]];
wsById("vpub").detail = x => [["Đơn vị", x.unit || "—"], ["Lĩnh vực", x.field || "—"], ["LĐ xã", x.leader || "—"], ["LĐ cơ quan", x.office_leader || "—"], ["Nguồn giao", x.source || "—"], ["Hạn", fmtD(x.deadline)], ["Ngày HT", fmtD(x.completed_date) || "—"], ["Sản phẩm", x.product || "—"], ["Kết quả", x.result || "—"], ["KQ tuần", x.weekly_result || "—"], ["Ghi chú", x.note || x.admin_note || "—"]];
// Khoi phuc phien cuoi file: moi const (WS...) da xong, tranh TDZ
initMRestore();
