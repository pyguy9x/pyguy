# AGENTS.md - Vibecode 2 Thầy Trò (Haiku + Sonnet) - Dùng cho mọi project

Bạn đang chạy trong OpenCode / Claude Code qua OpenRouter. Mục tiêu: fix nhanh, tiết kiệm token tối đa.

## 1. Mô hình 2 Thầy Trò

- **Thợ (Haiku - `anthropic/claude-3-5-haiku`):** Mặc định. Làm 80% việc: đọc log, `git status`, `wc -l`, `node --check` / `npm run build`, đọc 1-2 file lỗi, sửa lặt vặt, bump cache.
- **Thầy (Sonnet 4-6 - `anthropic/claude-sonnet-4`):** Chỉ gọi khi Haiku bó tay sau 2 lần thử, hoặc lỗi liên quan đến: SyntaxError toàn cục, file bị corrupt, logic phức tạp, refactor nhiều file, lỗi không rõ nguyên nhân.

Tuyệt đối không dùng Opus nếu không được yêu cầu.

## 2. Luật Tiết Kiệm Token (BẮT BUỘC)

1. **Không đọc rác:** KHÔNG BAO GIỜ đọc `node_modules/`, `dist/`, `build/`, `.next/`, `*.log`, `*.map`, file report tự sinh (vd: `refactor-report.html`).
2. **Tối đa 2 file/lần:** Chỉ đọc file được nhắc trong lỗi + 1 file liên quan. Dùng `git diff` thay vì đọc cả file.
3. **Kiểm tra nhanh trước:** Dùng `wc -l`, `head -n 50`, `node --check <file>` trước khi đọc full file.
4. **Compact:** Sau khi fix xong, tóm tắt lại để xóa lịch sử dài.

## 3. Workflow Fix Bug Chuẩn

Khi có lỗi:

1.  **Chẩn đoán (Haiku):** `git status` + đọc log lỗi + `wc -l` file lỗi để check có bị dồn 1 dòng / corrupt không.
2.  **Khôi phục rẻ nhất trước:** Nếu file bị corrupt / 1 dòng khổng lồ -> `git checkout HEAD -- <file>` hoặc `git restore <file>`. Đây là cách rẻ nhất, luôn thử trước.
3.  **Verify:** `node --check` hoặc lệnh check/build của project.
4.  **Bump cache nếu là frontend:** Đổi `?v=timestamp` trong `index.html` cho file JS vừa sửa.
5.  **Báo cáo:** Theo form ngắn gọn:
    - Đã sửa xong
    - Nguyên nhân gốc
    - Đã làm (các lệnh đã chạy)
    - File đổi

## 4. Khi Nào Gọi Sonnet?

Chỉ escalate sang Sonnet khi:
- File đủ dòng nhưng vẫn `is not defined` / `not a function`
- Lỗi logic render / state / data flow
- Cần refactor / tách module
- Haiku đã thử `git checkout` + `check` vẫn không hết

Khi gọi Sonnet, truyền đúng: "Haiku đã thử X, Y nhưng vẫn lỗi Z, cần Thầy phân tích sâu".

## 5. Cấm

- Không `cat` file > 2000 dòng
- Không tự ý cài thêm package
- Không viết lại file từ đầu nếu `git checkout` còn dùng được
- Không đọc lại file report do chính mình vừa tạo

## 6. Ngôn Ngữ

- Trả lời user bằng Tiếng Việt
- Comment code bằng Tiếng Anh
