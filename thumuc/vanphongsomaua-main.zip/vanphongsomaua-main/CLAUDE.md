# CLAUDE.md - Vibecode Generic - 2 Thầy Trò Tiết Kiệm

## 1. Nguyên tắc Model (QUAN TRỌNG - Tiết kiệm tiền)

Bạn đang chạy qua OpenRouter / Chutes / WUS. Phải tiết kiệm token tối đa.

- **Mặc định: Model RẺ NHẤT (Thợ):**
  - `chutes/inkling-small-free` (0đ) hoặc `claude-haiku-3-5` / `deepseek-v4-flash`
  - Dùng cho: đọc log, `git status`, `wc -l`, `node --check`, `npm run build`, đọc 1-2 file lỗi, sửa lặt vặt, bump cache.

- **Chỉ escalate lên Model ĐẮT (Thầy - Sonnet 4-6):**
  - `WUS/claude-sonnet-4-6` hoặc `anthropic/claude-sonnet-4`
  - Chỉ khi: user ghi `dung pro`, hoặc thợ đã thử 2 lần không được, hoặc lỗi logic phức tạp, file bị corrupt nặng, refactor đa file, lỗi `is not defined` dù file đủ dòng.

Tuyệt đối không dùng Opus nếu không được yêu cầu.

## 2. Luật Tiết Kiệm Token (BẮT BUỘC)

1.  **KHÔNG đọc rác:** `node_modules/`, `dist/`, `build/`, `.next/`, `.ast-bro/`, `*.png`, `*.mp4`, `*.log`, `*.map`, file report tự sinh (`refactor-report.html`, `archive.md`).
2.  **File lớn >500 dòng:** LUÔN dùng `ast-bro` (map/digest) + `Read offset/limit`. KHÔNG BAO GIỜ `cat` full file.
3.  **Tối đa 2 file/lần:** Chỉ đọc file báo lỗi + 1 file liên quan. Dùng `git diff` thay vì đọc lại cả file.
4.  **Check nhanh trước:** `wc -l <file>` để check file có bị dồn 1 dòng/corrupt không. `node --check <file>` để check syntax.
5.  **Compact:** Sau mỗi lần fix xong, tóm tắt lại.

## 3. Quy ước Project (Điền vào cho từng project)

- **Stack:** [vd: Vanilla JS classic script, window globals / Next.js / React...]
- **Thứ tự load BẮT BUỘC (nếu có):** [vd: store -> utils -> auth -> ... -> legacy. KHÔNG đổi thứ tự]
- **File legacy/giới hạn:** [vd: legacy.js đang đóng băng ở 6462 dòng (435/644 hàm). DỪNG TÁCH nữa.]
- **Cách thêm tính năng mới:** [vd: Tạo file mới `js/modules/<ten>.js` dạng classic script window globals, thêm vào `main.js` TRƯỚC legacy.]

> Khi refactor: Giữ lại hàm dài quan trọng (vd: isOwnedByToken...). Tính năng mới không sửa vào legacy.

## 4. Workflow Fix Bug Chuẩn (Áp dụng mọi lỗi)

1.  **Chẩn đoán (Thợ):** `git status` + đọc log + `wc -l file lỗi` xem có bị corrupt không.
2.  **Khôi phục rẻ nhất:** Nếu file 1 dòng khổng lồ hoặc SyntaxError -> `git checkout HEAD -- <file>` hoặc `git restore <file>` TRƯỚC, đừng viết lại.
3.  **Verify:** Chạy lệnh check của project: `node --check <files>` hoặc `npm run build`. Phải pass hết mới xong.
4.  **Bump cache (nếu là frontend):** Đổi `?v=timestamp` trong `index.html` cho file vừa sửa.
5.  **Báo cáo ngắn gọn:**
    - Đã sửa xong.
    - Nguyên nhân gốc
    - Đã làm (liệt kê lệnh)
    - File đổi

## 5. Cấm

- Không `cat` file >2000 dòng
- Không tự ý cài package mới
- Không viết lại file từ đầu nếu `git checkout` còn dùng được
- Không đọc lại file report do chính mình vừa tạo ra

## 6. Ngôn ngữ & Báo cáo

- Trả lời user: Tiếng Việt
- Comment code: Tiếng Anh
- Báo cáo luôn dùng form: Đã sửa xong / Nguyên nhân gốc / Đã làm / File đổi
- Cuối cùng luôn nhắc user: F5 cứng `Ctrl+Shift+R` để test
