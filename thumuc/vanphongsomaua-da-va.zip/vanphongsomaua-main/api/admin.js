// /api/admin.js — xác thực token và quản lý Set role (chạy phía máy chủ Vercel)
//
// Biến môi trường BẮT BUỘC trên Vercel (Settings > Environment Variables):
//   SUPABASE_URL                 địa chỉ dự án Supabase
//   SUPABASE_SERVICE_ROLE_KEY    khóa service_role (KHÔNG dùng khóa anon thay thế)
//   ADMIN_TOKEN                  token Admin, tối thiểu 16 ký tự, tự sinh ngẫu nhiên
// Biến tùy chọn:
//   TOKENS_JSON                  token dự phòng khi DB chưa có, dạng {"TOKEN":"Tên hiển thị"}
//
// Nguyên tắc: không có token nào được viết cứng trong mã; mọi hành động đều phải xác thực;
// token không bao giờ được trả về cho người không phải Admin.

import { createHash, timingSafeEqual } from 'node:crypto';

const OFFICER_TABLES = [
  { tbl: 'officers',                 scope: 'bch',       role: 'staff' },
  { tbl: 'tt_btv_officers',          scope: 'ttbtv',     role: 'staff' },
  { tbl: 'province_officers',        scope: 'province',  role: 'staff' },
  { tbl: 'office_officers',          scope: 'office',    role: 'staff' },
  { tbl: 'action_100_days_officers', scope: 'action100', role: 'department' }
];
const WORKSPACES = new Set(['office', 'bch', 'ttbtv', 'province', 'action100', 'vpub', 'mttq']);

// ---------- tiện ích ----------
function send(res, status, body) { return res.status(status).json(body); }

function safeEqual(a, b) {
  const ha = createHash('sha256').update(String(a)).digest();
  const hb = createHash('sha256').update(String(b)).digest();
  return timingSafeEqual(ha, hb);
}

function getConfig() {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return { url, key };
}

function sbHeaders(key, extra) {
  return { apikey: key, Authorization: `Bearer ${key}`, ...(extra || {}) };
}

function isAdminToken(t) {
  const adm = process.env.ADMIN_TOKEN;
  return !!adm && adm.length >= 16 && safeEqual(t, adm);
}

// ---------- chống dò token (best-effort: bộ nhớ của từng instance serverless) ----------
const FAILS = new Map();
const WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILS = 10;
function clientIp(req) {
  const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xf || req.socket?.remoteAddress || 'unknown';
}
function isBlocked(ip) {
  const rec = FAILS.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.first > WINDOW_MS) { FAILS.delete(ip); return false; }
  return rec.count >= MAX_FAILS;
}
function noteFail(ip) {
  const now = Date.now();
  const rec = FAILS.get(ip);
  if (!rec || now - rec.first > WINDOW_MS) FAILS.set(ip, { first: now, count: 1 });
  else rec.count += 1;
  if (FAILS.size > 5000) FAILS.clear();
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- tra cứu token ----------
async function queryOfficer(cfg, table, token) {
  try {
    const select = table === 'office_officers' ? 'id,name,token,title' : 'id,name,token,title,unit';
    const r = await fetch(
      `${cfg.url}/rest/v1/${table}?select=${select}&token=eq.${encodeURIComponent(token)}&limit=1`,
      { headers: sbHeaders(cfg.key) }
    );
    if (!r.ok) return null;
    const arr = await r.json();
    const row = Array.isArray(arr) ? arr[0] : null;
    if (row && safeEqual(String(row.token || '').trim(), token)) return row;
  } catch { /* bỏ qua */ }
  return null;
}

function tryEnvTokens(token) {
  try {
    const raw = process.env.TOKENS_JSON || '';
    if (!raw) return null;
    const map = JSON.parse(raw);
    if (!map || typeof map !== 'object' || !Object.prototype.hasOwnProperty.call(map, token)) return null;
    const name = String(map[token]).trim();
    const isNGN = name === 'Nguyễn Giang Nam';
    if (name === 'CV nhập liệu') return { id: 'data-entry-cv', name, role: 'staff', scope: 'data_entry', isNGN };
    if (name === 'VPUB') return { id: 'department-vpub-maua', name, role: 'department', scope: 'vpub', isNGN };
    if (token.startsWith('CQ-')) return { id: 'department-' + token.slice(8).toLowerCase(), name, role: 'department', scope: 'action100', isNGN };
    return { id: 'env-' + token.slice(-10), name, role: 'staff', scope: 'office', isNGN };
  } catch { return null; }
}

function buildUser(row, scope, token) {
  const name = String(row.name || '').trim();
  const title = String(row.title || '').trim();
  const unit = String(row.unit || '').trim();
  const isNGN = name === 'Nguyễn Giang Nam';
  if (name === 'CV nhập liệu') return { id: `cv-${row.id}`, name, role: 'staff', scope: 'data_entry', title, unit, isNGN };
  if (token.startsWith('CQ-')) {
    return { id: `department-${row.id}`, name, role: 'department', scope: name === 'VPUB' ? 'vpub' : 'action100', title, unit, isNGN };
  }
  const bchTier = scope === 'bch'
    ? (['Hà Đức Anh', 'Phạm Xuân Sơn', 'Chu Chính Sơn'].includes(name) ? 'full' : 'broad')
    : undefined;
  return { id: `${scope}-${row.id}`, name, role: 'staff', scope, title, unit, isNGN, ...(bchTier ? { bchTier } : {}) };
}

async function getOverrideForToken(cfg, token) {
  try {
    const r = await fetch(`${cfg.url}/rest/v1/role_overrides?select=perms&token=eq.${encodeURIComponent(token)}&limit=1`, { headers: sbHeaders(cfg.key) });
    if (!r.ok) return null;
    const arr = await r.json();
    const row = Array.isArray(arr) ? arr[0] : null;
    return row && row.perms && typeof row.perms === 'object' ? row.perms : null;
  } catch { return null; }
}

function attachPerms(user, perms) {
  if (perms && Object.keys(perms).length) {
    user._perms = perms;
    const extra = Object.keys(perms).filter((ws) => { const p = perms[ws]; return p && (p.v || p.a || p.e || p.d); });
    if (extra.length) user._extraScopes = extra;
  }
  return user;
}

async function resolveUser(cfg, token) {
  if (isAdminToken(token)) return { id: 'admin', name: 'Quản trị hệ thống', role: 'admin', scope: 'all' };
  if (cfg) {
    for (const { tbl, scope } of OFFICER_TABLES) {
      const row = await queryOfficer(cfg, tbl, token);
      if (row) return attachPerms(buildUser(row, scope, token), await getOverrideForToken(cfg, token));
    }
  }
  const envUser = tryEnvTokens(token);
  if (envUser) return attachPerms(envUser, cfg ? await getOverrideForToken(cfg, token) : null);
  return null;
}

// ---------- role_overrides ----------
function sanitizeOverrides(input) {
  const out = {};
  if (!input || typeof input !== 'object' || Array.isArray(input)) return out;
  for (const [tok, perms] of Object.entries(input)) {
    if (typeof tok !== 'string' || !tok || tok.length > 100 || !perms || typeof perms !== 'object') continue;
    const clean = {};
    for (const [ws, p] of Object.entries(perms)) {
      if (!WORKSPACES.has(ws) || !p || typeof p !== 'object') continue;
      const o = {};
      for (const k of ['v', 'a', 'e', 'd']) if (typeof p[k] === 'boolean') o[k] = p[k];
      if (Object.keys(o).length) clean[ws] = o;
    }
    if (Object.keys(clean).length) out[tok] = clean;
  }
  return out;
}

async function listOverrides(cfg) {
  const r = await fetch(`${cfg.url}/rest/v1/role_overrides?select=token,perms`, { headers: sbHeaders(cfg.key) });
  if (!r.ok) return null;
  const arr = await r.json();
  if (!Array.isArray(arr)) return null;
  const map = {};
  arr.forEach((row) => { if (row.token && row.perms && typeof row.perms === 'object') map[row.token] = row.perms; });
  return map;
}

async function replaceOverrides(cfg, overrides, adminLabel) {
  const existing = (await listOverrides(cfg)) || {};
  const toDelete = Object.keys(existing).filter((k) => !(k in overrides));
  for (const tok of toDelete) {
    await fetch(`${cfg.url}/rest/v1/role_overrides?token=eq.${encodeURIComponent(tok)}`, { method: 'DELETE', headers: sbHeaders(cfg.key) });
  }
  const rows = Object.entries(overrides).map(([token, perms]) => ({ token, perms, updated_by: adminLabel, updated_at: new Date().toISOString() }));
  if (rows.length) {
    const r = await fetch(`${cfg.url}/rest/v1/role_overrides?on_conflict=token`, {
      method: 'POST',
      headers: sbHeaders(cfg.key, { 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(rows)
    });
    if (!r.ok) return { ok: false, error: (await r.text()) || r.statusText };
  }
  return { ok: true, saved: rows.length, deleted: toDelete.length };
}

// Danh sách token cho màn Set role — CHỈ Admin
async function listAllTokens(cfg) {
  const out = [];
  for (const { tbl, scope, role } of OFFICER_TABLES) {
    const select = tbl === 'office_officers' ? 'id,name,token,title' : 'id,name,token,title,unit';
    const r = await fetch(`${cfg.url}/rest/v1/${tbl}?select=${select}&order=name`, { headers: sbHeaders(cfg.key) });
    if (!r.ok) continue;
    const arr = await r.json();
    if (!Array.isArray(arr)) continue;
    for (const o of arr) {
      const tok = String(o.token || '').trim();
      if (!tok) continue;
      let rRole = role, rScope = scope;
      const name = String(o.name || '').trim();
      if (tok.startsWith('CQ-')) { rRole = 'department'; rScope = name === 'VPUB' ? 'vpub' : 'action100'; }
      if (name === 'CV nhập liệu') { rRole = 'staff'; rScope = 'data_entry'; }
      out.push({ token: tok, name, role: rRole, scope: rScope, src: tbl, title: String(o.title || '').trim(), unit: String(o.unit || '').trim() });
    }
  }
  return out;
}

// ---------- handler ----------
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' });
  try {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const action = String(body.action || '');
    const token = String(body.token || '').trim();
    const ip = clientIp(req);

    if (!['login', 'get_role_overrides', 'save_role_overrides', 'list_tokens', 'verify_admin'].includes(action)) {
      return send(res, 400, { error: 'Invalid action' });
    }
    if (!token || token.length > 200) return send(res, 400, { error: 'Missing token' });
    if (isBlocked(ip)) return send(res, 429, { error: 'Thử sai quá nhiều lần. Vui lòng chờ 15 phút.' });

    const cfg = getConfig();
    if (!cfg && !isAdminToken(token) && !process.env.TOKENS_JSON) {
      return send(res, 500, { error: 'Máy chủ chưa cấu hình SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY.' });
    }

    const user = await resolveUser(cfg, token);
    if (!user) {
      noteFail(ip);
      await sleep(400);
      return send(res, 401, { error: 'Token không hợp lệ hoặc chưa được cấp quyền.' });
    }

    if (action === 'login') return send(res, 200, user);

    if (action === 'verify_admin') {
      return user.role === 'admin' ? send(res, 200, { ok: true }) : send(res, 403, { error: 'Chỉ Admin.' });
    }

    if (!cfg) return send(res, 500, { error: 'Missing Supabase config' });

    if (action === 'get_role_overrides') {
      const all = await listOverrides(cfg);
      if (all === null) return send(res, 200, { overrides: {}, error: 'role_overrides table missing - run SQL to create' });
      if (user.role === 'admin') return send(res, 200, { overrides: all });
      return send(res, 200, { overrides: all[token] ? { [token]: all[token] } : {} });
    }

    // Từ đây trở xuống chỉ Admin
    if (user.role !== 'admin') return send(res, 403, { error: 'Chỉ Admin được thực hiện thao tác này.' });

    if (action === 'list_tokens') return send(res, 200, { tokens: await listAllTokens(cfg) });

    if (action === 'save_role_overrides') {
      const clean = sanitizeOverrides(body.overrides);
      const result = await replaceOverrides(cfg, clean, 'admin');
      if (!result.ok) return send(res, 500, { error: result.error || 'save failed' });
      return send(res, 200, result);
    }
    return send(res, 400, { error: 'Invalid action' });
  } catch (e) {
    console.error('api/admin error:', e);
    return send(res, 500, { error: 'Internal error' });
  }
}
