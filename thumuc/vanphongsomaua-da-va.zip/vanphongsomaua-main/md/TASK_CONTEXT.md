# TASK CONTEXT — Phiên làm việc mới

## Mục tiêu chính
Dự án web frontend thuần HTML/CSS/JS (không `package.json`), dùng Supabase REST:
- Quản lý nhiệm vụ nhiều workspace: Văn phòng, BCH, TT/BTV, Tỉnh giao, KH hành động 100 ngày, VPUB.
- Có hệ thống đăng nhập bằng token, phân quyền theo role (admin/staff/department) + workspace theo scope.
- File chính: `index.html`, `js/legacy.js`, `js/email.js`, `js/config.js`, `css/style.css`.
- Yêu cầu gần nhất: thêm bộ lọc nhanh ở Trang chủ + siết quyền xem data Văn phòng.

## Các thay đổi đã hoàn thành (phiên vừa rồi)

### 1. Sửa lỗi "token is not define" khi Admin sửa nhiệm vụ Văn phòng
- `js/legacy.js`: xóa 5 dòng thừa (logic đăng nhập `CQ-MAUA-***`) dán nhầm vào hàm `renderAgencyTotalsChart()`. Lỗi từng làm gãy chuỗi render khi lưu nhiệm vụ.

### 2. Sửa lỗi "lưu thành công nhưng không vào Supabase" (nhiệm vụ sheet không có office_tasks)
- `js/legacy.js` `saveEditTask()`: khi PATCH trả về mảng rỗng (không có bản ghi office_tasks khớp), tự INSERT mới vào `office_tasks` để thay đổi thực sự được lưu.

### 3. Đổi thứ tự cột Nhiệm vụ ngay sau cột STT toàn bộ bảng
- `index.html` + `js/legacy.js`: áp dụng cho bảng chính + popup drill của Văn phòng, home drill, stats drill, BCH, TT/BTV, Tỉnh giao, KH100/VPUB (`showDrill`/`renderBCHTable`/`renderTTBTVTable`/`renderPROVTable`/`renderAction100Table`) + export CSV.

### 4. Tính năng Sao lưu/Khôi phục dữ liệu (chỉ Admin)
- `index.html`: mục menu "🛡️ Sao lưu dữ liệu" (`backupSidebarItem`) + modal `backupModal`.
- `js/legacy.js`: `openBackupModal`, `closeBackupModal`, `backupData`, `restoreBackup`, hằng `BACKUP_TABLES` (12 bảng). Export JSON, restore upsert theo `on_conflict=id`.
- Khôi phục yêu cầu đúng password (mật khẩu cũ đã bãi bỏ) (dùng `prompt` rồi `confirm`).
- `css/style.css`: thêm `.backup-dialog`, `.backup-body`, `.backup-status`.

### 5. Siết quyền xem data Văn phòng
- Chỉ **Admin**, `CQ-MAUA-***` (data_entry), và **token Văn phòng** (staff·office) được xem workspace Văn phòng.
- `js/legacy.js` thêm `canAccessOfficeData(user)`. Áp dụng vào:
  - `syncUserWorkspaceVisibility` (ẩn menu), `openOfficeWorkspace` (chặn mở).
  - `getAllHomeTasks`, `renderCharts`, `renderAgencyTotalsChart`, `updateGlobalHonors`, `openHonorBestTasks`, `openHomeTaskDrill`, `handleChartDrill`(chart1), `handleOfficeChartDrill`, `drillTask`, `openCurrentUserTasks`.

### 6. Bộ lọc nhanh Trang chủ (mới nhất)
- `index.html`: thanh `#home-filter-bar` (Cơ quan · Cán bộ · Trạng thái + Đặt lại) dưới chartBar.
- `js/legacy.js` thêm: `HOME_FILTER`, `homeAgencyMatch`, `homeStatusOf`, `homeRowPass`, `homeFilterSource`, `homeFilteredTasks`, `refreshHomeFilterOwnerOptions`, `applyHomeFilter`, `resetHomeFilter`, `renderHomeDashboard`.
- Bộ lọc điều khiển toàn bộ KPI + biểu đồ Trang chủ, chỉ lọc dữ liệu hiện có; ẩn option "Văn phòng" cho token không được phép.

### 7. Tài liệu
- Tạo `token_role.txt` (markdown) liệt kê toàn bộ token + role + quyền, Unicode.
- Tạo `CONTEXT.md` đã có sẵn từ trước.

## Vấn đề/bug còn tồn đọng
- **Không có lỗi code đang chặn.** `node --check js/legacy.js` pass.
- Lưu ý thiết kế: công cụ khôi phục (restore) hiện chưa tự reset sequence của các cột id sau khi chèn lại id gốc từ backup (rủi ro trùng id khi thêm mới trong trường hợp hiếm). Chưa xử lý để tránh thêm rủi ro qua anon key.
- `renderAgencyTotalsChart`, `renderCharts`, `handleChartDrill` ... đã được sửa đổi nhiều lần — nên test lại giao diện Trang chủ trên trình duyệt (admin + 1 token BCH + 1 token department) để chắc không lệch.
- Luôn chạy `node --check js/*.js` sau khi sửa. Dự án không có `package.json` nên không có lint/build thật.

## Bước tiếp theo khi mở phiên mới
1. **Kiểm tra thực tế trên trình duyệt** bộ lọc Trang chủ & quyền Văn phòng với các token: Admin, staff·office, `CQ-MAUA-***`, một token BCH, một token department (`CQ-MAUA-*`).
2. Xác nhận biểu đồ Top-10 & biểu đồ tổng (chartBar) hiển thị đúng theo từng quyền/bộ lọc.
3. Kiểm tra luồng Sao lưu → tải JSON → Khôi phục bằng đúng password; xác nhận không hỏng 12 bảng.
4. Nếu có yêu cầu tiếp theo (thắt quyền VPUB chỉ `CQ-VPUB-MAUA`/Admin, cấp quyền riêng cho lãnh đạo, v.v.) — hiện đề bài chỉ ghi chú "tính sau".

## Phiên mới: Cân đối bảng nhiệm vụ + click/hover nhiệm vụ (đang hoàn thiện)

### 1. Cân đối bố cục bảng, ưu tiên cột Nhiệm vụ, bỏ giới hạn dòng
- Nguyên nhân: sau khi đổi thứ tự cột "Nhiệm vụ" lên ngay sau STT, các rule CSS `nth-child` gán bề rộng cột vẫn theo thứ tự cũ → cột Nhiệm vụ bị bóp hẹp.
- `js/legacy.js`:
  - `showDrill()`: thêm class `office-drill-table` cho bảng `#drillModal` (phân biệt popup nhiệm vụ Văn phòng).
  - `openActivityLog()`: xóa class `office-drill-table` khi mở Nhật ký (vì `#drillModal` dùng chung).
- `css/style.css` (thêm block cuối file, `!important` để thắng rule cũ):
  - Popup Văn phòng (11 cột): Nhiệm vụ col2 = 400px, các cột khác thu gọn; vẫn cuộn ngang khi cần.
  - Popup Trang chủ/Chỉ số (8 cột): Nhiệm vụ col2 = 400px, bỏ chặn `max-width:120px`.
  - Popup BCH/TT-BTV/Tỉnh (9 cột, `.bch-drill-table`): Nhiệm vụ col2 = 30%; cột Thao tác (col9) đang ~10%, đã thêm margin cho nút tránh chồng.
  - Workspace BCH/TT-BTV/Tỉnh (`.bch-table`): đồng nhất `.c-task` = 34%/min 340px (sửa Tỉnh giao đang 26%).
  - Bỏ `-webkit-line-clamp` cho `.bch-task-text`/`.bch-product-text` → nội dung dài hiện đầy đủ, tự xuống dòng.
  - KH 100 ngày/VPUB: cột Nhiệm vụ in đậm, đảm bảo wrap.

### 2. Popup Văn phòng: click mở Cập nhật + hover xem nội dung dài
- `js/legacy.js` `renderOfficeDrillRows()`:
  - **Click vào dòng nhiệm vụ**: nếu `canEditTask(x)` → `openEditTask(DATA.indexOf(x))` (mở popup Cập nhật nhiệm vụ); nếu chỉ xem → fallback `openHomeTaskDrill('office', id)` (mở popup xem chi tiết).
  - Gói tên nhiệm vụ trong `<div class="task-tip" data-full="...">`.
  - Bọc dựng bảng trong `try/catch` để popup luôn mở kể cả khi lỗi dữ liệu (hiện thông báo thay thế).
  - Thêm handler delegation tooltip: hover `.task-tip` → nếu nội dung dài (>= 40 ký tự) hiện popup nổi `.task-tip-popup` chứa nội dung đầy đủ, định vị sát ô, tự ẩn khi rời/cuộn.
  - Expose `window.drillOfficeKPI`, `window.openOfficeWorkspace` cạnh `window.DATA` để handler inline chắc chắn resolve.
- `css/style.css`: thêm `.task-tip-popup` (tooltip nổi tối màu, bo góc, shadow, fade in/out).

### Lưu ý khi tiếp tục
- Đã kiểm tra `node --check js/legacy.js`, `js/email.js` pass; CSS cân bằng ngoặc.
- Chưa kiểm tra trực quan trên trình duyệt: bảng các workspace+các popup (Admin + 1 token BCH), click/hover nhiệm vụ Văn phòng, popup Nhật ký không vỡ.
- Bề rộng cột Thao tác popup BCH đang 10% (vừa thu lại theo yêu cầu) — cần xác nhận nút không chồng.

## Phiên 28/08/2026: Siết quyền KH100 + lọc BCH/Tỉnh giao (hiện tại)

### 1. KH 100 ngày siết scope sửa + cột Thao tác
- `js/legacy.js:6481` `canEditAction100Task` chỉ cho `scope: action100` nếu `commune_leader`/`unit_name` (VPUB `unit`/`field`) khớp không dấu với `CURRENT_USER.name` (chuẩn hoá NFD, bỏ `CB`/`CQ`, `includes` 2 chiều). VD `Công an xã`/`Cong an` đều khớp `Công an`.
- `js/legacy.js:6375` `renderAction100Table` chỉ hiện nút `Sửa` khi `canEditAction100Task`.
- Token `CQ-MAUA-***` `Ban XDD`→`Ban Xây dựng Đảng` (`js/legacy.js:22`), `CQ-MAUA-***` chuẩn hoá `UBND xã`, thêm `CQ-MAUA-***`=`UBND`.

### 2. Bộ lọc
- KH100: `index.html:1102` thêm `#action100Agency` (distinct `commune_leader`/`unit_name`), `js/legacy.js:6348` `populateAction100AgencyFilter` + lọc không dấu `renderAction100Table:6355` + `reset/load`.
- BCH: `index.html:1202` thêm `#bchOfficerNameFilter` text lọc `bchFold` `officer_name`, `js/legacy.js:3132` `applyBCHFilters` + `resetBCHFilters:3852` + `renderBCHCharts:3200`.

### 3. Tỉnh giao mở cho scope100 + hạn chế PCM
- Mở `openPROVWorkspace:5999` cho `department` `scope action100` để test; thêm `UBND`/`UBND xã` đều khớp.
- `js/legacy.js:7118` thêm `ppNorm`, `ppScope100CanEditTask`, `ppCanEditProvinceTask`, `ppScope100CanEditAgency` (khớp cơ quan chính/phối hợp không dấu).
- `js/legacy.js:7154` `ppSyncTaskRoleUI` chỉ hiện `Lưu`/`Sửa` (ẩn `Xóa`) cho `isLimited`, per-agency `+LĐ PCM` chỉ khi `ppScope100CanEditAgency`; khi mở rộng chỉ cho sửa 5 trường `Tên`/`ngày HT`/`sản phẩm`/`tiến độ`/`lý do` trong `.pp-person` (khoá `deadline`, `agencyOther`, `nhiemvu`, `mota`, docs).
- `js/legacy.js:7114` `ppEditTask`, `6771` `ppAddPCM`/`ppTogglePCMList`, `7480` `ppSaveOne`, `6811` `ppDeleteTask` (về admin) tôn trọng quyền hạn chế.
- `js/legacy.js:7165` `ppSyncAllProvinceRoleUI` không blanket `readOnly` cho `scope100`.

### 4. Kiểm tra
- `node --check js/legacy.js` + `git diff --check` pass mỗi bước; `CHANGES.md` giữ 10 dòng mới nhất.

### 5. Trang chủ thu nhỏ + Top cơ quan KH100/VPUB (28/08 tiếp)
- `index.html:407` `home-bottom-grid 1.6fr/1fr/1fr`, bar 430→260px `horizontal bar` (`indexAxis y`), thêm 2 biểu đồ `line` (Tỷ lệ) + `polarArea` (Top cơ quan); `css/style.css:4315` + `js/legacy.js:1484` `renderAgencyTotalsChart` thêm `chartStatusDonut`/`chartAgencyDonut`.
- `js/legacy.js:6312` thêm `KH100_TASKS_CACHE`/`VPUB_TASKS_CACHE`; `js/legacy.js:6340` `loadAction100Data` lưu cache; `js/legacy.js:1488` bg fetch nếu trống; `js/legacy.js:1283` `getAllHomeTasks` + `1314` `homeFilterSource` + `1373` `homeSource`/`homeSourceKey`/`homeStatus` + `1327` `homeFilteredTasks` + `1409` `openHomeTaskDrill` hỗ trợ `KH100`/`VPUB`; `index.html:419` `homeFilterAgency` thêm option `KH100`/`VPUB`; Top cơ quan `polarArea` 6 cột (Văn phòng/BCH/BTV/Tỉnh/KH100/VPUB).

### 6. BCH drill popup lọc (28/08 tiếp)
- `index.html:752` thêm `bchDrillOfficerFilter` (search) + `bchDrillOfficerSelect` (dropdown) + `bchDrillStatusFilter` (processing/done/overdue); `js/legacy.js:3333` `onBCHDrillFilterChange` kết hợp `bchFold` + `bchStatusGroup`; `js/legacy.js:3449` `renderBCHDrill` populate distinct + clear khi mở.

### 7. Fix Đ/đ + per-agency (28/08)
- `js/legacy.js:7137` `ppNorm` Đ→D, `ppInitials`/`ppTokenInit` cho `VPDU`↔`Văn phòng Đảng ủy`/`VPĐU` (probe 14 agencies/19 tokens, `VPDU`/`HĐND` hết lỗi); `js/legacy.js:6506` `canEditAction100Task` + `6373` agency filter Đ; `js/legacy.js:7154` per-agency `Trạm Y tế` chỉ sửa ag khớp.

### 8. Trang chủ hero + header gọn (28/08)
- `index.html:167` `hero-banner hero-split` glass-card trái (`heroTotal/Done/Doing/Late` `drillKPI`) + `hero-topbar` phải dọc (`syncDot/syncText` + `header-actions`); `css/style.css:8029` kính mờ Sapa `hero-title/subtitle/ribbon/qick-stats`.
- `js/legacy.js:1964` `render()` cập nhật hero stats; `js/legacy.js:363/459` `logoutUser`/`setLoggedInUser` giữ `logoutBtn` (ẩn/hiện theo auth) để đổi token.
- Header rút gọn: xóa `In / Xuất PDF`, `Xuất CSV`, `Đăng xuất (đổi token)` chỉ giữ `🔄 Cập nhật ngay` + `↩ Đăng xuất`; `node --check` pass.

### 9. Logo tròn + KPI + perf (28/08)
- `index.html:54` logo 78px tròn `50%` viền vàng `2.5px #d4a84b` `scale(1.18)` `hardRefreshHome` soft (bỏ `reload` tránh nháy `authGate`); favicon/logo bỏ base64 → URL giảm 772KB→118KB.
- `js/legacy.js:2468` `drillKPI` bỏ chặn `department/data_entry` → `Tổng/ Hoàn thành` hiện `statsDrillModal`; `js/legacy.js:6127` `hardRefreshHome` đóng workspace + `scrollTo` + `render()` không reload; Chart giữ `sync`.

### 10. Cảnh báo + Sắp đến hạn + Nhật ký (28/08)
- Nút `🔔 Sắp đến hạn (x)` (`notifBtn`) hiện với mọi token, mở `openDailyWarnModal` (popup `Nhiệm vụ sắp đến hạn`) lọc theo `Phụ trách`; `getSoonTasksForCurrentUser:1491` + `isOwnedByToken:6688` khớp `owner/officer_name` theo `scope` (a100 `canEditAction100Task`/`commune_leader`, vpub `unit/field/leader`), `updateNotifCount:1537` async `refreshDailyWarnTasks` → `DAILY_SOON_TASKS.length`.
- `refreshDailyWarnTasks:6648` `soonEnd +7`; mục `⚠️ Cảnh báo` (`warnSidebarItem`) chỉ admin + staff·office (`setLoggedInUser:371` + `logoutUser` ẩn); non-admin ẩn cột Email + nút Gửi; popup 944px, Hạn `dd-mm-yyyy`.
- Nhật ký: `openActivityLog:138` `activity-log-mode`/`activity-log-table`, `showDrill` gỡ class; `css/style.css:8042` grid 1104px + filter 3 cột + fixed (56/12/12/14/50/84%), ghi chú `line-clamp:5`, badge thao tác `data-full` tooltip `.task-tip-popup`.

## Lưu ý quy trình
- Không commit/push/branch nếu chưa được yêu cầu.
- Sửa ít file nhất, giữ API/bố cục hiện có.
- Trả lời tiếng Việt, ngắn gọn.

## Phiên 04/09/2026: Vinh danh + Tỉnh giao theo cây + quyền token + BCH/TTBTV/VP (đã xong)
- Vinh danh: cá nhân VP theo tháng, BCH theo NV hoàn thành quý (`updateGlobalHonors`, `openHonorBestTasks`, `openHonorLeaderTasks`, `index.html` nhãn).
- SW `vps-maua-v1` treo F5: `sw.js` killer + gỡ dự phòng (`legacy.js` đầu file); chống cache `?v=20260906` (`index.html`, `js/main.js`).
- Tỉnh giao: bảng cũ/KPI/biểu đồ/drill/lọc theo cây (`getPROVTreeRows`, `applyPROVFilters`, `renderPROVTable`, `renderPROVCharts`, `drillPROVChart`, `buildPROVPerfPersons`, `provinceBadgeStatus`); bỏ form Thêm popup; sort ngày tạo; ẩn nút Xuất/Xác nhận lưu.
- Cây Tỉnh giao: `ppPersonStrictStatus` chốt theo ngày, gom bỏ dòng trống, lưới 2 hàng + head sticky, `type=date` + `ppDateInputVal`/`ppDispDate`, Enter chuyển ô, badge `x/y`, textarea 80px, nút chàm + toggle Nhiệm vụ chính, bỏ viền khung.
- Quyền cây: `ppMatchAgencyByToken` (alias VPUB), scope `vpub`, viền `#6ee7b7`, chỉ Admin thêm/xóa dòng VB (`ppAddDoc`/`ppRemoveDoc` + nút ×).
- Backup 14 bảng: phân trang, bỏ qua lỗi, restore `id=not.is.null`; `api/admin.js` bỏ `bch_officers`.
- Trang chủ: nhãn VP Đảng ủy/VP HĐND&UBND, gom `undefined`; BCH Kết quả=Sản phẩm + cột 27%/12%; TT/BTV Nguồn giao bắt buộc + sửa Nguồn/Lãnh đạo của mình + tùy chọn Khác; VP lọc theo ngày tạo.
- Kiểm tra: `node --check` + `git diff --check` pass mỗi bước; commit theo nhóm (10 commit `bf60ab8`→`5c63e68`).
- Còn tồn: chưa kiểm tra trực quan trên trình duyệt (cây date-picker, badge, dialog Khác, popup drill); file đính kèm Storage chưa vào backup (chỉ metadata).
