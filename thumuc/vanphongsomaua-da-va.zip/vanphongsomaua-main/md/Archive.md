# Archive - Lịch sử chi tiết dự án (không gửi cho AI mỗi lần chat)

> File này chỉ để lưu trữ. Khi cần debug task cũ mới @file này. Đừng để opencode đọc tự động.

## Đã hoàn thành (tóm tắt)

- Sửa lỗi gửi email do không tìm thấy data -> lấy từ `window.DATA`.
- Chỉ hiển thị nút gửi email cho nhiệm vụ quá hạn/sắp hạn.
- Thêm nhật ký hoạt động, chỉ Admin xem, có nút Xóa (xác nhận bằng token Admin), ghi vết cả thao tác xóa.
- Popup nhật ký: STT, thao tác, tài khoản, ngày hoàn thành, ghi chú. Đã bỏ bộ lọc chung gây xung đột.
- Popup gia hạn: có trường lý do, ghi chú Admin mẫu `Thêm lý do gia hạn từ [Hạn cũ] - [Hạn mới]: [Lý do]`.
- Giữ bố cục cũ, thêm cuộn ngang, thu gọn cột ngày/tài khoản.

## Sửa xóa tệp popup Tỉnh giao
- `deletePROVAttachment` cho phép xóa cả bản ghi chỉ có `attachment_name`.
- Không gọi Storage khi không có `attachment_path`; lỗi `Object not found` được bỏ qua.
- Vẫn xóa metadata tên file trong `province_tasks`.

## Sửa hiển thị tệp Tỉnh giao / BCH
- Popup `Cập nhật nhiệm vụ Tỉnh giao` hiển thị tên file từ `attachment_name` không phụ thuộc file gốc.
- Tài khoản thường thấy tên file và trạng thái; chỉ Admin thấy nút xem, phê duyệt, xóa.
- Popup `Cập nhật nhiệm vụ BCH` tương tự: thường thấy tên + trạng thái duyệt; Admin thấy nút duyệt/xóa.
- Quyền cập nhật ghi chú/file BCH không giới hạn theo workspace, chỉ đối chiếu tên người phụ trách.
- Đã kiểm tra `node --check` và `git diff --check`.

## Cập nhật giao diện bảng nhiệm vụ
- Popup `Nhiệm vụ Văn phòng Đảng ủy` khôi phục đủ nhãn cột.
- Đồng bộ kích thước popup Văn phòng với `Tổng nhiệm vụ` Trang chủ, max 1500px, có cuộn ngang.
- Cột `Nhiệm vụ` min 420px, `Cán bộ` 120px, `Trạng thái` 180px, `STT` 50px, `Thao tác` 110px.
- Nội dung dài tự xuống dòng.

## Cập nhật nhập liệu và token
- Thêm token `CQ-MAUA-***` cho `CV nhập liệu`, được nhập liệu các workspace trừ Văn phòng.
- Bị chặn Văn phòng; các thao tác đăng nhập/thêm được ghi vào `activity_logs`.
- Chỉ được thêm mới, không sửa/xóa.
- Thêm nút `+ Thêm nhiệm vụ` riêng góc phải BCH, BTV, Tỉnh giao, chỉ hiện với `CQ-MAUA-***`.
- Sửa lưu mới BCH, BTV, Tỉnh giao cho `CQ-MAUA-***`; trường `Lãnh đạo phụ trách` là ô text tự nhập.

## Sửa upload popup BCH
- Popup `Cập nhật nhiệm vụ BCH` không upload file gốc; khi chọn file sẽ lưu `attachment_name`, loại, kích thước.
- Trạng thái BCH khi lưu file mới nhận cả `attachment_path` và `attachment_name`.

## Kiểm tra và sửa logic lần cuối
- Bộ lọc `Có tệp` của Văn phòng, BCH, BTV, Tỉnh nhận cả `attachment_path` và `attachment_name`.
- Xóa tệp BCH, BTV, Tỉnh không gọi Storage khi không có file gốc.
- Lỗi Storage `Object not found` xem như file đã không còn.

## Cập nhật phiên làm việc gần nhất
- Nút `Gui TB` chỉ hiện và chỉ thực thi với Admin.
- Tất cả form gửi file không upload file gốc; chỉ lưu tên file vào `attachment_name`.
- Giao diện hiện tên file và nhãn `Chỉ lưu tên file`, không hiện nút xem/tải nếu thiếu `attachment_path`.
- Nút `Phê duyệt tệp` của Văn phòng, BCH, BTV, Tỉnh hoạt động với bản ghi chỉ có `attachment_name`.

## KH HÀNH ĐỘNG 100 NGÀY - ĐÃ HOÀN THÀNH
- Menu và workspace riêng, kết nối 2 bảng: `action_100_days_officers`, `action_100_days_tasks`.
- Có KPI, tìm kiếm, lọc trạng thái, thêm nhiệm vụ, click dòng mở popup.
- Popup đủ trường: tên, lãnh đạo xã, lãnh đạo VP, chuyên viên, hạn, ngày hoàn thành, trạng thái, số ngày còn lại, sản phẩm, ghi chú cán bộ, ghi chú ADMIN.
- Người phụ trách có lựa chọn nhập tên tùy chọn.
- Đã tăng kích thước nút, KPI, bảng, popup; responsive mobile.

## Cập nhật lớn - Token cơ quan và bố cục workspace
- Thêm 8 token cơ quan chỉ truy cập KH 100 ngày: VPDU, UBNDXA, BANXDD, MTTQ, HDND, CBCONGAN, CBQUANSU, UBKT.
- Dùng `role: department`, `scope: action100`.
- Biểu đồ Hiệu suất Top 10 BCH, Tỉnh giao, TT/BTV tăng chiều cao desktop 330px, mobile 260px.
- Click vào cán bộ trên biểu đồ Top 10 mở popup drill-down danh sách nhiệm vụ.
- BCH, Tỉnh giao, TT/BTV dùng cuộn dọc toàn trang như Văn phòng, không khóa `.bch-shell`.

## Cập nhật VPUB và phân quyền token CQ-VPUB-MAUA
- Thêm workspace `Nhiệm vụ VPUB`, bảng `public.vpub_tasks`.
- Form thêm VPUB 12 trường: đơn vị, lĩnh vực, nội dung, nguồn giao, lãnh đạo phụ trách, ngày bắt đầu, thời hạn, kết quả tuần này, khó khăn, đề xuất, trạng thái, ghi chú.
- Đơn vị VPUB: KT, VH, CA, QS, HCC, DVTH, VP.
- Token `CQ-VPUB-MAUA` được xem BCH, TT/BTV, Tỉnh giao, KH 100 ngày; không xem Văn phòng.

## Cập nhật phiên: hover trang chủ + tuổi lục form Tỉnh giao
- Hover tên nhiệm vụ dài trong popup Trang chủ (`showHomeDrill`) và Chi số (`showStatsDrill`) hiện popup đầy đủ.
- Bỏ tooltip `title="Click để xem chi tiết nhiệm vụ"`.
- Popup tooltip `.task-tip-popup` tăng chữ ~10% (13.5px), gradient, viền trái xanh, bo góc, bóng đổ.

## Tươi lục trường thêm/sửa/chi tiết nhiệm vụ Tỉnh giao
- Form "Thêm nhiệm vụ Tỉnh giao" đổi thứ tự trường: Nhiệm vụ, Hình thức cụ thể hóa (`source_form`), Thẩm quyền ban hành (`issuing_authority`), Cơ quan tham mưu: Cơ quan (`unit_name`), Lãnh đạo UBND (`officer_name`), Lãnh đạo phòng chuyên môn (`role`), Chuyên viên (`specialist_name`), Hạn hoàn thành, Ngày hoàn thành, Thời gian còn lại (tự động), Tiến độ (`progress`), Trạng thái (tự động), Sản phẩm (`product`), Ghi chú (`staff_note`), Ghi chú Admin (`admin_note`).
- Bỏ trường cũ "Kết quả thực hiện"/"Tệp kết quả".
- Popup "Cập nhật" và "Chi tiết" đồng bộ đủ trường.

## Xác nhận thêm nhiệm vụ (Tỉnh, BCH, BTV)
- Thêm bước xác nhận trước khi ghi Supabase cho 3 workspace: khi bấm "Thêm nhiệm vụ" sẽ mở popup xác nhận `#addConfirmModal`.
- Hàm `openAddConfirm(scopeLabel, pending, rows)` dùng chung.
- Popup xác nhận luôn z-index 999999 để nằm trên cùng.

## Token đăng nhập cán bộ
- Định dạng: `CB-MAUA-[viết tắt]-[secret]`, mỗi token dài 15 ký tự.
- Ví dụ: CB-MAUA-***, CB-MAUA-***, VTK-8LM, VTL-2PD, LAM-6QZ, NTT-9HC, v.v.

## Phiên 04/09/2026 - Vinh danh + Tỉnh giao theo cây + TT/BTV + BCH + VP
- Vinh danh: cá nhân VP tính trong tháng (subtitle `Vinh danh trong tháng`); BCH tính NV hoàn thành nhiều nhất quý (`done>0`, popup chỉ NV hoàn thành).
- SW: `sw.js` killer xóa cache `vps-maua-*` + unregister (xóa file không gỡ SW cũ); gỡ dự phòng trong `legacy.js`; chống cache `?v=20260906`.
- Tỉnh giao hiển thị theo cây mới: bảng cũ/KPI/biểu đồ/drill/lọc ưu tiên `getPROVTreeRows`; bỏ form Thêm trong popup (nút + Thêm mở cây); Top10 + tròn Số NV tách từng người (`buildPROVPerfPersons`); sort ngày tạo mới nhất; cột Trạng thái gọn `Hoàn thành`.
- Cây Tỉnh giao: chốt trạng thái theo ngày (đủ 2 ngày → hoàn thành, nhãn `HT quá hạn` cam), gom bỏ dòng trống, nhãn thu gọn đủ đúng/trước hạn → `Hoàn thành`.
- Nhập liệu cây: lưới 2 hàng + head sticky, date-picker (tương thích cũ), Enter chuyển ô, badge `x/y`, textarea 80px, nút chàm + toggle Nhiệm vụ chính, bỏ viền khung giữ thanh trạng thái.
- Quyền cây: alias VPUB↔`Văn phòng HĐND & UBND`/`UBND xã` (scope `vpub` sửa 5 trường/agency khớp); viền xanh mục sửa được; chỉ Admin thêm/xóa dòng VB.
- Backup 14 bảng: phân trang (fix cắt 1000), bỏ qua bảng lỗi, restore `id=not.is.null`; xóa `bch_officers` khỏi `api/admin.js`.
- Trang chủ: nhãn `Văn phòng Đảng ủy`/`VP HĐND&UBND`; Tỷ lệ gom `undefined`.
- BCH: Kết quả = Sản phẩm; cột Nhiệm vụ 27%, Trạng thái 12%/140px.
- TT/BTV: Nguồn giao bắt buộc; token sửa Nguồn giao + Lãnh đạo của mình; Lãnh đạo có tùy chọn Khác.
- VP: lọc thời gian theo ngày tạo (fix lọc nhầm Hạn).
- Kiểm tra mỗi bước: `node --check js/legacy.js` + `git diff --check` pass (CSS chỉ `git diff --check`).

---
File gốc đầy đủ dòng 1-230 đã được rút gọn vào CONTEXT_GON.md để giảm từ ~100k token xuống ~2k token/request.
