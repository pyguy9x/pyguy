# Context dự án - Bản tối ưu cho Opencode + DeepSeek v4

## Cập nhật phiên 09/09/2026
- KPI MTTQ: workspace độc lập đang dùng 3 bảng mới `mttq_kpi_people`, `mttq_kpi_catalog`, `mttq_kpi_tasks`; không trộn vào các bảng nhiệm vụ cũ. SQL đã chạy.
- KPI MTTQ đã đồng bộ Excel: 10 cán bộ, 128 danh mục, 145 nhiệm vụ; 145/145 khóa `source_sheet + source_row` duy nhất, 4 nhiệm vụ thiếu hạn được giữ nguyên.
- KPI MTTQ: dữ liệu Unicode đã nạp lại đúng; `index.html` tải subset `vietnamese`, CSS dùng fallback `Segoe UI/system-ui`.
- KPI MTTQ: có drill-down từ từng dòng, thẻ sắp hạn 3/7 ngày và biểu đồ cột chồng theo cán bộ/trạng thái; không đổi schema 3 bảng.
- KPI MTTQ: biểu đồ cán bộ/trạng thái dùng cột ngang (`indexAxis: 'y'`) để đọc tên cán bộ dài dễ hơn.
- KPI MTTQ token: Admin dùng token hiện tại `<ADMIN_TOKEN>`; cán bộ dùng scope `mttq`, chỉ được sửa/xóa nhiệm vụ có tên mình và được thêm nhiệm vụ mới. Token được khai báo đồng bộ ở `js/legacy.js` và `api/admin.js`.
- `CQ-MAUA-***` có cờ `mttqAdmin`: toàn quyền trong workspace KPI MTTQ, không được nâng quyền sang các workspace khác.
- TT/BTV: nếu đã nhập `Ngày hoàn thành`, trạng thái tự động so sánh với Hạn hoàn thành; không tiếp tục báo Quá hạn chỉ vì chưa có sản phẩm/file.
- Tỉnh giao biểu đồ Thời hạn xử lý: nhóm `Sắp đến hạn trong 7 ngày` tính từ hôm nay đến +7 ngày; drill-down dùng cùng điều kiện; nhóm vẫn hiển thị khi bằng 0.
- Tỉnh giao biểu đồ `Theo tên lãnh đạo cơ quan`: biểu đồ số 2 lấy tên từ `.pp-leader-row [data-k=name]`, drill-down lọc đúng task; không dùng placeholder `Chưa rõ cơ quan chủ trì`. Biểu đồ số 4 giữ `Số nhiệm vụ` theo cơ quan.
- Tỉnh giao cây: nhiệm vụ phối hợp thu gọn hiển thị badge `Đang xử lý`/`Hoàn thành`/`Quá hạn` cạnh nút `Xóa nhiệm vụ`, cập nhật theo ngày và trạng thái person.
- Tỉnh giao Danh sách chi tiết: khi lọc `provinceOfficerFilter`, badge mở rộng tính theo đúng agency được lọc qua `provinceFilteredBadgeStatus`, không dùng trạng thái tổng task.
- Tỉnh giao ngày tháng: form cập nhật và các dòng person trong cây hiển thị/nhập `dd/mm/yyyy`; `dateToDb`/`ppDateDisplayVal` chuẩn hóa khi lưu, dữ liệu cũ ISO vẫn tương thích.
- TT/BTV: `ttbtv-status-summary` chỉ hiển thị trạng thái có số lượng lớn hơn 0.
- TT/BTV: chỉ Admin được sửa `Nguồn giao` và `Nguồn giao của UBND`.
- Sidebar: User và Sắp đến hạn nằm dưới logo; User hiển thị họ tên và chức vụ thành 2 dòng.
- VPUB: Cơ quan phụ trách, Cơ quan phối hợp và Lãnh đạo cơ quan phụ trách dùng dropdown; mục Khác của lãnh đạo yêu cầu nhập tên lãnh đạo.
- VPUB: ngày tháng nhập `dd/mm/yyyy`, lưu về `yyyy-mm-dd`; cột Cơ quan phối hợp khớp trường `field`, lãnh đạo khớp `leader`.
- Phân quyền: token `CQ-MAUA-***` được phép xóa nhiệm vụ trong workspace VPUB.
- `js/config.js` là cấu hình riêng, không đồng bộ/ghi đè khi cập nhật sang bản sao dự án.

## Kiến trúc
- Web frontend thuần HTML/CSS/JS, không có `package.json`.
- `index.html`: giao diện chính, sidebar, popup chi tiết, popup gia hạn, nhật ký.
- `mobile/index.html` + `mobile/app.js`: bản di động `/mobile` (gate token, drawer toggle, xem/sửa full BCH/TTBTV/Tỉnh/KH100/VPUB, dùng chung `/api/admin` + Supabase REST).
- `js/legacy.js`: logic chính - nhiệm vụ, popup, file (chỉ lưu tên), gia hạn, nhật ký, KPI, biểu đồ Top 10.
- `js/email.js`: kiểm tra điều kiện gửi email (quá hạn / hôm nay / sắp hạn 3 ngày).
- `js/config.js`: cấu hình Supabase.
- `css/style.css`, `css/toast.css`: giao diện.
- `supabase/functions/send-email/index.ts`: Edge Function gửi email.
- Data: Supabase REST API.

## Bảng Supabase
- `activity_logs`: log hoạt động (đã tạo)
- `province_tasks`, `bch_tasks`, `ttbtv_tasks`, `vpub_tasks`, `action_100_days_tasks`, `action_100_days_officers`
- Cột mới đã thêm: `progress`, `commune_leader`, `office_leader`

## Quy ước kỹ thuật (bắt buộc)
1. Sửa ít file nhất, giữ nguyên API, bố cục, timeline cũ.
2. Không commit, push, tạo branch nếu chưa yêu cầu.
3. Không upload file gốc lên Storage: chỉ lưu `attachment_name`, loại, kích thước.
4. Hiển thị: chỉ tên file + nhãn `Chỉ lưu tên file`, không có nút xem/tải nếu thiếu `attachment_path`.
5. Kiểm tra: chỉ dùng `node --check js/legacy.js` và `git diff --check`. Không có lint/build.
6. Popup xác nhận thêm mới (`#addConfirmModal`) luôn z-index cao nhất 999999.

## Phân quyền Token
- `Admin`: full quyền, xem nhật ký, xóa log (cần xác nhận bằng token Admin), gửi TB (`Gui TB`).
- `CQ-MAUA-***` (CV nhập liệu, `scope: data_entry`, login staff như local): sửa TT/BTV + Tỉnh bảng cũ + cây Tỉnh giao (5 trường/agency, không thêm/xóa cấu trúc) + KH100/VPUB (trừ Ghi chú Admin, chỉ cập nhật không xóa), NHƯNG khóa Nội dung nhiệm vụ + Hạn hoàn thành (chỉ Admin, cả UI lẫn payload). Chặn Văn phòng + BCH + Nhật ký. Check token TRƯỚC DEPARTMENT_TOKENS; click Văn phòng → redirect TT/BTV.
- Token cơ quan `CQ-MAUA-*` (19 token `scope: action100`): VPDU, UBND=`UBND`, UBNDXA/`UBND xã`, BANXDD=`Ban Xây dựng Đảng`, MTTQ, HDND, CBCONGAN=`Công an xã`, CBQUANSU=`Quân sự xã`, UBKT, TTCT=`Trung tâm Chính trị`, KTHT=`Phòng Kinh Tế hạ tầng`, PVH=`Phòng văn hóa`, HCC=`Trung tâm DV HCC`, DVTH-CVE61=`Trung tâm Dịch vụ tổng hợp`, DTXD-8LX74F=`BQL dự án đầu tư xây dựng`, NNMT-CV=`Phòng NN và MT`, TYTLD/TYTCV=`Trạm Y tế`, UBNDXA2=`UBND xã`): `role: department`, `scope: action100`, truy cập KH 100 ngày + Tỉnh giao cây (`province_plan_blocks`) để test (mở `openPROVWorkspace:5999` cho `action100`). Khớp tên không dấu (`ppNorm`/`canEditAction100Task:6481` + bỏ `CB/CQ`, `includes` 2 chiều) — vd `Công an xã`/`Cong an` đều khớp `Công an`.
- `CQ-VPUB-MAUA`: xem BCH, TT/BTV, Tinh giao, KH 100 ngày, tự thêm ở VPUB. Không xem Văn phòng.
- `CB-MAUA-*`: token cá nhân 15 ký tự, xem/sửa theo người phụ trách.
- `STAFF_ACTION100_TOKENS` (4 token `scope: action100`): LTT `Lê Trường Thịnh`, TAT `Trần Anh Tráng`, DNC `Phòng NN và MT`, NGN `Nguyễn Giang Nam` — cùng quy tắc khớp cơ quan như trên, chỉ sửa khi tên nằm trong Cơ quan phụ trách/phối hợp.

## Task hiện tại
- Ghi nhật ký Admin (writeActivity) cho mọi workspace: BCH/TT/BTV/Tỉnh giao/KH100/VPUB gồm Thêm, Sửa, Xóa nhiệm vụ, Xóa/Duyệt file.
- Nút "Thêm nhiệm vụ" chỉ hiện cho ai có quyền thêm; bấm tự mở workspace tương ứng + scroll tới form thêm.
- CQ-MAUA-***: thêm/sửa/xóa nhiệm vụ chỉ trong TT/BTV, mở toàn quyền sửa như admin tại BTV (trừ Ghi chú Admin). Check token TRƯỚC DEPARTMENT_TOKENS; click Văn phòng → redirect TT/BTV.
- Nút Gia hạn ở cột Thao tác nhiệm vụ Văn phòng: chỉ hiện khi nhiệm vụ có trạng thái `Quá hạn` và là Admin.
- VPUB: workspace riêng, 12 trường, đơn vị chọn: KT, VH, CA, QS, HCC, DVTH, VP; lịch sử cũ trong `archive.md`.
- TT/BTV: biểu đồ tròn "Theo cơ quan chủ trì" nhóm theo `role||unit_name`, đủ tổng nhiệm vụ; popup drill có nút Xuất CSV; hover tên nhiệm vụ hiện popup nội dung (class `task-tip`); có trường "Nguồn giao" (lưu cột `amount`) ở form thêm/cập nhật; hiện tooltip cuộn nội dung khi quá dài (không còn thanh cuộn kẹt trong tooltip).
- Tỉnh giao: bảng hiển thị 10 cột cố định (STT, Nhiệm vụ cụ thể, Cơ quan tham mưu, Lãnh đạo UBND, Hạn, Ngày hoàn thành, Thời gian còn lại, Tiến độ, Trạng thái, Sản phẩm); bỏ Thẩm quyền, bảng `prov-wide` + cuộn ngang, hover tooltip; modal xác nhận tự đóng (tránh double-add); `<textarea>` cho Sản phẩm/Lý do/Nhiệm vụ kèm hover tooltip.

- KH 100 ngày: Trạng thái luôn tính lại (bỏ `x.status` cũ); Số ngày còn lại = deadline-completed hoặc today-deadline; non-admin chỉ sửa Ngày hoàn thành/Sản phẩm/Ghi chú.
- TT/BTV: token `CB-MAUA-***` (Đinh Mạnh Cường) sửa được Ghi chú cán bộ khi `officer_name` khớp; bỏ check `scope===ttbtv`.
- Giao diện: focus `#6d28d9`; Báo cáo xuống cuối; Cảnh báo chỉ Admin; Tỉnh giao cây Kế hoạch mỗi người 1 trạng thái, có tóm tắt khi thu gọn (tên+mô tả+SL cơ quan+hạn).
- Kế hoạch: Nhiệm vụ lớn + Mô tả ngắn; mỗi Cơ quan có Tên (khi khác) + Nhiệm vụ cụ thể; mỗi người có Hạn/Ngày HT/Còn lại/Tiến độ/Trạng thái/Sản phẩm/Lý do riêng, LĐ PCM tùy biến.
- Lưu: `province_plan_blocks` (`stt, van_ban_tinh/xa, nhiem_vu, blocks:{mota, agencies:[{agency,type,agencyTask,persons,pcmList}]}`), Sửa/Xem theo quyền, F5 thu gọn tất cả và hiện tóm tắt.
- Nút Ẩn/Hiện danh sách cũ trên đầu (toggle provinceOldCard, lưu localStorage).
  Fix 1920x1080: .bch-table-card {display:flex !important} thắng inline → dùng getComputedStyle + setProperty('display','none','important')/removeProperty.
- ppHeaderStatus strict như Văn phòng: finish+product mới hoàn thành, dl<today là quá hạn, đồng bộ ppUpdateAll.
- Tooltip dài (>400 ký tự) giữ để cuộn (pointerEvents auto), chỉ ẩn khi chuột xa ±40/60.
- Văn phòng/BCH/TT/BTV Hiệu suất Top10 bar: click theo trạng thái (owner+statusKey/datasetIndex).
  Văn phòng dùng officePerformanceRows, BCH/TTBTV dùng bch/ttbtvStatusGroup; chỉ filter hiển thị, không đổi DB.
- TT/BTV popup Hiệu suất: bộ lọc gộp 1 dòng, bỏ 3 label+hint, rút gọn option Mới nhất/Có file.
  CSS flex nowrap, select/input 32px co giãn, nút Xóa lọc gọn.
- Tỉnh giao cây: newest lên đầu (sort stt/id desc, afterbegin + scroll focus).
  Fix mất focus (pointer-events auto, focus #6d28d9, stopPropagation) + paste plain text (execCommand insertText).
- Tỉnh giao KPI theo cây (fix 40→10): đếm .pp-task theo dataset.statusKey, officer distinct.
  renderPROVKPIs ưu tiên getProvinceTreeStats, ppUpdateAll + filter gọi KPI.
  Đúng 10 nhiệm vụ thay vì 40 persons.
- Tỉnh giao popup Tất cả nhiệm vụ khớp cây (fix 72→10): getPROVTreeRows + getPROVRowsByMode ưu tiên tree.
  onPROVDrillFilterChange hỗ trợ tree, renderPROVDrill render _isTree với Xem cây.
  Scroll highlight nhiệm vụ trong cây thư mục.
- Tỉnh giao dialog + header: #provinceConfirmModal gradient, async provinceConfirm thay confirm().
  Header sticky top:0, cursor pointer, onclick toggle toàn nhiệm vụ, nút stopPropagation.
  ppUpdateSTT giữ tên nhiệm vụ khi mở rộng, không revert Nhiệm vụ 1,2,3.
- Tỉnh giao accordion: chỉ mở 1 nhiệm vụ tại một thời điểm, giữ header tại vị trí trỏ chuột.
  ppToggleTask lưu oldTop, collapse others trước expand, scrollBy delta newTop-oldTop.
  Đóng portal tooltip, update badge/header.
- Tỉnh giao tooltip chỉ mắt hiện: bỏ hover pp-summary, chỉ eye mouseenter hiện.
  Bỏ setTimeout 3000, eye hiện ngay portal đẹp tự lật không bị che.
  Sum không tự hiện tooltip, giữ badge.
- Tỉnh giao tooltip sang trái: eye portal left = r.left - tw -12, fallback r.right+12.
  Giữ top r.bottom+10, flip lên nếu vượt vh, clamp vw 8px.
  Chỉ mắt hiện, giữ portal đẹp không bị che.
- Tỉnh giao popup đồng bộ cột với danh sách: header 11 cột (STT→Sản phẩm) + Thao tác.
  Sửa index.html thead và renderPROVDrill 12 td, map issuing_authority/unit/completed/remaining/progress.
  Tree hiện '—' nếu thiếu, old row giữ nguyên, colspan 9→12, không đổi DB.
- Tỉnh giao bỏ KPI Lãnh đạo + cột Thẩm quyền, chỉnh tiêu đề hợp lý.
  Xóa provinceOfficerCount, xóa c-auth th/td, popup colspan 12→11, render bỏ issuing_authority.
  CSS th 36px/34px 7px 8px, c-task 420/620, c-unit 180, KPI grid 4 cột, min-height 72px.
- Tỉnh giao đổi nhãn cây: LĐ (CQT)→Lãnh đạo CQ chủ trì, LĐ PT→Tên PCM, Cơ quan chủ trì→Nhiệm vụ chính, Cơ quan phối hợp→Nhiệm vụ phối hợp 1,2,3 động, + Cơ quan→+ Nhiệm vụ, + Thêm nhiệm vụ→+ Nội dung.
  Sửa ppAgencyBlock/ppRefreshAgencyTitles (đánh số i), ppPCMBlock, ppTaskBlock, index.html provincePlanAddTask.
- Tỉnh giao cây tinh gọn: Xóa CQ→Xóa nhiệm vụ, bỏ 2 trường Nhiệm vụ/Mô tả ngắn trên Nhiệm vụ chính, thêm nút Thu gọn/Mở rộng cho Nhiệm vụ phối hợp (wrapper .pp-agency-content + ppToggleAgency).
  Thay ppTaskBlock, ppAgencyBlock, ppUpdateSTT/ppToggleTask/provincePlanSave fallback agencyTask.
- Tỉnh giao nhạt màu nút phối hợp: Mở rộng #e2e8f0/#475569 border #cbd5e1, Xóa nhiệm vụ #fef2f2/#dc2626 border #fecaca (chính giữ #ef4444), removeStyle động theo isCT.
- Tỉnh giao tooltip Cơ quan không xuống dòng: badge Phối hợp/Chủ trì thêm white-space nowrap, flex 0 0 auto, min-width 64/68, padding 2px 10px, inline-flex, chống vỡ dòng trong #ppFixedTip.
- Tỉnh giao +LĐ PCM nhạt & click thanh phối hợp: +LĐ PCM #fce7f3/#9d174d border #fbcfe8 (bỏ #E91E63 đậm), thanh Nhiệm vụ phối hợp cursor pointer + headerAttrs onclick ppToggleAgency(toggleBtn) (chính không toggle).
- Tỉnh giao đổi placeholder Chưa nhập: Nhiệm vụ ${stt}/${i+1} — Chưa nhập → Hãy nhập nội dung cụ thể tại ppToggleTask/ppUpdateSTT fallback.
- Tỉnh giao popup Khác đẹp: prompt native → provinceConfirm gradient với input #customAgencyInput #6d28d9.
  Auto focus + Enter, thêm option trước __other__, áp dụng cho cả chính & phối hợp.
  Thay ppHandleAgencyOtherChange, đẹp hơn prompt native.
- Tỉnh giao: "Chuyển dữ liệu cũ"→"Xuất sang danh sách kiểu cũ" (provinceExportTreeToOldList duyệt cây → province_tasks chỉ lấy Nhiệm vụ/Cơ quan/Lãnh đạo/Hạn/Ngày HT/Tiến độ/Sản phẩm/Lý do + VB tỉnh/xã, provinceConfirm).
- BCH/KH100/VPUB/TT/BTV: lưới border separate radius 12px + th sticky top0, STT +50% (BCH 4.24%→6.36%, KH100 4.4%→6.6%, TT/BTV 3.85%→4.24%), Nhiệm vụ 34% + Kết quả 5 dòng clamp task-tip bỏ title, ẩn c-amount/c-product.
- Trang chủ 4 biểu đồ tròn home-four-grid 1fr×4 + Modern clean theme 206 dòng; FIX VPUB unit_name→unit (PGRST204); KH100 bộ lọc Hoàn thành gộp.
- Token mới action100: CQ TTCT/KTHT/PVH/HCC/DVTH-CVE61/DTXD-8LX74F/NNMT-CV/TYTLD/TYTCV/UBNDXA2 (UBND xã) + STAFF_ACTION100_TOKENS (LTT Lê Trường Thịnh, TAT Trần Anh Tráng, DNC Phòng NN&MT, NGN Nguyễn Giang Nam); canEditAction100Task khớp tên cơ quan mọi trường (unit_name/role/commune_leader/office_leader/specialist/officer) contains 2 chiều, department/staff action100 chỉ cập nhật không xóa.
- 29 token BCH (bảng officers, scope bch): sidebar + trang chủ chỉ còn BCH (syncUserWorkspaceVisibility ẩn province/ttbtv/vpub/action100; homeFilterSource trả [] cho nguồn khác → KPI/popup drillKPI chỉ BCH).
- UBKT fix: tên cơ quan nằm ở commune_leader thay vì unit_name; CQ-VPUB-MAUA giữ nguyên scope vpub cho VPUB.
- Tối ưu 1920x1080 giữ đẹp chỉ JS: debounce search 280ms/office 220ms/province 150ms, cache homeFiltered + _dueTs/_statusKey, Map id->idx thay indexOf/find, Chart update thay destroy + delegation legend + devicePixelRatio 1.5, DocumentFragment provincePlanLoad, không bôi đen focus (cursor cuối) + viền xanh lá #10b981/#86efac; chat_log2.txt.
- Tỉnh giao popup grid: #provinceDrillModal border separate radius 12px sticky header, prov-task-text clamp 5 + task-tip.
- Dialog focus: bchEditTask readOnly !isAdmin + focusFirstEditable + pointer-events auto cho tất cả dialog.
- Bộ lọc Tuần/Tháng/Quý toàn workspace tính theo thời điểm tạo nhiệm vụ (created_at): Office _createdDate + BCH/TTBTV/Province/Action100 getCreationDate + Province tree dataset.createdAt, helper getTimeRange/isDateInTimeRange/getCreationDate, bỏ lọc theo Hạn.
- Tỉnh giao cây menu Cơ quan + PCM: Nhiệm vụ chính menu HĐND (HĐND xã + 2 Ban) + UBND xã 8 + TM giúp việc 3 + Trung tâm CT + MTTQ, ppAgencyOptionsHtml(), ppPersonRowPCM(select), PCM hidden + toggle, patch restore select custom.
- Tỉnh giao gọn VB tỉnh/xã chỉ hiện thời gian: ppShortDoc(CV 1297, ngày 15/7/2026), ppBuildTaskTitle + ppToggleTask extra/tip dùng short, placeholder VD + CSS [data-placeholder]:empty:before.
- Giữ nguyên tên VB rút gọn sau ngày: "Công văn số 1397-CV/TU ngày 06/8/2026 của Ban..." → "Công văn số 1397-CV/TU ngày 06/8/2026" (ppShortDoc cắt sau ngày), menu Cơ quan chính HĐND (HĐND, 2 Ban) / UBND (UBND xã) / CQ TM (4) / Trung tâm CT / MTTQ.
- Fix lặp "ngày ngày": ppShortDoc nếu đã có "ngày dd/mm/yyyy" thì không thêm "ngày" nữa (direct match CV+ngày), trước đó before chứa "ngày" + thêm " ngày " → duplicate.
- Giữ nguyên tiền tố VB (Công văn/Chỉ thị/Thông báo...): ppShortDoc docType mở rộng (Chỉ thị/Thông báo/Quyết định...), regex \d+\S* giữ "88/QĐ-UBND" không cắt "Đ".
- Hiện tên PCM cho nhiệm vụ phối hợp: phối hợp đã có tên PCM thì hiện luôn (ppRefreshAgencyTitles ': PCM', ppBuildTaskTitle 'PCM: name', ppUpdateAll refresh + change).
- Tách 2 menu cơ quan: Nhiệm vụ chính menu gọn (HĐND/UBND/CQ TM/TTCT/MTTQ - ppAgencyOptionsHtml), Nhiệm vụ phối hợp + Tên PCM menu đầy đủ như cũ (UBND xã 8 + TM 3 + TTCT + MTTQ 7 - ppAgencyOptionsFullHtml), ppAgencyBlock ${isCT?main:full}, label phối hợp = tên cơ quan đã chọn.
- KH 100 ngày siết quyền sửa (28/08): `canEditAction100Task:6481` chỉ cho `scope: action100` nếu `commune_leader` (Cơ quan phụ trách) hoặc `unit_name` (Cơ quan phối hợp) khớp không dấu với `CURRENT_USER.name` (VPUB `unit`/`field`); cột Thao tác `renderAction100Table:6375` ẩn `Sửa` nếu không đủ quyền.
- KH 100 ngày bộ lọc Cơ quan (28/08): `#action100Agency` distinct `commune_leader`/`unit_name`, `populateAction100AgencyFilter:6348`, lọc không dấu `renderAction100Table:6355`, `open` cho `action100`.
- BCH lọc Tên cán bộ (28/08): `#bchOfficerNameFilter` text `bchFold` `officer_name` includes, `applyBCHFilters:3132` + `resetBCHFilters:3852` + `renderBCHCharts:3200`.
- Tỉnh giao scope100 hạn chế (28/08, fix 28/08 per-agency): `ppNorm/ppScope100CanEditTask/ppCanEditProvinceTask:7118` khớp cơ quan chính/phối hợp không dấu; `ppSyncTaskRoleUI:7154` chỉ hiện `Lưu`/`Sửa` (ẩn `Xóa`) và `+LĐ PCM` per-agency `ppScope100CanEditAgency`; `ppEditTask:7114`/`ppAddPCM:6771`/`ppTogglePCMList`/`ppSaveOne:7480`/`ppDeleteTask:6811` cho phép hạn chế 5 trường `Tên/ngày HT/sản phẩm/tiến độ/lý do` **chỉ trong agency khớp** (Trạm Y tế không sửa được phối hợp khác); `openPROVWorkspace:5999` mở cho `action100`.
- Token `CQ-MAUA-***` đổi `Ban XDD`→`Ban Xây dựng Đảng` (`js/legacy.js:22`); `CQ-MAUA-***` chuẩn hoá `UBND xã`; thêm `CQ-MAUA-***`=`UBND` để test cả `UBND`/`UBND xã`.
- Trang chủ (28/08): bar `Tổng số nhiệm vụ` 430→260px `horizontal bar` (`indexAxis y`), `home-bottom-grid 1.6fr/1fr/1fr` + 2 biểu đồ `line` (Tỷ lệ trạng thái, fill+tension) + `polarArea` (Top cơ quan); Top cơ quan thêm `KH100`/`VPUB` (`KH100_TASKS_CACHE`/`VPUB_TASKS_CACHE` + bg fetch, `homeSource`/`homeSourceKey`/`homeStatus`/`getAllHomeTasks`/`homeFilterSource`/`homeFilteredTasks`/`homeFilterAgency` option, `renderAgencyTotalsChart:1484`).
- BCH drill popup (28/08): `bchDrillOfficerFilter` (search) + `bchDrillOfficerSelect` (dropdown) + `bchDrillStatusFilter` (`bchStatusGroup`), `onBCHDrillFilterChange:3333` kết hợp, `renderBCHDrill:3449` populate distinct + clear khi mở (`index.html:752`).
- Fix Đ/đ + per-agency (28/08): `ppNorm` Đ→D, `ppInitials`/`ppTokenInit` cho `VPDU`↔`Văn phòng Đảng ủy`/`VPĐU`, `canEditAction100Task:6506` + `renderAction100Table:6373` agency filter, `ppSyncTaskRoleUI` per-agency `Trạm Y tế` chỉ sửa ag khớp.
- Trang chủ hero (28/08): `index.html:167` `hero-banner hero-split` glass-card trái (860px) + `hero-topbar` phải dọc (260px) + 4 `hq-stat` `heroTotal/Done/Doing/Late`; `css/style.css:8029` hero kính mờ Sapa; `js/legacy.js:1964` `render()` đồng bộ hero stats; header chỉ giữ `🔄 Cập nhật ngay` + `↩ Đăng xuất` (xóa In/CSV/đổi token), liên kết `refreshAllData`/`logoutUser`/`initAuth`.
- Logo + KPI + perf (28/08): `index.html:54` logo 78px tròn `50%` viền vàng `2.5px #d4a84b` `scale(1.18)` + `onclick hardRefreshHome` soft (bỏ `reload` tránh nháy `authGate`); favicon/logo bỏ base64 → URL `i.ibb.co` giảm 772KB→118KB; `js/legacy.js:2468` `drillKPI` bỏ chặn `department/data_entry` để `Tổng/ Hoàn thành` hiện `statsDrillModal`; Chart `sync` giữ nguyên.
- Cảnh báo + Sắp đến hạn (28/08): nút `🔔 Sắp đến hạn (x)` (`notifBtn`) trên `Đăng xuất` hiện với mọi token, mở popup `Nhiệm vụ sắp đến hạn` (`openDailyWarnModal`) lọc theo `Phụ trách` (`isOwnedByToken` khớp `owner/officer_name` theo `scope`; a100 `canEditAction100Task`/`commune_leader`, vpub `unit/field/leader`); `updateNotifCount` async dùng `refreshDailyWarnTasks` → `DAILY_SOON_TASKS.length` khớp popup. `refreshDailyWarnTasks:6648` `soonEnd +7` ngày, mục `⚠️ Cảnh báo` (`warnSidebarItem`) chỉ hiện admin + staff·office; non-admin ẩn cột `Email nhận TB` + nút `Gửi tất cả`. `openDailyWarnModal` popup 944px, cột Hạn `dd-mm-yyyy`.
- Nhật ký hoạt động (28/08): `openActivityLog:138` thêm class `activity-log-mode` + `activity-log-table`; `css/style.css:8042` grid 1104px, filter 3 cột, table fixed (56/12/12/14/50/84%), ghi chú `line-clamp:5`, badge thao tác `data-full` tooltip `.task-tip-popup` (bỏ ngưỡng 40), `showDrill` gỡ class để dùng chung `#drillModal`.
- Fix chuẩn hóa + office_officers (02/09): `normalizeTask:1759` alias `deadline`/`deadline_date`, nới lỏng ngưỡng ký tự; `confirmAddTask:2751`/`confirmNewBCH/TTBTV/PROV:3549/4486/5625` fallback `task_name/officer/deadline` từ pending trước normalize + tạo `fb` nếu Supabase trả thiếu; thêm bảng `office_officers(id,name,token,title,unit)` giữ RLS + 4 policy permissive (select/insert/update/delete using true).
- Fix token F5 + gỡ offline + sidebar (03/09): `initAuth:522` fix `ADMIN_TOKEN` undefined → `"<ADMIN_TOKEN>"`, khôi phục nhanh từ `vp_demo_user` cache, giữ phiên khi mạng lỗi; `setLoggedInUser:374`/`logoutUser:504` dùng `safeLS`; `js/main.js` bỏ `lz-string`, `sw.js` tự hủy cache `vps-maua-v1`; xóa `offlineBanner/Queue` `index.html` + CSS; xóa `#sidebarCollapseBtn` thu gọn (sidebar luôn hiện); `node --check` pass.
- Vinh danh BCH quý + xóa SW (03/09): `updateGlobalHonors:1143` đổi tháng→quý, BCH tính tổng NV quý (`leaderMap.total`) thay vì hoàn thành; `index.html:243`/`index-fix.html:262` label `có nhiều nhiệm vụ nhất trong Quý`; xóa hẳn `sw.js` + gỡ offline hoàn toàn; `node --check` pass.
- Vinh danh tháng/quý (04/09): cá nhân VP tính trong tháng (`isOfficeInCurrentMonth`, popup `Vinh danh tháng M/YYYY`, subtitle `Vinh danh trong tháng`); BCH tính NV hoàn thành nhiều nhất quý (`done>0`, sort done→total, popup chỉ NV hoàn thành, nhãn `có nhiều nhiệm vụ hoàn thành nhất trong quý hiện tại`).
- SW killer (04/09): `sw.js` killer tự xóa cache `vps-maua-*` + unregister (xóa file không gỡ được SW cũ); `legacy.js` gỡ dự phòng khi tải trang; chống cache `?v=20260906` (`main.js`→`legacy.js`, `index.html`→`main.js`+`style.css`).
- Tỉnh giao theo cây mới (04/09): bảng cũ/KPI/biểu đồ/drill/lọc CB ưu tiên `getPROVTreeRows` (kèm unit/progress/createdAt/_treeIdx, click cuộn tới cây); bỏ form Thêm trong popup (`openPROVAddTaskPanel`→`provincePlanAddTask`); Hiệu suất Top10 + tròn Số NV tách từng người (`buildPROVPerfPersons`, click drill đúng người); sắp xếp mặc định ngày tạo mới nhất; cột Trạng thái ghi gọn `Hoàn thành` (tooltip giữ chi tiết, `provinceBadgeStatus`).
- Cây Tỉnh giao trạng thái (04/09): `ppPersonStrictStatus` chốt theo ngày (đủ Ngày HT+Hạn → trước/đúng/`HT quá hạn`, hết treo Quá hạn); gom task bỏ qua dòng trống; nhãn thu gọn đủ đúng/trước hạn → `Hoàn thành`.
- Nhập liệu cây (04/09): person lưới 2 hàng + head sticky, ô ngày `type=date` (`ppParseDate` hỗ trợ ISO, `ppDateInputVal`/`ppDispDate` tương thích cũ), Enter chuyển ô, badge `x/y hoàn thành` agency, textarea 80px; nút agency Mở rộng/Thu gọn chàm + toggle được Nhiệm vụ chính; bỏ toàn bộ viền khung (giữ thanh trái trạng thái, khử focus đen).
- Quyền cây (04/09): `ppMatchAgencyByToken` alias VPUB↔`Văn phòng HĐND & UBND`/`UBND xã`, scope `vpub` sửa 5 trường trong agency khớp; viền xanh `#6ee7b7` mục sửa được; chỉ Admin thêm/xóa dòng VB tỉnh/xã (khóa nút ×, chặn `ppAddDoc`/`ppRemoveDoc`).
- Backup (04/09): 14 bảng, đọc phân trang (fix cắt 1000 dòng), bỏ qua bảng lỗi, restore `id=not.is.null` (uuid); xóa `bch_officers` khỏi `api/admin.js` (bảng không tồn tại).
- Trang chủ (04/09): nhãn `Văn phòng Đảng ủy`/`VP HĐND&UBND` (bar + Top cơ quan + lọc nhanh); Tỷ lệ trạng thái gom `undefined`→Đang triển khai.
- BCH (04/09): cột Kết quả = Sản phẩm (fallback cũ); Nhiệm vụ 34%→27%, Trạng thái 12%/140px.
- TT/BTV (04/09): Nguồn giao bắt buộc (thêm/sửa, nhãn *); token TT/BTV sửa Nguồn giao + Lãnh đạo của mình; Lãnh đạo có tùy chọn Khác (dialog đẹp).
- VP (04/09): lọc Hôm nay/Tuần/Tháng theo ngày tạo (`officePerformanceRows` dùng `_createdDate`+`isDateInTimeRange`, trước lọc nhầm Hạn).
- Focus (07/09): bảo vệ focus toàn bộ token/workspace bằng CSS `pointer-events:user-select` cho input/textarea/select/contenteditable + document capture `pointerdown/mousedown`; tooltip ẩn không chặn click, `focusFirstEditable` không cướp focus user.
- Nhật ký (07/09): thêm bộ lọc `Có nội dung nhiệm vụ` (`details.task`), `Chỉ dòng của Admin` và menu thao tác động từ các action đang có; `filterActivityLog` lọc kết hợp tên/ngày.
- BCH (15/09): `Kết quả/Sản phẩm` thay `Chức vụ` tại `index.html:1368` + `bchDrill:758` khớp `bchEditProduct` (fallback `product||result`); `File đính kèm` thay `Kết quả` chỉ hiện `Có file đính kèm`/trống (`renderBCHTable:4248` `c-title` + `renderBCHDrill:3852` 8 cột); `Chỉ lưu tên file` giữ nguyên - `uploadBCHTaskFile:4024` trả `path=""` nên duyệt chỉ đổi `attachment_approved`; `css/style.css:5509` clamp 5 dòng cho `c-title .bch-product-text`; `_vp_t` + `*_officers_cache` mã hóa token `btoa-reverse` (task giữ plain) giữ mượt.

## Bản đồ file lớn legacy.js (9619 dòng - tra trước khi sửa)
- A Auth/RBAC 1-470: ADMIN_TOKEN/STAFF_TOKENS/DEPARTMENT_TOKENS/STAFF_ACTION100_TOKENS/BCH tiers, CURRENT_USER, resolveWorkspaceToken, loginWithToken, syncUserWorkspaceVisibility, canAccessOfficeData
- B Perf helpers 58-63 + I Home 1213-1415 + J Utils 1447-1748: debounce, idleSave, _homeFilteredCache, COLORS/completedStatuses, getAllHomeTasks, homeFilteredTasks, mergeDepartmentAndOffice(1684 ưu tiên off.task)
- F Office 473-1020 + N Office Add/Drill 2451-2870: canEditTask, openEditTask(OFFICE_EDIT_ID), saveEditTask(PATCH office_tasks + department_tasks sheet_name/row_number), OFFICE_DRILL_STATE
- G Honors 1023-1203, H Supabase 1205-1212 (URL https://zipvocbtmilyeuhqqrur.supabase.co), U Tree 8335-9619 (PROVINCE_PLAN_API 8335, ppSerializeAgency, ppSaveOne)
- O BCH 3325-4300 (BCH_TASKS_API 3325 tasks, renderBCHDrill 3852 8 cột Kết quả/Sản phẩm+File đính kèm, saveBCHTaskEdit 4140, renderBCHTable 4248 c-title=product), P TTBTV 4314-5620 (TTBTV_TASKS_API 4314 tt_btv_tasks), Q Province 5628-8330 (PROV_TASKS_API 5628 province_tasks, renderPROVTable, provinceFilteredBadgeStatus), R Action100/VPUB 6615-7300 (ACTION100_TASKS_API switch vpub_tasks)
- Quy tắc tra: Grep từ khóa (vd `function saveEditTask`) → Read offset 80 dòng, không đọc cả file.

## Supabase binding (single source - không đổi schema)
- 13 bảng: office_tasks, department_tasks, tasks(BCH), tt_btv_tasks, province_tasks, province_plan_blocks, action_100_days_tasks, vpub_tasks, officers, tt_btv_officers, province_officers, action_100_days_officers, office_officers, activity_logs (+ mttq_kpi_people/catalog/tasks - 3 bảng KPI riêng)
- 3 bucket: task-files (BCH/office - chỉ lưu tên `path=""`), tt-btv-files, province-task-files (Storage encodePath) - BCH/TTBTV/Province đều `Chỉ lưu tên file` khi upload mới
- 1 Edge Function: functions/v1/send-email (Resend) - headers apikey+Bearer anonKey, Prefer return=representation/minimal

## RBAC & Cache (giữ nguyên khi bảo trì)
- 29 token BCH (HDA/PXS/CCS full, 19 broad, 7 bch-only) + 23 token action100 (19 CQ department + 4 STAFF_ACTION100_TOKENS LTT/TAT/DNC/NGN) — CQ-MAUA-*** mới
- 17 key localStorage: vp_demo_user/token, vp_tasks_cache, bch_*_cache, ttbtv_*_cache, province_*_cache, user_email, deadline_email_last_sent, last_overdue_alert_date, provinceOldListHidden
- Test mỗi sửa: tạo TEST_*_YYYYMMDD 3 trạng thái (Hoàn thành đúng hạn/quá hạn/Quá hạn) → POST/PATCH/GET/DELETE 200 → DELETE dọn, như 26/08 đã pass.

## Cập nhật phiên 11/09/2026
+ Đã làm: Sao lưu 17 bảng (3342 dòng), đồng bộ dev-map 17 bảng, sửa guard ADD + province normalize, BCH dd/mm/yyyy + lọc gọn, Tỉnh giao cho token sửa theo tên trong cây và nổi bật 3 trường Ngày HT/Tiến độ viền cam nền xanh lá
+ File đổi: `js/legacy.js`, `css/style.css`, `js/dev-map.js`, `index.html`, `scripts/backup-now.js`, `TEST_REPORT.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-11
+ Đã làm: Tạo link tải toàn bộ data qua n8n webhook ?token + auto đẩy Drive giữ 5 bản
+ File đổi: `n8n/vp-backup-workflow.json`, `n8n/README.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-15
+ Đã làm: Khóa Nội dung + Hạn chỉ Admin sửa toàn workspace, ẩn lỗi 400/401 F12, highlight nhãn TT/BTV; BCH đổi `Chức vụ`→`Kết quả/Sản phẩm` khớp `bchEditProduct` + `Kết quả`→`File đính kèm` (`Có file đính kèm`/trống), cập nhật map 9619 dòng; Mức 2 chặn DevTools nhẹ (F12/Ctrl+Shift+I/Ctrl+U toast, chặn contextmenu #authGate) + mã hóa localStorage `_vp_t` btoa-reverse giữ trơn tru, làm mờ fallback `<ADMIN_TOKEN>` join; Thêm mục 🔐 Set role trong Tiện ích (chỉ Admin) - popup liệt kê token từ 5 bảng officers + Admin, mở rộng 24 checkbox quyền (Xem/Thêm/Sửa/Xóa × 6 workspace), auto-detect quyền hiện có theo role+scope (`computeDefaultPerms`), đánh dấu cam khi admin sửa khác mặc định; lưu `localStorage` `vp_token_multiscope` cấu trúc `{token:{ws:{v,a,e,d}}}`, áp dụng qua `applyTokenMultiScope` ở `setLoggedInUser` gắn `_perms` vào user; `syncUserWorkspaceVisibility` check `userCan(user,"view",wsId)` cho extra scopes; `userCan(user, action, wsId)` dùng chung; `canEditAction100Task` + `deleteAction100Task` ưu tiên `userCan(CURRENT_USER, "edit"/"delete", wsId)` ở đầu → khi admin tick Sửa/Xóa VPUB cho token (vd NGN) thì bypass check khớp tên/cơ quan, sửa/xóa được mọi nhiệm vụ trong workspace đó; Lưu server `role_overrides` (Supabase) để mọi trình duyệt đều thấy: `api/admin.js` thêm `get/save_role_overrides`, login trả `_perms`/`_extraScopes` cho token, `js/legacy.js` đồng bộ `fetch/saveServerOverrides`, `supabase_seed_tokens.sql` tạo bảng `role_overrides(token pk, perms jsonb)`; Gộp 3 token Sầm/Sẩm Thị Lê/Lệ Khuyên thành 1: giữ `CB-MAUA-***` (`Sẩm Thị Lệ Khuyên`), xóa `CB-MAUA-***`/`CB-MAUA-***` trong `province_officers`, Tỉnh giao 23→21 token; VP thêm trạng thái Thường xuyên: `calculateTaskStatus`/`canonicalStatus`/`dbStatus`/`statusBadgeClass` hỗ trợ `Thường xuyên`, token Văn phòng (scope office) + Admin tick được (checkbox `addOfficeRegular`/`editOfficeRegular`), nhiệm vụ Thường xuyên giữ nguyên sang tháng sau (bypass `applyFilters`/`officePerformanceRows` date filter), `colors` + `ownerStatusMap` + `statusFilter`/`officePerformanceStatus` thêm Thường xuyên
+ File đổi: `index.html`, `js/legacy.js`, `css/style.css`, `CONTEXT.md`, `CHANGES.md`, `js/dev-map.js`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-16
+ Đã làm: Cho token NGN (`CB-MAUA-***`) quyền ADD/Sửa nhiệm vụ BCH và Gia hạn task BCH quá hạn; fix lỗi PGRST2047 do bảng `tasks` thiếu cột `is_extended`
+ File đổi: `js/legacy.js`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-17
+ Đã làm: Workspace Văn phòng cân gọn grid Thêm nhiệm vụ (nút sang phải) và thêm nút +Thêm nhiệm vụ gần Xuất Excel nhập kiểu popup.
+ File đổi: `css/style.css`, `index.html`, `js/legacy.js`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-17
+ Đã làm: Gọn nút tick Thường xuyên Văn phòng thành tick xanh 20x20 trên nền trắng, checked xanh lá
+ File đổi: `css/style.css`, `index.html`, `js/legacy.js`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-21
+ Đã làm: Tỉnh giao chốt hoàn thành theo Ngày HT và popup 11 cột vừa màn 1920x1080.
+ File đổi: `js/legacy.js`, `css/style.css`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-21 (BCH skin + cây Tỉnh giao)
+ Đã làm: Khoác layout mới cho BCH (pill tổng, tháng, panels, bảng 7 cột, phân trang) và gọn cây Tỉnh giao (trường lãnh đạo theo cơ quan, sản phẩm/lý do từng người).
+ File đổi: `index.html`, `js/legacy.js`, `css/style.css`, `BCH-new-skin.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-22 (BTV new-skin)
+ Đã làm: BTV port BCH-new-skin: trái=list cơ quan (`role||unit_name`, click set agency), bảng 7 cột Cán bộ→Nguồn giao (`amount`), pill/tháng/panels/phân trang, giữ filter cũ ẩn + drill/edit cũ.
+ Bổ sung: cột trái BTV gom theo Nguồn giao như cũ (`amount||source_doc||ubnd_source`, sort `ttbtvDocDate`, click toggle `TTBTV_SRC_Q` đồng bộ `ttbtvFSource`).
+ Chốt: BTV giữ list cơ quan trái (`role||unit_name`, fallback `Chưa rõ cơ quan chủ trì` khớp popup) + bảng gom nhóm theo Nguồn giao như cũ (5 cột); skin BCH giữ pill/tháng/panels.
+ Lọc danh sách BTV: ô tìm nội dung (`ttbtvFTask`→`ttbtvSearch`) + lọc trạng thái (`ttbtvFStatus`→`ttbtvStatusFilter`) ngay trên đầu bảng, `resetTTBTVFilters` xóa cả 2.
+ Popup Thêm TT/BTV riêng (`ttbtvAddModal`, field `ttbtvNew*` đủ như Cập nhật): +Thêm nhiệm vụ → `openTTBTVAddModal`, lưu `stageNewTTBTVModalTask` → `confirmNewTTBTVTask` (`addMode:"modal"` đóng modal, không vẽ drill); hàng Thêm trong drill giữ nguyên.
+ Popup Thêm BCH riêng (`bchAddModal`, field `bchNew*` đủ như Cập nhật + Lãnh đạo/Chuyên viên/Ghi chú Admin): +Thêm nhiệm vụ → `openBCHAddModal`, lưu `stageNewBCHModalTask` → `confirmNewBCHTask` (`addMode:"modal"` đóng modal); hàng Thêm trong drill giữ nguyên.
+ Lọc Quý BCH: nút Quý I-IV xen tháng (`setBCHQuarter` ↔ `setBCHMonth`, state `BCH_QUARTER`, active `bchSyncMonthStrip`), scope/drill theo quý hạn.
+ Sidebar thu gọn (`#sbToggle`/`toggleSidebar`, `sbWrapLabels` tách icon-nhãn, `body.sb-collapsed` rail 78px icon+tooltip, nhớ `vp_sb_collapsed`, chỉ desktop ≥1001px) + gọn laptop 1366x768 (sidebar 232px, paddings/chữ/hero/bảng nhỏ).
+ Fix thu gọn: `sbInitCollapse` chạy ngay khi legacy đã qua loading (main.js nạp động), bump `?v=20260922(-1)`, icon 🗂️🚩📍📌 thay ✓, title `display:none` + divider, content sát menu (`padding-left` + transition grid).
+ File đổi: `index.html`, `js/legacy.js`, `css/style.css`, `CHANGES.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-22
+ Đã làm: Chốt BTV (cơ quan trái, gom Nguồn giao, lọc, popup Thêm), popup Thêm BCH, lọc Quý, sidebar thu gọn + gọn 1366, bản mobile /mobile xem/sửa full 6 workspace theo RBAC desktop.
+ File đổi: `index.html`, `js/legacy.js`, `js/main.js`, `css/style.css`, `vercel.json`, `mobile/index.html`, `mobile/app.js`, `mobile-skin.md`, `CHANGES.md`
+ Còn lỗi: không

## SQL cần chạy nếu chưa có

## Cập nhật phiên 2026-09-22
+ Đã làm: BCH bỏ fallback nhãn done cũ; TT/BTV trạng thái theo group vai trò (lãnh đạo bắt buộc, CV được thiếu), ngày chính mirror theo lãnh đạo, thêm cột trạng thái từng người.
+ File đổi: `js/legacy.js`, `index.html`, `css/style.css`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-23
+ Đã làm: TT/BTV gom Phòng NN vào UBND (tổng UBND = tổng con), chuyển Xoá lọc lên Tổng và in đậm quote, nổi bật UBND, giữ menu khi F5, ẩn Top10 Tỉnh giao thay KPI đẹp khớp lọc/tháng, bỏ Gia hạn/Gửi TB ở BCH Quá hạn.
+ File đổi: `js/legacy.js`, `index.html`, `css/style.css`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-23
+ Đã làm: Tỉnh giao bố trí cơ quan bên trái, văn bản tỉnh/xã dạng dropdown chọn kèm sửa nhanh và tooltip, đồng bộ group vai trò tự nhảy trạng thái/thời gian và hỗ trợ chọn lịch.
+ File đổi: `index.html`, `js/legacy.js`, `css/style.css`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-23
+ Đã làm: BCH thêm dòng “Luôn bấm Xoá tất cả bộ lọc...” và đưa nút 🧹 Xoá tất cả bộ lọc lên cụm Tổng (khớp TT/BTV), đồng bộ nhãn nút ở đầu bảng.
+ File đổi: `index.html`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-23
+ Đã làm: Regenerate `js/dev-map.js` theo `legacy.js` thực tế 12358 dòng (hết overlap Q/R, thêm W_MTTQ + S_SHELL, refresh QUICK_GREP); verify spot-check khớp, không import prod.
+ File đổi: `js/dev-map.js`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-23
+ Đã làm: BCH thêm dòng hướng dẫn Xoá lọc lên cụm Tổng, regenerate dev-map theo legacy thực tế.
+ File đổi: `index.html`, `js/dev-map.js`, `CONTEXT.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-24
+ Đã làm: Tỉnh giao tắt tooltip khi di chuột vào nhiệm vụ (bỏ hover .pp-summary-tip, bỏ mouseenter mắt chỉ giữ click, bỏ title full ở .pp-task-title); popup Cập nhật văn bản tỉnh chuyển select sang textbox input; ẩn tooltip task-tip-popup ở nhiệm vụ tỉnh (bỏ qua .prov-task-text/.prov-doc-tip/#provinceDrillModal); popup tỉnh sắp xếp Văn bản tỉnh - Văn bản xã - Nhiệm vụ; ẩn task-tip-popup ở danh sách chi tiết (#provinceTableBody), mắt 👁 duy nhất ở header cột Nguồn giao + header Nhiệm vụ cụ thể popup (bấm tự thu sidebar + mở full nội dung inline toàn bảng, không bung nhánh; fix selector gỡ kẹp popup viết ngược thứ tự + bump ?v=20260924 chống cache).
+ File đổi: `css/style.css`, `js/modules/pp-mttq.js`, `js/legacy.js`, `index.html`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-24
+ Đã làm: Tách `legacy.js` 12359→6462 dòng thành 5 modules classic + `store.js`, nối `main.js` load tuần tự, regen `dev-map.js` tự động.
+ File đổi: `js/legacy.js`, `js/main.js`, `js/store.js`, `js/modules/utils.js`, `js/modules/auth.js`, `js/modules/ttbtv.js`, `js/modules/prov-bch.js`, `js/modules/pp-mttq.js`, `js/dev-map.js`, `tools/gen-dev-map.js`, `LEGACY_MAP.md`, `SPLIT_PLAN.md`
+ Còn lỗi: không

## Cập nhật phiên 09/28/2026 (AI analysis)
+ Phân tích codebase: 20 bugs (7 Critical security/functional, 4 High, 4 Medium, 2 Low).
+ Security: anon key lộ trong config.js/.env/.env.local, RLS tắt, backup JSON public, WUS_API_KEY/VERCEL_OIDC_TOKEN lộ, SQL seed tokens lộ.
+ Chức năng: showToast conflict (email.js 2param vs legacy.js 5param), provinceCompletedDate() gọi nhầm deadline, cache version typo 20260934, DEMO_MODE hardcoded false, provinceCompletedDate() trả về deadline.
+ UI: toast-container trùng appToastWrap, thiếu label tokenInput, bỏ focus outline, index2.html stale, CSS 1.16MB.
+ Fix: gộp toast thành 1 hàm (email.js dùng window.showToast), thêm label + focus outline, xóa index2.html + toast.css trùng, RLS Phase1+Phase2 SQL + Edge Function secure-write.
+ Province task: Văn bản xã dropdown→textbox; Ngày hoàn thành Lãnh đạo UBND mirror sang Ngày hoàn thành nhiệm vụ (mirrorProvinceDoneDate).
+ Popup Chi tiết Tỉnh giao: Hình thức cụ thể hóa→Văn bản tỉnh, Thẩm quyền ban hành→Văn bản xã (field source_form/issuing_authority).
+ Popup Xác nhận xóa: summary giới hạn 3 dòng + gradient fade (CSS max-height:4.8em).
+ Save province task: lưu roles JSON vào note field (provinceCollectEditRoles→noteJSON). Nút Lưu thay đổi→Lưu nhiệm vụ.

## Kiến trúc (cập nhật)
+ Stack: Vanilla JS classic script + ES module wrapper (main.js). loadClassic() nối tiếp: store→utils/auth/ttbtv/prov-bch/pp-mttq modules→legacy.js.
+ Auth: token CB-MAUA-*/CQ-MAUA-* lưu localStorage "_vp_t", Supabase anon key cho mọi fetch, RLS Phase1 cho phép anon read/write, Phase2 yêu cầu X-User-Token header + Edge Function proxy.
+ js/utils.js, js/data.js, js/render.js: chỉ "export {}", code thật trong legacy.js + modules/.
+ js/email.js: dùng window.showToast từ legacy.js, không tự define showToast nữa.

## Quy ước kỹ thuật (cập nhật)
+ Không commit .env, .env.local, backup-*.json, legacy_old.js.
+ RLS: bật Phase1 trước (anon write allowed), migrate app sang Edge Function rồi chạy Phase2 (chặt token header).
+ popup xác nhận xóa: summary dài tự cắt 3 dòng + gradient mờ (add-confirm-summary trong delete-confirm-body).
+ mirrorProvinceDoneDate: mirror ngày hoàn thành Lãnh đạo UBND→Ngày hoàn thành nhiệm vụ, bỏ readOnly check.
+ provinceCollectEditRoles→noteJSON: lưu roles vào note field, không ghi staffNote vào note.

## Cập nhật phiên 2026-09-30 (UI/UX Pro Max skin)
+ Đã làm: Học skill `ui-ux-pro-max` v2.13.0, chạy `--design-system` (variance 2/motion 2/density 7) chốt Minimalism & Swiss + palette navy/blue `#0F172A/#0369A1` + font `Be Vietnam Pro/Noto Sans`, lưu `design-system/vanphongmaua/MASTER.md`; tạo skin riêng `css/pro-skin.css` load sau `style.css` (xóa link là rollback). Sidebar giữ đỏ rượu dịu `#7a2f3d→#612732→#4e2029`, active trắng mờ + gạch vàng `#d4a84b`. Auth emblem SVG vàng-đỏ xoay 14s + thở 3.2s (tắt khi reduced-motion). Fix popup Trang chủ bị che: `statsDrillModal:30000 < homeDrillModal:30001` (dưới tooltip 99999 + confirm 999997+). Auth gate thêm `#authStatusLine`: token cũ → "Đang tải… xin đợi", mới/đăng xuất → "Xin chào".
+ File đổi: `index.html`, `css/pro-skin.css` (mới), `js/modules/auth.js`, `design-system/vanphongmaua/MASTER.md`, `CONTEXT.md`
+ Còn lỗi: không

## Cập nhật phiên 2026-09-30 (Audit UI + Charts + Skeleton)
+ Đã làm: Audit 6 workspace theo checklist bàn giao — fix tương phản, focus bàn phím, 375px (xem pro-skin.css AUDIT LAYER). Biểu đồ: palette Okabe-Ito (`#06b6d4→#56B4E9`, `#22c55e→#009E73`, `#ef4444→#D55E00`, `soon3→#7c3aed`), 27 canvas `role=img` + `aria-label` Việt. Bảng: `showTableSkeleton()` ở 4 loader + shimmer CSS + empty viền đứt. Tự bắt bug `display:flex !important` đè `display:none` → bỏ.
+ File đổi: `css/pro-skin.css`, `index.html`, `js/legacy.js`, `js/modules/utils.js`, `js/modules/ttbtv.js`, `js/modules/prov-bch.js`, `js/modules/pp-mttq.js`, `CONTEXT.md`
+ NQ: lát Trung ương `#D55E00→#E06666` (đỏ dịu theo yêu cầu, chấp nhận kém an toàn mù màu hơn 1 chút)
+ NQ labels: plugin inline `nqSlicePct` (% trắng trên lát donut >6%) + `nqBarTotal` (tổng đầu cột chồng: nằm trong nếu đủ chỗ, ngoài nếu cột ngắn), bật ở donut + 2 cột NQ, không thêm dependency
+ NQ: TW donut + 2 cot `#E06666→#EA580C` (cam, đồng bộ cả 3 chart); chart BTV bỏ `.slice(0,10)` hiện đủ mọi UVBTV trong data + nới khung 260→380px
+ TTBTV drill: bỏ nút Gửi TB + Gia hạn ở dòng Quá hạn (giữ Sửa/Xem); tiện xóa bug `sendWorkspaceDeadlineNotice('ttbtv',)` thiếu id
+ Văn phòng: Thường xuyên hiện mọi tháng/quý ở biểu đồ + KPI (`officePerformanceRows`/`officeKpiRows` bypass như bảng chính)
+ TTBTV: KPI Đến hạn bấm được (thêm mode `dueToday` đúng công thức đếm + gắn onclick, trước đó div không có click)
+ Popup: nút Đóng phủ màu brand (gradient xanh `#0284c7→#0369A1`, nhiều nút đang xám mặc định); gọn đều 13px 1 hàng, head cho wrap cả cụm
+ NQ Tổng quan: bỏ thẻ KPI Chưa phân công (lưới 5→4 cột); JS null-safe nên không đụng JS
+ VPUB drill: khóa layout 6 cột (`table-layout:fixed`), Nội dung co giãn, Thời hạn 96px không bị che
+ TTBTV: tên Lãnh đạo được để trống (""); đối chiếu tên server trả về sau PATCH, lệch là toast đỏ ngay
+ Văn phòng: ô Hạn/Ngày hoàn thành popup Cập nhật sang text dd/mm/yyyy + mask (bỏ date native mm/dd)
+ Thường xuyên: sang tháng mới tạo bản mới giống hệt (trống Ngày HT + Sản phẩm, Hạn +1 tháng kẹp cuối tháng, cuối tên thêm "[NV Thường xuyên từ Tháng trước: Tháng M/YYYY]"); giữ tháng cũ (bỏ 3 chỗ xóa trùng); đã có bản tháng này thì cập nhật bản đó
+ Thường xuyên: tick lần đầu cũng tạo bản mới (bỏ đòi `x.is_regular` cũ); lọc tháng/quý popup drill chừa TX; NV cũ chưa có marker hiện tag "(NV từ tháng M/YYYY)" tím lúc hiển thị

## Cập nhật phiên 2026-10-02
+ Nút Đặt lại / Xoá tất cả bộ lọc: chuẩn hoá thành pill xanh gradient `#0ea5e9 -> #0369a1` bo tròn 999px, `min-width:150px`, có icon, hover nhấc 1px, focus ring — dùng chung rule `.bch-btn.reset-pill` (đặt SAU block `.bch-btn` vì block đó dùng `!important` cho border-radius/font-weight). Áp cho workspace Văn phòng (`office-perf-reset`, thêm `justify-self:center` trong grid), BCH, TT/BTV, Tỉnh giao. Văn phòng đổi nhãn ngắn `↺ Đặt lại`; 3 workspace còn lại giữ nguyên nhãn cũ `🧹 Xoá tất cả bộ lọc`.
+ Audit che khuất ở viewport laptop 1536x864 (1920x1080 scale 125%) — 3 lỗi thật đã fix: (1) popup xác nhận `#addConfirmModal` / `#deleteTaskConfirmModal` / `#provinceConfirmModal` dùng `.drill-dialog` (`overflow:hidden`, `max-height:90vh`) nhưng body không cuộn nên mất hàng nút ở đáy → thêm `overflow-y:auto; min-height:0; overscroll-behavior:contain` cho `.add-confirm-body` / `.province-confirm-body` / `.delete-confirm-body`. (2) lệch 8px giữa sidebar và workspace ở dải 1001–1280px (rule sau đè `left:240px` trong khi sidebar 232px) → sửa về `left:232px`. (3) màn <=1000px sidebar chuyển off-canvas nhưng workspace vẫn `left:280px` → thêm block `@media (max-width:1000px)` đặt `left:0` cho 7 workspace shell. KHÔNG đụng `min-width` bảng drill, khối lock 1920x1080, `.office-alerts-grid`, `#setRoleModal`, hero-split.
+ Chuẩn hoá TẤT CẢ ô nhập ngày về `dd/mm/yyyy` (quy ước dự án: Supabase lưu `yyyy-mm-dd`, hiển thị/nhập `dd/mm/yyyy`). Thêm helper dùng chung `dsNormalizeDateFields(root)` + `dsWatchDateFields()` trong `js/modules/utils.js`: quét mọi `input[data-ds-date]`, tự đổi `type=date` → text, gắn `dateMask`, placeholder `dd/mm/yyyy`, thêm nút lịch (tái dùng `vpubWrapDateInput` / `vpubOpenDatePicker` có sẵn), kèm MutationObserver debounce 60ms nên phủ cả các ô sinh động lúc mở modal. Gắn `data-ds-date="1"` cho 7 ô tĩnh trong `index.html` (`dateFrom`, `dateTo`, `activityDateFilter`, `extendNewDate`, `action100EditDue`, `action100EditCompleted`, `mttqKpiDeadline`) và 8 ô trong template JS (Văn phòng add, `addDeadline`/`addCompletedDate`, `provinceAddDeadline`/`provinceAddCompleted`, `action100Deadline`/`action100Completed`).
+ Fix kèm theo khi chuẩn hoá ngày: (a) `action100EditDue`/`action100EditCompleted` ở chế độ KH100 trước bị gán `formatDate()` (dd/mm/yyyy) vào `type=date` → trình duyệt từ chối, ô TRẮNG và lưu mất hạn; nay là text nên hiển thị đúng. (b) `ttbtvPickerDeadline` (ttbtv.js) và `bchPickerDeadline` (legacy.js) ghi `dd-mm-yyyy` → đổi sang `/`. (c) placeholder `bchFDeadline` `dd-mm-yyyy` → `dd/mm/yyyy`. (d) `filterActivityLog` so sánh `created_at.startsWith(date)` sẽ vỡ khi ô sang dd/mm/yyyy → so qua `dateToDb(date)`. (e) `extendNewDate` prefill bằng `formatDate()`, khi lưu đổi `dateToDb(...)` cho `deadline_date` / `patch.deadline` để vẫn ghi đúng ISO vào Supabase. Đã verify mọi đường đọc/ghi (`requireValidDate`, `dateToDb`, `parseDate`, `action100ParseDate`, `provinceDeadlineDate`, `mttqKpiDateDb`) đều nhận cả ISO lẫn dd/mm/yyyy. CSS thêm `.ds-date-wrap` để giữ kích thước ô trong thanh lọc Nhật ký sau khi bỏ `input[type=date]`.
+ TT/BTV popup Cập nhật nhiệm vụ: khi các dòng "Vai trò thực hiện" của Lãnh đạo bắt buộc đã đủ Ngày hoàn thành + Kết quả thì tự lấy Kết quả của Lãnh đạo điền vào ô "Kết quả thực hiện" (chỉ khi ô đang trống, không ghi đè nội dung đã nhập) và ẨN khối `✅ Kết quả thực hiện` để khỏi nhập trùng; xoá trống lại hoặc tick Thường xuyên thì khối hiện lại. Thêm `ttbtvSyncLeaderCompletion(editRoles)` trong `js/modules/ttbtv.js`, gọi trong `refreshTTBTVAutoStatus()` TRƯỚC khi tính trạng thái nên ô "Trạng thái (tự động)" (cùng hàng với "Cơ quan chủ trì") nhảy ngay khi gõ. Dùng đúng luật với `ttbtvGroupKeyFromRoles`: LĐ phòng luôn bắt buộc, thêm LĐ UBND khi Cơ quan chủ trì là UBND xã. Chỉ áp dụng cho popup Cập nhật, không đụng popup Thêm mới.
+ File đổi: `index.html`, `css/style.css`, `js/modules/utils.js`, `js/modules/ttbtv.js`, `js/legacy.js`, `js/main.js`, `CONTEXT.md`
+ Cache bump: `style.css?v=20261018`; `js/main.js`, `js/modules/utils.js`, `js/modules/ttbtv.js`, `js/legacy.js` → `20260961`.
+ Kiểm tra: `node --check js/legacy.js js/store.js js/config.js js/main.js js/modules/*.js` → PASS. Chưa chạy test trình duyệt (cần F5 cứng `Ctrl+Shift+R`).
+ Còn lỗi: không
