// Edge Function: gửi thông báo nhiệm vụ sắp đến hạn
//
// Secrets cần đặt (supabase secrets set ...):
//   RESEND_API_KEY   khóa Resend
//   ADMIN_TOKEN      cùng giá trị với ADMIN_TOKEN trên Vercel
//   MAIL_FROM        người gửi đã xác minh miền trên Resend, ví dụ: "Văn phòng số Mậu A <thongbao@ten-mien-cua-ban.vn>"
//   ALLOWED_ORIGINS  (tùy chọn) danh sách origin được phép, cách nhau bằng dấu phẩy
// SUPABASE_URL và SUPABASE_SERVICE_ROLE_KEY do Supabase tự cấp cho Edge Function.
//
// Chỉ Admin hoặc cán bộ Văn phòng (office_officers) có token hợp lệ mới được gửi.

import { Resend } from "npm:resend@4.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const ADMIN_TOKEN = Deno.env.get("ADMIN_TOKEN") ?? "";
const MAIL_FROM = Deno.env.get("MAIL_FROM") ?? "Văn phòng số Mậu A <onboarding@resend.dev>";
const ORIGINS = (Deno.env.get("ALLOWED_ORIGINS") ?? "").split(",").map((s) => s.trim()).filter(Boolean);

const allowedOrigin = (origin: string | null) => {
  if (!origin) return "";
  if (ORIGINS.length) return ORIGINS.includes(origin) ? origin : "";
  try { return new URL(origin).hostname.endsWith(".vercel.app") ? origin : ""; } catch { return ""; }
};
const corsHeaders = (origin: string | null): Record<string, string> => ({
  "Access-Control-Allow-Origin": allowedOrigin(origin),
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-user-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
});
const escapeHtml = (v: unknown) => String(v ?? "")
  .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;").replaceAll("'", "&#39;");
const clean = (v: unknown, max: number) => String(v ?? "").replace(/[\r\n]+/g, " ").trim().slice(0, max);

async function sha256(s: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function safeEqual(a: string, b: string) { return (await sha256(a)) === (await sha256(b)); }

async function mayJustSend(token: string): Promise<boolean> {
  if (!token || token.length > 200) return false;
  if (ADMIN_TOKEN.length >= 16 && await safeEqual(token, ADMIN_TOKEN)) return true;
  if (!SUPABASE_URL || !SERVICE_KEY) return false;
  const r = await fetch(`${SUPABASE_URL}/rest/v1/office_officers?select=id&token=eq.${encodeURIComponent(token)}&limit=1`, {
    headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}` },
  });
  if (!r.ok) return false;
  const rows = await r.json();
  return Array.isArray(rows) && rows.length > 0;
}

// Giới hạn tần suất theo token (best-effort, trong bộ nhớ instance)
const SENT = new Map<string, number[]>();
function overLimit(token: string) {
  const now = Date.now();
  const arr = (SENT.get(token) ?? []).filter((t) => now - t < 60 * 60 * 1000);
  if (arr.length >= 60) { SENT.set(token, arr); return true; }
  arr.push(now); SENT.set(token, arr);
  if (SENT.size > 2000) SENT.clear();
  return false;
}

Deno.serve(async (request) => {
  const origin = request.headers.get("origin");
  const headers = { ...corsHeaders(origin), "Content-Type": "application/json" };
  const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers });

  if (request.method === "OPTIONS") return new Response("ok", { headers });
  if (request.method !== "POST") return reply(405, { error: "Method not allowed" });
  if (origin && !allowedOrigin(origin)) return reply(403, { error: "Origin not allowed" });

  try {
    const token = (request.headers.get("x-user-token") ?? "").trim();
    if (!(await mayJustSend(token))) return reply(401, { error: "Không có quyền gửi thông báo." });
    if (overLimit(token)) return reply(429, { error: "Đã gửi quá nhiều thông báo trong 1 giờ." });

    const body = await request.json();
    const to = clean(body.to_email, 254);
    const taskName = clean(body.task_name, 300);
    if (!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(to)) return reply(400, { error: "Email người nhận không hợp lệ." });
    if (!taskName) return reply(400, { error: "Thiếu tên nhiệm vụ." });

    const owner = clean(body.owner, 200);
    const deadline = clean(body.deadline, 40);
    const note = clean(body.admin_note, 1000);
    const link = clean(body.attachment_link, 1000);
    const safeLink = /^https:\/\//i.test(link) ? link : "";

    const html = `<h2>Thông báo nhiệm vụ sắp đến hạn</h2>` +
      `<p><b>Nhiệm vụ:</b> ${escapeHtml(taskName)}</p>` +
      `<p><b>Người phụ trách:</b> ${escapeHtml(owner)}</p>` +
      `<p><b>Hạn hoàn thành:</b> ${escapeHtml(deadline)}</p>` +
      (note ? `<p><b>Ghi chú Admin:</b> ${escapeHtml(note)}</p>` : "") +
      (safeLink ? `<p><a href="${escapeHtml(safeLink)}">Xem tệp đính kèm</a></p>` : "");

    const result = await resend.emails.send({ from: MAIL_FROM, to: [to], subject: `Nhiệm vụ sắp đến hạn: ${taskName}`, html });
    if (result.error) throw new Error(result.error.message);
    return reply(200, { ok: true, id: result.data?.id });
  } catch (error) {
    console.error("send-email:", error);
    return reply(500, { error: "Không gửi được email." });
  }
});
