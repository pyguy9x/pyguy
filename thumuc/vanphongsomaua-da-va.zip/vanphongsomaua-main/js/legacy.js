// ===== SUPABASE GLOBALS (fix ReferenceError khi legacy.js nạp qua main.js) =====
// LƯU Ý BẢO MẬT (fix Lỗi 1 REPORT): Hiện dùng anonKey chung cho mọi fetch; phân quyền chỉ ở client (canEdit*).
// Cần bật RLS + tạo policy per scope hoặc proxy write qua Edge Function api/tasks để tránh bypass.
// Giữ tạm guard client canAccessOfficeData/canAddBCH... để giảm rủi ro trước khi có RLS.
var SUPABASE_URL = window.SUPABASE_URL || window.SUPABASE_CONFIG?.url || "https://zipvocbtmilyeuhqqrur.supabase.co";
var SUPABASE_KEY = window.SUPABASE_KEY || window.SUPABASE_CONFIG?.anonKey || "";
window.SUPABASE_URL = SUPABASE_URL; window.SUPABASE_KEY = SUPABASE_KEY;
function safeLSSet(k,v){ try{ localStorage.setItem(k, typeof v==="string"?v:JSON.stringify(v)); }catch(e){ console.warn("LS set fail",k,e); } }
function safeLSGet(k, fallback=null){ try{ const v=localStorage.getItem(k); return v===null?fallback:v; }catch(e){ return fallback; } }
function readCache(baseKey){ try{ const raw=localStorage.getItem(baseKey); return raw?JSON.parse(raw):null; }catch(e){ return null; } }
function writeCache(baseKey, obj){ try{ localStorage.setItem(baseKey, JSON.stringify(obj)); }catch(e){} }
// Mức 2: mã hóa token localStorage để không lộ plain-text trong Application tab
// Chỉ mã hóa field token trong officers_cache (task giữ nguyên)
function _obfOfficers(arr){
  if(!Array.isArray(arr)) return arr;
  return arr.map(o=>{
    if(!o || !o.token) return o;
    try{ return {...o, token: _obfToken(String(o.token))}; }catch(_){ return o; }
  });
}
function _deobfOfficers(arr){
  if(!Array.isArray(arr)) return arr;
  return arr.map(o=>{
    if(!o || !o.token) return o;
    const t = String(o.token);
    // Nếu đã là base64 đảo thì atob thành công và reverse ra pattern CB-/CQ-/ADM-
    try{
      const dec = _deobfToken(t);
      if(/^(CB-|CQ-|ADM-)/.test(dec)) return {...o, token: dec};
      // fallback: token cũ plain không match pattern -> thử deobf, nếu fail giữ plain
      // Nếu dec không match nhưng t khác dec thì vẫn là obf
      if(dec !== t && dec.length>4) return {...o, token: dec};
    }catch(_){}
    return o;
  });
}
function writeOfficersCache(key, arr){ try{ localStorage.setItem(key, JSON.stringify(_obfOfficers(arr))); }catch(e){} try{ writeCache(key, _obfOfficers(arr)); }catch(_){} }
function readOfficersCache(key){
  try{
    const raw = localStorage.getItem(key);
    if(raw){ const arr = JSON.parse(raw); const dec = _deobfOfficers(arr); if(dec!==arr) return dec; return dec; }
  }catch(_){
  }
  try{ const c = readCache(key); if(c) return _deobfOfficers(c); }catch(_){
  }
  return null;
}
// ===== DEMO MODE (?demo=1) - CHE TÊN + CHẶN GHI SUPABASE =====
var DEMO_MODE = false; // Tắt demo để load dữ liệu thật từ DB
window.DEMO_MODE = DEMO_MODE;
var _demoNameMap = new Map();
function demoMaskName(name){
    if(!DEMO_MODE) return name;
    const raw = String(name||'').trim(); if(!raw) return raw;
    if(_demoNameMap.has(raw)) return _demoNameMap.get(raw);
    // ẩn theo cấu trúc họ và tên: giữ ký tự đầu mỗi từ, còn lại thành ***
    const parts = raw.split(/\s+/);
    let masked = parts.map(w=>{
        if(!w) return w;
        const first = w[0];
        // nếu tên chỉ 1 ký tự -> giữ + ***
        if(w.length <= 1) return first + '***';
        return first + '***';
    }).join(' ');
    // đảm bảo không trùng lặp hoàn toàn: thêm hậu tố số nếu đã tồn tại masked
    let uniq = masked, n=2;
    const used = new Set(_demoNameMap.values());
    while(used.has(uniq)){ uniq = masked + ' ' + n; n++; }
    _demoNameMap.set(raw, uniq); return uniq;
}
function demoMaskText(text){
    if(!DEMO_MODE || !text) return text;
    let out = String(text);
    // thay tên dài trước để tránh thay nhầm substring
    const entries = [..._demoNameMap.entries()].sort((a,b)=> b[0].length - a[0].length);
    // nếu chưa có map (chưa render bảng) thì tạo mask tạm cho các tên trong text
    if(!entries.length && out){
        // fallback: mask trực tiếp các cụm họ tên trong text (2-4 từ viết hoa)
        return out;
    }
    entries.forEach(([real, masked])=>{
        if(real && out.includes(real)) out = out.split(real).join(masked);
    });
    return out;
}
// đảm bảo mọi tên gặp lần đầu đều được tạo mask trước khi render text
function demoEnsureNames(names){
    if(!DEMO_MODE || !names) return;
    (Array.isArray(names)?names:[names]).forEach(n=>{ if(n) demoMaskName(n); });
}
function isDemoWriteBlocked(url, method){
    if(!DEMO_MODE) return false;
    const m = String(method||'GET').toUpperCase();
    if(!['POST','PATCH','PUT','DELETE'].includes(m)) return false;
    try{ if(String(url||'').includes('supabase.co')) return true; }catch(e){}
    return false;
}
(function(){
    if(!DEMO_MODE) return;
    const _origFetch = window.fetch.bind(window);
    window.fetch = function(url, opts){
        const method = (opts && opts.method) || 'GET';
        const u = String(url||'');
        if(isDemoWriteBlocked(url, method)){
            console.warn('[DEMO] chặn ghi Supabase:', method, url);
            try{ showToast('info','Chế độ demo','Không ghi dữ liệu thật — chỉ thay đổi trên giao diện.'); }catch(e){}
            return Promise.resolve(new Response(JSON.stringify({ demo:true }), { status:200, headers:{'Content-Type':'application/json'} }));
        }
        if(DEMO_MODE && u.includes('supabase.co')){
            // chặn mọi đọc Supabase trong demo để không rò rỉ tên thật qua Network
            console.warn('[DEMO] chặn đọc Supabase, trả rỗng:', method, url);
            // trả mảng rỗng cho REST, object rỗng cho form khác
            const isRest = u.includes('/rest/v1/');
            return Promise.resolve(new Response(isRest ? JSON.stringify([]) : JSON.stringify({ demo:true }), { status:200, headers:{'Content-Type':'application/json'} }));
        }
        return _origFetch(url, opts);
    };
    // hiện banner + đổi title
    function showDemoBanner(){ const b=document.getElementById('demoBanner'); if(b) b.style.display='block'; try{ document.title='[DEMO] '+document.title; }catch(e){} }
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', showDemoBanner); else showDemoBanner();
    window.addEventListener('load', showDemoBanner);
    // che tên trong cây Tỉnh giao (input [data-k=name]) sau mỗi lần render
    function demoMaskProvinceInputs(){ try{ document.querySelectorAll('#provincePlanTree [data-k=name]').forEach(inp=>{ const v=String(inp.value||'').trim(); if(!v || inp.dataset.demoMasked) return; const m=demoMaskName(v); if(m!==v){ inp.value=m; inp.dataset.demoMasked='1'; } }); }catch(e){} }
    // patch provincePlanLoad nếu có
    setTimeout(()=>{ try{ const orig=window.provincePlanLoad; if(typeof orig==='function' && !orig._demoPatched){ window.provincePlanLoad = async function(){ const r=await orig.apply(this, arguments); demoMaskProvinceInputs(); return r; }; window.provincePlanLoad._demoPatched=true; }
    const orig2=window.renderProvincePlanTree || window.applyProvincePlanTreeFilter; if(typeof window.applyProvincePlanTreeFilter==='function' && !window.applyProvincePlanTreeFilter._demoPatched){ const o=window.applyProvincePlanTreeFilter; window.applyProvincePlanTreeFilter=function(){ const r=o.apply(this, arguments); demoMaskProvinceInputs(); return r; }; window.applyProvincePlanTreeFilter._demoPatched=true; }
    }catch(e){} }, 1200);
    // observer cho cây tỉnh giao
    try{ const obs=new MutationObserver(demoMaskProvinceInputs); const tree=document.getElementById('provincePlanTree'); if(tree) obs.observe(tree,{childList:true,subtree:true}); }catch(e){}
})();
// ===== DEMO SNAPSHOT: ĐỌC LOCAL THAY VÌ SUPABASE KHI ?demo=1 =====
let DEMO_SNAPSHOT_CACHE = null;
// fallback nhúng sẵn để chạy được cả khi mở file:// (file trực tiếp không qua server)
const DEMO_SNAPSHOT_EMBED = {"_meta":{"generated_at":"2026-09-14T04:25:48.427Z","note":"Demo snapshot 20 nhiệm vụ/workspace - tên đã che P*** V***","version":2},"office_tasks":[{"id":9001,"task":"Rà soát kế hoạch tuần 1","owner":"P*** V*** M***","role":"Chuyên viên","due":"2026-09-18","status":"Đang triển khai","product":"Sản phẩm 1","staff_note":"","admin_note":"","attachment_name":"","completed_date":null},{"id":9002,"task":"Chuẩn bị nội dung họp giao ban 2","owner":"N*** T*** M*** T***","role":"Phó Chánh VP","due":"2026-09-20","status":"Quá hạn","product":"Không","staff_note":"Đang xử lý 2","admin_note":"Ghi chú admin 2","attachment_name":"","completed_date":null},{"id":9003,"task":"Tổng hợp báo cáo tháng 9 3","owner":"V*** T*** K*** T***","role":"Văn thư","due":"2026-09-25","status":"Hoàn thành trước hạn","product":"Báo cáo 3.pdf","staff_note":"","admin_note":"Ghi chú admin 3","attachment_name":"File3.pdf","completed_date":"2026-09-15"},{"id":9004,"task":"Cập nhật lịch công tác lãnh đạo 4","owner":"V*** T*** L***","role":"Bí thư","due":"2026-09-30","status":"Hoàn thành đúng hạn","product":"Báo cáo 4.pdf","staff_note":"Đang xử lý 4","admin_note":"","attachment_name":"File4.pdf","completed_date":"2026-09-10"},{"id":9005,"task":"Triển khai hồ sơ cán bộ 5","owner":"L*** A*** M***","role":"Phó Bí thư","due":"2026-10-05","status":"Hoàn thành quá hạn","product":"Báo cáo 5.pdf","staff_note":"","admin_note":"Ghi chú admin 5","attachment_name":"File5.pdf","completed_date":"2026-09-12"},{"id":9006,"task":"Kiểm tra quy chế làm việc 6","owner":"L*** T*** T***","role":"Chuyên viên","due":"2026-10-10","status":"Đang triển khai","product":"Không","staff_note":"Đang xử lý 6","admin_note":"Ghi chú admin 6","attachment_name":"","completed_date":null},{"id":9007,"task":"Tổ chức chuyển đổi số 7","owner":"T*** V*** H***","role":"Phó Chánh VP","due":"2026-10-15","status":"Quá hạn","product":"Sản phẩm 7","staff_note":"","admin_note":"","attachment_name":"","completed_date":null},{"id":9008,"task":"Báo cáo chuẩn bị Đại hội 8","owner":"N*** V*** H***","role":"Văn thư","due":"2026-10-20","status":"Hoàn thành trước hạn","product":"Báo cáo 8.pdf","staff_note":"Đang xử lý 8","admin_note":"Ghi chú admin 8","attachment_name":"File8.pdf","completed_date":"2026-09-10"},{"id":9009,"task":"Xây dựng hội nghị tuyên truyền 9","owner":"T*** V*** A***","role":"Bí thư","due":"2026-09-18","status":"Hoàn thành đúng hạn","product":"Báo cáo 9.pdf","staff_note":"","admin_note":"Ghi chú admin 9","attachment_name":"File9.pdf","completed_date":"2026-09-12"},{"id":9010,"task":"Thẩm định tiến độ NTM 10","owner":"L*** V*** B***","role":"Phó Bí thư","due":"2026-09-20","status":"Hoàn thành quá hạn","product":"Báo cáo 10.pdf","staff_note":"Đang xử lý 10","admin_note":"","attachment_name":"File10.pdf","completed_date":"2026-09-14"},{"id":9011,"task":"Phối hợp quy trình một cửa 11","owner":"P*** T*** C***","role":"Chuyên viên","due":"2026-09-25","status":"Đang triển khai","product":"Không","staff_note":"","admin_note":"Ghi chú admin 11","attachment_name":"","completed_date":null},{"id":9012,"task":"Hoàn thiện hồ sơ số 12","owner":"L*** T*** C***","role":"Phó Chánh VP","due":"2026-09-30","status":"Quá hạn","product":"Không","staff_note":"Đang xử lý 12","admin_note":"Ghi chú admin 12","attachment_name":"","completed_date":null},{"id":9013,"task":"Số hóa kế hoạch KT-XH 13","owner":"N*** T*** T***","role":"Văn thư","due":"2026-10-05","status":"Hoàn thành trước hạn","product":"Báo cáo 13.pdf","staff_note":"","admin_note":"","attachment_name":"File13.pdf","completed_date":"2026-09-12"},{"id":9014,"task":"Tham mưu dự án đầu tư công 14","owner":"V*** T*** L***","role":"Bí thư","due":"2026-10-10","status":"Hoàn thành đúng hạn","product":"Báo cáo 14.pdf","staff_note":"Đang xử lý 14","admin_note":"Ghi chú admin 14","attachment_name":"File14.pdf","completed_date":"2026-09-14"},{"id":9015,"task":"Giám sát Chỉ thị 45 Tỉnh ủy 15","owner":"L*** V*** N***","role":"Phó Bí thư","due":"2026-10-15","status":"Hoàn thành quá hạn","product":"Báo cáo 15.pdf","staff_note":"","admin_note":"Ghi chú admin 15","attachment_name":"File15.pdf","completed_date":"2026-09-15"},{"id":9016,"task":"Vận động Nghị quyết 57 16","owner":"T*** V*** H*** 2","role":"Chuyên viên","due":"2026-10-20","status":"Đang triển khai","product":"Sản phẩm 16","staff_note":"Đang xử lý 16","admin_note":"","attachment_name":"","completed_date":null},{"id":9017,"task":"Tuyên truyền ý kiến cử tri 17","owner":"P*** V*** M***","role":"Phó Chánh VP","due":"2026-09-18","status":"Quá hạn","product":"Không","staff_note":"","admin_note":"Ghi chú admin 17","attachment_name":"","completed_date":null},{"id":9018,"task":"Đánh giá công trình NTM 18","owner":"N*** T*** M*** T***","role":"Văn thư","due":"2026-09-20","status":"Hoàn thành trước hạn","product":"Báo cáo 18.pdf","staff_note":"Đang xử lý 18","admin_note":"Ghi chú admin 18","attachment_name":"File18.pdf","completed_date":"2026-09-14"},{"id":9019,"task":"Kiểm đếm BHYT toàn dân 19","owner":"V*** T*** K*** T***","role":"Bí thư","due":"2026-09-25","status":"Hoàn thành đúng hạn","product":"Báo cáo 19.pdf","staff_note":"","admin_note":"","attachment_name":"File19.pdf","completed_date":"2026-09-15"},{"id":9020,"task":"Lập kế hoạch quản lý đất đai 20","owner":"V*** T*** L***","role":"Phó Bí thư","due":"2026-09-30","status":"Hoàn thành quá hạn","product":"Báo cáo 20.pdf","staff_note":"Đang xử lý 20","admin_note":"Ghi chú admin 20","attachment_name":"File20.pdf","completed_date":"2026-09-10"}],"department_tasks":[{"id":9101,"task":"Phối hợp chuẩn bị hội nghị demo","owner":"L*** T*** T***","role":"Chuyên viên","due":"2026-09-28","status":"Đang triển khai","product":"Kế hoạch hội nghị","staff_note":"","admin_note":"","attachment_name":""}],"officers":[{"id":8001,"name":"P*** V*** M***","title":"Bí thư Đảng ủy","unit":"Văn phòng Đảng ủy"},{"id":8002,"name":"N*** T*** M*** T***","title":"Phó Bí thư","unit":"Văn phòng Đảng ủy"},{"id":8003,"name":"V*** T*** K*** T***","title":"Ủy viên BTV","unit":"Ban Xây dựng Đảng"},{"id":8004,"name":"V*** T*** L***","title":"Chuyên viên","unit":"Văn phòng Đảng ủy"},{"id":8005,"name":"L*** A*** M***","title":"Phó Ban","unit":"Ban Xây dựng Đảng"}],"tasks":[{"id":8101,"task_name":"Rà soát kế hoạch tuần BCH 1","officer_name":"P*** V*** M***","specialist_name":"T*** V*** A***","source_doc":"CV 123","amount":"","deadline":"2026-09-10","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8102,"task_name":"Chuẩn bị nội dung họp giao ban BCH 2","officer_name":"N*** T*** M*** T***","specialist_name":"L*** V*** B***","source_doc":"KH 45","amount":"","deadline":"2026-09-15","completed_date":"2026-09-12","product":"Báo cáo BCH 2","result":"Hoàn thành","statusKey":"done"},{"id":8103,"task_name":"Tổng hợp báo cáo tháng 9 BCH 3","officer_name":"V*** T*** K*** T***","specialist_name":"P*** T*** C***","source_doc":"QĐ 78","amount":"","deadline":"2026-09-30","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8104,"task_name":"Cập nhật lịch công tác lãnh đạo BCH 4","officer_name":"V*** T*** L***","specialist_name":"L*** T*** C***","source_doc":"CT 45","amount":"","deadline":"2026-10-05","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8105,"task_name":"Triển khai hồ sơ cán bộ BCH 5","officer_name":"L*** A*** M***","specialist_name":"N*** T*** T***","source_doc":"CV 200","amount":"","deadline":"2026-10-12","completed_date":"2026-09-12","product":"Báo cáo BCH 5","result":"Hoàn thành","statusKey":"done"},{"id":8106,"task_name":"Kiểm tra quy chế làm việc BCH 6","officer_name":"L*** T*** T***","specialist_name":"T*** V*** A***","source_doc":"CV 123","amount":"","deadline":"2026-09-10","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8107,"task_name":"Tổ chức chuyển đổi số BCH 7","officer_name":"T*** V*** H***","specialist_name":"L*** V*** B***","source_doc":"KH 45","amount":"","deadline":"2026-09-15","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8108,"task_name":"Báo cáo chuẩn bị Đại hội BCH 8","officer_name":"N*** V*** H***","specialist_name":"P*** T*** C***","source_doc":"QĐ 78","amount":"","deadline":"2026-09-30","completed_date":"2026-09-12","product":"Báo cáo BCH 8","result":"Hoàn thành","statusKey":"done"},{"id":8109,"task_name":"Xây dựng hội nghị tuyên truyền BCH 9","officer_name":"T*** V*** A***","specialist_name":"L*** T*** C***","source_doc":"CT 45","amount":"","deadline":"2026-10-05","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8110,"task_name":"Thẩm định tiến độ NTM BCH 10","officer_name":"L*** V*** B***","specialist_name":"N*** T*** T***","source_doc":"CV 200","amount":"","deadline":"2026-10-12","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8111,"task_name":"Phối hợp quy trình một cửa BCH 11","officer_name":"P*** T*** C***","specialist_name":"T*** V*** A***","source_doc":"CV 123","amount":"","deadline":"2026-09-10","completed_date":"2026-09-12","product":"Báo cáo BCH 11","result":"Hoàn thành","statusKey":"done"},{"id":8112,"task_name":"Hoàn thiện hồ sơ số BCH 12","officer_name":"L*** T*** C***","specialist_name":"L*** V*** B***","source_doc":"KH 45","amount":"","deadline":"2026-09-15","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8113,"task_name":"Số hóa kế hoạch KT-XH BCH 13","officer_name":"N*** T*** T***","specialist_name":"P*** T*** C***","source_doc":"QĐ 78","amount":"","deadline":"2026-09-30","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8114,"task_name":"Tham mưu dự án đầu tư công BCH 14","officer_name":"V*** T*** L***","specialist_name":"L*** T*** C***","source_doc":"CT 45","amount":"","deadline":"2026-10-05","completed_date":"2026-09-12","product":"Báo cáo BCH 14","result":"Hoàn thành","statusKey":"done"},{"id":8115,"task_name":"Giám sát Chỉ thị 45 Tỉnh ủy BCH 15","officer_name":"L*** V*** N***","specialist_name":"N*** T*** T***","source_doc":"CV 200","amount":"","deadline":"2026-10-12","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8116,"task_name":"Vận động Nghị quyết 57 BCH 16","officer_name":"T*** V*** H*** 2","specialist_name":"T*** V*** A***","source_doc":"CV 123","amount":"","deadline":"2026-09-10","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8117,"task_name":"Tuyên truyền ý kiến cử tri BCH 17","officer_name":"P*** V*** M***","specialist_name":"L*** V*** B***","source_doc":"KH 45","amount":"","deadline":"2026-09-15","completed_date":"2026-09-12","product":"Báo cáo BCH 17","result":"Hoàn thành","statusKey":"done"},{"id":8118,"task_name":"Đánh giá công trình NTM BCH 18","officer_name":"N*** T*** M*** T***","specialist_name":"P*** T*** C***","source_doc":"QĐ 78","amount":"","deadline":"2026-09-30","completed_date":null,"product":"","result":"Chưa điền","statusKey":"overdue"},{"id":8119,"task_name":"Kiểm đếm BHYT toàn dân BCH 19","officer_name":"V*** T*** K*** T***","specialist_name":"L*** T*** C***","source_doc":"CT 45","amount":"","deadline":"2026-10-05","completed_date":null,"product":"","result":"Đang triển khai","statusKey":"processing"},{"id":8120,"task_name":"Lập kế hoạch quản lý đất đai BCH 20","officer_name":"V*** T*** L***","specialist_name":"N*** T*** T***","source_doc":"CV 200","amount":"","deadline":"2026-10-12","completed_date":"2026-09-12","product":"Báo cáo BCH 20","result":"Hoàn thành","statusKey":"done"}],"tt_btv_tasks":[{"id":8201,"task_name":"Rà soát kế hoạch tuần TTBTV 1","officer_name":"P*** V*** M***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","specialist_name":"V*** T*** K*** T***","deadline":"2026-09-26","completed_date":null,"product":"","result":"","amount":"CV 200","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"processing"},{"id":8202,"task_name":"Chuẩn bị nội dung họp giao ban TTBTV 2","officer_name":"N*** T*** M*** T***","role":"MTTQ","unit_name":"MTTQ","specialist_name":"V*** T*** L***","deadline":"2026-09-12","completed_date":"2026-09-25","product":"Báo cáo TTBTV 2","result":"","amount":"CV 210","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"done"},{"id":8203,"task_name":"Tổng hợp báo cáo tháng 9 TTBTV 3","officer_name":"V*** T*** K*** T***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","specialist_name":"L*** A*** M***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","amount":"CV 220","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"overdue"},{"id":8204,"task_name":"Cập nhật lịch công tác lãnh đạo TTBTV 4","officer_name":"V*** T*** L***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","specialist_name":"L*** T*** T***","deadline":"2026-10-08","completed_date":null,"product":"","result":"","amount":"CV 230","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"regular"},{"id":8205,"task_name":"Triển khai hồ sơ cán bộ TTBTV 5","officer_name":"L*** A*** M***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","specialist_name":"T*** V*** H***","deadline":"2026-09-26","completed_date":null,"product":"","result":"","amount":"CV 200","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"processing"},{"id":8206,"task_name":"Kiểm tra quy chế làm việc TTBTV 6","officer_name":"L*** T*** T***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","specialist_name":"N*** V*** H***","deadline":"2026-09-12","completed_date":"2026-09-25","product":"Báo cáo TTBTV 6","result":"","amount":"CV 210","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"done"},{"id":8207,"task_name":"Tổ chức chuyển đổi số TTBTV 7","officer_name":"T*** V*** H***","role":"MTTQ","unit_name":"MTTQ","specialist_name":"T*** V*** A***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","amount":"CV 220","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"overdue"},{"id":8208,"task_name":"Báo cáo chuẩn bị Đại hội TTBTV 8","officer_name":"N*** V*** H***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","specialist_name":"L*** V*** B***","deadline":"2026-10-08","completed_date":null,"product":"","result":"","amount":"CV 230","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"regular"},{"id":8209,"task_name":"Xây dựng hội nghị tuyên truyền TTBTV 9","officer_name":"T*** V*** A***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","specialist_name":"P*** T*** C***","deadline":"2026-09-26","completed_date":null,"product":"","result":"","amount":"CV 200","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"processing"},{"id":8210,"task_name":"Thẩm định tiến độ NTM TTBTV 10","officer_name":"L*** V*** B***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","specialist_name":"L*** T*** C***","deadline":"2026-09-12","completed_date":"2026-09-25","product":"Báo cáo TTBTV 10","result":"","amount":"CV 210","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"done"},{"id":8211,"task_name":"Phối hợp quy trình một cửa TTBTV 11","officer_name":"P*** T*** C***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","specialist_name":"N*** T*** T***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","amount":"CV 220","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"overdue"},{"id":8212,"task_name":"Hoàn thiện hồ sơ số TTBTV 12","officer_name":"L*** T*** C***","role":"MTTQ","unit_name":"MTTQ","specialist_name":"V*** T*** L***","deadline":"2026-10-08","completed_date":null,"product":"","result":"","amount":"CV 230","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"regular"},{"id":8213,"task_name":"Số hóa kế hoạch KT-XH TTBTV 13","officer_name":"N*** T*** T***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","specialist_name":"L*** V*** N***","deadline":"2026-09-26","completed_date":null,"product":"","result":"","amount":"CV 200","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"processing"},{"id":8214,"task_name":"Tham mưu dự án đầu tư công TTBTV 14","officer_name":"V*** T*** L***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","specialist_name":"T*** V*** H*** 2","deadline":"2026-09-12","completed_date":"2026-09-25","product":"Báo cáo TTBTV 14","result":"","amount":"CV 210","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"done"},{"id":8215,"task_name":"Giám sát Chỉ thị 45 Tỉnh ủy TTBTV 15","officer_name":"L*** V*** N***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","specialist_name":"P*** V*** M***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","amount":"CV 220","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"overdue"},{"id":8216,"task_name":"Vận động Nghị quyết 57 TTBTV 16","officer_name":"T*** V*** H*** 2","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","specialist_name":"N*** T*** M*** T***","deadline":"2026-10-08","completed_date":null,"product":"","result":"","amount":"CV 230","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"regular"},{"id":8217,"task_name":"Tuyên truyền ý kiến cử tri TTBTV 17","officer_name":"P*** V*** M***","role":"MTTQ","unit_name":"MTTQ","specialist_name":"V*** T*** K*** T***","deadline":"2026-09-26","completed_date":null,"product":"","result":"","amount":"CV 200","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"processing"},{"id":8218,"task_name":"Đánh giá công trình NTM TTBTV 18","officer_name":"N*** T*** M*** T***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","specialist_name":"V*** T*** L***","deadline":"2026-09-12","completed_date":"2026-09-25","product":"Báo cáo TTBTV 18","result":"","amount":"CV 210","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"done"},{"id":8219,"task_name":"Kiểm đếm BHYT toàn dân TTBTV 19","officer_name":"V*** T*** K*** T***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","specialist_name":"L*** A*** M***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","amount":"CV 220","ubnd_leader":"N*** V*** H***","ubnd_source":"CV 200/TU","statusKey":"overdue"},{"id":8220,"task_name":"Lập kế hoạch quản lý đất đai TTBTV 20","officer_name":"V*** T*** L***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","specialist_name":"L*** T*** T***","deadline":"2026-10-08","completed_date":null,"product":"","result":"","amount":"CV 230","ubnd_leader":"T*** V*** H***","ubnd_source":"CV 210/TU","statusKey":"regular"}],"tt_btv_officers":[{"id":8211,"name":"P*** V*** M***","title":"Bí thư"},{"id":8212,"name":"N*** T*** M*** T***","title":"Phó Bí thư"},{"id":8213,"name":"V*** T*** K*** T***","title":"Ủy viên"}],"province_tasks":[{"id":8301,"task_name":"Rà soát kế hoạch tuần tỉnh 1","officer_name":"P*** V*** M***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","deadline":"2026-10-05","completed_date":null,"product":"","amount":"CT 45","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"20%","statusKey":"processing"},{"id":8302,"task_name":"Chuẩn bị nội dung họp giao ban tỉnh 2","officer_name":"N*** T*** M*** T***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","deadline":"2026-09-28","completed_date":"2026-09-10","product":"Báo cáo tỉnh 2","amount":"CV 88","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8303,"task_name":"Tổng hợp báo cáo tháng 9 tỉnh 3","officer_name":"V*** T*** K*** T***","role":"Phòng KTHT","unit_name":"Phòng KTHT","deadline":"2026-10-12","completed_date":null,"product":"","amount":"CV 123","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"60%","statusKey":"overdue"},{"id":8304,"task_name":"Cập nhật lịch công tác lãnh đạo tỉnh 4","officer_name":"V*** T*** L***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","deadline":"2026-09-15","completed_date":null,"product":"","amount":"QĐ 12","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"80%","statusKey":"processing"},{"id":8305,"task_name":"Triển khai hồ sơ cán bộ tỉnh 5","officer_name":"L*** A*** M***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","deadline":"2026-10-05","completed_date":"2026-09-20","product":"Báo cáo tỉnh 5","amount":"CT 45","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8306,"task_name":"Kiểm tra quy chế làm việc tỉnh 6","officer_name":"L*** T*** T***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","deadline":"2026-09-28","completed_date":null,"product":"","amount":"CV 88","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"40%","statusKey":"overdue"},{"id":8307,"task_name":"Tổ chức chuyển đổi số tỉnh 7","officer_name":"T*** V*** H***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","deadline":"2026-10-12","completed_date":null,"product":"","amount":"CV 123","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"60%","statusKey":"processing"},{"id":8308,"task_name":"Báo cáo chuẩn bị Đại hội tỉnh 8","officer_name":"N*** V*** H***","role":"Phòng KTHT","unit_name":"Phòng KTHT","deadline":"2026-09-15","completed_date":"2026-09-10","product":"Báo cáo tỉnh 8","amount":"QĐ 12","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8309,"task_name":"Xây dựng hội nghị tuyên truyền tỉnh 9","officer_name":"T*** V*** A***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","deadline":"2026-10-05","completed_date":null,"product":"","amount":"CT 45","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"20%","statusKey":"overdue"},{"id":8310,"task_name":"Thẩm định tiến độ NTM tỉnh 10","officer_name":"L*** V*** B***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","deadline":"2026-09-28","completed_date":null,"product":"","amount":"CV 88","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"40%","statusKey":"processing"},{"id":8311,"task_name":"Phối hợp quy trình một cửa tỉnh 11","officer_name":"P*** T*** C***","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","deadline":"2026-10-12","completed_date":"2026-09-20","product":"Báo cáo tỉnh 11","amount":"CV 123","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8312,"task_name":"Hoàn thiện hồ sơ số tỉnh 12","officer_name":"L*** T*** C***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","deadline":"2026-09-15","completed_date":null,"product":"","amount":"QĐ 12","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"80%","statusKey":"overdue"},{"id":8313,"task_name":"Số hóa kế hoạch KT-XH tỉnh 13","officer_name":"N*** T*** T***","role":"Phòng KTHT","unit_name":"Phòng KTHT","deadline":"2026-10-05","completed_date":null,"product":"","amount":"CT 45","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"20%","statusKey":"processing"},{"id":8314,"task_name":"Tham mưu dự án đầu tư công tỉnh 14","officer_name":"V*** T*** L***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","deadline":"2026-09-28","completed_date":"2026-09-10","product":"Báo cáo tỉnh 14","amount":"CV 88","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8315,"task_name":"Giám sát Chỉ thị 45 Tỉnh ủy tỉnh 15","officer_name":"L*** V*** N***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","deadline":"2026-10-12","completed_date":null,"product":"","amount":"CV 123","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"60%","statusKey":"overdue"},{"id":8316,"task_name":"Vận động Nghị quyết 57 tỉnh 16","officer_name":"T*** V*** H*** 2","role":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","deadline":"2026-09-15","completed_date":null,"product":"","amount":"QĐ 12","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"80%","statusKey":"processing"},{"id":8317,"task_name":"Tuyên truyền ý kiến cử tri tỉnh 17","officer_name":"P*** V*** M***","role":"Phòng NN&MT","unit_name":"Phòng NN&MT","deadline":"2026-10-05","completed_date":"2026-09-20","product":"Báo cáo tỉnh 17","amount":"CT 45","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"},{"id":8318,"task_name":"Đánh giá công trình NTM tỉnh 18","officer_name":"N*** T*** M*** T***","role":"Phòng KTHT","unit_name":"Phòng KTHT","deadline":"2026-09-28","completed_date":null,"product":"","amount":"CV 88","van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01","progress":"40%","statusKey":"overdue"},{"id":8319,"task_name":"Kiểm đếm BHYT toàn dân tỉnh 19","officer_name":"V*** T*** K*** T***","role":"Ban Xây dựng Đảng","unit_name":"Ban Xây dựng Đảng","deadline":"2026-10-12","completed_date":null,"product":"","amount":"CV 123","van_ban_tinh":"Chỉ thị 45","van_ban_xa":"CV 12","progress":"60%","statusKey":"processing"},{"id":8320,"task_name":"Lập kế hoạch quản lý đất đai tỉnh 20","officer_name":"V*** T*** L***","role":"Trung tâm HCC","unit_name":"Trung tâm HCC","deadline":"2026-09-15","completed_date":"2026-09-10","product":"Báo cáo tỉnh 20","amount":"QĐ 12","van_ban_tinh":"CV 88/UBND","van_ban_xa":"BC 05","progress":"100%","statusKey":"done"}],"province_officers":[{"id":8311,"name":"P*** V*** M***","title":"Bí thư"},{"id":8312,"name":"V*** T*** K*** T***","title":"Trưởng phòng"},{"id":8313,"name":"N*** T*** H***","title":"Phó phòng"}],"province_plan_blocks":[{"id":8401,"stt":1,"van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01/ĐU","nhiem_vu":"Nhiệm vụ demo Tỉnh giao 1","blocks":{"mota":"Triển khai nhiệm vụ demo khối 1","agencies":[{"agency":"Văn phòng Đảng ủy","type":"chu_tri","agencyTask":"Chủ trì tổng hợp 1","persons":[{"name":"P*** V*** M***","deadline":"2026-09-30","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 0","reason":""},{"name":"N*** T*** M*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** K*** T***","deadline":"2026-10-05","completed":"","progress":"70%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** L***","deadline":"2026-10-10","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 3","reason":""},{"name":"L*** A*** M***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""}],"pcmList":[]},{"agency":"Phòng Văn hóa","type":"phoi_hop","agencyTask":"Phối hợp tuyên truyền 1","persons":[{"name":"P*** V*** M***","deadline":"2026-09-30","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 0","reason":""},{"name":"N*** T*** M*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** K*** T***","deadline":"2026-10-05","completed":"","progress":"70%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** L***","deadline":"2026-10-10","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 3","reason":""}],"pcmList":[]}]}},{"id":8402,"stt":2,"van_ban_tinh":"CT 45/TU","van_ban_xa":"KH 02/ĐU","nhiem_vu":"Nhiệm vụ demo Tỉnh giao 2","blocks":{"mota":"Triển khai nhiệm vụ demo khối 2","agencies":[{"agency":"Văn phòng Đảng ủy","type":"chu_tri","agencyTask":"Chủ trì tổng hợp 2","persons":[{"name":"L*** T*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"T*** V*** H***","deadline":"2026-10-05","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 6","reason":""},{"name":"N*** V*** H***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""},{"name":"T*** V*** A***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""},{"name":"L*** V*** B***","deadline":"2026-09-28","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 9","reason":""}],"pcmList":[]},{"agency":"Phòng Văn hóa","type":"phoi_hop","agencyTask":"Phối hợp tuyên truyền 2","persons":[{"name":"L*** T*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"T*** V*** H***","deadline":"2026-10-05","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 6","reason":""},{"name":"N*** V*** H***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""},{"name":"T*** V*** A***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""}],"pcmList":[]},{"agency":"Phòng KTHT","type":"phoi_hop","agencyTask":"Thẩm định kỹ thuật 2","persons":[{"name":"L*** T*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"T*** V*** H***","deadline":"2026-10-05","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 6","reason":""},{"name":"N*** V*** H***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""}],"pcmList":[]}]}},{"id":8403,"stt":3,"van_ban_tinh":"CV 200/TU","van_ban_xa":"CV 12/ĐU","nhiem_vu":"Nhiệm vụ demo Tỉnh giao 3","blocks":{"mota":"Triển khai nhiệm vụ demo khối 3","agencies":[{"agency":"Văn phòng Đảng ủy","type":"chu_tri","agencyTask":"Chủ trì tổng hợp 3","persons":[{"name":"P*** T*** C***","deadline":"2026-10-05","completed":"","progress":"70%","statusKey":"processing","product":"","reason":""},{"name":"L*** T*** C***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""},{"name":"N*** T*** T***","deadline":"2026-09-30","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 12","reason":""},{"name":"V*** T*** L***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"L*** V*** N***","deadline":"2026-10-05","completed":"","progress":"70%","statusKey":"processing","product":"","reason":""}],"pcmList":[]},{"agency":"Phòng Văn hóa","type":"phoi_hop","agencyTask":"Phối hợp tuyên truyền 3","persons":[{"name":"P*** T*** C***","deadline":"2026-10-05","completed":"","progress":"70%","statusKey":"processing","product":"","reason":""},{"name":"L*** T*** C***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""},{"name":"N*** T*** T***","deadline":"2026-09-30","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 12","reason":""},{"name":"V*** T*** L***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""}],"pcmList":[]}]}},{"id":8404,"stt":4,"van_ban_tinh":"CV 123/TU","van_ban_xa":"KH 01/ĐU","nhiem_vu":"Nhiệm vụ demo Tỉnh giao 4","blocks":{"mota":"Triển khai nhiệm vụ demo khối 4","agencies":[{"agency":"Văn phòng Đảng ủy","type":"chu_tri","agencyTask":"Chủ trì tổng hợp 4","persons":[{"name":"T*** V*** H*** 2","deadline":"2026-10-10","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 15","reason":""},{"name":"P*** V*** M***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""},{"name":"N*** T*** M*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** K*** T***","deadline":"2026-10-05","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 18","reason":""},{"name":"V*** T*** L***","deadline":"2026-10-10","completed":"","progress":"90%","statusKey":"processing","product":"","reason":""}],"pcmList":[]},{"agency":"Phòng Văn hóa","type":"phoi_hop","agencyTask":"Phối hợp tuyên truyền 4","persons":[{"name":"T*** V*** H*** 2","deadline":"2026-10-10","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 15","reason":""},{"name":"P*** V*** M***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""},{"name":"N*** T*** M*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""},{"name":"V*** T*** K*** T***","deadline":"2026-10-05","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 18","reason":""}],"pcmList":[]},{"agency":"Phòng KTHT","type":"phoi_hop","agencyTask":"Thẩm định kỹ thuật 4","persons":[{"name":"T*** V*** H*** 2","deadline":"2026-10-10","completed":"2026-09-25","progress":"100%","statusKey":"done","product":"Sản phẩm 15","reason":""},{"name":"P*** V*** M***","deadline":"2026-09-30","completed":"","progress":"30%","statusKey":"overdue","product":"","reason":""},{"name":"N*** T*** M*** T***","deadline":"2026-09-28","completed":"","progress":"50%","statusKey":"processing","product":"","reason":""}],"pcmList":[]}]}}],"action_100_days_tasks":[{"id":8501,"task_name":"Rà soát kế hoạch tuần KH100 1","commune_leader":"Ban Xây dựng Đảng","unit_name":"Trung tâm HCC","office_leader":"P*** V*** M***","xa_leader":"N*** T*** M*** T***","officer_name":"V*** T*** K*** T***","specialist_name":"V*** T*** L***","deadline":"2026-10-10","completed_date":null,"product":"","result":"","statusKey":"processing"},{"id":8502,"task_name":"Chuẩn bị nội dung họp giao ban KH100 2","commune_leader":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","office_leader":"N*** T*** M*** T***","xa_leader":"V*** T*** K*** T***","officer_name":"V*** T*** L***","specialist_name":"L*** A*** M***","deadline":"2026-09-18","completed_date":"2026-09-17","product":"Hồ sơ 2","result":"","statusKey":"done"},{"id":8503,"task_name":"Tổng hợp báo cáo tháng 9 KH100 3","commune_leader":"UBND xã","unit_name":"Phòng KTHT","office_leader":"V*** T*** K*** T***","xa_leader":"V*** T*** L***","officer_name":"L*** A*** M***","specialist_name":"L*** T*** T***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","statusKey":"overdue"},{"id":8504,"task_name":"Cập nhật lịch công tác lãnh đạo KH100 4","commune_leader":"MTTQ","unit_name":"Trung tâm HCC","office_leader":"V*** T*** L***","xa_leader":"L*** A*** M***","officer_name":"L*** T*** T***","specialist_name":"T*** V*** H***","deadline":"2026-09-30","completed_date":null,"product":"","result":"","statusKey":"regular"},{"id":8505,"task_name":"Triển khai hồ sơ cán bộ KH100 5","commune_leader":"Ban Xây dựng Đảng","unit_name":"Văn phòng Đảng ủy","office_leader":"L*** A*** M***","xa_leader":"L*** T*** T***","officer_name":"T*** V*** H***","specialist_name":"N*** V*** H***","deadline":"2026-10-10","completed_date":null,"product":"","result":"","statusKey":"planned"},{"id":8506,"task_name":"Kiểm tra quy chế làm việc KH100 6","commune_leader":"Văn phòng Đảng ủy","unit_name":"Phòng KTHT","office_leader":"L*** T*** T***","xa_leader":"T*** V*** H***","officer_name":"N*** V*** H***","specialist_name":"T*** V*** A***","deadline":"2026-09-18","completed_date":null,"product":"","result":"","statusKey":"processing"},{"id":8507,"task_name":"Tổ chức chuyển đổi số KH100 7","commune_leader":"UBND xã","unit_name":"Trung tâm HCC","office_leader":"T*** V*** H***","xa_leader":"N*** V*** H***","officer_name":"T*** V*** A***","specialist_name":"L*** V*** B***","deadline":"2026-10-01","completed_date":"2026-09-17","product":"Hồ sơ 7","result":"","statusKey":"done"},{"id":8508,"task_name":"Báo cáo chuẩn bị Đại hội KH100 8","commune_leader":"MTTQ","unit_name":"Văn phòng Đảng ủy","office_leader":"N*** V*** H***","xa_leader":"T*** V*** A***","officer_name":"L*** V*** B***","specialist_name":"P*** T*** C***","deadline":"2026-09-30","completed_date":null,"product":"","result":"","statusKey":"overdue"},{"id":8509,"task_name":"Xây dựng hội nghị tuyên truyền KH100 9","commune_leader":"Ban Xây dựng Đảng","unit_name":"Phòng KTHT","office_leader":"T*** V*** A***","xa_leader":"L*** V*** B***","officer_name":"P*** T*** C***","specialist_name":"L*** T*** C***","deadline":"2026-10-10","completed_date":null,"product":"","result":"","statusKey":"regular"},{"id":8510,"task_name":"Thẩm định tiến độ NTM KH100 10","commune_leader":"Văn phòng Đảng ủy","unit_name":"Trung tâm HCC","office_leader":"L*** V*** B***","xa_leader":"P*** T*** C***","officer_name":"L*** T*** C***","specialist_name":"N*** T*** T***","deadline":"2026-09-18","completed_date":null,"product":"","result":"","statusKey":"planned"},{"id":8511,"task_name":"Phối hợp quy trình một cửa KH100 11","commune_leader":"UBND xã","unit_name":"Văn phòng Đảng ủy","office_leader":"P*** T*** C***","xa_leader":"L*** T*** C***","officer_name":"N*** T*** T***","specialist_name":"V*** T*** L***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","statusKey":"processing"},{"id":8512,"task_name":"Hoàn thiện hồ sơ số KH100 12","commune_leader":"MTTQ","unit_name":"Phòng KTHT","office_leader":"L*** T*** C***","xa_leader":"N*** T*** T***","officer_name":"V*** T*** L***","specialist_name":"L*** V*** N***","deadline":"2026-09-30","completed_date":"2026-09-17","product":"Hồ sơ 12","result":"","statusKey":"done"},{"id":8513,"task_name":"Số hóa kế hoạch KT-XH KH100 13","commune_leader":"Ban Xây dựng Đảng","unit_name":"Trung tâm HCC","office_leader":"N*** T*** T***","xa_leader":"V*** T*** L***","officer_name":"L*** V*** N***","specialist_name":"T*** V*** H*** 2","deadline":"2026-10-10","completed_date":null,"product":"","result":"","statusKey":"overdue"},{"id":8514,"task_name":"Tham mưu dự án đầu tư công KH100 14","commune_leader":"Văn phòng Đảng ủy","unit_name":"Văn phòng Đảng ủy","office_leader":"V*** T*** L***","xa_leader":"L*** V*** N***","officer_name":"T*** V*** H*** 2","specialist_name":"P*** V*** M***","deadline":"2026-09-18","completed_date":null,"product":"","result":"","statusKey":"regular"},{"id":8515,"task_name":"Giám sát Chỉ thị 45 Tỉnh ủy KH100 15","commune_leader":"UBND xã","unit_name":"Phòng KTHT","office_leader":"L*** V*** N***","xa_leader":"T*** V*** H*** 2","officer_name":"P*** V*** M***","specialist_name":"N*** T*** M*** T***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","statusKey":"planned"},{"id":8516,"task_name":"Vận động Nghị quyết 57 KH100 16","commune_leader":"MTTQ","unit_name":"Trung tâm HCC","office_leader":"T*** V*** H*** 2","xa_leader":"P*** V*** M***","officer_name":"N*** T*** M*** T***","specialist_name":"V*** T*** K*** T***","deadline":"2026-09-30","completed_date":null,"product":"","result":"","statusKey":"processing"},{"id":8517,"task_name":"Tuyên truyền ý kiến cử tri KH100 17","commune_leader":"Ban Xây dựng Đảng","unit_name":"Văn phòng Đảng ủy","office_leader":"P*** V*** M***","xa_leader":"N*** T*** M*** T***","officer_name":"V*** T*** K*** T***","specialist_name":"V*** T*** L***","deadline":"2026-10-10","completed_date":"2026-09-17","product":"Hồ sơ 17","result":"","statusKey":"done"},{"id":8518,"task_name":"Đánh giá công trình NTM KH100 18","commune_leader":"Văn phòng Đảng ủy","unit_name":"Phòng KTHT","office_leader":"N*** T*** M*** T***","xa_leader":"V*** T*** K*** T***","officer_name":"V*** T*** L***","specialist_name":"L*** A*** M***","deadline":"2026-09-18","completed_date":null,"product":"","result":"","statusKey":"overdue"},{"id":8519,"task_name":"Kiểm đếm BHYT toàn dân KH100 19","commune_leader":"UBND xã","unit_name":"Trung tâm HCC","office_leader":"V*** T*** K*** T***","xa_leader":"V*** T*** L***","officer_name":"L*** A*** M***","specialist_name":"L*** T*** T***","deadline":"2026-10-01","completed_date":null,"product":"","result":"","statusKey":"regular"},{"id":8520,"task_name":"Lập kế hoạch quản lý đất đai KH100 20","commune_leader":"MTTQ","unit_name":"Văn phòng Đảng ủy","office_leader":"V*** T*** L***","xa_leader":"L*** A*** M***","officer_name":"L*** T*** T***","specialist_name":"T*** V*** H***","deadline":"2026-09-30","completed_date":null,"product":"","result":"","statusKey":"planned"}],"action_100_days_officers":[{"id":8511,"name":"T*** V*** H***","title":"Phó Chủ tịch"},{"id":8512,"name":"N*** V*** H***","title":"Trưởng phòng"}],"vpub_tasks":[{"id":8601,"task_name":"Rà soát kế hoạch tuần VPUB 1","unit":"Phòng KTHT","field":"Phòng Văn hóa","leader":"P*** V*** M***","office_leader":"N*** T*** M*** T***","source":"CV 300/UBND","ubnd_source":"CV 300","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"Khó khăn 0","proposal":"Đề xuất 0","product":"","statusKey":"processing"},{"id":8602,"task_name":"Chuẩn bị nội dung họp giao ban VPUB 2","unit":"BQL DA","field":"Phòng NN&MT","leader":"N*** T*** M*** T***","office_leader":"V*** T*** K*** T***","source":"CV 310/UBND","ubnd_source":"CV 310","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"","proposal":"","product":"Báo cáo VPUB 2","statusKey":"done"},{"id":8603,"task_name":"Tổng hợp báo cáo tháng 9 VPUB 3","unit":"Phòng Văn hóa","field":"Trung tâm HCC","leader":"V*** T*** K*** T***","office_leader":"V*** T*** L***","source":"CV 320/UBND","ubnd_source":"CV 300","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"overdue"},{"id":8604,"task_name":"Cập nhật lịch công tác lãnh đạo VPUB 4","unit":"Trung tâm HCC","field":"Phòng Văn hóa","leader":"V*** T*** L***","office_leader":"L*** A*** M***","source":"CV 300/UBND","ubnd_source":"CV 310","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"processing"},{"id":8605,"task_name":"Triển khai hồ sơ cán bộ VPUB 5","unit":"Phòng KTHT","field":"Phòng NN&MT","leader":"L*** A*** M***","office_leader":"L*** T*** T***","source":"CV 310/UBND","ubnd_source":"CV 300","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"Khó khăn 4","proposal":"","product":"Báo cáo VPUB 5","statusKey":"done"},{"id":8606,"task_name":"Kiểm tra quy chế làm việc VPUB 6","unit":"BQL DA","field":"Trung tâm HCC","leader":"L*** T*** T***","office_leader":"T*** V*** H***","source":"CV 320/UBND","ubnd_source":"CV 310","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"","proposal":"Đề xuất 5","product":"","statusKey":"overdue"},{"id":8607,"task_name":"Tổ chức chuyển đổi số VPUB 7","unit":"Phòng Văn hóa","field":"Phòng Văn hóa","leader":"T*** V*** H***","office_leader":"N*** V*** H***","source":"CV 300/UBND","ubnd_source":"CV 300","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"processing"},{"id":8608,"task_name":"Báo cáo chuẩn bị Đại hội VPUB 8","unit":"Trung tâm HCC","field":"Phòng NN&MT","leader":"N*** V*** H***","office_leader":"T*** V*** A***","source":"CV 310/UBND","ubnd_source":"CV 310","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"","proposal":"","product":"Báo cáo VPUB 8","statusKey":"done"},{"id":8609,"task_name":"Xây dựng hội nghị tuyên truyền VPUB 9","unit":"Phòng KTHT","field":"Trung tâm HCC","leader":"T*** V*** A***","office_leader":"L*** V*** B***","source":"CV 320/UBND","ubnd_source":"CV 300","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"Khó khăn 8","proposal":"","product":"","statusKey":"overdue"},{"id":8610,"task_name":"Thẩm định tiến độ NTM VPUB 10","unit":"BQL DA","field":"Phòng Văn hóa","leader":"L*** V*** B***","office_leader":"P*** T*** C***","source":"CV 300/UBND","ubnd_source":"CV 310","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"processing"},{"id":8611,"task_name":"Phối hợp quy trình một cửa VPUB 11","unit":"Phòng Văn hóa","field":"Phòng NN&MT","leader":"P*** T*** C***","office_leader":"L*** T*** C***","source":"CV 310/UBND","ubnd_source":"CV 300","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"","proposal":"Đề xuất 10","product":"Báo cáo VPUB 11","statusKey":"done"},{"id":8612,"task_name":"Hoàn thiện hồ sơ số VPUB 12","unit":"Trung tâm HCC","field":"Trung tâm HCC","leader":"L*** T*** C***","office_leader":"N*** T*** T***","source":"CV 320/UBND","ubnd_source":"CV 310","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"overdue"},{"id":8613,"task_name":"Số hóa kế hoạch KT-XH VPUB 13","unit":"Phòng KTHT","field":"Phòng Văn hóa","leader":"N*** T*** T***","office_leader":"V*** T*** L***","source":"CV 300/UBND","ubnd_source":"CV 300","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"Khó khăn 12","proposal":"","product":"","statusKey":"processing"},{"id":8614,"task_name":"Tham mưu dự án đầu tư công VPUB 14","unit":"BQL DA","field":"Phòng NN&MT","leader":"V*** T*** L***","office_leader":"L*** V*** N***","source":"CV 310/UBND","ubnd_source":"CV 310","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"","proposal":"","product":"Báo cáo VPUB 14","statusKey":"done"},{"id":8615,"task_name":"Giám sát Chỉ thị 45 Tỉnh ủy VPUB 15","unit":"Phòng Văn hóa","field":"Trung tâm HCC","leader":"L*** V*** N***","office_leader":"T*** V*** H*** 2","source":"CV 320/UBND","ubnd_source":"CV 300","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"overdue"},{"id":8616,"task_name":"Vận động Nghị quyết 57 VPUB 16","unit":"Trung tâm HCC","field":"Phòng Văn hóa","leader":"T*** V*** H*** 2","office_leader":"P*** V*** M***","source":"CV 300/UBND","ubnd_source":"CV 310","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"","proposal":"Đề xuất 15","product":"","statusKey":"processing"},{"id":8617,"task_name":"Tuyên truyền ý kiến cử tri VPUB 17","unit":"Phòng KTHT","field":"Phòng NN&MT","leader":"P*** V*** M***","office_leader":"N*** T*** M*** T***","source":"CV 310/UBND","ubnd_source":"CV 300","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"Khó khăn 16","proposal":"","product":"Báo cáo VPUB 17","statusKey":"done"},{"id":8618,"task_name":"Đánh giá công trình NTM VPUB 18","unit":"BQL DA","field":"Trung tâm HCC","leader":"N*** T*** M*** T***","office_leader":"V*** T*** K*** T***","source":"CV 320/UBND","ubnd_source":"CV 310","start_date":"2026-09-10","deadline":"2026-10-12","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"overdue"},{"id":8619,"task_name":"Kiểm đếm BHYT toàn dân VPUB 19","unit":"Phòng Văn hóa","field":"Phòng Văn hóa","leader":"V*** T*** K*** T***","office_leader":"V*** T*** L***","source":"CV 300/UBND","ubnd_source":"CV 300","start_date":"2026-09-01","deadline":"2026-10-01","weekly_result":"Đang triển khai","difficulties":"","proposal":"","product":"","statusKey":"processing"},{"id":8620,"task_name":"Lập kế hoạch quản lý đất đai VPUB 20","unit":"Trung tâm HCC","field":"Phòng NN&MT","leader":"V*** T*** L***","office_leader":"L*** A*** M***","source":"CV 310/UBND","ubnd_source":"CV 310","start_date":"2026-09-05","deadline":"2026-09-20","weekly_result":"Hoàn thành","difficulties":"","proposal":"","product":"Báo cáo VPUB 20","statusKey":"done"}],"mttq_kpi_people":[{"id":"p1","name":"T*** V*** H***","title":"Chủ tịch MTTQ"},{"id":"p2","name":"N*** T*** T***","title":"Phó Chủ tịch"},{"id":"p3","name":"P*** T*** Q***","title":"Ủy viên"},{"id":"p4","name":"L*** V*** M***","title":"Cán bộ"}],"mttq_kpi_catalog":[{"id":"c1","task_name":"Vận động nhân dân tham gia BHYT","level":2,"kpi_axis":"Trục 1"},{"id":"c2","task_name":"Giám sát NTM","level":1,"kpi_axis":"Trục 2"}],"mttq_kpi_tasks":[{"id":"m1","person_id":"p1","task_name":"Rà soát kế hoạch tuần MTTQ 1","assigner":"P*** V*** M***","deadline":"15/09/2026","outcome":"","quality_errors":0,"level":1,"conversion_factor":1,"product":"","kpi_axis":"Trục 1","note":"","task_month":9,"task_year":2026},{"id":"m2","person_id":"p2","task_name":"Chuẩn bị nội dung họp giao ban MTTQ 2","assigner":"N*** T*** M*** T***","deadline":"20/09/2026","outcome":"Đúng hạn","quality_errors":1,"level":2,"conversion_factor":1,"product":"Sản phẩm MTTQ 2","kpi_axis":"Trục 2","note":"Ghi chú 1","task_month":10,"task_year":2026},{"id":"m3","person_id":"p3","task_name":"Tổng hợp báo cáo tháng 9 MTTQ 3","assigner":"V*** T*** K*** T***","deadline":"25/09/2026","outcome":"Trước hạn","quality_errors":2,"level":3,"conversion_factor":1,"product":"Sản phẩm MTTQ 3","kpi_axis":"Trục 3","note":"","task_month":11,"task_year":2026},{"id":"m4","person_id":"p4","task_name":"Cập nhật lịch công tác lãnh đạo MTTQ 4","assigner":"V*** T*** L***","deadline":"30/09/2026","outcome":"Quá hạn","quality_errors":0,"level":4,"conversion_factor":1,"product":"Sản phẩm MTTQ 4","kpi_axis":"Trục 1","note":"Ghi chú 3","task_month":12,"task_year":2026},{"id":"m5","person_id":"p1","task_name":"Triển khai hồ sơ cán bộ MTTQ 5","assigner":"L*** A*** M***","deadline":"05/10/2026","outcome":"Không hoàn thành","quality_errors":1,"level":1,"conversion_factor":1,"product":"Sản phẩm MTTQ 5","kpi_axis":"Trục 2","note":"","task_month":9,"task_year":2026},{"id":"m6","person_id":"p2","task_name":"Kiểm tra quy chế làm việc MTTQ 6","assigner":"L*** T*** T***","deadline":"15/09/2026","outcome":"","quality_errors":2,"level":2,"conversion_factor":1,"product":"","kpi_axis":"Trục 3","note":"Ghi chú 5","task_month":10,"task_year":2026},{"id":"m7","person_id":"p3","task_name":"Tổ chức chuyển đổi số MTTQ 7","assigner":"T*** V*** H***","deadline":"20/09/2026","outcome":"Đúng hạn","quality_errors":0,"level":3,"conversion_factor":1,"product":"Sản phẩm MTTQ 7","kpi_axis":"Trục 1","note":"","task_month":11,"task_year":2026},{"id":"m8","person_id":"p4","task_name":"Báo cáo chuẩn bị Đại hội MTTQ 8","assigner":"N*** V*** H***","deadline":"25/09/2026","outcome":"Trước hạn","quality_errors":1,"level":4,"conversion_factor":1,"product":"Sản phẩm MTTQ 8","kpi_axis":"Trục 2","note":"Ghi chú 7","task_month":12,"task_year":2026},{"id":"m9","person_id":"p1","task_name":"Xây dựng hội nghị tuyên truyền MTTQ 9","assigner":"T*** V*** A***","deadline":"30/09/2026","outcome":"Quá hạn","quality_errors":2,"level":1,"conversion_factor":1,"product":"Sản phẩm MTTQ 9","kpi_axis":"Trục 3","note":"","task_month":9,"task_year":2026},{"id":"m10","person_id":"p2","task_name":"Thẩm định tiến độ NTM MTTQ 10","assigner":"L*** V*** B***","deadline":"05/10/2026","outcome":"Không hoàn thành","quality_errors":0,"level":2,"conversion_factor":1,"product":"Sản phẩm MTTQ 10","kpi_axis":"Trục 1","note":"Ghi chú 9","task_month":10,"task_year":2026},{"id":"m11","person_id":"p3","task_name":"Phối hợp quy trình một cửa MTTQ 11","assigner":"P*** T*** C***","deadline":"15/09/2026","outcome":"","quality_errors":1,"level":3,"conversion_factor":1,"product":"","kpi_axis":"Trục 2","note":"","task_month":11,"task_year":2026},{"id":"m12","person_id":"p4","task_name":"Hoàn thiện hồ sơ số MTTQ 12","assigner":"L*** T*** C***","deadline":"20/09/2026","outcome":"Đúng hạn","quality_errors":2,"level":4,"conversion_factor":1,"product":"Sản phẩm MTTQ 12","kpi_axis":"Trục 3","note":"Ghi chú 11","task_month":12,"task_year":2026},{"id":"m13","person_id":"p1","task_name":"Số hóa kế hoạch KT-XH MTTQ 13","assigner":"N*** T*** T***","deadline":"25/09/2026","outcome":"Trước hạn","quality_errors":0,"level":1,"conversion_factor":1,"product":"Sản phẩm MTTQ 13","kpi_axis":"Trục 1","note":"","task_month":9,"task_year":2026},{"id":"m14","person_id":"p2","task_name":"Tham mưu dự án đầu tư công MTTQ 14","assigner":"V*** T*** L***","deadline":"30/09/2026","outcome":"Quá hạn","quality_errors":1,"level":2,"conversion_factor":1,"product":"Sản phẩm MTTQ 14","kpi_axis":"Trục 2","note":"Ghi chú 13","task_month":10,"task_year":2026},{"id":"m15","person_id":"p3","task_name":"Giám sát Chỉ thị 45 Tỉnh ủy MTTQ 15","assigner":"L*** V*** N***","deadline":"05/10/2026","outcome":"Không hoàn thành","quality_errors":2,"level":3,"conversion_factor":1,"product":"Sản phẩm MTTQ 15","kpi_axis":"Trục 3","note":"","task_month":11,"task_year":2026},{"id":"m16","person_id":"p4","task_name":"Vận động Nghị quyết 57 MTTQ 16","assigner":"T*** V*** H*** 2","deadline":"15/09/2026","outcome":"","quality_errors":0,"level":4,"conversion_factor":1,"product":"","kpi_axis":"Trục 1","note":"Ghi chú 15","task_month":12,"task_year":2026},{"id":"m17","person_id":"p1","task_name":"Tuyên truyền ý kiến cử tri MTTQ 17","assigner":"P*** V*** M***","deadline":"20/09/2026","outcome":"Đúng hạn","quality_errors":1,"level":1,"conversion_factor":1,"product":"Sản phẩm MTTQ 17","kpi_axis":"Trục 2","note":"","task_month":9,"task_year":2026},{"id":"m18","person_id":"p2","task_name":"Đánh giá công trình NTM MTTQ 18","assigner":"N*** T*** M*** T***","deadline":"25/09/2026","outcome":"Trước hạn","quality_errors":2,"level":2,"conversion_factor":1,"product":"Sản phẩm MTTQ 18","kpi_axis":"Trục 3","note":"Ghi chú 17","task_month":10,"task_year":2026},{"id":"m19","person_id":"p3","task_name":"Kiểm đếm BHYT toàn dân MTTQ 19","assigner":"V*** T*** K*** T***","deadline":"30/09/2026","outcome":"Quá hạn","quality_errors":0,"level":3,"conversion_factor":1,"product":"Sản phẩm MTTQ 19","kpi_axis":"Trục 1","note":"","task_month":11,"task_year":2026},{"id":"m20","person_id":"p4","task_name":"Lập kế hoạch quản lý đất đai MTTQ 20","assigner":"V*** T*** L***","deadline":"05/10/2026","outcome":"Không hoàn thành","quality_errors":1,"level":4,"conversion_factor":1,"product":"Sản phẩm MTTQ 20","kpi_axis":"Trục 2","note":"Ghi chú 19","task_month":12,"task_year":2026}]};
async function getDemoSnapshot(){
    if(DEMO_SNAPSHOT_CACHE) return DEMO_SNAPSHOT_CACHE;
    // thử 3 đường dẫn khác nhau để tránh lỗi khi chạy ở subfolder
    const tryUrls = ['data/demo-snapshot.json','./data/demo-snapshot.json','/data/demo-snapshot.json'];
    for(const u of tryUrls){
        try{
            const r = await fetch(u, { cache:'no-store' });
            if(r.ok){ const j = await r.json(); DEMO_SNAPSHOT_CACHE = j; return j; }
        }catch(e){}
    }
    console.warn('[DEMO] fetch snapshot thất bại (có thể mở file:// hoặc chưa chạy server), dùng bản nhúng');
    try{ showToast('info','Demo offline','Dùng dữ liệu mẫu nhúng sẵn - không cần server'); }catch(_){}
    DEMO_SNAPSHOT_CACHE = DEMO_SNAPSHOT_EMBED;
    return DEMO_SNAPSHOT_EMBED;
}

// ===== GỠ SW CŨ vps-maua-v1 (dự phòng khi killer sw.js chưa kịp cài) =====
try {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.getRegistrations().then((rs) => rs.forEach((r) => r.unregister())).catch(() => {});
  }
  if (window.caches && caches.keys) {
    caches.keys().then((keys) => keys.filter((k) => k.indexOf("vps-maua") === 0).forEach((k) => caches.delete(k))).catch(() => {});
  }
} catch (e) {}

// ===== ĐĂNG NHẬP TOKEN / PHÂN QUYỀN DEMO =====
// Xác thực duy nhất qua POST /api/admin; không có token nào được viết cứng trong mã nguồn.
// Bản triển khai thật nên dùng Supabase Auth + RLS; token demo này chỉ dùng cho file trình diễn. Đã bật RLS
// const ADMIN_TOKEN = ["ADM", "MAUA", "adm"].join("-");
// Token thật đã chuyển lên Supabase (4 bảng: officers, tt_btv_officers, province_officers, office_officers)
// Không hardcode token trong source để tránh lộ khi người khác đọc code.
// Xác thực duy nhất qua POST /api/admin (server dùng SERVICE_ROLE_KEY tra DB, giữ nguyên giá trị, không xóa data cũ).
const STAFF_TOKENS = {};
const MTTQ_TOKENS = {};
const MTTQ_ADMIN_TOKEN = "YOUR_MTTQ_ADMIN_TOKEN"; // cờ mttqAdmin do server (/api/admin) trả về, không so sánh token ở client
const DEPARTMENT_TOKENS = {};
const STAFF_ACTION100_TOKENS = {};
const BCH_FULL_TOKENS = new Set();
const BCH_BROAD_TOKENS = new Set();
const TTBTV_ALLOWED_TOKENS = new Set();
let CURRENT_USER = null;
let editingDataIndex = -1;
window.OFFICE_EDIT_ID = null;
// Tối ưu JS giữ hiệu ứng đẹp: debounce + requestIdleCallback + Map cache
function debounce(fn, wait){ let t; return function(...a){ clearTimeout(t); t=setTimeout(()=>fn.apply(this,a), wait); }; }
const idleSave = (cb)=> (window.requestIdleCallback ? requestIdleCallback(cb, {timeout:800}) : setTimeout(cb, 300));
let _homeFilteredCache=null, _homeFilteredAt=0;
let _idToIdxMap=null;
if(window.Chart) try{ Chart.defaults.devicePixelRatio = Math.min(window.devicePixelRatio||1, 1.5); Chart.defaults.animation = Chart.defaults.animation || {}; Chart.defaults.animation.duration = 400; }catch(e){}
// === Bộ lọc thời gian chung Tuần/Tháng/Quý ===
function getTimeRange(mode){
  const now=new Date(); now.setHours(0,0,0,0);
  if(mode==='week'){ const day=now.getDay()||7; const from=new Date(now); from.setDate(now.getDate()-day+1); const to=new Date(from); to.setDate(from.getDate()+6); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='month'){ const from=new Date(now.getFullYear(), now.getMonth(), 1); const to=new Date(now.getFullYear(), now.getMonth()+1, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='prevMonth'){ const from=new Date(now.getFullYear(), now.getMonth()-1, 1); const to=new Date(now.getFullYear(), now.getMonth(), 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='nextMonth'){ const from=new Date(now.getFullYear(), now.getMonth()+1, 1); const to=new Date(now.getFullYear(), now.getMonth()+2, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='quarter'){ const q=Math.floor(now.getMonth()/3); const from=new Date(now.getFullYear(), q*3, 1); const to=new Date(now.getFullYear(), q*3+3, 0); to.setHours(23,59,59,999); return {from,to}; }
  if(mode==='today'){ const from=new Date(now); const to=new Date(now); to.setHours(23,59,59,999); return {from,to}; }
  return null;
}
function isDateInTimeRange(dateObj, mode){
  if(!mode || mode==='all') return true;
  if(!dateObj || isNaN(dateObj)) return false;
  const r=getTimeRange(mode); if(!r) return true;
  const d=new Date(dateObj); d.setHours(12,0,0,0);
  return d>=r.from && d<=r.to;
}
function getCreationDate(x){
  if(!x) return null;
  const v = x.created_at || x.createdAt || x.updated_at || x.updatedAt || x.created || "";
  if(!v) return null;
  const d=new Date(v);
  if(!isNaN(d)) return d;
  const m=String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(m){ const dt=new Date(+m[1],+m[2]-1,+m[3]); return isNaN(dt)?null:dt; }
  return null;
}
function parseDeadlineAny(s){
  if(!s) return null;
  if(s instanceof Date) return isNaN(s)?null:new Date(s.getFullYear(), s.getMonth(), s.getDate());
  const str=String(s).trim();
  // thử parseDate (dd/mm/yyyy hoặc iso)
  try{ const p=parseDate(str); if(p && !isNaN(p)) return new Date(p.getFullYear(), p.getMonth(), p.getDate()); }catch(e){}
  try{ const p=typeof bchDeadlineDate==='function'?bchDeadlineDate(str):null; if(p && !isNaN(p)) return p; }catch(e){}
  try{ const p=typeof action100ParseDate==='function'?action100ParseDate(str):null; if(p && !isNaN(p)) return p; }catch(e){}
  const d=new Date(str); return isNaN(d)?null:new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

async function writeActivity(action, details = {}) {
    if (!CURRENT_USER) return;
    try {
        await fetch(`${SUPABASE_URL}/rest/v1/activity_logs`, {
            method: "POST",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", Prefer: "return=minimal" },
            body: JSON.stringify({ user_id: CURRENT_USER.id, user_name: CURRENT_USER.name, user_role: CURRENT_USER.role, action, details })
        });
    } catch (e) { console.warn("Không ghi được nhật ký hoạt động", e); }
}
window.writeActivity = writeActivity;

let ACTIVITY_LOG_ROWS = [];
function renderActivityLog(rows) {
    const body = rows.map((x,i) => `<tr><td>${i+1}</td><td><span class="activity-action-badge" data-full="${esc(x.action || "")}">${esc(x.action || "")}</span></td><td class="activity-account-cell" title="${esc(x.user_name || "")}">${esc(x.user_name || "")}</td><td class="activity-date-cell">${esc(formatDate(x.created_at).replaceAll('/','-'))} ${new Date(x.created_at).toLocaleTimeString("vi-VN",{hour:'2-digit',minute:'2-digit'})}</td><td class="activity-note-cell" title="${esc(x.details?.task || JSON.stringify(x.details||"").slice(0,120))}">${esc(x.details?.task || (x.details? JSON.stringify(x.details).slice(0,80): ""))}</td><td><button class="btn-danger-soft activity-delete-btn" onclick="deleteActivityLog(${Number(x.id)})">Xóa</button></td></tr>`).join("");
    document.getElementById("drillCount").textContent = rows.length;
    document.getElementById("drillBody").innerHTML = body || `<tr><td colspan="6" style="text-align:center;padding:24px;color:#94a3b8">Chưa có dữ liệu</td></tr>`;
}
async function deleteActivityLog(id) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const pass = prompt("Nhập lại token Admin để xác nhận xóa nhật ký:");
    if (pass === null) return;
    if (!(await verifyAdminToken(pass))) return showToast("error", "Xác nhận không đúng", "Không thể xóa bản ghi nhật ký.");
    const row = ACTIVITY_LOG_ROWS.find(x => Number(x.id) === Number(id));
    const r = await fetch(`${SUPABASE_URL}/rest/v1/activity_logs?id=eq.${encodeURIComponent(id)}`, { method: "DELETE", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
    if (!r.ok) return showToast("error", "Không thể xóa nhật ký", await r.text());
    ACTIVITY_LOG_ROWS = ACTIVITY_LOG_ROWS.filter(x => Number(x.id) !== Number(id));
    renderActivityLog(ACTIVITY_LOG_ROWS);
    writeActivity("Xóa nhật ký hoạt động", { deleted_id: id, deleted_action: row?.action || "" });
    showToast("success", "Đã xóa nhật ký");
}
function filterActivityLog() {
    const q = document.getElementById("activityNameFilter").value.trim().toLowerCase();
    const action = document.getElementById("activityActionFilter").value.trim().toLowerCase();
    const adminMode = document.getElementById("activityAdminFilter").value;
    const taskMode = document.getElementById("activityTaskFilter").value;
    const date = document.getElementById("activityDateFilter").value;
    const sort = document.getElementById("activitySortFilter")?.value || "";
    let rows = ACTIVITY_LOG_ROWS.filter(x => {
        const hasTask = !!String(x.details?.task || "").trim();
        const isAdmin = String(x.user_role || "").toLowerCase() === "admin";
        const hay = [x.user_name, x.action, x.user_role, x.created_at, x.details?.task, x.details?.note, x.details?.source, x.details?.officer, typeof x.details === 'object' ? JSON.stringify(x.details) : String(x.details||'')].join(' ').toLowerCase();
        const adminOk = !adminMode || (adminMode === "admin" ? isAdmin : adminMode === "non_admin" ? !isAdmin : String(x.user_name || "").trim() === adminMode);
        return (!q || hay.includes(q))
            && (!action || String(x.action || "").toLowerCase() === action)
            && adminOk
            && (!taskMode || (taskMode === "has_task" && hasTask))
            && (!date || String(x.created_at || "").startsWith(dateToDb(date) || "\u0000"));
    });
    if (sort === "name") rows.sort((a,b)=> String(a.user_name||"").localeCompare(String(b.user_name||""),"vi"));
    else if (sort === "action") rows.sort((a,b)=> String(a.action||"").localeCompare(String(b.action||""),"vi"));
    else if (sort === "date") rows.sort((a,b)=> new Date(b.created_at) - new Date(a.created_at));
    renderActivityLog(rows);
}
async function openActivityLog() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const r = await fetch(`${SUPABASE_URL}/rest/v1/activity_logs?select=*&order=created_at.desc&limit=300`, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
    if (!r.ok) { showToast("error", "Không thể tải nhật ký", await r.text()); return; }
    const rows = await r.json();
    const excludeActions = new Set(["Xóa nhật ký hoạt động", "Cảnh báo nhiệm vụ hàng ngày"]);
    const visibleRows = rows.filter(x => !excludeActions.has(String(x.action || "").trim()));
    ACTIVITY_LOG_ROWS = visibleRows;
    const modal = document.getElementById("drillModal");
    modal.classList.add("activity-log-mode");
    document.getElementById("drillTitle").textContent = "🧾 Nhật ký hoạt động";
    document.getElementById("activityNameFilter").value = "";
    const actionFilter = document.getElementById("activityActionFilter");
    if (actionFilter) {
        const actions = [...new Set(visibleRows.map(x => String(x.action || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        actionFilter.innerHTML = '<option value="">Tất cả thao tác</option>' + actions.map(a => `<option value="${esc(a)}">${esc(a)}</option>`).join("");
        actionFilter.value = "";
    }
    const adminFilter = document.getElementById("activityAdminFilter");
    if (adminFilter) {
        const names = [...new Set(visibleRows.map(x => String(x.user_name || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        adminFilter.innerHTML = '<option value="">Tất cả tài khoản</option><option value="admin">Chỉ dòng của Admin</option><option value="non_admin">Không phải Admin</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
        adminFilter.value = "";
    }
    document.getElementById("activityTaskFilter").value = "";
    document.getElementById("activityDateFilter").value = "";
    const _actSort = document.getElementById("activitySortFilter"); if (_actSort) { _actSort.value = ""; _actSort.style.display = ""; }
    const _afWrap = document.getElementById("activityFilterWrap"); if (_afWrap) _afWrap.style.display = "";
    const _ofWrapHide = document.getElementById("officeFilterWrap"); if (_ofWrapHide) _ofWrapHide.style.display = "none";
    document.getElementById("activityLogFilters").style.display = "flex";
    document.getElementById("activityLogFilters").style.flexDirection = "column";
    // hiện đủ 6 lọc Nhật ký như cũ: Tên/thao tác/tài khoản/ghi chú/ngày + Sắp xếp; ẩn lọc Văn phòng
    ["activityNameFilter","activityActionFilter","activityAdminFilter","activityTaskFilter","activityDateFilter","activitySortFilter"].forEach(id=>{ const el=document.getElementById(id); if(el) el.style.display=""; });
    document.getElementById("officeDrillOrderLabel").style.display = "none";
    const _oOrderAct = document.getElementById("officeDrillOrder"); if (_oOrderAct) _oOrderAct.style.display = "none";
    const _sortFieldHide = document.getElementById("officeSortField") || document.querySelector("#officeFilterWrap .of-sort"); if (_sortFieldHide) _sortFieldHide.style.display = "none";
    document.getElementById("officeDrillOfficerFilter").style.display = "none";
    const _oqnHide = document.getElementById("officeDrillOfficerNameFilter"); if (_oqnHide) _oqnHide.style.display = "none";
    const _oclHide = document.getElementById("officeDrillClearFilter"); if (_oclHide) _oclHide.style.display = "none";
    document.getElementById("officeDrillOfficerSelect").style.display = "none";
    document.getElementById("officeDrillStatusFilter").style.display = "none";
    ["officeDrillTimeFilter", "officeDrillQuarterFilter", "officeDrillMonthFilter"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = "none"; });
    document.getElementById("officeDrillFilterHint").style.display = "none";
    document.getElementById("drillEmpty").style.display = "none";
    const drillTbl = document.querySelector("#drillModal .drill-table");
    if (drillTbl) { drillTbl.classList.remove("office-drill-table"); drillTbl.classList.add("activity-log-table"); }
    document.querySelector("#drillModal thead").innerHTML = "<tr><th>STT</th><th>Thao tác</th><th class=\"activity-account-head\">Tài khoản</th><th class=\"activity-date-head\">Ngày</th><th>Ghi chú</th><th>Xóa</th></tr>";
    renderActivityLog(visibleRows);
    document.getElementById("drillEmpty").style.display = "none";
    smoothOpenModal(modal);
}

// ===== BACKUP / RESTORE TOÀN BỘ DỮ LIỆU =====
// Thứ tự bảng: Cha trước, Con sau để thuận tiện cho việc Insert
const BACKUP_TABLES = [
    "officers",
    "tt_btv_officers",
    "province_officers",
    "action_100_days_officers",
    "office_officers",
    "tasks",
    "tt_btv_tasks",
    "province_tasks",
    "province_plan_blocks",
    "action_100_days_tasks",
    "vpub_tasks",
    "office_tasks",
    "department_tasks",
    "mttq_kpi_people",
    "mttq_kpi_catalog",
    "mttq_kpi_tasks",
    "activity_logs"
];

function setBackupStatus(msg, isError = false) {
    const el = document.getElementById("backupStatus");
    if (el) el.innerHTML = msg === "" ? "" : `<span style="color:${isError ? "#dc2626" : "#334155"}">${esc(String(msg))}</span>`;
}

function openBackupModal() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    setBackupStatus("Sẵn sàng. Chọn 'Tải xuống bản sao lưu' hoặc 'Khôi phục từ tệp sao lưu'.");
    document.getElementById("backupRestoreFile").value = "";
    smoothOpenModal("backupModal");
}

function closeBackupModal() {
    smoothCloseModal("backupModal", () => setBackupStatus(""));
}

async function backupData() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const btn = document.getElementById("backupExportBtn");
    const oldText = btn ? btn.textContent : "";
    if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang sao lưu..."; }
    try {
        const payload = { exported_at: new Date().toISOString(), app: "vanphongtonghop", version: 2, tables: {}, skipped: [] };
        const headers = { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` };
        let totalRows = 0;
        for (const table of BACKUP_TABLES) {
            // Đọc phân trang (PostgREST mặc định cắt 1000 dòng) + bỏ qua bảng lỗi thay vì sập cả bản sao lưu
            try {
                const all = [];
                let offset = 0;
                for (;;) {
                    setBackupStatus(`Đang đọc bảng ${table} (${all.length} dòng)...`);
                    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=*&order=id.asc&limit=1000&offset=${offset}`, { headers });
                    if (!r.ok) { const t = await r.text(); throw new Error(t || ("HTTP " + r.status)); }
                    const batch = await r.json();
                    if (!Array.isArray(batch) || !batch.length) break;
                    all.push(...batch);
                    if (batch.length < 1000) break;
                    offset += 1000;
                }
                payload.tables[table] = all;
                totalRows += all.length;
            } catch (e) {
                payload.skipped.push({ table, error: String((e && e.message) || e) });
            }
        }
        const json = JSON.stringify(payload, null, 2);
        const blob = new Blob([json], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `backup-vpdu-${new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-")}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        writeActivity("Sao lưu dữ liệu", { tables: Object.keys(payload.tables), rows: totalRows, skipped: payload.skipped.map(s => s.table) });
        const skipMsg = payload.skipped.length ? ` Bỏ qua ${payload.skipped.length} bảng lỗi: ${payload.skipped.map(s => s.table).join(", ")}.` : "";
        setBackupStatus(`✓ Đã tạo bản sao lưu (${Object.keys(payload.tables).length} bảng, ${totalRows} dòng, ${new Blob([json]).size} bytes). Tệp đã được tải xuống.${skipMsg}`);
    } catch (e) {
        console.error("Lỗi sao lưu:", e);
        setBackupStatus(`✗ Lỗi sao lưu: ${e.message || "Vui lòng kiểm tra kết nối."}`, true);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = oldText; }
    }
}

async function restoreBackup(event) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") return;
    const file = event.target && event.target.files && event.target.files[0];
    if (!file) return;
    const entered = prompt("Nhập lại token Admin để xác nhận khôi phục dữ liệu:\n(Thao tác này sẽ GHI ĐÈ lên toàn bộ dữ liệu hiện tại)");
    if (entered === null) { event.target.value = ""; return; }
    if (!(await verifyAdminToken(entered))) { event.target.value = ""; showToast("error", "Xác nhận không đúng", "Cần token Admin hợp lệ để khôi phục dữ liệu."); return; }
    if (!window.confirm("Khôi phục dữ liệu sẽ GHI ĐÈ lên dữ liệu hiện tại theo ID. Bạn chắc chắn muốn tiếp tục?")) { event.target.value = ""; return; }
    setBackupStatus("Đang đọc tệp sao lưu...");
    try {
        const payload = JSON.parse(await file.text());
        const tables = payload && payload.tables && typeof payload.tables === "object" ? payload.tables : null;
        if (!tables) throw new Error("Tệp không phải bản sao lưu hợp lệ (thiếu trường 'tables').");

        // 1) Xoá sạch dữ liệu cũ theo thứ tự NGƯỢC (Con trước, Cha sau) để tránh lỗi FK
        const reversedTables = [...BACKUP_TABLES].reverse();
        for (const table of reversedTables) {
            setBackupStatus(`Đang dọn dẹp bảng ${table}...`);
            // id=not.is.null xóa sạch mọi bản ghi, tương thích cả id số và id uuid (province_plan_blocks)
            const del = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=not.is.null`, { method: "DELETE", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` } });
            if (!del.ok && del.status !== 404) {
                const t = await del.text();
                if (t.includes("42501") || t.includes("row-level security")) {
                    throw new Error(`Lỗi quyền (RLS) trên bảng ${table}. Bạn cần vào Supabase SQL Editor chạy lệnh: ALTER TABLE ${table} DISABLE ROW LEVEL SECURITY;`);
                }
                throw new Error(`Không xoá được bảng ${table}: ${t || del.status}`);
            }
        }

        // 2) Chèn lại dữ liệu theo thứ tự THUẬN (Cha trước, Con sau)
        let restored = 0, skipped = 0;
        for (const table of BACKUP_TABLES) {
            const rows = Array.isArray(tables[table]) ? tables[table] : null;
            if (!rows) { skipped++; continue; }
            setBackupStatus(`Đang khôi phục dữ liệu bảng ${table}...`);
            if (!rows.length) continue;
            for (let i = 0; i < rows.length; i += 250) {
                const batch = rows.slice(i, i + 250);
                const up = await fetch(`${SUPABASE_URL}/rest/v1/${table}?on_conflict=id`, {
                    method: "POST",
                    headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "resolution=merge-duplicates,return=minimal" },
                    body: JSON.stringify(batch)
                });
                if (!up.ok) {
                    const t = await up.text();
                    if (t.includes("42501") || t.includes("row-level security")) {
                        throw new Error(`Lỗi quyền (RLS) khi chèn bảng ${table}. Bạn cần vào Supabase SQL Editor chạy lệnh: ALTER TABLE ${table} DISABLE ROW LEVEL SECURITY;`);
                    }
                    throw new Error(`Không chèn được bảng ${table}: ${t || up.status}`);
                }
            }
            restored += rows.length;
        }
        writeActivity("Khôi phục dữ liệu", { restored, skipped });
        setBackupStatus(`✓ Đã khôi phục ${restored} bản ghi (bỏ qua ${skipped} bảng không có trong tệp). Nên tải lại trang để áp dụng toàn bộ.`);
    } catch (e) {
        console.error("Lỗi khôi phục:", e);
        setBackupStatus(`✗ Lỗi khôi phục: ${e.message || "Tệp không hợp lệ."}`, true);
    } finally {
        event.target.value = "";
    }
}










function showToast(type, title, message = "", duration = 3200, options = {}) {
    const wrap = document.getElementById("appToastWrap");
    if (!wrap) return;
    const icons = { success: "✓", error: "!", info: "i", warning: "⏰" };
    const el = document.createElement("div");
    el.className = `app-toast ${type || "info"}${options.onClick ? " clickable" : ""}`;
    el.innerHTML = `<div class="app-toast-icon">${icons[type] || icons.info}</div><div><div class="app-toast-title">${esc(title)}</div>${message ? `<div class="app-toast-msg">${esc(message)}</div>` : ""}</div>`;
    if (options.onClick) el.addEventListener("click", () => { el.remove(); options.onClick(); });
    wrap.appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 220); }, duration);
}


function openEditTask(dataIndex) {
    const x = DATA[dataIndex];
    if (!x || !canEditTask(x)) { showToast("error", "Không có quyền chỉnh sửa", "Bạn chỉ được sửa nhiệm vụ thuộc phạm vi được phân quyền."); return; }
    editingDataIndex = dataIndex; window.OFFICE_EDIT_ID = x.id;
    document.getElementById("editOwnerLine").textContent = `Cán bộ: ${x.owner} · ${CURRENT_USER.role === "admin" ? "Admin đang chỉnh sửa" : "Nhiệm vụ của bạn"}`;
    document.getElementById("editTaskText").value = x.task || "";
    const _taskEl = document.getElementById("editTaskText");
    const _isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    _taskEl.readOnly = !_isAdmin;
    _taskEl.style.background = _isAdmin ? "#fff" : "#f1f5f9";
    _taskEl.title = _isAdmin ? "" : "Chỉ Admin được sửa Nội dung nhiệm vụ.";
    try {
        const editRoleSel = document.getElementById("editRole");
        if (editRoleSel) {
            editRoleSel.innerHTML = officeRoleOptionsHtml(x.role || "");
            const can = officeRoleCanonical(x.role || "");
            const otherEl = document.getElementById("editRoleOther");
            if (otherEl) {
                if (can !== "Chủ trì" && can !== "Phối hợp" && String(x.role || "").trim() !== "") {
                    editRoleSel.value = "__other__";
                    otherEl.value = String(x.role || "").trim();
                    otherEl.style.display = "";
                } else {
                    otherEl.style.display = "none";
                    otherEl.value = "";
                    if (can === "Chủ trì" || can === "Phối hợp") editRoleSel.value = can;
                    else editRoleSel.value = "";
                }
            }
        }
    } catch (e) { try { document.getElementById("editRole").value = x.role || ""; } catch (_) {} }
    const d = parseDate(x.due);
    const dueEl = document.getElementById("editDue");
    dueEl.value = d ? formatDate(d) : "";
    dueEl.readOnly = CURRENT_USER.role !== "admin";
    dueEl.style.background = dueEl.readOnly ? "#f1f5f9" : "#fff";
    dueEl.title = CURRENT_USER.role === "admin" ? "Admin có thể điều chỉnh Hạn hoàn thành." : "Hạn hoàn thành đã được chốt khi tạo nhiệm vụ. Chỉ Admin được thay đổi.";
    document.getElementById("editStatus").value = calculateTaskStatus(x);
    const completed = parseDate(x.completed_date);
    const completedEl = document.getElementById("editCompletedDate");
    completedEl.value = completed ? formatDate(completed) : "";
    completedEl.readOnly = false;
    completedEl.style.background = "#fff";
    completedEl.title = "Có thể cập nhật ngày hoàn thành thực tế.";
    document.getElementById("editProduct").value = (x.product && x.product !== "---") ? x.product : "";
    document.getElementById("editAttachment").value = "";
    renderCurrentAttachment(x);
    const regBox = document.getElementById("editOfficeRegular");
    if (regBox) {
        const isRegular = !!x.is_regular;
        regBox.checked = isRegular;
        const canToggle = CURRENT_USER.role === "admin" || CURRENT_USER.scope === "office";
        regBox.disabled = !canToggle;
        regBox.title = canToggle ? "" : "Chỉ Admin và token Văn phòng được gán Thường xuyên";
    }
    updateEditCompletedDateAccess();

    const staffNoteEl = document.getElementById("editStaffNote");
    staffNoteEl.value = x.staff_note || "";
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const staffCanEdit = CURRENT_USER.role === "staff" && CURRENT_USER.name === x.owner;
    staffNoteEl.readOnly = !(staffCanEdit || isAdmin);
    staffNoteEl.style.background = staffCanEdit ? "#fff" : "#f8fafc";
    document.getElementById("staffNoteHelp").textContent = (staffCanEdit || isAdmin)
        ? "Bạn có thể cập nhật ghi chú bổ sung cho nhiệm vụ này."
        : "Ghi chú của cán bộ phụ trách — Admin cũng có thể sửa.";

    const noteEl = document.getElementById("editAdminNote");
    noteEl.value = x.admin_note || "";
    noteEl.readOnly = CURRENT_USER.role !== "admin";
    noteEl.style.background = noteEl.readOnly ? "#f8fafc" : "#fff";
    document.getElementById("adminNoteHelp").textContent = CURRENT_USER.role === "admin"
        ? "Ghi chú này sẽ hiển thị cho cán bộ trong bảng chi tiết."
        : "Ghi chú từ Admin — bạn chỉ có quyền xem.";

    const delBtn = document.getElementById("editDeleteBtn");
    if (delBtn) delBtn.style.display = canEditTask(x) ? "inline-flex" : "none";

    smoothOpenModal("editModal");
    focusFirstEditable("editModal");
}


function updateEditCompletedDateAccess() {
    const el = document.getElementById("editCompletedDate"); let x = null; if (window.OFFICE_EDIT_ID != null) x = DATA.find(r => String(r.id) === String(window.OFFICE_EDIT_ID)); if (!x) x = DATA[editingDataIndex];
    if (!el || !CURRENT_USER || !x) return;
    // Trạng thái nay tự động; ngày hoàn thành vẫn cho phép cập nhật theo quyền hiện có.
    el.disabled = false; el.readOnly = false; el.style.background = "#fff";
    el.title = "Nhập ngày hoàn thành thực tế; chỉ cần có nội dung sản phẩm hoặc tệp đính kèm là đủ minh chứng hoàn thành.";
    refreshEditAutoStatus();
}

function refreshEditAutoStatus() {
    let x = null; if (window.OFFICE_EDIT_ID != null) x = DATA.find(r => String(r.id) === String(window.OFFICE_EDIT_ID)); if (!x) x = DATA[editingDataIndex]; const out = document.getElementById("editStatus");
    if (!x || !out) return;
    const selected = document.getElementById("editAttachment")?.files?.[0] || null;
    const due = document.getElementById("editDue")?.value || x.due;
    const completed = document.getElementById("editCompletedDate")?.value || "";
    const product = document.getElementById("editProduct")?.value || "";
    out.value = calculateTaskStatus(x, { _regular: false, due, completed_date: completed, product, hasFile: !!x.attachment_path || !!selected });
}


function closeEditTask() { smoothCloseModal("editModal", () => { editingDataIndex = -1; window.OFFICE_EDIT_ID = null; }); }

// ===== Xóa nhiệm vụ (delete task) =====
let DELETE_TASK_CONFIRM_CB = null;

function openDeleteTaskConfirm(opts) {
    const label = document.getElementById("deleteTaskConfirmLabel");
    if (label) label.textContent = (opts && opts.label) || "Bạn có chắc chắn muốn xóa nhiệm vụ này không?";
    const summary = document.getElementById("deleteTaskConfirmSummary");
    if (summary) summary.innerHTML = (opts && opts.summary) || "";
    const withFileBtn = document.getElementById("deleteTaskWithFileBtn");
    if (withFileBtn) withFileBtn.style.display = (opts && opts.hasFile) ? "inline-flex" : "none";
    const onlyBtn = document.getElementById("deleteTaskOnlyBtn");
    if (onlyBtn) {
        const hasFile = !!(opts && opts.hasFile);
        onlyBtn.textContent = hasFile ? "Không, chỉ xóa nhiệm vụ" : "Xóa nhiệm vụ";
        onlyBtn.className = hasFile ? "btn-danger-soft" : "btn-danger";
    }
    DELETE_TASK_CONFIRM_CB = (opts && opts.onConfirm) || null;
    smoothOpenModal("deleteTaskConfirmModal");
}

function closeDeleteTaskConfirm() {
    DELETE_TASK_CONFIRM_CB = null;
    smoothCloseModal("deleteTaskConfirmModal");
}

function deleteTaskConfirm(deleteFile) {
    const cb = DELETE_TASK_CONFIRM_CB;
    DELETE_TASK_CONFIRM_CB = null;
    smoothCloseModal("deleteTaskConfirmModal");
    if (typeof cb === "function") { try { cb(deleteFile); } catch (e) { console.error(e); } }
}



const STORAGE_BUCKET = "task-files";
const MAX_FILE_BYTES = 20 * 1024 * 1024;
const ALLOWED_EXTENSIONS = new Set(["pdf", "doc", "docx", "xls", "xlsx"]);

function safeFileName(name) {
    const dot = name.lastIndexOf(".");
    const ext = dot >= 0 ? name.slice(dot).toLowerCase() : "";
    const base = (dot >= 0 ? name.slice(0, dot) : name)
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d").replace(/Đ/g, "D")
        .replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "") || "tep-san-pham";
    return (base.slice(0, 90) + ext).toLowerCase();
}

function renderCurrentAttachment(x) {
    const el = document.getElementById("currentAttachment");
    if (!el) return;
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        el.innerHTML = '<span class="admin-note-empty">Chưa có tệp đính kèm</span>';
        return;
    }
    const approved = x.attachment_approved === true;
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        el.innerHTML = approved
            ? '<span class="approval-pill approved">✅ Tệp đã được Admin phê duyệt</span>'
            : '<span class="approval-pill pending">⏳ Tệp đã gửi · đang chờ Admin phê duyệt</span>';
        return;
    }
    const idx = DATA.indexOf(x);
    el.innerHTML = `<span class="file-pill">📄 ${esc(x.attachment_name || "Tệp sản phẩm")}</span>
                ${approved ? `<span class="approval-pill approved">✅ Đã duyệt</span>` : `<span class="approval-pill pending">⏳ Chờ duyệt</span>`}
                ${x.attachment_path ? `<button type="button" class="file-link-btn" onclick="openAttachmentByIndex(${idx},true)">👁 Xem tệp</button>` : `<span class="admin-note-empty">Chỉ lưu tên file</span>`}
                ${!approved ? `<button type="button" class="approve-file-btn" onclick="approveAttachment(${idx})">✓ Phê duyệt</button>` : ""}
                <button type="button" class="file-delete-btn" onclick="deleteCurrentAttachment()">🗑 Xóa tệp</button>`;
}

async function uploadTaskFile(file, task) {
    if (!file) return null;
    if (file.size > MAX_FILE_BYTES) throw new Error("Tệp vượt quá 20 MB.");
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) throw new Error("Chỉ chấp nhận tệp PDF, Word hoặc Excel.");
    return { path: "", name: file.name, type: file.type || "application/octet-stream", size: file.size };
}

function encodePath(path) { return String(path).split("/").map(encodeURIComponent).join("/"); }

async function openAttachmentByIndex(dataIndex, allowPending = false) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được phép xem hoặc tải tệp đính kèm.");
        return;
    }
    const x = DATA[dataIndex];
    if (!x || !x.attachment_path) { showToast("info", "Chưa có tệp", "Nhiệm vụ này chưa có tệp sản phẩm."); return; }
    if (!x.attachment_approved && !allowPending) {
        showToast("info", "Tệp đang chờ duyệt", "Hãy mở nhiệm vụ và phê duyệt tệp trước khi tệp xuất hiện trên Trang chủ.");
        return;
    }
    try {
        showToast("info", "Đang mở tệp", x.attachment_name || "Tệp sản phẩm", 1800);
        const r = await fetch(`${SUPABASE_URL}/storage/v1/object/authenticated/${STORAGE_BUCKET}/${encodePath(x.attachment_path)}`, {
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        if (!r.ok) { const t = await r.text(); throw new Error(t || `HTTP ${r.status}`); }
        const blob = await r.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.rel = "noopener"; a.download = x.attachment_name || "tep-san-pham";
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { console.error(e); showToast("error", "Không mở được tệp", e.message || "Kiểm tra policy Storage.", 5200); }
}

async function approveAttachment(dataIndex) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        showToast("error", "Không có quyền", "Chỉ Admin được phép phê duyệt tệp.");
        return;
    }
    const x = DATA[dataIndex];
    if (!x || (!x.attachment_path && !x.attachment_name)) { showToast("info", "Chưa có tệp", "Nhiệm vụ này chưa có tên file để duyệt."); return; }
    if (x.attachment_approved) { showToast("info", "Đã phê duyệt", "Tệp này đã được duyệt trước đó."); return; }
    try {
        const patch = {
            attachment_approved: true,
            attachment_approved_at: new Date().toISOString(),
            attachment_approved_by: CURRENT_USER.name || "Admin"
        };
        const r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
            body: JSON.stringify(patch)
        });
        const tx = await r.text();
        if (!r.ok) {
            let detail = tx; try { const j = JSON.parse(tx); detail = j.message || j.details || j.hint || tx } catch (e) { }
            if (String(detail).includes("attachment_approved")) detail = "Chưa có cột phê duyệt tệp trong Supabase. Hãy chạy file migration V19 trước.";
            throw new Error(detail || `HTTP ${r.status}`);
        }
        x.attachment_approved = true;
        x.attachment_approved_at = patch.attachment_approved_at;
        x.attachment_approved_by = patch.attachment_approved_by;
        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
        renderCurrentAttachment(x);
        applyFilters();
        if (typeof refreshActiveDrillPopup === "function") refreshActiveDrillPopup();
        writeActivity("Sửa - Duyệt file", { task: x.task, id: x.id, file: x.attachment_name || "" });
        showToast("success", "Đã phê duyệt tệp", `${x.attachment_name || "Tệp sản phẩm"} đã được phép hiển thị trên Trang chủ.`);
    } catch (e) {
        console.error(e);
        showToast("error", "Không thể phê duyệt tệp", e.message || "Vui lòng kiểm tra database.", 5600);
    }
}

async function deleteStorageObject(path) {
    if (!path) return;
    try {
        await fetch(`${SUPABASE_URL}/storage/v1/object/${STORAGE_BUCKET}/${encodePath(path)}`, {
            method: "DELETE", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
    } catch (e) { console.warn("Không xóa được tệp cũ:", e); }
}


async function deleteCurrentAttachment() {
    let x = null; if (window.OFFICE_EDIT_ID != null) x = DATA.find(r => String(r.id) === String(window.OFFICE_EDIT_ID)); if (!x) x = DATA[editingDataIndex];
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        showToast("info", "Chưa có tệp", "Nhiệm vụ này chưa có tệp đính kèm.");
        return;
    }
    if (!canEditTask(x)) {
        showToast("error", "Không có quyền xóa tệp", "Bạn chỉ được xóa tệp của nhiệm vụ thuộc phạm vi được phân quyền.");
        return;
    }

    const fileName = x.attachment_name || "tệp sản phẩm";
    const ok = window.confirm(`Xóa tệp đính kèm "${fileName}"?\n\nTệp sẽ bị xóa khỏi Supabase Storage. Nội dung sản phẩm vẫn được giữ nguyên.`);
    if (!ok) return;

    const btn = document.querySelector("#currentAttachment .file-delete-btn");
    if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang xóa..."; }

    const oldPath = x.attachment_path;
    try {
        // 1. Delete the object when it still exists; missing Storage objects are already gone.
        const sr = await fetch(`${SUPABASE_URL}/storage/v1/object/${STORAGE_BUCKET}/${encodePath(oldPath)}`, {
            method: "DELETE",
            headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }
        });
        const storageText = await sr.text();
        if (!sr.ok && sr.status !== 404 && !/object not found|not found/i.test(storageText)) {
            let detail = storageText;
            try { const j = JSON.parse(storageText); detail = j.message || j.error || storageText; } catch (e) { }
            throw new Error(detail || `Storage HTTP ${sr.status}`);
        }

        // 2. Clear only attachment metadata. Product is intentionally preserved.
        const patch = {
            attachment_path: null,
            attachment_name: null,
            attachment_type: null,
            attachment_size: null,
            attachment_approved: false,
            attachment_approved_at: null,
            attachment_approved_by: null,
            updated_at: new Date().toISOString()
        };
        const dr = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(patch)
        });
        const dbText = await dr.text();
        if (!dr.ok) {
            let detail = dbText;
            try { const j = JSON.parse(dbText); detail = j.message || j.details || j.hint || dbText; } catch (e) { }
            throw new Error("Tệp đã xóa khỏi Storage nhưng chưa xóa được metadata: " + (detail || `HTTP ${dr.status}`));
        }

        x.attachment_path = "";
        x.attachment_name = "";
        x.attachment_type = "";
        x.attachment_size = null;
        x.attachment_approved = false;
        x.attachment_approved_at = "";
        x.attachment_approved_by = "";
        x.updated_at = patch.updated_at;
        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));

        // Cập nhật ngay popup Cập nhật nhiệm vụ hiện tại.
        renderCurrentAttachment(x);

        // Cập nhật lại dashboard và popup danh sách đang mở phía sau
        // để cột Tệp sản phẩm chuyển ngay thành "Chưa có tệp".
        applyFilters();
        if (typeof refreshActiveDrillPopup === "function") {
            refreshActiveDrillPopup();
        }

        writeActivity("Sửa nhiệm vụ - Xóa file", { task: x.task, id: x.id, file: fileName });
        showToast("success", "Đã xóa tệp đính kèm", `${fileName} đã được xóa. Nội dung sản phẩm vẫn được giữ nguyên.`);
    } catch (e) {
        console.error("Lỗi xóa tệp:", e);
        showToast("error", "Không thể xóa tệp", e.message || "Vui lòng kiểm tra Supabase Storage.", 5600);
        renderCurrentAttachment(x);
    }
}

async function saveEditTask() {
    let x = null; if (window.OFFICE_EDIT_ID != null) x = DATA.find(r => String(r.id) === String(window.OFFICE_EDIT_ID)); if (!x) x = DATA[editingDataIndex];
    if (!x || !canEditTask(x)) {
        showToast("error", "Không có quyền chỉnh sửa", "Bạn chỉ được sửa nhiệm vụ thuộc phạm vi được phân quyền.");
        return;
    }

    let taskName = document.getElementById("editTaskText").value.trim();
    if (!taskName) {
        showToast("error", "Thiếu nội dung", "Nội dung nhiệm vụ không được để trống.");
        document.getElementById("editTaskText").focus();
        return;
    }
    // Chỉ Admin được sửa Nội dung nhiệm vụ (toàn hệ thống)
    if (CURRENT_USER.role !== "admin" && taskName !== String(x.task || "").trim()) {
        showToast("error", "Không có quyền", "Chỉ Admin được sửa Nội dung nhiệm vụ.");
        document.getElementById("editTaskText").value = x.task || "";
        taskName = String(x.task || "").trim();
    }

    let statusUI = "Đang triển khai";
    let dueValue = null, completedValue = null;
    try {
        dueValue = requireValidDate(document.getElementById("editDue").value, "Hạn hoàn thành", false);
        const cr = document.getElementById("editCompletedDate").value.trim();
        completedValue = cr ? requireValidDate(cr, "Ngày hoàn thành", false) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    // Hạn hoàn thành chỉ Admin được sửa
    if (CURRENT_USER.role !== "admin") {
        const origDue = String(x.due || x.deadline_date || "").trim();
        const origDueDb = origDue ? (function(v){ try{ return requireValidDate(v,"",false);}catch(_){ return String(v).trim();}}) (origDue) : "";
        if (dueValue !== origDueDb && dueValue !== String(origDue||"").trim()) {
            const cur = String(x.due || "").trim();
            if (cur && dueValue !== cur) {
                showToast("error", "Không có quyền", "Chỉ Admin được sửa Hạn hoàn thành.");
                const _rv = cur ? parseDate(cur) : parseDate(origDueDb);
                document.getElementById("editDue").value = _rv ? formatDate(_rv) : "";
                try{ dueValue = requireValidDate(document.getElementById("editDue").value,"Hạn hoàn thành",false);}catch(_){ dueValue = origDueDb; }
            }
        }
    }
    const productValue = document.getElementById("editProduct").value.trim() || "Không";
    const selectedFile = document.getElementById("editAttachment").files[0] || null;
    const isEditRegular = !!document.getElementById("editOfficeRegular")?.checked;
    statusUI = calculateTaskStatus(x, { _regular: false, due: dueValue, completed_date: completedValue, product: productValue, hasFile: !!x.attachment_path || !!selectedFile });
    const _editRoleVal = (function(){ let v=""; try{ v=getOfficeRoleValue("editRole"); }catch(e){ v=(document.getElementById("editRole")?.value||"").trim(); } const can=officeRoleCanonical(v); if(can==="Chủ trì"||can==="Phối hợp") return can; return v; })();
    if (!_editRoleVal) { showToast("error", "Thiếu vai trò", "Vui lòng chọn vai trò Chủ trì / Phối hợp hoặc nhập Khác."); return; }
    const dbPatch = {
        task_name: taskName,
        role: _editRoleVal,
        status: dbStatus(statusUI),
        is_regular: isEditRegular,
        product: productValue,
        updated_at: new Date().toISOString()
    };
    if (CURRENT_USER.role === "admin") {
        dbPatch.deadline_date = dueValue;
        dbPatch.completed_date = completedValue;
        dbPatch.note = document.getElementById("editAdminNote").value.trim();
        dbPatch.staff_note = document.getElementById("editStaffNote").value.trim();
        // V34: nhiệm vụ đã gia hạn phải giữ cờ gia hạn sau mọi lần Sửa → Lưu.
        if (x.extended === true) dbPatch.is_extended = true;
    } else {
        dbPatch.staff_note = document.getElementById("editStaffNote").value.trim();
        if (completedValue) dbPatch.completed_date = completedValue;
        else dbPatch.completed_date = null;
    }

    const saveBtn = document.querySelector('#editModal .btn-primary[onclick="saveEditTask()"]');
    const oldText = saveBtn ? saveBtn.textContent : "";
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = "⏳ Đang lưu..."; }

    let uploaded = null;
    const previousAttachmentPath = x.attachment_path || "";
    try {
        if (x.id === undefined || x.id === null || x.id === "") throw new Error("Bản ghi không có ID để cập nhật.");
        if (selectedFile) {
            document.getElementById("uploadProgress").style.display = "block";
            uploaded = await uploadTaskFile(selectedFile, x);
            dbPatch.attachment_path = uploaded.path;
            dbPatch.attachment_name = uploaded.name;
            dbPatch.attachment_type = uploaded.type;
            dbPatch.attachment_size = uploaded.size;
            dbPatch.attachment_approved = false;
            dbPatch.attachment_approved_at = null;
            dbPatch.attachment_approved_by = null;
        }
        statusUI = calculateTaskStatus(x, { _regular: false, due: dueValue, completed_date: completedValue, product: productValue, hasFile: !!x.attachment_path || !!uploaded });
        dbPatch.status = dbStatus(statusUI);
        // Thường xuyên: sang tháng mới → tạo bản tháng mới, GIỮ tháng cũ.
        // Bản mới: giống hệt, chỉ trống Ngày hoàn thành + Sản phẩm, Hạn +1 tháng,
        // cuối tên thêm "[NV Thường xuyên từ Tháng trước: Tháng M/YYYY]".
        // Lưu 1 bản/tháng: đã có bản tháng này thì cập nhật bản đó, không đẻ thêm.
        // Tick lan dau cung chay (x.is_regular cu co the false) — mien la thang tao != thang nay
        if (isEditRegular) {
            const taskDate = x._createdDate || (typeof getCreationDate === 'function' ? getCreationDate(x) : null) || parseDate(x.created_at);
            const nowM = new Date(); nowM.setHours(0,0,0,0);
            if (taskDate && (taskDate.getMonth() !== nowM.getMonth() || taskDate.getFullYear() !== nowM.getFullYear())) {
                const stripMarker = s => String(s || "").replace(/\s*\[NV Thường xuyên từ Tháng trước:[^\]]*\]\s*$/, "").trim();
                const prevLabel = `Tháng ${taskDate.getMonth()+1}/${taskDate.getFullYear()}`;
                const marker = `[NV Thường xuyên từ Tháng trước: ${prevLabel}]`;
                const baseName = stripMarker(taskName) || taskName;
                const newName = `${baseName} ${marker}`;
                // Hạn +1 tháng từ hạn cũ, kẹp ngày cuối tháng (31/08 -> 30/09).
                // Nếu vẫn lọt về quá khứ (nhiệm vụ cũ nhiều tháng), đẩy lên tháng hiện tại.
                const _baseDue = parseDate(dueValue || x.due);
                const _plusOne = _d => { let _m = _d.getMonth()+1, _y = _d.getFullYear(); if (_m > 11) { _m = 0; _y++; } const _last = new Date(_y, _m+1, 0).getDate(); return new Date(_y, _m, Math.min(_d.getDate(), _last)); };
                let _nd = _baseDue ? _plusOne(_baseDue) : null;
                if (_nd && (_nd.getFullYear() < nowM.getFullYear() || (_nd.getFullYear() === nowM.getFullYear() && _nd.getMonth() < nowM.getMonth()))) {
                    const _last = new Date(nowM.getFullYear(), nowM.getMonth()+1, 0).getDate();
                    const _baseDay = _baseDue ? _baseDue.getDate() : 1;
                    _nd = new Date(nowM.getFullYear(), nowM.getMonth(), Math.min(_baseDay, _last));
                }
                const newDeadlineDb = _nd ? dateToDb(_nd) : (dueValue || null);
                const _cloneStatusUI = calculateTaskStatus(x, { _regular: false, due: newDeadlineDb, completed_date: null, product: "", hasFile: !!x.attachment_path || !!uploaded });
                const existing = DATA.find(y => y && y.id !== x.id && !!y.is_regular && String(y.owner || "") === String(x.owner || "") && stripMarker(y.task) === baseName && String(y.task || "").includes(marker));
                const cloneFields = {
                    role: dbPatch.role || "",
                    deadline_date: newDeadlineDb,
                    completed_date: null,
                    product: "",
                    status: dbStatus(_cloneStatusUI),
                    note: dbPatch.note ?? "",
                    staff_note: dbPatch.staff_note ?? "",
                    updated_at: dbPatch.updated_at
                };
                if (existing) {
                    // Đã có bản tháng này → cập nhật bản đó, nhiệm vụ tháng cũ giữ nguyên
                    const upd = { ...cloneFields, task_name: existing.task };
                    let ur = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(existing.id)}`, {
                        method: "PATCH",
                        headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
                        body: JSON.stringify(upd)
                    });
                    let utx = await ur.text();
                    if (!ur.ok) { let d = utx; try { const j = JSON.parse(utx); d = j.message || j.details || utx; } catch (e) { } throw new Error(d || `HTTP ${ur.status}`); }
                    try { const uj = JSON.parse(utx || "null"); const urow = Array.isArray(uj) ? uj[0] : uj; if (urow) Object.assign(existing, urow, upd); else Object.assign(existing, upd); } catch (e) { Object.assign(existing, upd); }
                    try { localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA)); writeCache("vp_tasks_cache", DATA); } catch (e) { }
                    rebuildFilters(); applyFilters(); if (typeof refreshActiveDrillPopup === 'function') refreshActiveDrillPopup();
                    closeEditTask();
                    writeActivity("Cập nhật nhiệm vụ thường xuyên (tháng đã có)", { task: newName, id: existing.id });
                    showToast("success", "Đã cập nhật tháng mới", `Tháng ${nowM.getMonth()+1}/${nowM.getFullYear()} đã có nhiệm vụ này nên chỉ cập nhật (vẫn trống ngày HT/sản phẩm). Nhiệm vụ tháng cũ giữ nguyên.`);
                    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = oldText || "💾 Lưu thay đổi"; }
                    return;
                }
                const cloneRow = {
                    officer_name: x.owner || "",
                    task_name: newName,
                    is_regular: true,
                    ...cloneFields
                };
                if (x.emergent || x.is_arising) cloneRow.is_arising = true;
                if (x.extended || dbPatch.is_extended) cloneRow.is_extended = true;
                if (uploaded) {
                    cloneRow.attachment_path = uploaded.path;
                    cloneRow.attachment_name = uploaded.name;
                    cloneRow.attachment_type = uploaded.type;
                    cloneRow.attachment_size = uploaded.size;
                    cloneRow.attachment_approved = false;
                }
                let cr = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
                    method: "POST",
                    headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
                    body: JSON.stringify(cloneRow)
                });
                let ctxt = await cr.text();
                if (!cr.ok && String(ctxt).toLowerCase().includes("is_regular")) {
                    const fb = { ...cloneRow }; delete fb.is_regular; if (cloneRow.is_regular) fb.status = "thường xuyên";
                    cr = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
                        method: "POST",
                        headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" },
                        body: JSON.stringify(fb)
                    });
                    ctxt = await cr.text();
                }
                if (!cr.ok) {
                    let d = ctxt; try { const j = JSON.parse(ctxt); d = j.message || j.details || ctxt; } catch (e) { }
                    throw new Error(d || `HTTP ${cr.status}`);
                }
                let newRaw = null; try { const j = JSON.parse(ctxt); newRaw = Array.isArray(j) ? j[0] : j; } catch (e) { }
                if (newRaw) {
                    newRaw.task_name = newRaw.task_name || taskName;
                    newRaw.officer_name = newRaw.officer_name || x.owner;
                    const newObj = normalizeTask(newRaw, DATA.length);
                    if (newObj) {
                        DATA.push(newObj);
                        // GIỮ nhiệm vụ tháng cũ trên hệ thống (không xóa trùng nữa)
                        try { localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA)); writeCache("vp_tasks_cache", DATA); } catch (e) { }
                        rebuildFilters(); applyFilters(); if (typeof refreshActiveDrillPopup === 'function') refreshActiveDrillPopup();
                        closeEditTask();
                        writeActivity("Cập nhật nhiệm vụ thường xuyên (tạo tháng mới)", { task: newName, old_id: x.id, new_id: newObj.id });
                        showToast("success", "Đã tạo nhiệm vụ tháng mới", `Tháng ${nowM.getMonth()+1}/${nowM.getFullYear()}: hạn +1 tháng, trống ngày HT/sản phẩm. Nhiệm vụ tháng cũ giữ nguyên.`);
                        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = oldText || "💾 Lưu thay đổi"; }
                        return;
                    }
                }
            }
        }
        let r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`, {
            method: "PATCH",
            headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(dbPatch)
        });

        let responseText = await r.text();
        if (!r.ok && String(responseText).toLowerCase().includes("is_regular")) {
            const fbPatch = { ...dbPatch }; delete fbPatch.is_regular; if (dbPatch.is_regular) fbPatch.status = "thường xuyên"; else if (fbPatch.status === "thường xuyên") fbPatch.status = dbStatus(statusUI);
            r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`, {
                method: "PATCH",
                headers: {
                    "apikey": SUPABASE_KEY,
                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                    "Content-Type": "application/json",
                    "Prefer": "return=representation"
                },
                body: JSON.stringify(fbPatch)
            });
            responseText = await r.text();
            if (r.ok) dbPatch.is_regular = fbPatch.is_regular;
        }
        if (!r.ok) {
            let detail = responseText;
            try { const j = JSON.parse(responseText); detail = j.message || j.details || j.hint || responseText; } catch (e) { }
            throw new Error(detail || `HTTP ${r.status}`);
        }
        // V34: lấy chính bản ghi Supabase vừa PATCH trả về làm nguồn sự thật.
        let savedRow = null;
        try { const j = JSON.parse(responseText || "[]"); savedRow = Array.isArray(j) ? j[0] : j; } catch (e) { }

        // PATCH trả về mảng rỗng => không có bản ghi office_tasks khớp
        // (nhiệm vụ chỉ tồn tại ở sheet/đã bị xoá). Tạo bản ghi office_tasks để thay đổi
        // thực sự được lưu vào Supabase; lần merge sau sẽ dùng nó làm nguồn ghi đè.
        if (!savedRow) {
            const insertRow = {
                officer_name: x.owner || "",
                task_name: taskName,
                role: dbPatch.role || "",
                deadline_date: dueValue,
                completed_date: dbPatch.completed_date ?? null,
                product: productValue,
                status: dbPatch.status || dbStatus(statusUI),
                is_regular: isEditRegular,
                note: dbPatch.note ?? "",
                staff_note: dbPatch.staff_note ?? "",
                updated_at: dbPatch.updated_at
            };
            if (x.emergent || x.is_arising) insertRow.is_arising = true;
            if (x.extended) insertRow.is_extended = true;
            let ir = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
                method: "POST",
                headers: {
                    "apikey": SUPABASE_KEY,
                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                    "Content-Type": "application/json",
                    "Prefer": "return=representation"
                },
                body: JSON.stringify(insertRow)
            });
            let itxt = await ir.text();
            if (!ir.ok && String(itxt).toLowerCase().includes("is_regular")) {
                const fbInsert = { ...insertRow }; delete fbInsert.is_regular; if (insertRow.is_regular) fbInsert.status = "thường xuyên";
                ir = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
                    method: "POST",
                    headers: {
                        "apikey": SUPABASE_KEY,
                        "Authorization": `Bearer ${SUPABASE_KEY}`,
                        "Content-Type": "application/json",
                        "Prefer": "return=representation"
                    },
                    body: JSON.stringify(fbInsert)
                });
                itxt = await ir.text();
            }
            if (!ir.ok) {
                let d = itxt; try { const j = JSON.parse(itxt); d = j.message || j.details || itxt; } catch (e) { }
                throw new Error("Không có bản ghi danh mục để cập nhật và chưa tạo được bản ghi mới: " + (d || `HTTP ${ir.status}`));
            }
            try { const j = JSON.parse(itxt); savedRow = Array.isArray(j) ? j[0] : j; } catch (e) { }
            x.id = (savedRow && savedRow.id) || x.id;
        }

        // Chỉ cập nhật giao diện SAU KHI database xác nhận thành công.
        x.task = taskName;
        x.role = dbPatch.role;
        if ("deadline_date" in dbPatch) x.due = (savedRow && savedRow.deadline_date) || dueValue || "";
        x.extended = savedRow && savedRow.is_extended !== undefined ? savedRow.is_extended === true : (dbPatch.is_extended === true || x.extended === true);
        x.is_regular = savedRow && savedRow.is_regular !== undefined ? savedRow.is_regular === true : isEditRegular;
        x.status = statusUI;
        x.product = productValue;
        if ("completed_date" in dbPatch) x.completed_date = dbPatch.completed_date || "";
        if (CURRENT_USER.role === "admin") x.admin_note = dbPatch.note || "";
        if ("staff_note" in dbPatch) x.staff_note = dbPatch.staff_note || "";
        if (uploaded) {
            x.attachment_path = uploaded.path; x.attachment_name = uploaded.name; x.attachment_type = uploaded.type; x.attachment_size = uploaded.size;
            x.attachment_approved = false; x.attachment_approved_at = ""; x.attachment_approved_by = "";
            if (previousAttachmentPath && previousAttachmentPath !== uploaded.path) deleteStorageObject(previousAttachmentPath);
        }
        x.updated_at = (savedRow && savedRow.updated_at) || dbPatch.updated_at;
        x._dueDate = parseDate(x.due);
        try { x.role = officeRoleCanonical(x.role) || x.role; } catch (e) {}
        x._search = (x.task + " " + x.owner + " " + x.role + " " + (officeRoleDisplay(x.role) || "") + " " + (x.staff_note || "") + " " + (x.admin_note || "") + " " + (x.product || "")).toLowerCase();
        moveTaskToTop(DATA, x.id);
        // GIỮ lịch sử tháng cũ: không xóa nhiệm vụ thường xuyên trùng nữa

        // Đồng bộ department_tasks cho nhiệm vụ merged (Đang triển khai) để tránh revert sau F5
        if (x.sheet_name && x.row_number) {
            try {
                const depPatch = { task: taskName };
                if (CURRENT_USER.role === "admin" && dueValue) depPatch.due = dueValue;
                if (dbPatch.role) depPatch.role = dbPatch.role;
                if (productValue && productValue !== "Không") depPatch.product = productValue;
                await fetch(`${SUPABASE_URL}/rest/v1/department_tasks?sheet_name=eq.${encodeURIComponent(x.sheet_name)}&row_number=eq.${encodeURIComponent(x.row_number)}`, {
                    method: "PATCH",
                    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", Prefer: "return=minimal" },
                    body: JSON.stringify(depPatch)
                });
            } catch (depErr) { console.warn("Không đồng bộ department_tasks:", depErr); }
        }

        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));

        // Làm mới dashboard + popup chi tiết ngay sau khi database xác nhận lưu thành công.
        applyFilters();

        // Nếu popup danh sách nhiệm vụ đang mở, dựng lại đúng danh sách hiện tại
        // để trạng thái / sản phẩm / tệp / ghi chú thay đổi ngay mà không cần đóng mở lại.
        if (typeof refreshActiveDrillPopup === "function") {
            refreshActiveDrillPopup();
        }

        closeEditTask();
        writeActivity("Sửa nhiệm vụ", { task: x.task, id: x.id });
        if (uploaded) writeActivity("Sửa - Đính kèm file", { task: x.task, id: x.id, file: uploaded.name });
        showToast("success", "Đã lưu vào cơ sở dữ liệu", `Nhiệm vụ #${x.id} đã được cập nhật thành công.`);
        checkDailyCompletionAndCelebrate(x.owner);
    } catch (e) {
        console.error("Lỗi cập nhật Supabase:", e);
        if (uploaded && uploaded.path) await deleteStorageObject(uploaded.path);
        let msg = e.message || "Vui lòng kiểm tra cấu hình database/Storage.";
        if (String(msg).includes("attachment_approved")) msg = "CSDL chưa có cột phê duyệt tệp. Hãy chạy file SQL migration V19 một lần trong Supabase.";
        showToast("error", "Không thể lưu vào Supabase", msg, 6200);
    } finally {
        const up = document.getElementById("uploadProgress"); if (up) up.style.display = "none";
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = oldText || "💾 Lưu thay đổi"; }
    }
}


let HONOR_BEST_OWNER = "";
let HONOR_LEADER_OWNER = "";

function foldHonorText(s) {
    return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
}

function isLeadershipPosition(position) {
    const p = foldHonorText(position);
    if (!p) return false;
    return [
        "bi thu", "pho bi thu", "thuong truc", "chanh van phong", "pho chanh van phong",
        "chu tich", "pho chu tich", "truong ban", "pho truong ban", "truong", "pho truong",
        "lanh dao", "uy vien ban thuong vu", "bTV"
    ].some(k => p.includes(foldHonorText(k)));
}

function updateGlobalHonors() {
    const bestName = document.getElementById("honorBestName");
    const leaderName = document.getElementById("honorLeaderName");
    if (!bestName || !leaderName) return;

    // VINH DANH theo hạn hoàn thành: cá nhân tính trong tháng, BCH tính trong quý
    const now = new Date(); const curMonth = now.getMonth(); const curYear = now.getFullYear(); const curQuarter = Math.floor(curMonth/3);
    const isOfficeInCurrentMonth = (x) => {
        const d = x && x._dueDate ? x._dueDate : parseDate(x && x.due);
        return d && d.getMonth() === curMonth && d.getFullYear() === curYear;
    };
    const isOfficeInCurrentQuarter = (x) => {
        const d = x && x._dueDate ? x._dueDate : parseDate(x && x.due);
        return d && Math.floor(d.getMonth()/3) === curQuarter && d.getFullYear() === curYear;
    };
    const isBCHInCurrentQuarter = (x) => {
        const d = bchDeadlineDate(x && x.deadline);
        return d && Math.floor(d.getMonth()/3) === curQuarter && d.getFullYear() === curYear;
    };
    const subtitle = document.querySelector(".honors-subtitle");
    if (subtitle) subtitle.textContent = `Vinh danh trong tháng ${curMonth+1}/${curYear} · theo hạn hoàn thành`;

    // ---- 1. Cá nhân hoàn thành tốt nhiệm vụ (chỉ trong tháng hiện tại) ----
    // Xếp hạng: tỷ lệ hoàn thành cao nhất -> số nhiệm vụ hoàn thành nhiều nhất -> tổng nhiệm vụ nhiều hơn.
    const mayOfficeHonor = canAccessOfficeData(CURRENT_USER);
    const ownerStats = new Map();
    (mayOfficeHonor ? DATA : []).forEach(x => {
        if (!x || !x.owner) return;
        if (!isOfficeInCurrentMonth(x)) return;
        if (!ownerStats.has(x.owner)) ownerStats.set(x.owner, { owner: x.owner, total: 0, done: 0, early: 0, ontime: 0 });
        const s = ownerStats.get(x.owner);
        s.total++;
        if (completedStatuses.has(x.status)) s.done++;
        if (x.status === "Hoàn thành trước hạn") s.early++;
        if (x.status === "Hoàn thành đúng hạn") s.ontime++;
    });
    const ranked = [...ownerStats.values()]
        .filter(s => s.total > 0)
        .map(s => ({ ...s, rate: s.done / s.total }))
        .sort((a, b) => b.rate - a.rate || b.done - a.done || b.total - a.total || a.owner.localeCompare(b.owner, "vi"));

    const best = ranked[0] || null;
    if (best) {
        HONOR_BEST_OWNER = best.owner;
        document.getElementById("honorBestName").textContent = best.owner;
        document.getElementById("honorBestDetail").textContent =
            `${best.done}/${best.total} nhiệm vụ hoàn thành · ${best.early} trước hạn · ${best.ontime} đúng hạn`;
        document.getElementById("honorBestScore").textContent = Math.round(best.rate * 100) + "%";
    } else {
        HONOR_BEST_OWNER = "";
        document.getElementById("honorBestName").textContent = "Chưa có dữ liệu tháng này";
        document.getElementById("honorBestDetail").textContent = "—";
        document.getElementById("honorBestScore").textContent = "—";
    }

    // ---- 2. BCH vinh danh theo NHIỆM VỤ HOÀN THÀNH nhiều nhất trong quý hiện tại ----
    const leaderMap = new Map();
    if (Array.isArray(BCH_TASKS)) {
        const om = bchOfficerMap();
        BCH_TASKS.forEach(x => {
            if (!x || !x.officer_name) return;
            if (!isBCHInCurrentQuarter(x)) return;
            const statusKey = bchStatusFor(x);
            const key = String(x.officer_name).trim();
            const o = om.get(bchFold(key)) || {};
            const position = o.title || o.position || "";
            if (!leaderMap.has(key)) leaderMap.set(key, { name: key, position, total: 0, done: 0, early: 0, ontime: 0, latedone: 0 });
            const row = leaderMap.get(key);
            row.total++;
            if (["early", "ontime", "latedone"].includes(statusKey)) { row.done++; row[statusKey] = (row[statusKey] || 0) + 1; }
            if (!row.position && position) row.position = position;
        });
    }

    const leaders = [...leaderMap.values()]
        .filter(a => a.done > 0)
        .sort((a, b) => b.done - a.done || b.total - a.total || a.name.localeCompare(b.name, "vi"));

    const leader = leaders[0] || null;
    if (leader) {
        HONOR_LEADER_OWNER = leader.name;
        document.getElementById("honorLeaderName").textContent = leader.name;
        document.getElementById("honorLeaderDetail").textContent =
            `${leader.position ? leader.position + " · " : ""}${leader.done} hoàn thành / ${leader.total} NV trong quý`;
        document.getElementById("honorLeaderScore").textContent = leader.done + " HT";
    } else {
        HONOR_LEADER_OWNER = "";
        document.getElementById("honorLeaderName").textContent = "Chưa có dữ liệu quý này";
        document.getElementById("honorLeaderDetail").textContent = "—";
        document.getElementById("honorLeaderScore").textContent = "—";
    }

    const u = document.getElementById("honorsUpdated");
    if (u) u.textContent = `Cập nhật ${new Date().toLocaleTimeString("vi-VN")}`;
}

function openHonorBestTasks() {
    if (!HONOR_BEST_OWNER) return;
    if (!canAccessOfficeData(CURRENT_USER)) { showToast('error', 'Khong co quyen', 'Token nay khong duoc xem du lieu Van phong.'); return; }
    const now = new Date(); const cm = now.getMonth(); const cy = now.getFullYear();
    const rows = DATA.filter(x => x.owner === HONOR_BEST_OWNER && (() => { const d = x && x._dueDate ? x._dueDate : parseDate(x && x.due); return d && d.getMonth() === cm && d.getFullYear() === cy; })());
    showDrill(rows,
        `Vinh danh tháng ${cm+1}/${cy} · ${HONOR_BEST_OWNER}`, "🌟");
}

function openHonorLeaderTasks() {
    if (!HONOR_LEADER_OWNER) return;
    // Vinh danh BCH quý: mở các nhiệm vụ HOÀN THÀNH của người được vinh danh trong quý
    if (Array.isArray(BCH_TASKS)) {
        const now = new Date(); const cm = now.getMonth(); const cy = now.getFullYear(); const cq = Math.floor(cm/3);
        const bchRows = BCH_TASKS.filter(x => x.officer_name === HONOR_LEADER_OWNER && (() => { const d = bchDeadlineDate(x.deadline); return d && Math.floor(d.getMonth()/3) === cq && d.getFullYear() === cy; })() && ["early", "ontime", "latedone"].includes(bchStatusFor(x)));
        if (bchRows.length) {
            renderBCHDrill(bchRows, `BCH quý ${cq+1}/${cy} · ${HONOR_LEADER_OWNER} · ${bchRows.length} hoàn thành`, "👑");
        }
    }
}

function updatePersonalCompletionCelebration(triggerFireworks = true) {
    const box = document.getElementById("personalCongrats");
    if (!box) return;
    if (!CURRENT_USER || CURRENT_USER.role !== "staff") {
        box.style.display = "none"; return;
    }
    const mine = DATA.filter(x => x.owner === CURRENT_USER.name);
    const done = mine.filter(x => completedStatuses.has(x.status));
    const allDone = mine.length > 0 && done.length === mine.length;
    if (!allDone) {
        box.style.display = "none"; return;
    }
    document.getElementById("congratsTitle").textContent = `Chúc mừng ${CURRENT_USER.name}!`;
    document.getElementById("congratsText").textContent = `Bạn đã hoàn thành toàn bộ ${mine.length} nhiệm vụ được giao. Tuyệt vời!`;
    document.getElementById("congratsScore").textContent = "100%";
    box.style.display = "flex";
    if (triggerFireworks) {
        const key = `vp_all_done_celebrated_${CURRENT_USER.name}`;
        if (!sessionStorage.getItem(key)) {
            sessionStorage.setItem(key, "1");
            launchLightFireworks(CURRENT_USER.name);
        }
    }
}

function checkDailyCompletionAndCelebrate(owner) {
    // Tên hàm cũ được giữ để tương thích các điểm gọi trước đây.
    if (CURRENT_USER && CURRENT_USER.role === "staff" && owner === CURRENT_USER.name) {
        updatePersonalCompletionCelebration(true);
    }
}

function launchLightFireworks(owner) {
    const canvas = document.getElementById("fireworksCanvas"), ctx = canvas.getContext("2d"), toast = document.getElementById("celebrateToast");
    canvas.width = innerWidth; canvas.height = innerHeight; canvas.style.display = "block";
    toast.textContent = `🎉 ${owner} đã hoàn thành 100% nhiệm vụ được giao!`; toast.style.display = "block";
    const particles = [];
    const palette = ["#f59e0b", "#fde68a", "#D55E00", "#009E73", "#60a5fa", "#ffffff"];
    for (let burst = 0; burst < 6; burst++) {
        const cx = innerWidth * (.2 + Math.random() * .6), cy = innerHeight * (.18 + Math.random() * .35);
        for (let i = 0; i < 26; i++) { const a = Math.PI * 2 * i / 22 + Math.random() * .15, sp = 1.6 + Math.random() * 2.8; particles.push({ x: cx, y: cy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, c: palette[(i + burst) % palette.length] }); }
    }
    const started = performance.now();
    function frame(now) {
        ctx.clearRect(0, 0, canvas.width, canvas.height); for (const p of particles) { p.x += p.vx; p.y += p.vy; p.vy += .024; p.vx *= .993; p.life -= .014; if (p.life > 0) { ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, 2.0, 0, Math.PI * 2); ctx.fill(); } } ctx.globalAlpha = 1;
        if (now - started < 5000) requestAnimationFrame(frame); else { canvas.style.display = "none"; toast.style.display = "none"; ctx.clearRect(0, 0, canvas.width, canvas.height); }
    }
    requestAnimationFrame(frame);
}

// ===== CẤU HÌNH SUPABASE =====
// office_tasks giữ dữ liệu nghiệp vụ bổ sung của Dashboard (file, ghi chú, gia hạn...).
const OFFICE_API_URL = `${SUPABASE_URL}/rest/v1/office_tasks?select=*&order=id.asc`;
const DEPARTMENT_API_URL = `${SUPABASE_URL}/rest/v1/department_tasks?select=*&order=sheet_name.asc,row_number.asc`;

// ===== GLOBAL STATE =====
let DATA = [], filtered = [];
function moveTaskToTop(arr, id) { const i = arr.findIndex(r => String(r.id) === String(id)); if (i > 0) { const [x] = arr.splice(i, 1); arr.unshift(x); } }
Object.defineProperty(window, "DATA", {
    configurable: true,
    get: () => DATA
});
const colors = {
    "Đang triển khai": "#12a8b4",
    "Hoàn thành trước hạn": "#009E73",
    "Hoàn thành đúng hạn": "#3b82f6",
    "Hoàn thành quá hạn": "#f59e0b",
    "Quá hạn": "#D55E00",
    "Thường xuyên": "#a855f7"
};
const completedStatuses = new Set(["Hoàn thành trước hạn", "Hoàn thành đúng hạn", "Hoàn thành quá hạn"]);
let charts = {};

let HOME_REFRESHING = false;

async function refreshAllData() {
    if (HOME_REFRESHING) return;
    HOME_REFRESHING = true;
    const btn = document.getElementById("refreshBtn");
    if (btn) btn.disabled = true;
    try {
        await Promise.all([loadData(), loadBCHData(true), loadTTBTVData(true), loadPROVData(true)]);
        render();
        checkDailyOverdueAlert();
    } finally {
        HOME_REFRESHING = false;
        if (btn) btn.disabled = false;
    }
}

function getAllHomeTasks() {
    const tier = getBchViewTier(CURRENT_USER);
    if (CURRENT_USER?.role === "staff" && CURRENT_USER?.scope === "bch") {
        if (tier === "full") { const hideOffice = !canAccessOfficeData(CURRENT_USER); return [...(hideOffice ? [] : DATA), ...BCH_TASKS, ...TTBTV_TASKS, ...PROV_TASKS, ...KH100_TASKS_CACHE, ...VPUB_TASKS_CACHE]; }
        if (tier === "broad") return [...BCH_TASKS, ...TTBTV_TASKS, ...PROV_TASKS, ...KH100_TASKS_CACHE];
        return [...BCH_TASKS];
    }
    const hideOffice = !canAccessOfficeData(CURRENT_USER);
    return [...(hideOffice ? [] : DATA), ...BCH_TASKS, ...TTBTV_TASKS, ...PROV_TASKS, ...KH100_TASKS_CACHE, ...VPUB_TASKS_CACHE];
}

// ===== BỘ LỌC NHANH TRANG CHỦ (chỉ lọc dữ liệu hiện có) =====
let HOME_FILTER = { agency: "all", owner: "", status: "" };

function homeAgencyMatch(x) {
    const key = homeSourceKey(x);
    if (HOME_FILTER.agency === "all") return true;
    return key === HOME_FILTER.agency;
}
function homeStatusOf(x) {
    const src = homeSourceKey(x);
    const s = src === "bch" ? bchStatusLabel(bchStatusFor(x)) : src === "ttbtv" ? ttbtvStatusLabel(ttbtvStatusFor(x)) : src === "province" ? provinceStatusLabel(provinceStatusFor(x)) : x.status;
    return s;
}
function homeRowPass(x) {
    if (!homeAgencyMatch(x)) return false;
    const owner = String(x.owner || x.officer_name || "").trim();
    if (HOME_FILTER.owner && owner !== HOME_FILTER.owner) return false;
    if (HOME_FILTER.status && homeStatusOf(x) !== HOME_FILTER.status) return false;
    return true;
}
function homeFilterSource(source) {
    const isBch = CURRENT_USER?.role === "staff" && CURRENT_USER?.scope === "bch";
    const tier = getBchViewTier(CURRENT_USER);
    const bchOnly = isBch && tier !== "full" && tier !== "broad";
    const broad = tier === "broad";
    const map = { office: canAccessOfficeData(CURRENT_USER) ? DATA : [], bch: BCH_TASKS, ttbtv: (bchOnly ? [] : TTBTV_TASKS), province: (bchOnly ? [] : PROV_TASKS), action100: (bchOnly ? [] : KH100_TASKS_CACHE), vpub: (bchOnly ? [] : VPUB_TASKS_CACHE) };
    if (bchOnly && source !== "bch") return [];
    if (isBch && broad && source === "office") return [];
    return (map[source] || []).filter(homeRowPass);
}
function homeFilteredTasks() {
    const key = JSON.stringify(HOME_FILTER) + '|' + (DATA.length+BCH_TASKS.length+TTBTV_TASKS.length+PROV_TASKS.length) + '|' + (canAccessOfficeData(CURRENT_USER)?'1':'0');
    if(_homeFilteredCache && _homeFilteredAt===key) return _homeFilteredCache;
    const res = ["office", "bch", "ttbtv", "province", "action100", "vpub"].flatMap(s => homeFilterSource(s));
    _homeFilteredCache=res; _homeFilteredAt=key;
    return res;
}

function refreshHomeFilterOwnerOptions() {
    const mayOffice = canAccessOfficeData(CURRENT_USER);
    const agencySel = document.getElementById("homeFilterAgency");
    if (agencySel) {
        const officeOpt = agencySel.querySelector('option[value="office"]');
        if (officeOpt) officeOpt.style.display = mayOffice ? "" : "none";
    }
    const el = document.getElementById("homeFilterOwner");
    if (!el) return;
    const prev = el.value;
    const names = [...new Set(homeFilteredTasks().map(x => String(x.owner || x.officer_name || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
    el.innerHTML = '<option value="">Tất cả cán bộ</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
    el.value = names.includes(prev) ? prev : "";
}

function applyHomeFilter() {
    const agency = document.getElementById("homeFilterAgency");
    const owner = document.getElementById("homeFilterOwner");
    const status = document.getElementById("homeFilterStatus");
    HOME_FILTER.agency = agency ? agency.value : "all";
    HOME_FILTER.owner = owner ? owner.value : "";
    HOME_FILTER.status = status ? status.value : "";
    renderHomeDashboard();
}
function resetHomeFilter() {
    HOME_FILTER = { agency: "all", owner: "", status: "" };
    const a = document.getElementById("homeFilterAgency"); if (a) a.value = "all";
    const s = document.getElementById("homeFilterStatus"); if (s) s.value = "";
    refreshHomeFilterOwnerOptions();
    renderHomeDashboard();
}
function renderHomeDashboard() {
    if (!canAccessOfficeData(CURRENT_USER)) {
        const o = document.getElementById("homeFilterAgency");
        if (o) { const allow = ["all", "bch", "ttbtv", "province"]; if (!allow.includes(o.value)) o.value = "all"; }
        if (HOME_FILTER.agency === "office" || o?.value === "office") HOME_FILTER.agency = "all";
    }
    refreshHomeFilterOwnerOptions();
    render();
}

function homeSource(x) {
    if (BCH_TASKS.includes(x)) return "BCH";
    if (TTBTV_TASKS.includes(x)) return "BTV";
    if (PROV_TASKS.includes(x)) return "Tỉnh";
    if (typeof KH100_TASKS_CACHE !== 'undefined' && KH100_TASKS_CACHE.includes(x)) return "KH100";
    if (typeof VPUB_TASKS_CACHE !== 'undefined' && VPUB_TASKS_CACHE.includes(x)) return "VPUB";
    if (typeof ACTION100_TASKS !== 'undefined' && ACTION100_TASKS.includes(x)) return ACTION100_MODE === 'vpub' ? "VPUB" : "KH100";
    const raw = String(x?._source || "").toLowerCase();
    if (raw.includes("bch")) return "BCH";
    if (raw.includes("tt") || raw.includes("btv")) return "BTV";
    if (raw.includes("prov") || raw.includes("tinh")) return "Tỉnh";
    if (raw.includes("kh100") || raw.includes("action")) return "KH100";
    if (raw.includes("vpub")) return "VPUB";
    return "Văn phòng";
}
function homeSourceKey(x) { return ({ "Văn phòng": "office", BCH: "bch", BTV: "ttbtv", "Tỉnh": "province", KH100: "action100", VPUB: "vpub" })[homeSource(x)] || "office"; }
function homeStatus(x) { const s = homeSource(x); if(s==="VPUB") return action100Label(action100Status(x), true); if(s==="KH100") return action100Label(action100Status(x)); return s === "BCH" ? bchStatusLabel(bchStatusFor(x)) : s === "BTV" ? ttbtvStatusLabel(ttbtvStatusFor(x)) : s === "Tỉnh" ? provinceStatusLabel(provinceStatusFor(x)) : x.status; }
function homeDue(x) { return homeSource(x) === "Văn phòng" ? x.due : parseDate(x.deadline || x.due || x.deadline_date); }
function sortNewestFirst(rows) {
    const stamp = x => { const t = Date.parse(x?.created_at || x?._createdDate || ""); return Number.isFinite(t) ? t : null; };
    return [...rows].sort((a, b) => {
        const A = stamp(a), B = stamp(b);
        if (A !== null && B !== null && A !== B) return B - A;
        if (A === null && B !== null) return 1;
        if (A !== null && B === null) return -1;
        const ai = Number(a?.id), bi = Number(b?.id);
        if (Number.isFinite(ai) && Number.isFinite(bi) && ai !== bi) return bi - ai;
        return String(b?.id ?? "").localeCompare(String(a?.id ?? ""));
    });
}
function showHomeDrill(rows, title) {
    rows = sortNewestFirst(rows);
    const body = document.getElementById("homeDrillBody");
    document.getElementById("homeDrillTitle").textContent = title;
    document.getElementById("homeDrillCount").textContent = rows.length;
    document.getElementById("homeDrillEmpty").style.display = rows.length ? "none" : "block";
    const jsA=v=>`'${String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}'`;
    body.innerHTML = rows.map((x, i) => `<tr class="home-drill-row" onclick="openHomeTaskDrill(${jsA(homeSourceKey(x))}, ${jsA(String(x.id))})"><td>${i + 1}</td><td class="task-tip-cell"><div class="task-tip" data-full="${esc((x.task || x.task_name || "") + regularMonthTagText(x))}">${esc(x.task || x.task_name || "")}${regularMonthTagHtml(x)}</div></td><td>${esc(homeSource(x))}</td><td>${esc(x.owner || x.officer_name || "")}</td><td>${formatDate(homeDue(x))}</td><td><span class="home-status-badge ${homeStatusClass(x)}">${esc(homeStatus(x))}</span></td><td>${esc(x.product || x.result || "Không")}</td><td onclick="event.stopPropagation()">${homeActionHtml(x)}</td></tr>`).join("");
    smoothOpenModal("homeDrillModal");
}

function showStatsDrill(rows, title) {
    rows = sortNewestFirst(rows);
    const body = document.getElementById("statsDrillBody");
    document.getElementById("statsDrillTitle").textContent = title;
    document.getElementById("statsDrillCount").textContent = rows.length;
    document.getElementById("statsDrillEmpty").style.display = rows.length ? "none" : "block";
    const jsA=v=>`'${String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}'`;
    body.innerHTML = rows.map((x, i) => `<tr class="home-drill-row" onclick="openHomeTaskDrill(${jsA(homeSourceKey(x))}, ${jsA(String(x.id))})" title="Click để xem chi tiết nhiệm vụ"><td>${i + 1}</td><td class="task-tip-cell"><div class="task-tip" data-full="${esc((x.task || x.task_name || "") + regularMonthTagText(x))}">${esc(x.task || x.task_name || "")}${regularMonthTagHtml(x)}</div></td><td>${esc(homeSource(x))}</td><td>${esc(x.owner || x.officer_name || "")}</td><td>${formatDate(homeDue(x))}</td><td><span class="home-status-badge ${homeStatusClass(x)}">${esc(homeStatus(x))}</span></td><td>${esc(x.product || x.result || "Không")}</td><td onclick="event.stopPropagation()">${homeActionHtml(x)}</td></tr>`).join("");
    smoothOpenModal("statsDrillModal");
}

function openHomeTaskDrill(source, id) {
    if (source === "province") {
        try{ smoothCloseModal("homeDrillModal"); smoothCloseModal("statsDrillModal"); }catch(e){}
        if(typeof openPROVTaskEdit==="function") return openPROVTaskEdit(String(id));
    }
    if (source === "office" && !canAccessOfficeData(CURRENT_USER)) { showToast('error', 'Khong co quyen', 'Token nay khong duoc xem du lieu Van phong.'); return; }
    const rows = source === "office" ? DATA : source === "bch" ? BCH_TASKS : source === "ttbtv" ? TTBTV_TASKS : source === "province" ? PROV_TASKS : source === "action100" ? (KH100_TASKS_CACHE.length?KH100_TASKS_CACHE:ACTION100_TASKS) : source === "vpub" ? (VPUB_TASKS_CACHE.length?VPUB_TASKS_CACHE:ACTION100_TASKS) : [];
    const task = rows.find(x => String(x.id) === String(id));
    if (!task) return;
    return showHomeDrill([task], `Chi tiết nhiệm vụ · ${homeSource(task)}`);
}

function homeStatusClass(x) {
    const status = homeStatus(x);
    if (status.includes("Hoàn thành trước")) return "early";
    if (status.includes("Hoàn thành đúng")) return "ontime";
    if (status.includes("Hoàn thành quá")) return "late-done";
    if (status.includes("Quá hạn")) return "overdue";
    return "doing";
}

function homeActionHtml(x) {
    const source = homeSourceKey(x);
    const due = homeDue(x);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const isOverdue = due && due < today && !homeStatus(x).includes("Hoàn thành");
    if (!isOverdue || !CURRENT_USER || CURRENT_USER.role !== "admin") return `<span class="home-click-hint">Xem</span>`;
    const jsA=v=>`'${String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'")}'`;
    return `<button class="extend-btn" onclick="openHomeExtend(${jsA(source)}, ${jsA(String(x.id))})">📅 Gia hạn</button>`;
}

async function sendWorkspaceDeadlineNotice(source, id) {
    const rows = source === "bch" ? BCH_TASKS : source === "ttbtv" ? TTBTV_TASKS : PROV_TASKS;
    const task = rows.find(x => String(x.id) === String(id));
    if (!task) return;
    if (source === "office") return window.sendDeadlineEmail?.(id);
    showToast("info", "Gửi thông báo", `Đã ghi nhận yêu cầu gửi thông báo cho nhiệm vụ ${task.task_name || "quá hạn"}.`);
    if (typeof writeActivity === "function") writeActivity("Gửi thông báo quá hạn", { source, id: task.id, task: task.task_name });
}

function openHomeExtend(source, id) {
    if (!CURRENT_USER || (CURRENT_USER.role !== "admin" && !isNGNUser(CURRENT_USER))) return;
    const rows = source === "office" ? DATA : source === "bch" ? BCH_TASKS : source === "ttbtv" ? TTBTV_TASKS : PROV_TASKS;
    const task = rows.find(x => String(x.id) === String(id));
    if (!task) return;
    window.HOME_EXTEND_TARGET = { source, id: task.id };
    document.getElementById("extendTaskLabel").textContent = `${task.owner || task.officer_name || ""} · ${task.task || task.task_name || ""}`;
    document.getElementById("extendCurrentDate").innerHTML = `<b>Hạn hiện tại:</b> ${formatDate(homeDue(task))}`;
    const d = homeDue(task), input = document.getElementById("extendNewDate");
    input.value = d ? formatDate(d) : "";
    document.getElementById("extendReason").value = "";
    smoothOpenModal("extendModal");
}

function openExtendFromWorkspace(source) {
    if (!CURRENT_USER || (CURRENT_USER.role !== "admin" && !isNGNUser(CURRENT_USER))) return;
    const ids = { bch: BCH_EDIT_ID, ttbtv: TTBTV_EDIT_ID, province: PROV_EDIT_ID };
    openHomeExtend(source, ids[source]);
}


function statsTaskRows(type) {
    return homeFilteredTasks().filter(x => {
        const source = homeSource(x);
        const sourceKey = homeSourceKey(x);
        const status = homeStatus(x);
        const statusKey = sourceKey === "bch" ? (typeof bchStatusFor === "function" ? bchStatusFor(x) : "") : sourceKey === "ttbtv" ? (typeof ttbtvStatusFor === "function" ? ttbtvStatusFor(x) : "") : sourceKey === "province" ? (typeof provinceStatusFor === "function" ? provinceStatusFor(x) : "") : sourceKey === "action100" || sourceKey === "vpub" ? (typeof action100Status === "function" ? action100Status(x) : "") : x.status;
        const due = homeDue(x);
        const day = due ? Math.round((due - new Date(new Date().setHours(0, 0, 0, 0))) / 86400000) : null;
        if (type === "total") return true;
        if (type === "done") {
            if (sourceKey === "office") return typeof completedStatuses !== "undefined" ? completedStatuses.has(x.status) : String(status).includes("Hoàn thành");
            if (["bch","ttbtv","province"].includes(sourceKey)) return ["early","ontime","latedone","done"].includes(statusKey);
            if (["action100","vpub"].includes(sourceKey)) return ["early","ontime","latedone"].includes(statusKey);
            return String(status).includes("Hoàn thành");
        }
        if (type === "doing") {
            if (sourceKey === "office") return x.status === "Đang triển khai";
            if (["bch","ttbtv","province"].includes(sourceKey)) return statusKey === "processing";
            if (["action100","vpub"].includes(sourceKey)) return statusKey === "processing";
            return status === "Đang triển khai";
        }
        if (type === "late") return status === "Quá hạn" || status === "NV đang xử lý" || (day !== null && day < 0 && !String(status).includes("Hoàn thành"));
        if (type === "soon") return day !== null && day >= 0 && day <= 7 && !String(status).includes("Hoàn thành");
        if (type === "emergent") return Boolean(x.emergent ?? x.phat_sinh ?? x.is_arising);
        if (type === "extended") return Boolean(x.extended ?? x.is_extended);
        return false;
    });
}

function getSoonTasksForCurrentUser(){
    const isSoon=x=>{
        const due=homeDue(x); const status=homeStatus(x);
        const day=due?Math.round((due-new Date(new Date().setHours(0,0,0,0)))/86400000):null;
        return day!==null && day>=0 && day<=7 && !String(status).includes("Hoàn thành");
    };
    if(!CURRENT_USER) return [];
    if(CURRENT_USER.role==="admin") return homeFilteredTasks().filter(isSoon);
    const scope=CURRENT_USER.scope; const name=CURRENT_USER.name||""; const norm=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim(); const u=norm(name);
    // office staff - chỉ nhiệm vụ VP Đảng ủy của chính mình
    if(scope==="office") return (typeof DATA!=="undefined"?DATA:[]).filter(x=>{const o=norm(String(x.owner||"")); return (o===u||o.includes(u)||u.includes(o)) && isSoon(x);});
    // BCH
    if(scope==="bch") return (typeof BCH_TASKS!=="undefined"?BCH_TASKS:[]).filter(x=>{const o=norm(String(x.officer_name||"")); return (o===u||o.includes(u)||u.includes(o)) && isSoon(x);});
    // TT/BTV
    if(scope==="ttbtv"||scope==="data_entry") return (typeof TTBTV_TASKS!=="undefined"?TTBTV_TASKS:[]).filter(x=>{const o=norm(String(x.officer_name||"")); return (o===u||o.includes(u)||u.includes(o)) && isSoon(x);});
    // Tỉnh giao
    if(scope==="province") return (typeof PROV_TASKS!=="undefined"?PROV_TASKS:[]).filter(x=>{const o=norm(String(x.officer_name||x.officer||"")); return (o===u||o.includes(u)||u.includes(o)) && isSoon(x);});
    // action100 department/staff - khớp cơ quan phụ trách/phối hợp
    if(scope==="action100"){
        const src=(typeof KH100_TASKS_CACHE!=="undefined"&&KH100_TASKS_CACHE.length?KH100_TASKS_CACHE:(typeof ACTION100_TASKS!=="undefined"?ACTION100_TASKS:[]));
        return src.filter(x=>{
            if(!isSoon(x)) return false;
            try{ if(typeof canEditAction100Task==="function" && canEditAction100Task(x)) return true; }catch(e){}
            const unit=norm(x.commune_leader||x.unit_name||""); return unit.includes(u)||u.includes(unit);
        });
    }
    if(scope==="vpub"){
        const src=(typeof VPUB_TASKS_CACHE!=="undefined"&&VPUB_TASKS_CACHE.length?VPUB_TASKS_CACHE:(typeof ACTION100_TASKS!=="undefined"?ACTION100_TASKS:[]));
        return src.filter(x=>{
            if(!isSoon(x)) return false;
            const unit=norm(x.unit||x.field||""); return unit.includes(u)||u.includes(unit)||String(x.leader||"").trim()===name;
        });
    }
    // fallback: chỉ nhiệm vụ mang tên mình trong home
    return homeFilteredTasks().filter(x=>{const o=norm(String(x.owner||x.officer_name||"")); return (o===u||o.includes(u)||u.includes(o)) && isSoon(x);});
}
async function updateNotifCount(){
    const el=document.getElementById("notifCount"); if(!el) return;
    if(!CURRENT_USER){ el.textContent=0; return; }
    try{ await refreshDailyWarnTasks(); }catch(e){}
    el.textContent=(typeof DAILY_SOON_TASKS!=="undefined"?DAILY_SOON_TASKS.length:0);
}
function openSoonTasks(){
    openDailyWarnModal();
}
if(typeof window!=="undefined"){ window.getSoonTasksForCurrentUser=getSoonTasksForCurrentUser; window.updateNotifCount=updateNotifCount; window.openSoonTasks=openSoonTasks; }
function renderAgencyTotalsChart() {
    const canvas = document.getElementById("chartBar");
    if (!canvas) return;
    const mayOffice = canAccessOfficeData(CURRENT_USER);
    const ag = HOME_FILTER.agency;
    if(!KH100_TASKS_CACHE.length){ const _c=readCache("action100_tasks_cache"); if(_c && _c.length) KH100_TASKS_CACHE=_c; }
    if(!VPUB_TASKS_CACHE.length){ const _c=readCache("vpub_tasks_cache"); if(_c && _c.length) VPUB_TASKS_CACHE=_c; }
    if(!KH100_TASKS_CACHE.length){
        fetch(`${SUPABASE_URL}/rest/v1/action_100_days_tasks?select=id,task_name,officer_name,deadline,product,result,staff_note`, {headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`}}).then(r=>r.ok?r.json():[]).then(j=>{ if(Array.isArray(j)&&j.length){ KH100_TASKS_CACHE=j; writeCache("action100_tasks_cache", j); try{renderAgencyTotalsChart();}catch(e){} } }).catch(()=>{});
    }
    if(!VPUB_TASKS_CACHE.length){
        fetch(`${SUPABASE_URL}/rest/v1/vpub_tasks?select=id,task_name,unit,field,leader,deadline,product`, {headers:{apikey:SUPABASE_KEY, Authorization:`Bearer ${SUPABASE_KEY}`}}).then(r=>r.ok?r.json():[]).then(j=>{ if(Array.isArray(j)&&j.length){ VPUB_TASKS_CACHE=j; writeCache("vpub_tasks_cache", j); try{renderAgencyTotalsChart();}catch(e){} } }).catch(()=>{});
    }
    const defs = [
        { key: "office", label: "Văn phòng Đảng ủy", color: "#2563eb", data: () => mayOffice ? homeFilterSource("office") : [] },
        { key: "bch", label: "BCH", color: "#0891b2", data: () => homeFilterSource("bch") },
        { key: "ttbtv", label: "BTV", color: "#7c3aed", data: () => homeFilterSource("ttbtv") },
        { key: "province", label: "Tỉnh", color: "#16a34a", data: () => homeFilterSource("province") },
        { key: "action100", label: "KH100", color: "#f59e0b", data: () => KH100_TASKS_CACHE },
        { key: "vpub", label: "VP HĐND&UBND", color: "#ec4899", data: () => VPUB_TASKS_CACHE }
    ].filter(d => (d.key !== "office" || mayOffice) && (ag === "all" || ag === d.key));
    const labels = defs.map(d => d.label);
    const counts = defs.map(d => d.data().length);
    const sources = defs.map(d => d.data());
    if (charts.chartBar) charts.chartBar.destroy();
    charts.chartBar = new Chart(canvas.getContext("2d"), {
        type: "bar",
        data: { labels, datasets: [{ label: "Tổng số nhiệm vụ", data: counts, backgroundColor: defs.map(d => d.color), borderRadius: 6 }] },
        options: {
            indexAxis: "y",
            responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }, onClick: (event, elements) => {
                if (!elements.length) return;
                const index = elements[0].index;
                showHomeDrill(sources[index] || [], `Tổng nhiệm vụ · ${labels[index]}`);
            }
        }
    });
    const sc=document.getElementById("chartStatusDonut");
    if(sc){
        const rows=homeFilteredTasks();
        const mp={}; rows.forEach(x=>{ let s=homeStatus(x); if(!s||s==="undefined") s="Đang triển khai"; mp[s]=(mp[s]||0)+1; });
        const lbs=Object.keys(mp);
        const cmap={"Đang triển khai":"#56B4E9","Hoàn thành trước hạn":"#009E73","Hoàn thành đúng hạn":"#3b82f6","Hoàn thành quá hạn":"#f59e0b","Quá hạn":"#D55E00"};
        if(charts.chartStatusDonut) charts.chartStatusDonut.destroy();
        charts.chartStatusDonut=new Chart(sc.getContext("2d"),{type:"line",data:{labels:lbs,datasets:[{label:"Số nhiệm vụ",data:lbs.map(k=>mp[k]),borderColor:"#0ea5e9",backgroundColor:"rgba(14,165,233,0.18)",fill:true,tension:0.38,pointBackgroundColor:lbs.map(k=>cmap[k]||"#94a3b8"),pointBorderColor:"#fff",pointRadius:5,pointHoverRadius:7,borderWidth:2.5}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}},x:{grid:{display:false}}},onClick:(e,els)=>{if(!els.length) return; const lb=lbs[els[0].index]; showHomeDrill(rows.filter(x=>homeStatus(x)===lb), `Trạng thái · ${lb}`);}}});
        const lg=document.getElementById("legendStatusDonut"); if(lg) lg.innerHTML=lbs.map(l=>`<div class="legend-item"><span class="legend-color" style="background:${cmap[l]||"#94a3b8"}"></span><span>${l} (${mp[l]})</span></div>`).join("");
    }
    const ac=document.getElementById("chartAgencyDonut");
    if(ac){
        if(charts.chartAgencyDonut) charts.chartAgencyDonut.destroy();
        charts.chartAgencyDonut=new Chart(ac.getContext("2d"),{type:"polarArea",data:{labels,datasets:[{data:counts,backgroundColor:defs.map(d=>d.color),borderColor:"#fff",borderWidth:1}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{r:{beginAtZero:true,ticks:{precision:0}}},onClick:(e,els)=>{if(!els.length) return; const idx=els[0].index; showHomeDrill(sources[idx]||[], `Cơ quan · ${labels[idx]}`);}}});
        const lg2=document.getElementById("legendAgencyDonut"); if(lg2) lg2.innerHTML=labels.map((l,i)=>`<div class="legend-item"><span class="legend-color" style="background:${defs[i].color}"></span><span>${l} (${counts[i]})</span></div>`).join("");
    }
}

function isSoonAcrossSources(x, source) {
    const status = homeStatus(x);
    if (String(status).includes("Hoàn thành")) return false;
    const due = parseDate(homeDue(x));
    if (!due) return false;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const days = Math.round((due - today) / 86400000);
    return days >= 0 && days <= 7;
}

function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, m => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[m]));
}

function parseDate(v) {
    if (!v) return null;
    if (v instanceof Date) return isNaN(v) ? null : new Date(v.getFullYear(), v.getMonth(), v.getDate());
    const s = String(v).trim();
    let y, m, d, a = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);
    if (a) { y = +a[1]; m = +a[2]; d = +a[3]; }
    else {
        a = s.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
        if (!a) return null;
        d = +a[1]; m = +a[2]; y = +a[3];
    }
    const dt = new Date(y, m - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
}
function formatDate(v) {
    const d = parseDate(v);
    return d ? `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}` : (v || "—");
}
function dateToDb(v) {
    if (!v) return null;
    const d = parseDate(v); if (!d) return null;
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function dateMask(el) {
    let x = String(el.value || "").replace(/\D/g, "").slice(0, 8);
    if (x.length > 4) x = x.slice(0, 2) + "/" + x.slice(2, 4) + "/" + x.slice(4);
    else if (x.length > 2) x = x.slice(0, 2) + "/" + x.slice(2);
    el.value = x;
}
function requireValidDate(value, label, required = false) {
    const s = String(value || "").trim();
    if (!s) { if (required) throw new Error(`${label} không được để trống.`); return null; }
    const db = dateToDb(s);
    if (!db) throw new Error(`${label} chưa phải là ngày hợp lệ.`);
    return db;
}
function dayDiff(v) {
    const d = v instanceof Date ? v : parseDate(v);
    if (!d) return null;
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    return Math.round((d - now) / 86400000);
}

function hasMeaningfulProduct(v) {
    const t = String(v ?? "").trim().toLowerCase();
    return !!t && !["không", "khong", "none", "null", "---", "--", "-"].includes(t);
}

// V19 - Công thức trạng thái duy nhất cho toàn Dashboard.
// Có nội dung sản phẩm HOẶC có tệp đính kèm = có minh chứng hoàn thành (tệp có thể đang chờ Admin duyệt).
// Ngày hoàn thành < hạn hiện hành => trước hạn; = hạn => đúng hạn; > hạn hiện hành/ngày gia hạn => HOÀN THÀNH QUÁ HẠN.
function calculateTaskStatus(x, overrides = {}) {
    if (overrides._regular === true) return "Thường xuyên";
    if (overrides._regular !== false && String(overrides.status ?? x?.status ?? "").trim() === "Thường xuyên") return "Thường xuyên";
    const due = parseDate(overrides.due !== undefined ? overrides.due : x?.due);
    const completed = parseDate(overrides.completed_date !== undefined ? overrides.completed_date : x?.completed_date);
    const product = overrides.product !== undefined ? overrides.product : x?.product;
    const hasFile = overrides.hasFile !== undefined ? !!overrides.hasFile : !!x?.attachment_path;
    const ready = (hasMeaningfulProduct(product) || hasFile) && !!completed && !!due;

    if (ready) {
        const delta = completed.getTime() - due.getTime();
        if (delta < 0) return "Hoàn thành trước hạn";
        if (delta === 0) return "Hoàn thành đúng hạn";
        return "Hoàn thành quá hạn";
    }

    // Chưa đủ điều kiện hoàn thành: nếu mốc thực tế (ngày hoàn thành đã nhập hoặc hôm nay) vượt hạn => Quá hạn.
    if (due) {
        const ref = completed || (() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; })();
        if (ref.getTime() > due.getTime()) return "Quá hạn";
    }
    return "Đang triển khai";
}

function statusBadgeClass(status) {
    return ({
        "Đang triển khai": "badge-status-doing",
        "Hoàn thành trước hạn": "badge-status-early",
        "Hoàn thành đúng hạn": "badge-status-ontime",
        "Hoàn thành quá hạn": "badge-status-late-done",
        "Quá hạn": "badge-status-overdue",
        "Thường xuyên": "badge-status-regular"
    })[status] || "badge-status-doing";
}

function urgencyInfo(x) {
    if (String(x.status || "").trim() === "Thường xuyên") return { key: "regular", label: "🔁 Thường xuyên", cls: "u-regular" };
    if (completedStatuses.has(x.status)) return { key: "done", label: "✅ Đã hoàn thành", cls: "u-safe" };
    const n = dayDiff(x.due);
    if (n === null) return { key: "none", label: "Chưa có hạn", cls: "u-safe" };
    if (n < 0) return { key: "overdue", label: `⏰ Quá ${Math.abs(n)} ngày`, cls: "u-overdue" };
    if (n === 0) return { key: "today", label: "📅 Hôm nay", cls: "u-today" };
    if (n <= 3) return { key: "soon3", label: `⏳ Còn ${n} ngày`, cls: "u-soon" };
    return { key: "safe", label: `📅 Còn ${n} ngày`, cls: "u-safe" };
}

function canonicalStatus(v) {
    const raw = String(v ?? "").trim().toLowerCase();
    const legacy = {
        "trước hạn": "Hoàn thành trước hạn",
        "đúng hạn": "Hoàn thành đúng hạn",
        "đã hoàn thành": "Hoàn thành đúng hạn",
        "hoàn thành": "Hoàn thành đúng hạn",
        "hoàn thành trước hạn": "Hoàn thành trước hạn",
        "hoàn thành đúng hạn": "Hoàn thành đúng hạn",
        "hoàn thành quá hạn": "Hoàn thành quá hạn",
        "quá hạn": "Quá hạn",
        "thường xuyên": "Thường xuyên",
        "regular": "Thường xuyên",
        "đang triển khai": "Đang triển khai",
        "chưa cập nhật": "Đang triển khai",
        "none": "Đang triển khai",
        "": "Đang triển khai"
    };
    return legacy[raw] || "Đang triển khai";
}

function dbStatus(v) {
    const map = {
        "Đang triển khai": "đang triển khai",
        "Hoàn thành trước hạn": "hoàn thành trước hạn",
        "Hoàn thành đúng hạn": "hoàn thành đúng hạn",
        "Hoàn thành quá hạn": "hoàn thành quá hạn",
        "Quá hạn": "quá hạn",
        "Thường xuyên": "thường xuyên"
    };
    return map[v] || "đang triển khai";
}

function normalizeTask(x, i, source = "office") {
    const due = String(x.deadline_date ?? x.deadline ?? x.due ?? "").trim();
    const taskText = String(x.task_name ?? x.task ?? x.nhiemVu ?? x["Nhiệm vụ"] ?? "").trim();
    if (!taskText || (!isNaN(taskText) && String(taskText).trim() !== "")) return null;
    if (taskText.length < 2) return null;

    const owner = String(x.officer_name ?? x.owner ?? x.sheet_name ?? "Chưa xác định").trim();
    const _isRegRaw = x.is_regular === true || String(x.is_regular || "").toLowerCase() === "true" || String(x.status || "").trim().toLowerCase() === "thường xuyên" || String(x.status || "").trim().toLowerCase() === "regular";
    const obj = {
        id: x.id,
        owner,
        position: String(x.position ?? "").trim(),
        stt: x.stt ?? x.id ?? (i + 1),
        task: taskText,
        role: String(x.role ?? "").trim(),
        due,
        completed_date: String(x.completed_date ?? x.completed ?? "").trim(),
        status: canonicalStatus(x.status),
        admin_note: String(x.note ?? x.admin_note ?? "").trim(),
        staff_note: String(x.staff_note ?? "").trim(),
        emergent: x.is_arising === true || x.emergent === true,
        extended: x.is_extended === true || x.extended === true,
        is_regular: _isRegRaw,
        product: String(x.product ?? "").trim() || "Không",
        attachment_path: String(x.attachment_path ?? "").trim(),
        attachment_name: String(x.attachment_name ?? "").trim(),
        attachment_type: String(x.attachment_type ?? "").trim(),
        attachment_size: Number(x.attachment_size ?? 0) || 0,
        attachment_approved: x.attachment_approved === undefined || x.attachment_approved === null
            ? !!String(x.attachment_path ?? "").trim()
            : x.attachment_approved === true,
        attachment_approved_at: String(x.attachment_approved_at ?? "").trim(),
        attachment_approved_by: String(x.attachment_approved_by ?? "").trim(),
        sheet_name: String(x.sheet_name ?? "").trim(),
        row_number: Number(x.row_number ?? 0) || 0,
        updated_at: String(x.updated_at ?? "").trim(),
        created_at: String(x.created_at ?? x.createdAt ?? "").trim(),
        _source: source
    };
    if (obj.is_regular && obj.status === "Thường xuyên") obj.status = "Đang triển khai";
    obj._matchKey = taskMatchKey(owner, taskText);
    obj.status = calculateTaskStatus(obj, { _regular: false });
    obj._dueDate = parseDate(due);
    obj._createdDate = getCreationDate(obj);
    try { obj.role = officeRoleCanonical(obj.role) || obj.role; } catch (e) {}
    obj._search = (obj.task + " " + obj.owner + " " + obj.role + " " + (officeRoleDisplay(obj.role) || "") + " " + obj.staff_note + " " + obj.admin_note + " " + obj.product).toLowerCase();
    return obj;
}

function taskMatchKey(owner, task) {
    const fold = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/\s+/g, " ").trim();
    return fold(owner) + "||" + fold(task);
}

function markDepartmentMonthBlocks(rows) {
    const groups = new Map();
    rows.forEach(x => {
        if (!x || !x.sheet_name) return;
        if (!groups.has(x.sheet_name)) groups.set(x.sheet_name, []);
        groups.get(x.sheet_name).push(x);
    });
    groups.forEach(list => {
        list.sort((a, b) => (a.row_number || 0) - (b.row_number || 0));
        let block = 0, prevStt = null;
        for (const x of list) {
            const n = Number(x.stt);
            if (prevStt !== null && n === 1 && Number(prevStt) >= 1) block++;
            x._monthBlock = block;
            prevStt = Number.isFinite(n) ? n : prevStt;
        }
        const maxBlock = Math.max(...list.map(x => x._monthBlock || 0));
        list.forEach(x => x._isLatestMonthBlock = (x._monthBlock || 0) === maxBlock);
    });
    return rows;
}

function mergeDepartmentAndOffice(departmentRows, officeRows) {
    const officeMap = new Map();
    officeRows.forEach(x => {
        if (!x) return;
        const key = x._matchKey;
        const current = officeMap.get(key);
        if (!current || Number(x.id || 0) > Number(current.id || 0)) officeMap.set(key, x);
    });

    const merged = [];
    const usedOffice = new Set();

    departmentRows.forEach(dep => {
        if (!dep) return;
        const off = officeMap.get(dep._matchKey);
        if (off) {
            usedOffice.add(off);
            // Nội dung gốc theo Sheet; dữ liệu Dashboard đã cập nhật được ưu tiên cho các trường nghiệp vụ.
            const x = {
                ...dep,
                id: off.id,
                task: off.task || dep.task,
                position: off.position || dep.position,
                role: off.role || dep.role,
                due: off.due || dep.due,
                completed_date: off.completed_date || dep.completed_date,
                product: (off.product && off.product !== "Không") ? off.product : dep.product,
                admin_note: off.admin_note || "",
                staff_note: off.staff_note || "",
                emergent: off.emergent || dep.emergent,
                extended: off.extended || false,
                attachment_path: off.attachment_path || "",
                attachment_name: off.attachment_name || "",
                attachment_type: off.attachment_type || "",
                attachment_size: off.attachment_size || 0,
                attachment_approved: off.attachment_approved === true,
                attachment_approved_at: off.attachment_approved_at || "",
                attachment_approved_by: off.attachment_approved_by || "",
                _source: "merged",
                _monthBlock: dep._monthBlock,
                _isLatestMonthBlock: dep._isLatestMonthBlock
            };
            x.status = calculateTaskStatus(x);
            x._dueDate = parseDate(x.due);
            x.created_at = off.created_at || dep.created_at || x.created_at || "";
            x._createdDate = getCreationDate(x);
            try { x.role = officeRoleCanonical(x.role) || x.role; } catch (e) {}
            x._search = (x.task + " " + x.owner + " " + x.role + " " + (officeRoleDisplay(x.role) || "") + " " + x.staff_note + " " + x.admin_note + " " + x.product).toLowerCase();
            merged.push(x);
        } else {
            dep.status = calculateTaskStatus(dep);
            merged.push(dep);
        }
    });

    // Giữ các nhiệm vụ chỉ tồn tại trong office_tasks để không làm mất dữ liệu thủ công/phát sinh.
    officeRows.forEach(off => {
        if (off && !usedOffice.has(off)) merged.push(off);
    });

    return merged;
}

function setSync(state, message) {
    document.getElementById("syncDot").className = "sync-dot " + state;
    document.getElementById("syncText").textContent = message;
}

async function loadData() {
    const btn = document.getElementById("refreshBtn");
    try {
        setSync("loading", "Đang đồng bộ dữ liệu từ Supabase...");
        btn.disabled = true;

        if(DEMO_MODE){
            const snap = await getDemoSnapshot();
            const depRaw = Array.isArray(snap.department_tasks) ? snap.department_tasks : [];
            const officeRaw = Array.isArray(snap.office_tasks) ? snap.office_tasks : [];
            const dep = markDepartmentMonthBlocks(depRaw.map((x, i) => normalizeTask(x, i, "department")).filter(Boolean));
            const office = officeRaw.map((x, i) => normalizeTask(x, i, "office")).filter(Boolean);
            DATA = mergeDepartmentAndOffice(dep, office);
            localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
            rebuildFilters(); applyFilters(); updatePersonalCompletionCelebration(true); updateGlobalHonors();
            setSync("ok", `✅ [DEMO] ${DATA.length} nhiệm vụ mẫu (không fetch Supabase)`);
            return;
        }
        const headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Content-Type": "application/json"
        };
        const [depResponse, officeResponse] = await Promise.all([
            fetch(DEPARTMENT_API_URL, { method: "GET", headers }),
            fetch(OFFICE_API_URL, { method: "GET", headers })
        ]);

        if (!depResponse.ok) throw new Error("department_tasks HTTP " + depResponse.status);
        if (!officeResponse.ok) throw new Error("office_tasks HTTP " + officeResponse.status);

        const depRaw = await depResponse.json();
        const officeRaw = await officeResponse.json();
        if (!Array.isArray(depRaw) || !Array.isArray(officeRaw)) throw new Error("Dữ liệu Supabase không phải mảng");

        const dep = markDepartmentMonthBlocks(depRaw.map((x, i) => normalizeTask(x, i, "department")).filter(Boolean));
        const office = officeRaw.map((x, i) => normalizeTask(x, i, "office")).filter(Boolean);
        DATA = mergeDepartmentAndOffice(dep, office);

        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
        rebuildFilters();
        applyFilters();
        updatePersonalCompletionCelebration(true);
        updateGlobalHonors();
        setSync("ok", `Đã tải thành công lúc ${new Date().toLocaleTimeString("vi-VN")}`);
    } catch (error) {
        console.error(error);
        const cached = readCache("vp_tasks_cache");
        if (cached) {
            DATA = cached.map((x, i) => normalizeTask(x, i, x._source || "cache")).filter(Boolean);
            rebuildFilters();
            applyFilters();
            updatePersonalCompletionCelebration(true);
            updateGlobalHonors();
            setSync("error", `Mất kết nối, hiển thị ${DATA.length} dữ liệu lưu gần nhất`);
        } else {
            setSync("error", "Lỗi tải dữ liệu: " + error.message);
        }
    } finally {
        btn.disabled = false;
    }
}

function rebuildFilters() {
    // Rebuild owner filter
    const owners = [...new Set(DATA.map(x => x.owner).filter(Boolean))].sort();
    const ownerSelect = document.getElementById("ownerFilter");
    const currentOwner = ownerSelect.value;
    ownerSelect.innerHTML = '<option value="">Tất cả cán bộ</option>' +
        owners.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join("");
    if (owners.includes(currentOwner)) ownerSelect.value = currentOwner;

    // Rebuild role filter
    const roles = [...new Set(DATA.map(x => x.role).filter(Boolean))].sort();
    const roleSelect = document.getElementById("roleFilter");
    const currentRole = roleSelect.value;
    roleSelect.innerHTML = '<option value="">Tất cả vai trò</option>' +
        roles.map(r => `<option value="${esc(r)}">${esc(r)}</option>`).join("");
    if (roles.includes(currentRole)) roleSelect.value = currentRole;
}

function applyFilters() {
    const dateRange = document.getElementById("dateRange").value;
    const owner = document.getElementById("ownerFilter").value;
    const officerQ = (typeof bchFold === "function" ? bchFold(document.getElementById("officeOfficerNameFilter")?.value || "") : String(document.getElementById("officeOfficerNameFilter")?.value || "").toLowerCase().trim());
    const status = document.getElementById("statusFilter").value;
    const role = document.getElementById("roleFilter").value;
    const search = document.getElementById("searchInput").value.toLowerCase();
    let dateFrom = null, dateTo = null;

    const now = new Date();
    now.setHours(0, 0, 0, 0);

    if (dateRange === "today" || dateRange === "week" || dateRange === "month" || dateRange === "prevMonth" || dateRange === "nextMonth" || dateRange === "quarter") {
        const r = getTimeRange(dateRange);
        if (r) { dateFrom = r.from; dateTo = r.to; }
    } else if (dateRange === "custom") {
        document.getElementById("customDateGroup").style.display = "flex";
        document.getElementById("customDateGroup2").style.display = "flex";
        const from = document.getElementById("dateFrom").value;
        const to = document.getElementById("dateTo").value;
        if (from) dateFrom = parseDate(from);
        if (to) dateTo = parseDate(to);
    } else {
        document.getElementById("customDateGroup").style.display = "none";
        document.getElementById("customDateGroup2").style.display = "none";
    }

    filtered = DATA.filter(x => {
        const isNextMonth = dateRange === "nextMonth";
        const checkDate = isNextMonth ? (x._dueDate || parseDate(x.due)) : (x._createdDate || getCreationDate(x));
        const isRegular = !!x.is_regular;
        let passDate = true;
        if (isNextMonth) {
            if (dateFrom && checkDate) passDate = passDate && checkDate >= dateFrom;
            if (dateTo && checkDate) passDate = passDate && checkDate <= dateTo;
        } else if (!isRegular) {
            if (dateFrom && checkDate) passDate = passDate && checkDate >= dateFrom;
            if (dateTo && checkDate) passDate = passDate && checkDate <= dateTo;
        }

        return (!owner || x.owner === owner) &&
            (!officerQ || (typeof bchFold === "function" ? bchFold(x.owner || "").includes(officerQ) : String(x.owner || "").toLowerCase().includes(officerQ))) &&
            (!status || (status === "Thường xuyên" ? !!x.is_regular : x.status === status)) &&
            (!role || x.role === role) &&
            (!search || String(x._search || "").includes(search)) &&
            passDate;
    });

    render();
}

function resetFilters() {
    document.getElementById("dateRange").value = "all";
    document.getElementById("ownerFilter").value = "";
    const _oq = document.getElementById("officeOfficerNameFilter"); if (_oq) _oq.value = "";
    document.getElementById("statusFilter").value = "";
    document.getElementById("roleFilter").value = "";
    document.getElementById("searchInput").value = "";
    document.getElementById("customDateGroup").style.display = "none";
    document.getElementById("customDateGroup2").style.display = "none";
    applyFilters();
}

function render() {
    refreshHomeFilterOwnerOptions();
    const allTasks = homeFilteredTasks();
    let total = 0, done = 0, doing = 0, late = 0, soon = 0, emergent = 0, extended = 0;

    for (const x of allTasks) {
        total++;
        const source = homeSourceKey(x);
        const statusKey = source === "bch" ? bchStatusFor(x) : source === "ttbtv" ? ttbtvStatusFor(x) : source === "province" ? provinceStatusFor(x) : source === "action100" || source === "vpub" ? (typeof action100Status === "function" ? action100Status(x) : x.status) : x.status;
        const isDone = ["bch","ttbtv","province"].includes(source) ? ["early", "ontime", "latedone", "done"].includes(statusKey) : ["action100","vpub"].includes(source) ? ["early", "ontime", "latedone"].includes(statusKey) : completedStatuses.has(x.status);
        const isDoing = source === "office" ? x.status === "Đang triển khai" : statusKey === "processing";
        const isLate = source === "office" ? x.status === "Quá hạn" : statusKey === "overdue";
        if (isDone) done++;
        if (isDoing) doing++;
        if (isLate) late++;
        if (!isDone && isSoonAcrossSources(x, source)) soon++;
        if (x.emergent ?? x.phat_sinh ?? x.is_arising) emergent++;
        if (x.extended ?? x.is_extended) extended++;
    }

    document.getElementById("kTotal").textContent = total;
    document.getElementById("kDone").textContent = done;
    document.getElementById("kDoing").textContent = doing;
    document.getElementById("kLate").textContent = late;
    document.getElementById("kSoon").textContent = soon;
    document.getElementById("kEmergent").textContent = emergent;
    document.getElementById("kExtended").textContent = extended;
    document.getElementById("kRate").textContent = (total ? Math.round(done / total * 100) : 0) + "%";
    const ht=document.getElementById("heroTotal"); if(ht) ht.textContent=total;
    const hd=document.getElementById("heroDone"); if(hd) hd.textContent=done;
    const hg=document.getElementById("heroDoing"); if(hg) hg.textContent=doing;
    const hl=document.getElementById("heroLate"); if(hl) hl.textContent=late;
    try{updateNotifCount();}catch(e){}
    renderCharts();
    renderAlerts();
}

function renderCharts() {
    const ag = HOME_FILTER.agency;
    const agMatch = key => ag === "all" || ag === key;
    const officeCard = document.getElementById("chart1")?.closest('.chart-card');
    if (officeCard) officeCard.style.display = (canAccessOfficeData(CURRENT_USER) && agMatch("office")) ? "" : "none";
    const _isBch = CURRENT_USER?.role === "staff" && CURRENT_USER?.scope === "bch";
    const _tier = getBchViewTier(CURRENT_USER);
    const bchOnlyUser = _isBch && _tier !== "full" && _tier !== "broad";
    [["chart2", "bch"], ["chart3", "ttbtv"], ["chartLine", "province"]].forEach(([id, key]) => {
        const card = document.getElementById(id)?.closest('.chart-card');
        if (card) card.style.display = (!bchOnlyUser || key === "bch") && agMatch(key) ? "" : "none";
    });
    // V63 Trang chủ: 4 biểu đồ đều là TRẠNG THÁI theo 4 workspace.
    const statusKeys = ["processing", "early", "ontime", "latedone", "overdue"];
    const statusPalette = { processing: "#56B4E9", early: "#009E73", ontime: "#3b82f6", latedone: "#f59e0b", overdue: "#D55E00", regular: "#a855f7" };

    const mayOffice = canAccessOfficeData(CURRENT_USER);
    const officeRows = agMatch("office") ? homeFilterSource("office") : [];
    const officeMap = {};
    for (const x of (mayOffice ? officeRows : [])) officeMap[x.status] = (officeMap[x.status] || 0) + 1;
    const officeLabels = Object.keys(officeMap);
    renderChart("chart1", officeLabels, officeLabels.map(k => officeMap[k]), officeLabels.map(k => colors[k] || "#94a3b8"), "legend1", "doughnut");

    const bchRows = agMatch("bch") ? homeFilterSource("bch") : [];
    const bchMap = {};
    for (const x of bchRows) { const k = bchStatusFor(x); bchMap[k] = (bchMap[k] || 0) + 1; }
    const bchKeys = statusKeys.filter(k => bchMap[k] > 0);
    renderChart("chart2", bchKeys.map(bchStatusLabel), bchKeys.map(k => bchMap[k]), bchKeys.map(k => statusPalette[k]), "legend2", "doughnut");

    const ttRows = agMatch("ttbtv") ? homeFilterSource("ttbtv") : [];
    const ttMap = {};
    for (const x of ttRows) { const k = ttbtvStatusFor(x); ttMap[k] = (ttMap[k] || 0) + 1; }
    const ttKeys = statusKeys.filter(k => ttMap[k] > 0);
    renderChart("chart3", ttKeys.map(ttbtvStatusLabel), ttKeys.map(k => ttMap[k]), ttKeys.map(k => statusPalette[k]), "legend3", "doughnut");

    const provRows = agMatch("province") ? homeFilterSource("province") : [];
    const provMap = {};
    for (const x of provRows) { const k = provinceStatusFor(x); provMap[k] = (provMap[k] || 0) + 1; }
    const provKeys = statusKeys.filter(k => provMap[k] > 0);
    renderChart("chartLine", provKeys.map(provinceStatusLabel), provKeys.map(k => provMap[k]), provKeys.map(k => statusPalette[k]), "legend4", "doughnut");

    // V33 Chart Bar: Hiệu suất Top 10 theo cán bộ + trạng thái nhiệm vụ
    const ownerSource = homeFilteredTasks();
    const ownerStatusMap = {};
    for (const x of ownerSource) {
        const owner = x.owner || "Chưa xác định";
        if (!ownerStatusMap[owner]) {
            ownerStatusMap[owner] = {
                total: 0,
                "Đang triển khai": 0,
                "Hoàn thành trước hạn": 0,
                "Hoàn thành đúng hạn": 0,
                "Hoàn thành quá hạn": 0,
                "Quá hạn": 0
            };
        }
        ownerStatusMap[owner].total++;
        if (ownerStatusMap[owner][x.status] !== undefined) ownerStatusMap[owner][x.status]++;
    }

    const topOwners = Object.entries(ownerStatusMap)
        .sort((a, b) => b[1].total - a[1].total)
        .slice(0, 10);

    const ownerLabels = topOwners.map(([name]) => name);
    const ownerBreakdown = topOwners.map(([, stats]) => stats);
    renderAgencyTotalsChart();

    if (document.getElementById("officeWorkspace")?.classList.contains("open")) renderOfficeCharts();
}

function handleChartDrill(canvasId, label) {
    if ((CURRENT_USER?.role === "department" && (CURRENT_USER.scope === "action100" || CURRENT_USER.scope === "vpub")) || CURRENT_USER?.scope === "data_entry") return;
    if (canvasId === "chart1") { if (!canAccessOfficeData(CURRENT_USER)) { showToast('error', 'Khong co quyen', 'Token nay khong duoc xem du lieu Van phong.'); return; } showHomeDrill(homeFilterSource("office").filter(x => x.status === label), `Văn phòng · ${label}`); return; }
    if (canvasId === "chart2") {
        const rows = homeFilterSource("bch").filter(x => bchStatusLabel(bchStatusFor(x)) === label); showHomeDrill(rows, `BCH · ${label}`); return;
    }
    if (canvasId === "chart3") {
        const rows = homeFilterSource("ttbtv").filter(x => ttbtvStatusLabel(ttbtvStatusFor(x)) === label); showHomeDrill(rows, `TT/BTV · ${label}`); return;
    }
    if (canvasId === "chartLine") {
        const rows = homeFilterSource("province").filter(x => provinceStatusLabel(provinceStatusFor(x)) === label); showHomeDrill(rows, `Tỉnh giao · ${label}`); return;
    }
    if (canvasId.startsWith("officeChart")) { handleOfficeChartDrill(canvasId, label); }
}

function renderChart(canvasId, labels, data, chartColors, legendId, type = "doughnut") {
    const canvas = document.getElementById(canvasId); if (!canvas) return; const ctx = canvas.getContext("2d");
    // Giữ hiệu ứng đẹp, chỉ tối ưu JS: dùng update thay vì destroy/create
    if (charts[canvasId]) {
        const existing = charts[canvasId];
        if (existing.config.type === type) {
            existing.data.labels = labels;
            existing.data.datasets[0].data = data;
            existing.data.datasets[0].backgroundColor = chartColors;
            existing.update();
            const legend = document.getElementById(legendId);
            if (legend) {
                legend.innerHTML = labels.map((label, i) => `
                <div class="legend-item" data-chart="${canvasId}" data-index="${i}" title="Click để xem chi tiết">
                    <div class="legend-color" style="background: ${chartColors[i]}"></div>
                    <span>${label} (${data[i]})</span>
                </div>
            `).join("");
            }
            return;
        } else {
            existing.destroy();
        }
    }

    charts[canvasId] = new Chart(ctx, {
        type: type,
        data: {
            labels: labels,
            datasets: [{ data: data, backgroundColor: chartColors, borderColor: "#ffffff", borderWidth: 2 }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            onHover: (event, elements) => { event.native.target.style.cursor = elements.length ? "pointer" : "default"; },
            onClick: (event, elements, chart) => {
                if (!elements.length) return;
                const idx = elements[0].index;
                handleChartDrill(canvasId, chart.data.labels[idx]);
            },
            plugins: { legend: { display: false } }
        }
    });

    const legend = document.getElementById(legendId);
    if (!legend) return;
    // Delegation 1 lần để tránh leak
    if (!legend.dataset.delegated) {
        legend.dataset.delegated = "1";
        legend.addEventListener('click', (e) => {
            const item = e.target.closest('.legend-item');
            if (!item) return;
            e.stopPropagation();
            const idx = Number(item.dataset.index);
            const lbl = item.textContent.split(' (')[0].trim();
            // lấy label từ DOM thay vì closure để tránh stale
            handleChartDrill(canvasId, lbl || labels[idx]);
        });
    }
    legend.innerHTML = labels.map((label, i) => `
                <div class="legend-item" data-chart="${canvasId}" data-index="${i}" title="Click để xem chi tiết">
                    <div class="legend-color" style="background: ${chartColors[i]}"></div>
                    <span>${label} (${data[i]})</span>
                </div>
            `).join("");
}

function renderBarChart(canvasId, labels, breakdown) {
    const ctx = document.getElementById(canvasId).getContext("2d");
    if (charts[canvasId]) charts[canvasId].destroy();

    const statusDefs = [
        { key: "Hoàn thành trước hạn", label: "✅ Trước hạn", color: "#009E73" },
        { key: "Hoàn thành đúng hạn", label: "🎯 Đúng hạn", color: "#3b82f6" },
        { key: "Hoàn thành quá hạn", label: "⚠️ Hoàn thành quá hạn", color: "#f59e0b" },
        { key: "Đang triển khai", label: "📌 Đang triển khai", color: "#56B4E9" },
        { key: "Quá hạn", label: "⏰ Quá hạn", color: "#D55E00" }
    ];

    const datasets = statusDefs.map(def => ({
        label: def.label,
        data: breakdown.map(s => Number(s[def.key] || 0)),
        backgroundColor: def.color,
        borderColor: "#ffffff",
        borderWidth: 1,
        borderRadius: 5,
        borderSkipped: false,
        stack: "status"
    }));

    charts[canvasId] = new Chart(ctx, {
        type: "bar",
        data: { labels, datasets },
        options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: "nearest", intersect: true },
            plugins: {
                legend: {
                    display: true,
                    position: "top",
                    labels: {
                        usePointStyle: true,
                        pointStyle: "rectRounded",
                        boxWidth: 10,
                        boxHeight: 10,
                        padding: 14,
                        font: { size: 11, weight: "600" }
                    }
                },
                tooltip: {
                    callbacks: {
                        title: (items) => {
                            if (!items.length) return "";
                            const idx = items[0].dataIndex;
                            const total = breakdown[idx]?.total || 0;
                            return `${labels[idx]} · Tổng ${total} nhiệm vụ`;
                        },
                        label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}`
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    stacked: true,
                    ticks: { precision: 0 },
                    grid: { color: "rgba(148,163,184,.18)" }
                },
                y: {
                    stacked: true,
                    grid: { display: false },
                    ticks: { font: { size: 11, weight: "600" } }
                }
            },
            onHover: (event, elements) => {
                if (event.native?.target) event.native.target.style.cursor = elements.length ? "pointer" : "default";
            },
            onClick: (event, elements, chart) => {
                if (!elements.length) return;
                const el = elements[0];
                const idx = el.index;
                const dsIdx = el.datasetIndex;
                const owner = chart.data.labels[idx];
                const statusKey = statusDefs[dsIdx]?.key;
                if (!statusKey) return;
                const base = (canvasId === "officeChartBar" && typeof officePerformanceRows === "function") ? officePerformanceRows() : filtered;
                const rows = base.filter(x => x.owner === owner && x.status === statusKey);
                showDrill(rows, `Hiệu suất · ${owner} · ${statusKey}`, "📊");
            }
        }
    });
}

function renderLineChart() {
    // Chart 4: Số nhiệm vụ (Doughnut)
    const ownerMap = {};
    for (const x of filtered) {
        const owner = x.owner || "Chưa xác định";
        ownerMap[owner] = (ownerMap[owner] || 0) + 1;
    }

    const ownerEntries = Object.entries(ownerMap)
        .sort((a, b) => b[1] - a[1]);
    const labels = ownerEntries.map(([name]) => name);
    const counts = ownerEntries.map(([, count]) => count);
    const palette = ["#7c3aed", "#2563eb", "#0891b2", "#0f9f6e", "#65a30d", "#ca8a04", "#ea580c", "#dc2626", "#db2777", "#9333ea", "#4f46e5", "#0d9488"];
    const chartColors = labels.map((_, i) => palette[i % palette.length]);
    renderChart("chartLine", labels, counts, chartColors, "legend4", "doughnut");
}

function renderAlerts() {
    const overdue = [], today = [], soon = [], soon7 = [];

    for (const x of homeFilteredTasks()) {
        const source = homeSourceKey(x);
        const due = source === "office" ? x.due : parseDate(x.deadline || x.due || x.deadline_date);
        const day = due ? Math.round((due - new Date(new Date().setHours(0, 0, 0, 0))) / 86400000) : null;
        const status = source === "bch" ? bchStatusFor(x) : source === "ttbtv" ? ttbtvStatusFor(x) : source === "province" ? provinceStatusFor(x) : x.status;
        if (status === "overdue" || status === "Quá hạn" || (day !== null && day < 0)) overdue.push(x);
        else if (day === 0) today.push(x);
        else if (day !== null && day >= 1 && day <= 3) soon.push(x);
        if (day !== null && day >= 1 && day <= 7) soon7.push(x);
    }

    function alertHTML(x) {
        const u = urgencyInfo(x);
        const urgencyColor = u.cls.includes("overdue") ? "#D55E00" : u.cls.includes("today") ? "#f59e0b" : "#3b82f6";
        return `<div class="alert-item">
                    <div class="alert-indicator" style="background: ${urgencyColor}"></div>
                    <div class="alert-content">
                        <div class="alert-task" onclick="event.stopPropagation(); openHomeTaskDrill('${String(homeSourceKey(x)).replace(/'/g,"\\'")}', '${String(x.id).replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')" title="${esc(x.task || x.task_name)}">
                            ${esc(String(x.task || x.task_name || "").slice(0, 55))}${String(x.task || x.task_name || "").length > 55 ? "..." : ""}
                        </div>
                        <div class="alert-meta">👤 ${esc(x.owner || x.officer_name || "")} · 📅 ${formatDate(homeDue(x))}</div>
                    </div>
                </div>`;
    }

    document.getElementById("overdueCount").textContent = overdue.length;
    document.getElementById("overdueList").innerHTML = overdue.slice(0, 5).map(alertHTML).join("") ||
        '<div class="drill-empty">✅ Không có nhiệm vụ quá hạn</div>';

    document.getElementById("todayCount").textContent = today.length;
    document.getElementById("todayList").innerHTML = today.slice(0, 5).map(alertHTML).join("") ||
        '<div class="drill-empty">✅ Không có nhiệm vụ đến hạn hôm nay</div>';

    document.getElementById("soonCount").textContent = soon.length;
    document.getElementById("soonList").innerHTML = soon.slice(0, 5).map(alertHTML).join("") ||
        '<div class="drill-empty">✅ Không có nhiệm vụ sắp đến hạn</div>';
    const soon7El = document.getElementById("soon7Count");
    if (soon7El) soon7El.textContent = soon7.length;
}

document.getElementById("homeDrillCloseBtn")?.addEventListener("click", () => smoothCloseModal("homeDrillModal"));

function drillAlert(type) {
    const meta = {
        overdue: ["Nhiệm vụ quá hạn", "⏰"],
        today: ["Nhiệm vụ đến hạn hôm nay", "📅"],
        soon3: ["Nhiệm vụ sắp đến hạn trong 3 ngày", "⏳"]
    };
    const [title, icon] = meta[type] || ["Chi tiết nhiệm vụ", "📋"];
    const rows = getAllHomeTasks().filter(x => homeAgencyMatch(x) && (() => {
        const source = homeSourceKey(x);
        const status = homeStatus(x);
        const due = homeDue(x);
        const day = due ? Math.round((due - new Date(new Date().setHours(0, 0, 0, 0))) / 86400000) : null;
        if (String(status).includes("Hoàn thành")) return false;
        if (type === "overdue") return status === "Quá hạn" || (day !== null && day < 0);
        if (type === "today") return day === 0;
        return day !== null && day >= 1 && day <= 3;
    })());
    showHomeDrill(rows, `${icon} ${title}`);
}


function drillOfficeSub(type, event) {
    if (event) event.stopPropagation();
    const meta = {
        doing: { title: "Nhiệm vụ Văn phòng Đảng ủy — Đang xử lý", icon: "📌", predicate: x => x.status === "Đang triển khai" },
        done: { title: "Nhiệm vụ Văn phòng Đảng ủy — Hoàn thành", icon: "✅", predicate: x => completedStatuses.has(x.status) },
        late: { title: "Nhiệm vụ Văn phòng Đảng ủy — Quá hạn", icon: "⏰", predicate: x => x.status === "Quá hạn" }
    };
    const cfg = meta[type];
    if (!cfg) return;

    document.querySelectorAll('.sidebar-subitem').forEach(el => el.classList.remove('active-sub'));
    if (event && event.currentTarget) event.currentTarget.classList.add('active-sub');
    showDrill(filtered.filter(cfg.predicate), cfg.title, cfg.icon);
}



function renderOfficePerformanceResults() {
    const wrap = document.getElementById("officePerformanceResults");
    if (!wrap) return;
    const q = (document.getElementById("officePerformanceSearch")?.value || "").toLowerCase().trim();
    if (!q) { wrap.style.display = "none"; wrap.innerHTML = ""; return; }
    const rows = DATA.filter(x => String(x._search || "").includes(q));
    wrap.style.display = "block";
    wrap.innerHTML = `<div class="office-perf-result-head">${rows.length} nhiệm vụ chứa "${esc(q)}"</div>` +
        (rows.length ? `<div class="office-perf-result-list">${rows.slice(0, 20).map(x => `<div class="office-perf-result-item" onclick="showDrill([DATA[${DATA.indexOf(x)}]], 'Chi tiết nhiệm vụ', '📋')" title="Click để xem chi tiết: ${esc(x.task || "")}"><span class="office-perf-result-name">${esc(x.task || "")}</span><span class="office-perf-result-meta">👤 ${esc(x.owner || "")} · 📅 ${formatDate(x.due)} · <span class="office-perf-status">${esc(x.status || "")}</span></span><span class="office-perf-result-action">▶ Xem chi tiết</span></div>`).join("")}${rows.length > 20 ? `<div class="office-perf-result-more">… và ${rows.length - 20} kết quả khác</div>` : ""}</div>` + `<button class="bch-btn" type="button" onclick="showDrill(DATA.filter(xr => String(xr._search||'').includes('${esc(q).replace(/'/g, "\\'")}')), 'Nhiệm vụ VP · Tìm \"${esc(q)}\"', '🔍')">Xem toàn bộ ${rows.length} kết quả</button>` : `<div class="office-perf-result-empty">Không có nhiệm vụ phù hợp.</div>`);
}
function renderOfficeCharts() {
    if (!document.getElementById("officeWorkspace")) return;
    renderOfficePerformanceResults();
    renderOfficeKPIs();
    const statusMap = {}; DATA.forEach(x => statusMap[x.status] = (statusMap[x.status] || 0) + 1);
    const sl = Object.keys(statusMap); renderChart("officeChart1", sl, sl.map(k => statusMap[k]), sl.map(k => colors[k] || "#94a3b8"), "officeLegend1", "doughnut");

    const urgencyMap = {}; DATA.forEach(x => { const k = urgencyInfo(x).key; if (k !== "none") urgencyMap[k] = (urgencyMap[k] || 0) + 1; });
    const order = ["overdue", "today", "soon3", "safe", "done"].filter(k => urgencyMap[k]);
    const names = { overdue: "Quá hạn", today: "Hôm nay", soon3: "Sắp đến ≤3 ngày", safe: "An toàn", done: "Hoàn thành" };
    const uc = { overdue: "#D55E00", today: "#f59e0b", soon3: "#7c3aed", safe: "#009E73", done: "#3b82f6" };
    renderChart("officeChart2", order.map(k => names[k]), order.map(k => urgencyMap[k]), order.map(k => uc[k]), "officeLegend2", "doughnut");

    const ownerMap = {}; DATA.forEach(x => { const k = x.owner || "Chưa xác định"; ownerMap[k] = (ownerMap[k] || 0) + 1; });
    const owners = Object.entries(ownerMap).sort((a, b) => b[1] - a[1]);
    const pal = ["#7c3aed", "#2563eb", "#0891b2", "#0f9f6e", "#65a30d", "#ca8a04", "#ea580c", "#dc2626", "#db2777", "#9333ea", "#4f46e5", "#0d9488"];
    renderChart("officeChart3", owners.map(x => x[0]), owners.map(x => x[1]), owners.map((_, i) => pal[i % pal.length]), "officeLegend3", "doughnut");

    const roleMap = {}; DATA.forEach(x => { const k = officeChartRole(x.role); roleMap[k] = (roleMap[k] || 0) + 1; });
    const roleOrder = ["Chủ trì","Phối hợp","TĐ","Khác"];
    const roles = roleOrder.map(k => [k, roleMap[k] || 0]);
    renderChart("officeChart4", roles.map(x => x[0]), roles.map(x => x[1]), roles.map((_, i) => pal[(i + 3) % pal.length]), "officeLegend4", "doughnut");

    // V65: Hiệu suất Top 10 chỉ dữ liệu Văn phòng
    const ownerStatusMap = {};
    officePerformanceRows().forEach(x => {
        const owner = x.owner || "Chưa xác định";
        if (!ownerStatusMap[owner]) ownerStatusMap[owner] = { total: 0, "Đang triển khai": 0, "Hoàn thành trước hạn": 0, "Hoàn thành đúng hạn": 0, "Hoàn thành quá hạn": 0, "Quá hạn": 0, "Thường xuyên": 0 };
        ownerStatusMap[owner].total++;
        if (ownerStatusMap[owner][x.status] !== undefined) ownerStatusMap[owner][x.status]++;
    });
    const topOwners = Object.entries(ownerStatusMap).sort((a, b) => b[1].total - a[1].total).slice(0, 10);
    renderBarChart("officeChartBar", topOwners.map(x => x[0]), topOwners.map(x => x[1]));
    renderOfficeAlerts();
}



function renderOfficeKPIs() {
    const values = { total: officeKpiRows("total").length, done: officeKpiRows("done").length, doing: officeKpiRows("doing").length, late: officeKpiRows("late").length, soon: officeKpiRows("soon").length, regular: officeKpiRows("regular").length, emergent: officeKpiRows("emergent").length };
    Object.entries(values).forEach(([key, value]) => { const el = document.getElementById(`officeKpi${key[0].toUpperCase()}${key.slice(1)}`); if (el) el.textContent = value; });
}

function drillOfficeKPI(type) {
    const labels = { total: "Tổng nhiệm vụ Văn phòng", done: "Văn phòng · Đã hoàn thành", doing: "Văn phòng · Đang triển khai", late: "Văn phòng · Quá hạn", soon: "Văn phòng · Sắp đến hạn", regular: "Văn phòng · Thường xuyên", emergent: "Văn phòng · Nhiệm vụ phát sinh" };
    showDrill(officeKpiRows(type), labels[type] || "Chi tiết nhiệm vụ Văn phòng", "🏢");
}





function renderOfficeAlerts() {
    const defs = [["overdue", "officeOverdueCount", "officeOverdueList", "✅ Không có nhiệm vụ quá hạn"], ["today", "officeTodayCount", "officeTodayList", "✅ Không có nhiệm vụ đến hạn hôm nay"], ["soon3", "officeSoon3Count", "officeSoon3List", "✅ Không có nhiệm vụ sắp đến hạn ≤ 3 ngày"], ["soon7", "officeSoon7Count", "officeSoon7List", "✅ Không có nhiệm vụ sắp đến hạn ≤ 7 ngày"]];
    defs.forEach(([type, countId, listId, empty]) => { const rows = officeAlertRows(type); const c = document.getElementById(countId), l = document.getElementById(listId); if (c) c.textContent = rows.length; if (l) l.innerHTML = rows.slice(0, 5).map(officeAlertHTML).join("") || `<div class="drill-empty">${empty}</div>`; });
}









function drillKPI(type) {
    const titles = { total: "Tổng nhiệm vụ", done: "Đã hoàn thành", doing: "Đang triển khai", late: "Quá hạn", soon: "Sắp đến hạn ≤ 3 ngày", emergent: "Nhiệm vụ phát sinh", extended: "Nhiệm vụ gia hạn" };
    showStatsDrill(statsTaskRows(type), titles[type] || "Chi tiết chỉ số");
    return;
    let predicate = null, title = "", icon = "";

    if (type === "total") {
        predicate = () => true;
        title = "Tất cả nhiệm vụ";
        icon = "📊";
    } else if (type === "done") {
        predicate = x => completedStatuses.has(x.status);
        title = "Nhiệm vụ đã hoàn thành";
        icon = "✅";
    } else if (type === "doing") {
        predicate = x => x.status === "Đang triển khai";
        title = "Nhiệm vụ đang triển khai";
        icon = "📌";
    } else if (type === "late") {
        predicate = x => x.status === "Quá hạn";
        title = "Nhiệm vụ quá hạn";
        icon = "⏰";
    } else if (type === "soon") {
        predicate = x => urgencyInfo(x).key === "today" || urgencyInfo(x).key === "soon3";
        title = "Nhiệm vụ sắp đến hạn";
        icon = "⏳";
    } else if (type === "emergent") {
        predicate = x => x.emergent;
        title = "Nhiệm vụ phát sinh";
        icon = "⚡";
    } else if (type === "extended") {
        predicate = x => x.extended;
        title = "Nhiệm vụ gia hạn";
        icon = "📅";
    }

    showDrill(filtered.filter(predicate), title, icon);
}

document.getElementById("statsDrillCloseBtn")?.addEventListener("click", () => smoothCloseModal("statsDrillModal"));


let PENDING_ADD_TASK = null;



function renderAddTaskRow() {
    if (!CURRENT_USER) return "";
    const isAdmin = CURRENT_USER.role === "admin";
    const canToggleRegular = isAdmin || CURRENT_USER.scope === "office";
    const officerControl = isAdmin
        ? `<select id="addOfficer"><option value="">Chọn cán bộ...</option>${addOfficerOptions()}</select>`
        : `<input id="addOfficer" value="${esc(CURRENT_USER.name)}" readonly>`;
    const adminNoteControl = isAdmin
        ? `<textarea id="addNote" placeholder="Ghi chú của Admin (nếu có)"></textarea>`
        : `<textarea id="addNote" readonly placeholder="Chỉ Admin được nhập ghi chú"></textarea>`;
    const staffNoteControl = isAdmin
        ? `<textarea id="addStaffNote" readonly placeholder="Cán bộ phụ trách sẽ bổ sung sau"></textarea>`
        : `<textarea id="addStaffNote" placeholder="Ghi chú bổ sung của bạn (nếu có)"></textarea>`;

    return `<tr class="add-task-row"><td colspan="11">
                <div class="add-task-shell">
                    <div class="add-task-title">
                        <span>➕ Thêm nhiệm vụ</span>
                        <span style="font-size:11.8px;color:#64748b;font-weight:600">Dữ liệu sẽ được ghi trực tiếp vào office_tasks</span>
                    </div>
                    <div class="add-task-grid">
                        <div class="field"><label>Cán bộ</label>${officerControl}</div>
                        <div class="field span2"><label>Nhiệm vụ</label><textarea id="addTaskName" placeholder="Nhập nội dung nhiệm vụ..."></textarea></div>
                        <div class="field"><label>Vai trò</label><select id="addRole" onchange="handleOfficeRoleOther(this)">${officeRoleOptionsHtml("")}</select><input id="addRoleOther" type="text" placeholder="Nhập vai trò khác" style="display:none;margin-top:6px"></div>

                        <div class="field"><label>Hạn hoàn thành <span style="color:#dc2626">*</span></label><input id="addDeadline" type="date" required data-ds-date="1" class="date-ddmmyyyy" oninput="dateMask(this);updateAddCompletedDateAccess()" placeholder="dd/mm/yyyy" lang="vi"></div>
                        <div class="field"><label>Ngày hoàn thành</label><input id="addCompletedDate" type="date" data-ds-date="1" class="date-ddmmyyyy" oninput="dateMask(this);updateAddCompletedDateAccess()" placeholder="dd/mm/yyyy" lang="vi"></div>
                        <div class="field"><label>Trạng thái <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="addStatus" class="auto-status-field" type="text" readonly value="Đang triển khai" title="Hệ thống tự tính trạng thái"></div>
                        <div class="field"><label>Tệp sản phẩm</label><input id="addAttachment" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx" onchange="updateAddCompletedDateAccess()"></div>

                        <div class="field span2"><label>Sản phẩm / kết quả</label><textarea id="addProduct" oninput="updateAddCompletedDateAccess()" placeholder="Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp..."></textarea></div>
                        <div class="field"><label>Phát sinh</label><div class="add-arising-wrap"><input id="addArising" type="checkbox"><span>Ngoài kế hoạch</span></div></div>
                        <div class="field regular-field"><label class="regular-toggle" title="${canToggleRegular ? "Bật để giữ nhiệm vụ sang tháng sau" : "Chỉ Admin và token Văn phòng được gán Thường xuyên"}"><span class="regular-icon">🔁</span><span class="regular-toggle-desc"><b>Thường xuyên</b><small>giữ sang tháng sau</small></span><input type="checkbox" id="addOfficeRegular" onchange="refreshAddOfficeStatus()" ${canToggleRegular ? "" : "disabled"}><span class="regular-switch-ui"></span></label></div>

                        <div class="field span2"><label>👤 Ghi chú cán bộ</label>${staffNoteControl}</div>
                        <div class="field span2"><label>📝 Ghi chú Admin</label>${adminNoteControl}</div>

                        <div class="field add-task-actions"><button class="add-task-btn" type="button" onclick="prepareAddTask()">＋ Thêm nhiệm vụ</button></div>
                    </div>
                    <div class="add-task-help">${isAdmin
            ? "Admin có thể nhập và điều chỉnh đầy đủ thông tin."
            : "Tài khoản cán bộ: Hạn hoàn thành chỉ nhập một lần khi tạo. Ngày hoàn thành chỉ được nhập khi nhiệm vụ đã hoàn thành và có tệp sản phẩm đính kèm."}</div>
                </div>
            </td></tr>`;
}

function appendAddTaskRow() {
    const body = document.getElementById("drillBody");
    if (!body || !CURRENT_USER) return;
    body.insertAdjacentHTML("beforeend", renderAddTaskRow());
}


function updateAddCompletedDateAccess() {
    const el = document.getElementById("addCompletedDate"); if (!el || !CURRENT_USER) return;
    el.disabled = false; el.readOnly = false; el.style.background = "#fff";
    el.title = "Nhập ngày hoàn thành thực tế; trạng thái sẽ tự tính.";
    const due = document.getElementById("addDeadline")?.value || "";
    const completed = el.value || "";
    const product = document.getElementById("addProduct")?.value || "";
    const file = document.getElementById("addAttachment")?.files?.[0] || null;
    const out = document.getElementById("addStatus");
    if (out) out.value = calculateTaskStatus({}, { _regular: false, due, completed_date: completed, product, hasFile: !!file });
}


function prepareAddTask() {
    if (!CURRENT_USER) return;
    // Guard ADD office: chỉ admin hoặc staff/office hoặc BCH full mới được thêm (fix Lỗi 2 REPORT)
    if (!canAccessOfficeData(CURRENT_USER)) { showToast("error", "Không có quyền", "Chỉ Admin hoặc tài khoản Văn phòng được thêm nhiệm vụ."); return; }
    const officer = CURRENT_USER.role === "admin"
        ? (document.getElementById("addOfficer")?.value || "").trim()
        : CURRENT_USER.name;
    const taskName = (document.getElementById("addTaskName")?.value || "").trim();
    const _rawRoleAdd = (function(){ try{ return getOfficeRoleValue("addRole"); }catch(e){ return (document.getElementById("addRole")?.value||"").trim(); }})();
    const role = officeRoleCanonical(_rawRoleAdd) || _rawRoleAdd;
    const isOfficeRegular = !!document.getElementById("addOfficeRegular")?.checked;
    let deadline = null, completedDate = null;
    try {
        const dlRaw = (document.getElementById("addDeadline")?.value || "").trim();
        if (isOfficeRegular) deadline = dlRaw ? requireValidDate(dlRaw, "Hạn hoàn thành", false) : null;
        else deadline = requireValidDate(dlRaw, "Hạn hoàn thành", true);
        const cr = (document.getElementById("addCompletedDate")?.value || "").trim();
        completedDate = cr ? requireValidDate(cr, "Ngày hoàn thành", false) : null;
    } catch (e) { showToast("error", "Ngày tháng chưa đúng", e.message); return; }
    const product = (document.getElementById("addProduct")?.value || "").trim() || "Không";
    const note = CURRENT_USER.role === "admin" ? (document.getElementById("addNote")?.value || "").trim() : "";
    const staffNote = CURRENT_USER.role === "staff" ? (document.getElementById("addStaffNote")?.value || "").trim() : "";
    const isArising = !!document.getElementById("addArising")?.checked;
    const file = document.getElementById("addAttachment")?.files?.[0] || null;
    const status = calculateTaskStatus({}, { _regular: false, due: deadline, completed_date: completedDate, product, hasFile: !!file });

    if (!officer) { showToast("error", "Thiếu cán bộ", "Vui lòng chọn cán bộ phụ trách."); return; }
    if (!taskName) { showToast("error", "Thiếu nhiệm vụ", "Vui lòng nhập nội dung nhiệm vụ."); document.getElementById("addTaskName")?.focus(); return; }
    if (taskName.length < 2) { showToast("error", "Nhiệm vụ quá ngắn", "Vui lòng nhập ít nhất 2 ký tự (ví dụ: AB)."); document.getElementById("addTaskName")?.focus(); return; }
    if (!role) { showToast("error", "Thiếu vai trò", "Vui lòng nhập vai trò của nhiệm vụ."); document.getElementById("addRole")?.focus(); return; }
    PENDING_ADD_TASK = { officer, taskName, role, deadline, completedDate, status, product, note, staffNote, isArising, is_regular: isOfficeRegular, file };

    const s = document.getElementById("addConfirmSummary");
    s.innerHTML = `
                <div><b>Cán bộ:</b> ${esc(officer)}</div>
                <div><b>Nhiệm vụ:</b> ${esc(taskName)}</div>
                <div><b>Vai trò:</b> ${esc(role)} &nbsp; · &nbsp; <b>Trạng thái:</b> ${esc(status)} ${isOfficeRegular ? '<span style="color:#7c3aed">· 🔁 Thường xuyên</span>' : ''}</div>
                <div><b>Thường xuyên:</b> ${isOfficeRegular ? "Có (giữ sang tháng sau)" : "Không"}</div>
                <div><b>Hạn hoàn thành:</b> ${deadline ? formatDate(deadline) : "Chưa nhập"}</div>
                <div><b>Ngày hoàn thành:</b> ${completedDate ? formatDate(completedDate) : "Chưa nhập"}</div>
                <div><b>Sản phẩm:</b> ${esc(product)}</div>
                <div><b>Ghi chú cán bộ:</b> ${staffNote ? esc(staffNote) : "Không có"}</div>
                <div><b>Tệp:</b> ${file ? esc(file.name) : "Không có tệp"}</div>
                ${CURRENT_USER.role !== "admin" ? `<div style="margin-top:8px;color:#9a3412"><b>Lưu ý:</b> Sau khi xác nhận, bạn không thể tự sửa Hạn hoàn thành. Ngày hoàn thành chỉ được cập nhật khi nhiệm vụ hoàn thành và đã có tệp sản phẩm.</div>` : ""}
            `;
    smoothOpenModal("addConfirmModal");
}

function openAddConfirm(scopeLabel, pending, rows) {
    const title = document.querySelector("#addConfirmModal .drill-head h3");
    if (title) title.textContent = `➕ Xác nhận thêm nhiệm vụ ${scopeLabel}`;
    document.getElementById("addConfirmSummary").innerHTML = rows.map(([k, v]) => `<div class="confirm-row"><span>${esc(k)}</span><strong>${esc(String(v || "—"))}</strong></div>`).join("");
    smoothOpenModal("addConfirmModal");
}

function cancelAddTaskConfirm() {
    PENDING_ADD_TASK = null;
    PENDING_PROV_TASK = null;
    PENDING_BCH_TASK = null;
    PENDING_TTBTV_TASK = null;
    smoothCloseModal("addConfirmModal");
}

async function confirmAddTask() {
    if (PENDING_PROV_TASK) { return confirmNewPROVTask(); }
    if (PENDING_BCH_TASK) { return confirmNewBCHTask(); }
    if (PENDING_TTBTV_TASK) { return confirmNewTTBTVTask(); }
    const p = PENDING_ADD_TASK;
    if (!p) return;
    const btn = document.getElementById("confirmAddTaskBtn");
    const oldText = btn ? btn.textContent : "";
    if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang thêm..."; }

    try {
        const dbRow = {
            officer_name: p.officer,
            task_name: p.taskName,
            is_arising: p.isArising,
            is_regular: !!p.is_regular,
            role: p.role,
            deadline_date: p.deadline,
            completed_date: p.completedDate,
            product: p.product || "Không",
            status: dbStatus(p.status),
            note: CURRENT_USER.role === "admin" ? p.note : "",
            staff_note: CURRENT_USER.role === "staff" ? (p.staffNote || "") : ""
        };

        let r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
            method: "POST",
            headers: {
                "apikey": SUPABASE_KEY,
                "Authorization": `Bearer ${SUPABASE_KEY}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(dbRow)
        });
        let txt = await r.text();
        if (!r.ok && String(txt).toLowerCase().includes("is_regular")) {
            const fbRow = { ...dbRow }; delete fbRow.is_regular; if (dbRow.is_regular) fbRow.status = "thường xuyên";
            r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks`, {
                method: "POST",
                headers: {
                    "apikey": SUPABASE_KEY,
                    "Authorization": `Bearer ${SUPABASE_KEY}`,
                    "Content-Type": "application/json",
                    "Prefer": "return=representation"
                },
                body: JSON.stringify(fbRow)
            });
            txt = await r.text();
        }
        if (!r.ok) {
            let detail = txt; try { const j = JSON.parse(txt); detail = j.message || j.details || j.hint || txt } catch (e) { }
            throw new Error(detail || `HTTP ${r.status}`);
        }
        const returned = JSON.parse(txt);
        if (!Array.isArray(returned) || !returned[0]) throw new Error("Supabase không trả lại bản ghi vừa tạo.");
        const raw = returned[0];
        raw.task_name = raw.task_name || raw.task || p.taskName;
        raw.officer_name = raw.officer_name || raw.owner || p.officer;
        raw.deadline_date = raw.deadline_date || raw.deadline || p.deadline;
        raw.task = raw.task || raw.task_name || p.taskName;
        raw.owner = raw.owner || raw.officer_name || p.officer;
        let obj = normalizeTask(raw, DATA.length);
        if (!obj) {
            const fb = { ...raw, task_name: p.taskName, task: p.taskName, officer_name: p.officer, owner: p.officer, deadline_date: p.deadline, deadline: p.deadline, id: raw.id || Date.now() };
            obj = normalizeTask(fb, DATA.length);
        }
        if (!obj) throw new Error("Không thể chuẩn hóa nhiệm vụ vừa tạo. Raw: " + JSON.stringify(raw).slice(0,300));

        // Upload file after receiving the new task ID.
        if (p.file) {
            try {
                const uploaded = await uploadTaskFile(p.file, obj);
                const finalStatus = calculateTaskStatus(obj, { hasFile: true });
                const patch = {
                    attachment_path: uploaded.path,
                    attachment_name: uploaded.name,
                    attachment_type: uploaded.type,
                    attachment_size: uploaded.size,
                    status: dbStatus(finalStatus),
                    updated_at: new Date().toISOString()
                };
                const pr = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(obj.id)}`, {
                    method: "PATCH",
                    headers: {
                        "apikey": SUPABASE_KEY,
                        "Authorization": `Bearer ${SUPABASE_KEY}`,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(patch)
                });
                if (!pr.ok) throw new Error(await pr.text());
                obj.attachment_path = uploaded.path; obj.attachment_name = uploaded.name;
                obj.attachment_type = uploaded.type; obj.attachment_size = uploaded.size;
                obj.status = calculateTaskStatus(obj);
                obj.updated_at = patch.updated_at;
            } catch (fileErr) {
                console.error(fileErr);
                showToast("error", "Nhiệm vụ đã thêm nhưng tệp chưa tải lên", fileErr.message || "Bạn có thể mở nhiệm vụ và tải tệp lại.", 5200);
            }
        }

        DATA.unshift(obj);
        // GIỮ lịch sử tháng cũ: không xóa nhiệm vụ thường xuyên trùng nữa
        localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
        rebuildFilters();
        applyFilters();

        cancelAddTaskConfirm();
        if (p && p._fromOfficePopup) { try { const g=document.getElementById("officeAddFormGrid"); if(g) g.innerHTML=""; smoothCloseModal("officeAddTaskModal"); } catch(e) {} }
        writeActivity("Thêm nhiệm vụ", { task: obj.task, owner: obj.owner, id: obj.id });
        showToast("success", "Đã thêm nhiệm vụ", `Nhiệm vụ #${obj.id} của ${obj.owner} đã được lưu vào Supabase.`);

        // Re-open a useful all-current-data list and keep the add row available.
        showDrill(filtered, "Tất cả nhiệm vụ", "📋");
    } catch (e) {
        console.error("Lỗi thêm nhiệm vụ:", e);
        showToast("error", "Không thể thêm nhiệm vụ", e.message || "Vui lòng kiểm tra Supabase.", 5600);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = oldText || "✓ Xác nhận thêm"; }
        PENDING_ADD_TASK = null;
    }
}


let EXTEND_DATA_INDEX = -1;
function openExtendDeadline(dataIndex) {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") { showToast("error", "Không có quyền", "Chỉ Admin được phép gia hạn nhiệm vụ."); return; }
    const x = DATA[dataIndex]; if (!x) return;
    window.HOME_EXTEND_TARGET = null;
    EXTEND_DATA_INDEX = dataIndex;
    document.getElementById("extendTaskLabel").textContent = `${x.owner} · ${x.task}`;
    document.getElementById("extendCurrentDate").innerHTML = `<b>Hạn hiện tại:</b> ${x.due ? formatDate(x.due) : "Chưa có hạn"}`;
    const d = parseDate(x.due), input = document.getElementById("extendNewDate");
    input.value = d ? formatDate(d) : "";
    document.getElementById("extendReason").value = "";
    smoothOpenModal("extendModal"); setTimeout(() => input.focus(), 100);
}
function closeExtendModal() { smoothCloseModal("extendModal", () => { EXTEND_DATA_INDEX = -1; window.HOME_EXTEND_TARGET = null; }); }
async function saveDeadlineExtension() {
    if (!CURRENT_USER || (CURRENT_USER.role !== "admin" && !isNGNUser(CURRENT_USER))) return;
    if (window.HOME_EXTEND_TARGET && window.HOME_EXTEND_TARGET.source !== "office") {
        await saveHomeWorkspaceExtension();
        return;
    }
    const x = DATA[EXTEND_DATA_INDEX], newDate = dateToDb(document.getElementById("extendNewDate").value);
    const reason = document.getElementById("extendReason").value.trim();
    if (!x || !newDate) { showToast("error", "Thiếu hạn mới", "Vui lòng chọn Hạn hoàn thành mới."); return; }
    if (!reason) { showToast("error", "Thiếu lý do", "Vui lòng nhập lý do gia hạn."); return; }
    const oldDate = parseDate(x.due), nextDate = parseDate(newDate);
    const oldDueValue = x.due;
    if (oldDate && nextDate && nextDate <= oldDate) { showToast("error", "Hạn mới chưa hợp lệ", "Hạn gia hạn phải sau Hạn hoàn thành hiện tại."); return; }
    const btn = document.getElementById("extendSaveBtn"), oldText = btn.textContent; btn.disabled = true; btn.textContent = "⏳ Đang lưu...";
    try {
        const actionTime = new Date().toISOString();
        const adminNote = `${x.admin_note ? `${x.admin_note}\n` : ""}Thêm lý do gia hạn từ [${oldDueValue ? formatDate(oldDueValue) : "Chưa có hạn"}] - [${formatDate(newDate)}]: ${reason}`;
        const r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(x.id)}`, { method: "PATCH", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" }, body: JSON.stringify({ deadline_date: newDate, is_extended: true, note: adminNote, status: dbStatus(calculateTaskStatus(x, { due: newDate })), updated_at: actionTime }) });
        const txt = await r.text(); if (!r.ok) { let d = txt; try { const j = JSON.parse(txt); d = j.message || j.details || j.hint || txt } catch (e) { } throw new Error(d || `HTTP ${r.status}`); }
        let saved = null; try { const j = JSON.parse(txt || "[]"); saved = Array.isArray(j) ? j[0] : j } catch (e) { }
        x.due = (saved && saved.deadline_date) || newDate; x.admin_note = (saved && saved.note) || adminNote; x.extended = saved && saved.is_extended !== undefined ? saved.is_extended === true : true; x.status = calculateTaskStatus(x); x.updated_at = (saved && saved.updated_at) || actionTime; x._dueDate = parseDate(x.due); localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA));
        applyFilters(); if (typeof refreshActiveDrillPopup === "function") refreshActiveDrillPopup();
        writeActivity("Gia hạn nhiệm vụ", { task: x.task, id: x.id, old_due: oldDueValue, new_due: newDate, reason, time: actionTime });
        closeExtendModal(); showToast("success", "Đã gia hạn", `Hạn mới: ${formatDate(newDate)} · Trạng thái tự động: ${x.status}.`);
    } catch (e) { console.error(e); showToast("error", "Không thể gia hạn", e.message || "Vui lòng kiểm tra Supabase.", 5200); }
    finally { btn.disabled = false; btn.textContent = oldText; }
}

async function saveHomeWorkspaceExtension() {
    const target = window.HOME_EXTEND_TARGET;
    const newDate = dateToDb(document.getElementById("extendNewDate").value);
    const reason = document.getElementById("extendReason").value.trim();
    const btn = document.getElementById("extendSaveBtn");
    if (!target || !newDate || !reason) { showToast("error", "Thiếu thông tin", "Vui lòng chọn hạn mới và nhập lý do gia hạn."); return; }
    const cfg = {
        bch: { rows: BCH_TASKS, table: "tasks", status: bchStatusFor, label: bchStatusLabel },
        ttbtv: { rows: TTBTV_TASKS, table: "tt_btv_tasks", status: ttbtvStatusFor, label: ttbtvStatusLabel },
        province: { rows: PROV_TASKS, table: "province_tasks", status: provinceStatusFor, label: provinceStatusLabel }
    }[target.source];
    if (!cfg) { showToast("error", "Không xác định được nguồn nhiệm vụ", "Vui lòng mở lại popup gia hạn."); return; }
    const x = cfg?.rows.find(r => String(r.id) === String(target.id));
    if (!x) return;
    const oldDue = x.deadline || x.due || "";
    const oldDate = parseDate(oldDue), nextDate = parseDate(newDate);
    if (!nextDate) { showToast("error", "Hạn mới chưa hợp lệ", "Vui lòng chọn ngày gia hạn hợp lệ."); return; }
    if (oldDate && nextDate <= oldDate) { showToast("error", "Hạn mới chưa hợp lệ", "Hạn gia hạn phải sau hạn hoàn thành hiện tại."); return; }
    if (cfg.status(x) !== "overdue") { showToast("error", "Không cần gia hạn", "Chỉ nhiệm vụ quá hạn mới được gia hạn."); return; }
    const isBCH = cfg.table === "tasks";
    const patch = { deadline: newDate, ...(!isBCH ? { is_extended: true } : {}), note: `${x.note ? `${x.note}\n` : ""}Gia hạn: ${formatDate(oldDue)} → ${formatDate(newDate)} · ${reason}`, status: cfg.label(cfg.status(x, { deadline: newDate })), updated_at: new Date().toISOString() };
    const oldText = btn?.textContent || "";
    if (btn) { btn.disabled = true; btn.textContent = "Đang lưu..."; }
    try {
        const r = await fetch(`${SUPABASE_URL}/rest/v1/${cfg.table}?id=eq.${encodeURIComponent(x.id)}`, { method: "PATCH", headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json", Prefer: "return=representation" }, body: JSON.stringify(patch) });
        if (!r.ok) throw new Error(await r.text());
        x.deadline = newDate; if (!isBCH) { x.is_extended = true; x.extended = true; } x.note = patch.note; x.admin_note = patch.note; x.status = patch.status; x.statusKey = cfg.status(x);
        closeExtendModal();
        if (target.source === "bch") await loadBCHData(true);
        if (target.source === "ttbtv") await loadTTBTVData(true);
        if (target.source === "province") await loadPROVData(true);
        render();
        if (target.source === "bch" && document.getElementById("bchDrillModal")?.classList.contains("open")) renderBCHDrill(BCH_DRILL_STATE.ids.map(id => BCH_TASKS.find(r => String(r.id) === String(id))).filter(Boolean), BCH_DRILL_STATE.title, BCH_DRILL_STATE.icon, false);
        if (target.source === "ttbtv" && document.getElementById("ttbtvDrillModal")?.classList.contains("open")) renderTTBTVDrill(TTBTV_DRILL_STATE.ids.map(id => TTBTV_TASKS.find(r => String(r.id) === String(id))).filter(Boolean), TTBTV_DRILL_STATE.title, TTBTV_DRILL_STATE.icon, false);
        if (target.source === "province" && document.getElementById("provinceDrillModal")?.classList.contains("open")) renderPROVDrill(PROV_DRILL_STATE.ids.map(id => PROV_TASKS.find(r => String(r.id) === String(id))).filter(Boolean), PROV_DRILL_STATE.title, PROV_DRILL_STATE.icon, false);
        showToast("success", "Đã gia hạn", `Hạn mới: ${formatDate(newDate)}`);
    } catch (e) { showToast("error", "Không thể gia hạn", e.message || "Vui lòng thử lại."); }
    finally { if (btn) { btn.disabled = false; btn.textContent = oldText || "Lưu gia hạn"; } window.HOME_EXTEND_TARGET = null; }
}


function openCurrentUserTasks() {
    if (!CURRENT_USER) return;
    if (!canAccessOfficeData(CURRENT_USER) && CURRENT_USER.scope !== "bch" && CURRENT_USER.scope !== "ttbtv" && CURRENT_USER.scope !== "province") return;
    // V50: tài khoản chuyên workspace phải mở đúng dữ liệu của workspace đó.
    // Tránh lỗi V48: token TT/BTV vẫn mở popup Văn phòng và nút Thêm ghi nhầm vào office_tasks.
    if (CURRENT_USER.role !== "admin" && CURRENT_USER.scope === "province") {
        const openMine = () => {
            const rows = PROV_TASKS.filter(x => provinceUserOwnsTask(x));
            renderPROVDrill(rows, `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤");
        };
        if (!PROV_LOADED) loadPROVData(true).then(openMine).catch(() => { }); else openMine();
        return;
    }
    if (CURRENT_USER.role !== "admin" && CURRENT_USER.scope === "ttbtv") {
        const openMine = () => {
            const rows = TTBTV_TASKS.filter(x => ttbtvFold(x.officer_name) === ttbtvFold(CURRENT_USER.name));
            renderTTBTVDrill(rows, `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤");
            appendTTBTVAddTaskRow();
        };
        if (!TTBTV_LOADED) loadTTBTVData(true).then(openMine).catch(() => { }); else openMine();
        return;
    }
    if (CURRENT_USER.role !== "admin" && CURRENT_USER.scope === "bch") {
        const openMine = () => {
            const rows = BCH_TASKS.filter(x => bchFold(x.officer_name) === bchFold(CURRENT_USER.name));
            renderBCHDrill(rows, `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤");
        };
        if (!BCH_LOADED) loadBCHData(true).then(openMine).catch(() => { }); else openMine();
        return;
    }
    if (CURRENT_USER.role === "admin") {
        showDrill(DATA, "Tất cả nhiệm vụ · ADMIN", "👤");
    } else {
        showDrill(DATA.filter(x => x.owner === CURRENT_USER.name), `Tất cả nhiệm vụ của ${CURRENT_USER.name}`, "👤");
    }
}

function drillTask(owner) {
    if (!canAccessOfficeData(CURRENT_USER)) { showToast('error', 'Khong co quyen', 'Token nay khong duoc xem du lieu Van phong.'); return; }
    showDrill(filtered.filter(x => x.owner === owner), `Nhiệm vụ của ${owner}`, "👤");
}

let OFFICE_DRILL_STATE = { ids: [], title: "Chi tiết", icon: "📋" };



async function cleanOldRegularDuplicates(newTask) {
    if (!newTask || !newTask.is_regular) return;
    if (!String(newTask.status || "").trim()) return;
    const now = new Date(); const curMonth = now.getMonth(), curYear = now.getFullYear();
    const prevMonth = curMonth === 0 ? 11 : curMonth - 1; const prevYear = curMonth === 0 ? curYear - 1 : curYear;
    const key = newTask._matchKey || (typeof taskMatchKey === 'function' ? taskMatchKey(newTask.owner, newTask.task) : String(newTask.owner||"")+"||"+String(newTask.task||""));
    const toDelete = DATA.filter(x => x.id !== newTask.id && !!x.is_regular && ((x._matchKey || (typeof taskMatchKey === 'function' ? taskMatchKey(x.owner, x.task) : "")) === key) && (() => { const d = x._createdDate || (typeof getCreationDate === 'function' ? getCreationDate(x) : null) || (typeof parseDate === 'function' ? parseDate(x.created_at) : null); return d && d.getMonth() === prevMonth && d.getFullYear() === prevYear; })());
    for (const old of toDelete) {
        try {
            const r = await fetch(`${SUPABASE_URL}/rest/v1/office_tasks?id=eq.${encodeURIComponent(old.id)}`, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
            if (r.ok || r.status === 404) { const idx = DATA.indexOf(old); if (idx >= 0) DATA.splice(idx, 1); }
        } catch (e) { }
    }
    if (toDelete.length) {
        try { localStorage.setItem("vp_tasks_cache", JSON.stringify(DATA)); if (typeof writeCache === 'function') writeCache("vp_tasks_cache", DATA); } catch (e) { }
        try { rebuildFilters(); applyFilters(); if (typeof refreshActiveDrillPopup === 'function') refreshActiveDrillPopup(); } catch (e) { }
    }
}


function resetOfficeDrillFilters() {
    const oqf = document.getElementById("officeDrillOfficerFilter"); if (oqf) oqf.value = "";
    const oqn = document.getElementById("officeDrillOfficerNameFilter"); if (oqn) oqn.value = "";
    const sel = document.getElementById("officeDrillOfficerSelect"); if (sel) sel.value = "";
    const st = document.getElementById("officeDrillStatusFilter"); if (st) st.value = "all";
    const ord = document.getElementById("officeDrillOrder"); if (ord) ord.value = "newest";
    ["officeDrillTimeFilter", "officeDrillQuarterFilter", "officeDrillMonthFilter"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    onOfficeDrillFilterChange();
}
function renderOfficeDrillRows(rows, title, icon, openModal = true) {
    if (openModal) {
        const allRows = OFFICE_DRILL_STATE.ids.map(id => DATA.find(v => String(v.id) === String(id))).filter(Boolean);
        const srcRows = allRows.length ? allRows : rows;
        const names = [...new Set(srcRows.map(x => String(x.owner || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "vi"));
        const sel = document.getElementById("officeDrillOfficerSelect");
        if (sel) { const cur = sel.value; sel.innerHTML = '<option value="">Tất cả cán bộ</option>' + names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join(""); sel.value = names.includes(cur) ? cur : ""; }
        const q = document.getElementById("officeDrillOfficerFilter"); if (q) q.value = "";
        const st = document.getElementById("officeDrillStatusFilter"); if (st) st.value = "all";
        const dtf = document.getElementById("officeDrillTimeFilter"); if (dtf) dtf.value = "";
        const dqf = document.getElementById("officeDrillQuarterFilter"); if (dqf) dqf.value = "";
        const dmf = document.getElementById("officeDrillMonthFilter"); if (dmf) dmf.value = "";
    }
    rows = applyOfficeDrillOrder(rows);
    const modal = document.getElementById("drillModal");
    document.getElementById("drillTitle").innerHTML = `<span>${icon}</span> ${title}`;
    document.getElementById("drillCount").textContent = rows.length;
    const tbody = document.getElementById("drillBody"), empty = document.getElementById("drillEmpty");
    const idToIdx = new Map(DATA.map((v, i) => [String(v.id), i]));
    let content = "";
    try {
        if (rows.length === 0) { content = renderAddTaskRow(); if (empty) empty.style.display = "block"; }
        else {
            if (empty) empty.style.display = "none";
            content = rows.map((x, i) => {
                const u = urgencyInfo(x), badgeClass = statusBadgeClass(x.status); const canOpenEdit = canEditTask(x); const idx = idToIdx.get(String(x.id)) ?? -1; return `<tr class="home-drill-row" onclick="${canOpenEdit ? `openEditTask(${idx})` : `openHomeTaskDrill('office', ${JSON.stringify(String(x.id))})`}" title="Click để ${canOpenEdit ? 'cập nhật' : 'xem chi tiết'} nhiệm vụ">
                    <td>${i + 1}</td><td class="task-tip-cell"><div class="task-tip" data-full="${esc(demoMaskText(x.task) + regularMonthTagText(x))}">${esc(demoMaskText(x.task))}${regularMonthTagHtml(x)}</div></td><td>👤 ${esc(demoMaskName(x.owner))}</td><td>${esc(officeRoleDisplay(x.role))}</td>
                    <td>📅 ${formatDate(x.due)}</td><td>${x.completed_date ? `✅ ${formatDate(x.completed_date)}` : `<span class="admin-note-empty">—</span>`}</td>
                    <td><span class="badge ${badgeClass}">${esc(x.status)}</span>${x.is_regular ? ' <span title="Thường xuyên - giữ sang tháng sau" style="color:#a855f7;font-weight:800">🔁</span>' : ''}</td>
                    <td class="admin-note-cell"><div class="note-stack">${x.staff_note ? `<div class="note-line staff"><span class="note-label">👤 Cán bộ</span>${esc(demoMaskText(x.staff_note))}</div>` : ""}${x.admin_note ? `<div class="note-line admin"><span class="note-label">🛡 Admin</span>${esc(demoMaskText(x.admin_note))}</div>` : ""}${!x.staff_note && !x.admin_note ? `<span class="admin-note-empty">Chưa có ghi chú</span>` : ""}</div></td>
                    <td class="product-cell">${esc(demoMaskText((x.product && !['---', '--', '-'].includes(String(x.product).trim())) ? x.product : 'Không'))}</td>
                    <td class="attachment-cell">${!x.attachment_path && !x.attachment_name ? `<span class="admin-note-empty">Chưa có tệp</span>` : x.attachment_path && x.attachment_approved && CURRENT_USER && CURRENT_USER.role === 'admin' ? `<button class="file-link-btn" onclick="event.stopPropagation();openAttachmentByIndex(${idToIdx.get(String(x.id)) ?? -1})">📎 ${esc(x.attachment_name || 'Xem tệp')}</button>` : `<span class="file-pill">📄 ${esc(x.attachment_name || 'Đã lưu tên file')}</span>`}</td>
                    <td><div class="task-actions-stack">${CURRENT_USER && CURRENT_USER.role === 'admin' && ['overdue', 'today', 'soon3'].includes(u.key) ? `<button class="edit-btn" onclick="event.stopPropagation();sendDeadlineEmail(${idToIdx.get(String(x.id)) ?? -1})">📧 Gửi TB</button>` : ''}${canEditTask(x) ? `<button class="edit-btn" onclick="event.stopPropagation();openEditTask(${idToIdx.get(String(x.id)) ?? -1})">✏️ Sửa</button>` : `<span class="locked-text">🔒 Chỉ xem</span>`}${CURRENT_USER && CURRENT_USER.role === 'admin' && x.status === "Quá hạn" ? `<button class="extend-btn" onclick="event.stopPropagation();openExtendDeadline(${idToIdx.get(String(x.id)) ?? -1})">📅 Gia hạn</button>` : ''}</div></td></tr>`
            }).join('') + renderAddTaskRow();
        }
        tbody.innerHTML = content;
    } catch (err) {
        console.error("[renderOfficeDrillRows] Lỗi dựng bảng, vẫn mở popup:", err);
        tbody.innerHTML = "<tr><td colspan=\"11\"><div class=\"drill-empty\">Không tải được danh sách nhiệm vụ.</div></td></tr>";
        if (empty) empty.style.display = "none";
    }
    if (openModal) { smoothOpenModal(modal); setTimeout(updateAddCompletedDateAccess, 0); }
}

function showDrill(rows, title, icon = "📋") {
    const filterBar = document.getElementById("activityLogFilters");
    if (filterBar) { filterBar.style.display = "flex"; filterBar.style.flexDirection = "column"; filterBar.style.gridTemplateColumns = ""; }
    const _afWrap2 = document.getElementById("activityFilterWrap"); if (_afWrap2) _afWrap2.style.display = "none";
    const _ofWrapShow = document.getElementById("officeFilterWrap"); if (_ofWrapShow) _ofWrapShow.style.display = "";
    document.getElementById("drillModal")?.classList.remove("activity-log-mode");
    const drillTbl = document.querySelector("#drillModal .drill-table");
    if (drillTbl) { drillTbl.classList.add("office-drill-table"); drillTbl.classList.remove("activity-log-table"); }
    document.querySelector("#drillModal thead").innerHTML = "<tr><th>STT</th><th>Nhiệm vụ</th><th>Cán bộ</th><th>Vai trò</th><th>Hạn hoàn thành</th><th>Ngày hoàn thành</th><th>Trạng thái</th><th>Ghi chú</th><th>Sản phẩm</th><th>Tệp sản phẩm</th><th>Thao tác</th></tr>";
    ["activityNameFilter", "activityActionFilter", "activityAdminFilter", "activityTaskFilter", "activityDateFilter", "activitySortFilter"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = "none"; });
    const _sortFieldShow = document.getElementById("officeSortField") || document.querySelector("#officeFilterWrap .of-sort"); if (_sortFieldShow) _sortFieldShow.style.display = "";
    document.getElementById("officeDrillOrderLabel").style.display = "";
    const _orderSel = document.getElementById("officeDrillOrder");
    if (_orderSel) {
        _orderSel.innerHTML = '<option value="newest">Mới nhất trước</option><option value="oldest">Cũ nhất trước</option><option value="due_far">Hạn xa nhất</option><option value="due_near">Hạn gần nhất</option><option value="with_file">Có file đính kèm</option>';
        _orderSel.style.display = "";
    }
    document.getElementById("officeDrillOfficerFilter").style.display = "";
    const _oqnShow = document.getElementById("officeDrillOfficerNameFilter"); if (_oqnShow) _oqnShow.style.display = "";
    const _oclShow = document.getElementById("officeDrillClearFilter"); if (_oclShow) _oclShow.style.display = "";
    document.getElementById("officeDrillOfficerSelect").style.display = "";
    document.getElementById("officeDrillStatusFilter").style.display = "";
    document.getElementById("officeDrillTimeFilter").style.display = "";
    document.getElementById("officeDrillQuarterFilter").style.display = "";
    document.getElementById("officeDrillMonthFilter").style.display = "";
    document.getElementById("officeDrillFilterHint").style.display = "";
    OFFICE_DRILL_STATE = { ids: rows.map(x => String(x.id)), title, icon };
    const sel = document.getElementById("officeDrillOrder"); if (sel) sel.value = "newest";
    renderOfficeDrillRows(rows, title, icon, true);
}

document.getElementById("drillCloseBtn").addEventListener("click", () => {
    smoothCloseModal("drillModal");
});

// Hover popup nội dung đầy đủ khi tên nhiệm vụ dài (cột Nhiệm vụ popup Văn phòng).
(function () {
    let tipEl = null, timer = null;
    const THRESHOLD = 40; // độ dài tối thiểu để hiện popup
    function ensureTip() {
        if (tipEl) return tipEl;
        tipEl = document.createElement("div");
        tipEl.className = "task-tip-popup";
        // Giữ tooltip khi chuột di chuyển vào tooltip
        tipEl.addEventListener("mouseenter", () => { if (timer) { clearTimeout(timer); timer = null; } });
        tipEl.addEventListener("mouseleave", () => { hideTip(); });
        document.body.appendChild(tipEl);
        return tipEl;
    }
    function hideTip() {
        if (timer) { clearTimeout(timer); timer = null; }
        timer = setTimeout(() => { if (tipEl) tipEl.classList.remove("show"); }, 200);
    }
    document.addEventListener("mouseover", (e) => {
        const cell = e.target.closest ? e.target.closest(".task-tip, .prov-task-tip, .activity-action-badge") : null;
        if (!cell) return;
        // An tooltip task-tip-popup o nhiem vu tinh (popup + danh sach chi tiet)
        if (cell.classList.contains("prov-task-text") || cell.classList.contains("prov-doc-tip") || (cell.closest && (cell.closest("#provinceDrillModal") || cell.closest("#provinceTableBody")))) return;
        const full = cell.getAttribute("data-full") || "";
        if (!full.trim()) return;
        const alwaysShow = cell.classList.contains("prov-task-tip") || cell.classList.contains("activity-action-badge") || cell.classList.contains("ttbtv-task-title") || cell.classList.contains("ttbtv-drill-task-text") || cell.parentElement.classList.contains("c-task");
        if (!alwaysShow && full.length < THRESHOLD) return;
        if (timer) { clearTimeout(timer); timer = null; }
        const tip = ensureTip();
        tip.textContent = full;
        const r = cell.getBoundingClientRect();
        tip.classList.add("show");
        const tr = tip.getBoundingClientRect();
        let left = r.left;
        let top = r.top - tr.height - 8;
        if (top < 6) top = r.bottom + 8;
        const maxLeft = window.innerWidth - tr.width - 8;
        if (left > maxLeft) left = maxLeft;
        if (left < 8) left = 8;
        tip.style.left = left + "px";
        tip.style.top = top + "px";
    });
    document.addEventListener("mouseout", (e) => {
        if (e.target.closest && e.target.closest(".task-tip, .prov-task-tip, .activity-action-badge")) hideTip();
    });
    document.addEventListener("scroll", hideTip, true);
    window.addEventListener("resize", hideTip);
})();


// ===== V17: NHIỆM VỤ BCH ĐẢNG BỘ / public.officers + public.tasks =====
const BCH_OFFICERS_API = `${SUPABASE_URL}/rest/v1/officers?select=id,name,title,unit,note&order=id.asc`;
const BCH_TASKS_API = `${SUPABASE_URL}/rest/v1/tasks?select=id,officer_name,task_name,product,amount,deadline,result,updated_at,created_at,note,phat_sinh,role,completed_date,status,staff_note,admin_note,attachment_path,attachment_name,attachment_type,attachment_size,attachment_approved,attachment_approved_at,attachment_approved_by&order=id.asc`;
let BCH_OFFICERS = [];
let BCH_TASKS = [];
let BCH_FILTERED = [];
let BCH_LOADED = false;

function bchFold(s) {
    return String(s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
}
function bchHasProduct(v) {
    const s = bchFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(s);
}
function bchHasResult(v) {
    const s = bchFold(v);
    return !!s && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null", "dang trien khai"].includes(s);
}
function bchDeadlineDate(v) {
    const s = String(v ?? "").trim();
    if (!s) return null;
    // Hỗ trợ yyyy-mm-dd và chuỗi tiếng Việt có dd/mm/yyyy, ví dụ: "Hoàn thành trước ngày 30/9/2026".
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) {
        const y = +iso[1], mo = +iso[2], d = +iso[3], dt = new Date(y, mo - 1, d);
        return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
    }
    const matches = [...s.matchAll(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/g)];
    if (!matches.length) return null;
    const m = matches[matches.length - 1], d = +m[1], mo = +m[2], y = +m[3];
    const dt = new Date(y, mo - 1, d);
    return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? dt : null;
}
function bchCompletedDate(v) {
    return bchDeadlineDate(v);
}
function bchDispDate(v) {
    const d = bchDeadlineDate(v);
    if (!d) return String(v || "").trim() || "Chưa có hạn";
    return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${d.getFullYear()}`;
}
function bchStatusFor(x, overrides = {}) {
    const due = bchDeadlineDate(overrides.deadline ?? x.deadline);
    const completed = bchCompletedDate(overrides.completed_date ?? x.completed_date);
    const rawStatus = bchFold(overrides.status ?? x.status ?? "");
    const rawResult = bchFold(overrides.result ?? x.result ?? "");

    // V41: nếu đã có ngày hoàn thành thì NGÀY là nguồn chuẩn cao nhất.
    // completed < deadline  => Hoàn thành trước hạn
    // completed = deadline  => Hoàn thành đúng hạn
    // completed > deadline  => Hoàn thành quá hạn
    // Không để status/result cũ từ lần import hoặc lần lưu trước ghi đè kết quả tính theo ngày.
    // Hoàn thành trước/đúng/quá hạn: phải có Sản phẩm + Ngày hoàn thành, thiếu 1 trong 2 là Đang triển khai.
    if (completed) {
        const hasFile = overrides.hasFile !== undefined ? !!overrides.hasFile : (!!x.attachment_path || !!x.attachment_name);
        const hasEvidence = bchHasResult(overrides.result ?? x.result) || bchHasProduct(overrides.product ?? x.product) || hasFile;
        if (!hasEvidence) return "processing";
        if (due) {
            const a = new Date(completed.getFullYear(), completed.getMonth(), completed.getDate()).getTime();
            const b = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
            if (a < b) return "early";
            if (a === b) return "ontime";
            return "latedone";
        }
        return "ontime";
    }

    // Chưa có Ngày hoàn thành: không thể Hoàn thành (dù status cũ còn lưu nhãn done) -> Đang triển khai / Quá hạn.
    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (due && due < today) return "overdue";
    return "processing";
}
function bchStatusLabel(k) {
    return ({
        processing: "Đang triển khai",
        early: "Hoàn thành trước hạn",
        ontime: "Hoàn thành đúng hạn",
        latedone: "Hoàn thành quá hạn",
        overdue: "Quá hạn"
    })[k] || "Đang triển khai";
}
function bchStatusGroup(k) {
    // V37: gom 3 trạng thái hoàn thành chi tiết về nhóm "done" cho KPI/bộ lọc.
    return ["early", "ontime", "latedone", "done"].includes(k) ? "done" : (k || "processing");
}




async function bchFetch(url) {
    const r = await fetch(url, { headers: { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}`, "Content-Type": "application/json" } });
    const tx = await r.text();
    if (!r.ok) { if(String(tx).includes("42501")||String(tx).toLowerCase().includes("row-level security")) throw new Error(tx+" (RLS chặn - kiểm tra policy hoặc DISABLE RLS)"); throw new Error(tx || `HTTP ${r.status}`); }
    const j = JSON.parse(tx);
    if (!Array.isArray(j)) throw new Error("Dữ liệu BCH không phải mảng.");
    return j;
}

// XÓA LUÔN 2 dòng này ở đầu file legacy.js đi, không cần nữa:
// const SUPABASE_URL = "..."
// const SUPABASE_KEY = "..."



function renderBCHKPIs() {
    const all = (typeof bchScopeRows === "function") ? bchScopeRows() : BCH_TASKS;
    const counts = { processing: 0, done: 0, overdue: 0 };
    all.forEach(x => { const g = bchStatusGroup(x.statusKey); counts[g] = (counts[g] || 0) + 1; });
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v };
    set("bchOfficerCount", BCH_OFFICERS.filter(o => bchFold(o.name) !== "vp admin").length);
    set("bchTotalCount", all.length);
    set("bchProcessingCount", counts.processing || 0);
    set("bchDoneCount", counts.done || 0);
    set("bchOverdueCount", counts.overdue || 0);
    set("bchShownCount", BCH_FILTERED.length);
    try {
        const total = all.length || 0;
        const done = counts.done || 0, proc = counts.processing || 0, over = counts.overdue || 0;
        const pct = n => total ? Math.round(n * 100 / total) : 0;
        const g = { processing: 0, done: 0, overdue: 0 };
        BCH_TASKS.forEach(x => { const k = bchStatusGroup(x.statusKey); g[k] = (g[k] || 0) + 1; });
        set("bchSumTotal", `${BCH_TASKS.length} nhiệm vụ`);
        set("bchSumDone", `${g.done || 0} hoàn thành`);
        set("bchSumProcessing", `${g.processing || 0} đang thực hiện`);
        set("bchSumOverdue", `${g.overdue || 0} quá hạn`);
        const bd = document.getElementById("bchRateDoneBar"); if (bd) bd.style.width = pct(done) + "%";
        const bp = document.getElementById("bchRateProcessingBar"); if (bp) bp.style.width = pct(proc) + "%";
        const bo = document.getElementById("bchRateOverdueBar"); if (bo) bo.style.width = pct(over) + "%";
        set("bchRateDoneCount", done); set("bchRateProcessingCount", proc); set("bchRateOverdueCount", over);
        set("bchRateDoneLabel", `Hoàn thành ${pct(done)}% (${done}/${total})`);
        set("bchRateProcessingLabel", `Chưa HT trong hạn ${pct(proc)}% (${proc}/${total})`);
        set("bchRateOverdueLabel", `Chưa HT quá hạn ${pct(over)}% (${over}/${total})`);
        const today = new Date(); today.setHours(0, 0, 0, 0);
        let dueToday = 0, withFile = 0;
        all.forEach(x => {
            if (String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim()) withFile++;
            const d = bchDeadlineDate(x.deadline);
            if (d && !bchCompletedDate(x.completed_date)) {
                const dd = new Date(d.getFullYear(), d.getMonth(), d.getDate());
                if (dd.getTime() === today.getTime()) dueToday++;
            }
        });
        set("bchDueTodayCount", dueToday);
        set("bchFileCount", withFile);
        if (typeof renderBCHLeaderList === "function") renderBCHLeaderList();
        if (typeof bchSyncMonthStrip === "function") bchSyncMonthStrip();
    } catch (e) {}
}

const BCH_CHARTS = {};
function bchRenderChart(canvasId, labels, data, colorsList, legendId, drillKind) {
    const canvas = document.getElementById(canvasId); if (!canvas || typeof Chart === "undefined") return;
    if (BCH_CHARTS[canvasId]) BCH_CHARTS[canvasId].destroy();
    BCH_CHARTS[canvasId] = new Chart(canvas.getContext("2d"), {
        type: "doughnut",
        data: { labels, datasets: [{ data, backgroundColor: colorsList, borderColor: "#fff", borderWidth: 2 }] },
        options: {
            responsive: true, maintainAspectRatio: false, cutout: "62%",
            plugins: { legend: { display: false } },
            onClick: (evt, els) => {
                if (!els.length) return;
                const label = labels[els[0].index];
                drillBCHChart(drillKind, label);
            }
        }
    });
    const lg = document.getElementById(legendId);
    if (lg) lg.innerHTML = labels.map((l, i) => `<div class="legend-item" onclick="drillBCHChart('${drillKind}',${JSON.stringify(l).replace(/"/g, '&quot;')})"><span class="legend-color" style="background:${colorsList[i]}"></span><span>${esc(l)} (${data[i]})</span></div>`).join("");
}
function renderWorkspacePerformance(canvasId, legendId, rows, getOwner, getStatus, chartStore, onOwnerClick) {
    const stats = {};
    rows.forEach(row => { const owner = getOwner(row) || "Chưa phân công"; const key = getStatus(row); if (!stats[owner]) stats[owner] = { done: 0, processing: 0, overdue: 0 }; stats[owner][key] = (stats[owner][key] || 0) + 1; });
    const top = Object.entries(stats).sort((a, b) => (b[1].done + b[1].processing + b[1].overdue) - (a[1].done + a[1].processing + a[1].overdue)).slice(0, 10);
    const canvas = document.getElementById(canvasId); if (!canvas || typeof Chart === "undefined") return;
    if (chartStore[canvasId]) chartStore[canvasId].destroy();
    chartStore[canvasId] = new Chart(canvas.getContext("2d"), { type: "bar", data: { labels: top.map(x => x[0]), datasets: [{ label: "Hoàn thành", data: top.map(x => x[1].done), backgroundColor: "#009E73" }, { label: "Đang triển khai", data: top.map(x => x[1].processing), backgroundColor: "#56B4E9" }, { label: "Quá hạn", data: top.map(x => x[1].overdue), backgroundColor: "#D55E00" }] }, options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true, beginAtZero: true, ticks: { precision: 0 } }, y: { stacked: true } }, plugins: { legend: { position: "top" } }, onClick: (event, elements) => { if (!elements.length || !onOwnerClick) return; const el = elements[0]; const owner = top[el.index]?.[0]; if (!owner) return; const statusKeys = ["done", "processing", "overdue"]; const statusKey = statusKeys[el.datasetIndex]; onOwnerClick(owner, statusKey); } } });
    const legend = document.getElementById(legendId); if (legend) legend.innerHTML = "";
}
function renderBCHCharts() {
    if (!BCH_TASKS.length) {
        ["bchChart1", "bchChart2", "bchChart3", "bchChart4"].forEach(id => { if (BCH_CHARTS[id]) { BCH_CHARTS[id].destroy(); delete BCH_CHARTS[id]; } });
        return;
    }
    const rows = BCH_FILTERED.length || ["all"].includes(document.getElementById("bchStatusFilter")?.value || "all") ? BCH_FILTERED : BCH_TASKS;
    const useRows = (document.getElementById("bchSearch")?.value || document.getElementById("bchOfficerNameFilter")?.value || document.getElementById("bchOfficerFilter")?.value || (document.getElementById("bchStatusFilter")?.value || "all") !== "all") ? BCH_FILTERED : BCH_TASKS;

    // 1. Status
    const sm = { processing: 0, done: 0, overdue: 0 }; useRows.forEach(x => { const g = bchStatusGroup(bchStatusFor(x)); sm[g] = (sm[g] || 0) + 1; });
    const sk = ["processing", "done", "overdue"].filter(k => sm[k]);
    bchRenderChart("bchChart1", sk.map(bchStatusLabel), sk.map(k => sm[k]), sk.map(k => ({ processing: "#56B4E9", done: "#009E73", overdue: "#D55E00" })[k]), "bchLegend1", "status");

    // 2. Officer title
    const om = bchOfficerMap(), tm = {};
    useRows.forEach(x => { const title = (om.get(bchFold(x.officer_name)) || {}).title || "Chưa có chức vụ"; tm[title] = (tm[title] || 0) + 1 });
    const titles = Object.entries(tm).sort((a, b) => b[1] - a[1]).slice(0, 7);
    const palette = ["#8b5cf6", "#3b82f6", "#009E73", "#f59e0b", "#ec4899", "#56B4E9", "#64748b"];
    bchRenderChart("bchChart2", titles.map(x => x[0]), titles.map(x => x[1]), palette.slice(0, titles.length), "bchLegend2", "title");

    // 3. Deadline
    const dm = { overdue: 0, soon: 0, safe_none: 0, done: 0 };
    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    useRows.forEach(x => {
        if (bchStatusGroup(bchStatusFor(x)) === "done") { dm.done++; return }
        const due = bchDeadlineDate(x.deadline);
        if (!due) { dm.none++; return }
        const days = Math.round((due - today) / 86400000);
        if (days < 0) dm.overdue++; else if (days <= 3) dm.soon++; else dm.safe++;
    });
    const dk = ["overdue", "soon", "safe", "done", "none"].filter(k => dm[k]);
    const dn = { overdue: "Quá hạn", soon: "≤ 3 ngày", safe: "Còn hạn", done: "Hoàn thành", none: "Chưa rõ hạn" };
    const dc = { overdue: "#D55E00", soon: "#f59e0b", safe: "#009E73", done: "#3b82f6", none: "#94a3b8" };
    bchRenderChart("bchChart3", dk.map(k => dn[k]), dk.map(k => dm[k]), dk.map(k => dc[k]), "bchLegend3", "deadline");

    // 4. Number of tasks by officer (Top 8)
    const cm = {}; useRows.forEach(x => cm[x.officer_name || "Chưa phân công"] = (cm[x.officer_name || "Chưa phân công"] || 0) + 1);
    const top = Object.entries(cm).sort((a, b) => b[1] - a[1]).slice(0, 8);
    bchRenderChart("bchChart4", top.map(x => x[0]), top.map(x => x[1]), ["#2563eb", "#56B4E9", "#8b5cf6", "#009E73", "#f59e0b", "#ec4899", "#64748b", "#0ea5e9"].slice(0, top.length), "bchLegend4", "officer");
    renderWorkspacePerformance("bchPerformanceChart", "bchPerformanceLegend", useRows, x => x.officer_name, x => bchStatusGroup(bchStatusFor(x)), BCH_CHARTS, (owner, statusKey) => { let rows = useRows.filter(x => String(x.officer_name || "") === String(owner)); if (statusKey) rows = rows.filter(x => bchStatusGroup(bchStatusFor(x)) === statusKey); const labelMap = { done: "Hoàn thành", processing: "Đang triển khai", overdue: "Quá hạn" }; const suffix = statusKey ? ` · ${labelMap[statusKey] || statusKey}` : ""; renderBCHDrill(rows, `Hiệu suất nhiệm vụ - ${owner}${suffix}`, "📊"); });
}
function drillBCHChart(kind, label) {
    if (kind === "status") {
        const key = label === "Hoàn thành" ? "done" : label === "Quá hạn" ? "overdue" : "processing";
        openBCHStatusPopup(key); return;
    }
    if (kind === "officer") {
        const o = document.getElementById("bchOfficerFilter"); if (o) o.value = label; applyBCHFilters(); return;
    }
    if (kind === "title") {
        const om = bchOfficerMap();
        const names = new Set(BCH_OFFICERS.filter(o => (o.title || "Chưa có chức vụ") === label).map(o => bchFold(o.name)));
        BCH_FILTERED = BCH_TASKS.filter(x => names.has(bchFold(x.officer_name)));
        renderBCHTable(BCH_FILTERED); return;
    }
    if (kind === "deadline") {
        const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        BCH_FILTERED = BCH_TASKS.filter(x => {
            const st = bchStatusFor(x), due = bchDeadlineDate(x.deadline);
            if (label === "Hoàn thành") return bchStatusGroup(st) === "done";
            if (label === "Chưa rõ hạn") return bchStatusGroup(st) !== "done" && !due;
            if (!due || bchStatusGroup(st) === "done") return false;
            const days = Math.round((due - today) / 86400000);
            if (label === "Quá hạn") return days < 0;
            if (label === "≤ 3 ngày") return days >= 0 && days <= 3;
            return days > 3;
        });
        renderBCHTable(BCH_FILTERED); return;
    }
}




let BCH_EDIT_ID = null;
let BCH_DRILL_MODE = "all";

function bchCanEdit(x) {
    if (!CURRENT_USER) return false;
    return CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.name === x.officer_name);
}

function bchScopeRows() {
    const q = bchFold(document.getElementById("bchSearch")?.value || "");
    const officer = document.getElementById("bchOfficerFilter")?.value || "";
    const officerQ = bchFold(document.getElementById("bchOfficerNameFilter")?.value || "");
    const timeMode = document.getElementById("bchTimeFilter")?.value || "all";
    BCH_TASKS.forEach(x => { if (!x.statusKey) x.statusKey = bchStatusFor(x); });
    return BCH_TASKS.filter(x => {
        if (q && !String(x._search || "").includes(q)) return false;
        if (officer && x.officer_name !== officer) return false;
        if (officerQ && !bchFold(x.officer_name || "").includes(officerQ)) return false;
        if (timeMode !== "all") { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (typeof BCH_MONTH !== "undefined" && BCH_MONTH) { const d = bchDeadlineDate(x.deadline); if (!d || (d.getMonth() + 1) !== BCH_MONTH) return false; }
        if (typeof BCH_QUARTER !== "undefined" && BCH_QUARTER) { const d = bchDeadlineDate(x.deadline); if (!d || Math.ceil((d.getMonth() + 1) / 3) !== BCH_QUARTER) return false; }
        if (typeof BCH_NODL !== "undefined" && BCH_NODL) { if (bchDeadlineDate(x.deadline)) return false; }
        if (typeof BCH_DL_DATE !== "undefined" && BCH_DL_DATE) { const dd = bchDeadlineDate(x.deadline); if (!dd || new Date(dd.getFullYear(), dd.getMonth(), dd.getDate()).getTime() !== BCH_DL_DATE) return false; }
        else if (typeof BCH_DL_Q !== "undefined" && BCH_DL_Q && !bchFold(x.deadline || "").includes(BCH_DL_Q)) return false;
        return true;
    });
}





let BCH_DRILL_STATE = { ids: [], title: "Nhiệm vụ BCH Đảng bộ", icon: "🏛️" };
function bchDrillTimestamp(x) { const t = Date.parse(x?.updated_at || ""); return Number.isFinite(t) ? t : (Number(x?.id) || 0) }


function resetBCHDrillFilters() { const q=document.getElementById("bchDrillOfficerFilter"); if(q) q.value=""; const sel=document.getElementById("bchDrillOfficerSelect"); if(sel) sel.value=""; const st=document.getElementById("bchDrillStatusFilter"); if(st) st.value="all"; const ord=document.getElementById("bchDrillOrder"); if(ord) ord.value="newest"; onBCHDrillFilterChange(); }


// ===== V65: THÊM NHIỆM VỤ BCH TRỰC TIẾP VÀO public.tasks =====
function renderBCHAddTaskRow() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.scope === "bch"))) return "";
    const names = [...new Set(BCH_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))];
    const ownerField = CURRENT_USER.role === "admin"
        ? `<select id="bchAddOfficer">${names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("")}</select>`
        : `<input id="bchAddOfficer" value="${CURRENT_USER.scope === "data_entry" ? "" : esc(CURRENT_USER.name)}" ${CURRENT_USER.scope === "data_entry" ? "placeholder=\"Nhập lãnh đạo phụ trách\"" : "readonly"}>`;
    return `<tr id="bchAddTaskRow" class="add-task-row"><td colspan="9">
                <div class="add-task-shell">
                  <div class="add-task-title"><span>➕ Thêm nhiệm vụ BCH</span><span style="font-size:11.8px;color:#64748b;font-weight:600">Ghi trực tiếp vào tasks</span></div>
                  <div class="add-task-grid">
                    <div class="field"><label>Lãnh đạo phụ trách</label>${ownerField}</div>
                    <div class="field span2"><label>Nhiệm vụ</label><textarea id="bchAddTaskName" placeholder="Nhập nội dung nhiệm vụ..."></textarea></div>
                    <div class="field"><label>Chuyên viên phụ trách</label><input id="bchAddSpecialist" placeholder="Nhập chuyên viên phụ trách"></div>
                    <div class="field"><label>Hạn hoàn thành <span style="color:#dc2626">*</span></label><input id="bchAddDeadline" type="text" placeholder="dd/mm/yyyy" inputmode="numeric" required class="date-ddmmyyyy" oninput="refreshBCHAddStatus()" lang="vi"></div>
                    <div class="field"><label>Ngày hoàn thành</label><input id="bchAddCompleted" type="text" placeholder="dd/mm/yyyy" inputmode="numeric" class="date-ddmmyyyy" oninput="refreshBCHAddStatus()" lang="vi"></div>
                    <div class="field"><label>Trạng thái <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="bchAddStatus" class="auto-status-field" value="Đang triển khai" readonly></div>
                    <div class="field span2"><label>Kết quả thực hiện</label><textarea id="bchAddResult" placeholder="Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp..." oninput="refreshBCHAddStatus()"></textarea></div>
                    <div class="field"><label>Tệp kết quả</label><input id="bchAddAttachment" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx" onchange="refreshBCHAddStatus()"></div>
                    <div class="field span3"><label>👤 Ghi chú cán bộ</label><textarea id="bchAddStaffNote" placeholder="Ghi chú bổ sung (nếu có)"></textarea></div>
                    <div class="field add-task-actions"><button id="bchAddBtn" class="add-task-btn" type="button" onclick="stageNewBCHTask()">＋ Thêm nhiệm vụ</button></div>
                  </div>
                  <div class="add-task-help">Hạn hoàn thành là bắt buộc. Trạng thái tự tính theo Hạn hoàn thành + Ngày hoàn thành + Kết quả/tệp.</div>
                </div>
            </td></tr>`;
}







let PENDING_BCH_TASK = null;



function renderBCHDrill(rows, title, icon, openModal = true) {
    if (openModal) { BCH_DRILL_STATE = { ids: rows.map(x => String(x.id)), title: title || "Nhiệm vụ BCH Đảng bộ", icon: icon || "🏛️" }; const sel = document.getElementById("bchDrillOrder"); if (sel) sel.value = "newest"; const off = document.getElementById("bchDrillOfficerFilter"); if (off) off.value = ""; const offSel = document.getElementById("bchDrillOfficerSelect"); if(offSel){ const names=[...new Set(rows.map(x=>String(x.officer_name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi')); offSel.innerHTML='<option value="">Tất cả cán bộ</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join(''); offSel.value=''; } const stSel=document.getElementById("bchDrillStatusFilter"); if(stSel) stSel.value="all"; }
    const _isPerfPopupBCH = String(title || BCH_DRILL_STATE.title || "").includes("Hiệu suất nhiệm vụ -");
    const _offSelBCH = document.getElementById("bchDrillOfficerSelect"), _stSelBCH = document.getElementById("bchDrillStatusFilter"), _qBCH = document.getElementById("bchDrillOfficerFilter");
    if (_offSelBCH) { _offSelBCH.style.display = _isPerfPopupBCH ? "none" : ""; if (_isPerfPopupBCH) _offSelBCH.value = ""; }
    if (_stSelBCH) { _stSelBCH.style.display = _isPerfPopupBCH ? "none" : ""; if (_isPerfPopupBCH) _stSelBCH.value = "all"; }
    if (_qBCH) _qBCH.placeholder = "🔎 Lọc nội dung...";
    rows = applyBCHDrillOrder(rows);
    const body = document.getElementById("bchDrillBody"), empty = document.getElementById("bchDrillEmpty");
    document.getElementById("bchDrillTitle").textContent = `${icon || "🏛️"} ${title || "Nhiệm vụ BCH Đảng bộ"}`;
    document.getElementById("bchDrillCount").textContent = rows.length;
    body.innerHTML = rows.map((x, i) => {
        const can = bchCanEdit(x);
        const prod = [x.product, x.result].map(v => String(v || "").trim()).find(v => v && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(bchFold(v))) || "Chưa điền";
        const hasFile = !!(String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim());
        const fileText = hasFile ? "Có file đính kèm" : "";
        return `<tr class="bch-drill-row" onclick="openBCHTaskEdit(${x.id})">
                  <td>${i + 1}</td>
                   <td><div class="ttbtv-drill-task-text task-tip" data-full="${esc(x.task_name || "—")}">${esc(x.task_name || "—")}</div></td>
                    <td><b>${esc(x.officer_name || "—")}</b></td>
                   <td><div class="task-tip" data-full="${esc(prod)}">${esc(prod)}</div></td>
                    <td>${esc((bchDeadlineDate(x.deadline) ? formatDate(bchDeadlineDate(x.deadline)) : (x.deadline || "—")))}</td>
                  <td><span class="bch-badge ${x.statusKey}">${bchStatusLabel(x.statusKey)}</span></td>
                  <td>${esc(fileText)}</td>
                  <td>${can ? `<button class="edit-btn" onclick="event.stopPropagation();openBCHTaskEdit(${x.id})">✏️ Sửa</button>` : `<span class="locked-text">🔒 Xem</span>`}</td>
                </tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    appendBCHAddTaskRow();
    if (typeof setupBCHDateFields === 'function') setupBCHDateFields();
    if (openModal) smoothOpenModal("bchDrillModal");
}

function closeBCHDrill() { smoothCloseModal("bchDrillModal"); }






function renderBCHCurrentAttachment(x) {
    const el = document.getElementById("bchCurrentAttachment"); if (!el) return;
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        el.innerHTML = '<span class="admin-note-empty">Chưa có tệp đính kèm</span>'; return;
    }
    const approved = x.attachment_approved === true;
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    el.innerHTML = `<span class="file-pill">📄 ${esc(x.attachment_name || "Tệp sản phẩm")}</span>
                ${approved ? '<span class="approval-pill approved">✅ Đã duyệt</span>' : '<span class="approval-pill pending">⏳ Chờ duyệt</span>'}
                ${isAdmin && x.attachment_path ? `<button type="button" class="file-link-btn" onclick="openBCHAttachment(${x.id},true)">👁 Xem tệp</button>` : `<span class="admin-note-empty">Chỉ lưu tên file</span>`}
                ${isAdmin && !approved ? `<button type="button" class="approve-file-btn" onclick="approveBCHAttachment(${x.id})">✓ Phê duyệt</button>` : ""}
                ${isAdmin ? `<button type="button" class="file-delete-btn" onclick="deleteBCHAttachment(${x.id})">🗑 Xóa tệp</button>` : ""}`;
}




async function deleteBCCTask() {
    const x = BCH_TASKS.find(r => String(r.id) === String(BCH_EDIT_ID));
    if (!x) { showToast("error", "Không thể xóa nhiệm vụ", "Không tìm thấy nhiệm vụ đang chỉnh sửa."); return; }
    if (!canEditBCHTask(x)) { showToast("error", "Không có quyền", "Bạn không có quyền xóa nhiệm vụ này."); return; }

    const hasFile = !!x.attachment_path || !!x.attachment_name;
    const name = x.task_name || "Nhiệm vụ";
    const summary = `
                <div class="confirm-row"><span>Cán bộ</span><strong>${esc(x.officer_name || "")}</strong></div>
                <div class="confirm-row"><span>Nhiệm vụ</span><strong>${esc(name)}</strong></div>
                ${hasFile ? `<div class="confirm-row"><span>Tệp đính kèm</span><strong>${esc(x.attachment_name || "Có")}</strong></div><div class="confirm-note">Lưu ý: nếu chọn "Không, chỉ xóa nhiệm vụ", tệp vẫn được giữ lại trong Storage.</div>` : ""}
            `;
    openDeleteTaskConfirm({
        label: `Xóa nhiệm vụ "${name}"?`,
        summary,
        hasFile,
        onConfirm: async (deleteFile) => {
            try {
                if (deleteFile && x.attachment_path) {
                    const delUrl = `${SUPABASE_URL}/storage/v1/object/${BCH_STORAGE_BUCKET}/${x.attachment_path.split("/").map(encodeURIComponent).join("/")}`;
                    const dr = await fetch(delUrl, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                    if (!dr.ok && dr.status !== 404) { const tx = await dr.text(); throw new Error(tx || `Storage HTTP ${dr.status}`); }
                }
                const delUrl2 = `${SUPABASE_URL}/rest/v1/tasks?id=eq.${encodeURIComponent(x.id)}`;
                const r = await fetch(delUrl2, { method: "DELETE", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
                if (!r.ok && r.status !== 404) { const tx = await r.text(); throw new Error(tx || `HTTP ${r.status}`); }

                const di = BCH_TASKS.findIndex(t => String(t.id) === String(x.id));
                if (di >= 0) BCH_TASKS.splice(di, 1);
                localStorage.setItem("bch_tasks_cache", JSON.stringify(BCH_TASKS));
                applyBCHFilters();
                if (document.getElementById("bchDrillModal")?.classList.contains("open")) {
                    renderBCHDrill(getBCHRowsByMode(BCH_DRILL_MODE),
                        ({ all: "Tất cả nhiệm vụ BCH Đảng bộ", processing: "Nhiệm vụ BCH — Đang xử lý", done: "Nhiệm vụ BCH — Hoàn thành", overdue: "Nhiệm vụ BCH — Quá hạn" })[BCH_DRILL_MODE] || "Nhiệm vụ BCH Đảng bộ",
                        ({ all: "📋", processing: "📌", done: "✅", overdue: "⏰" })[BCH_DRILL_MODE] || "🏛️");
                }
                closeBCHTaskEdit();
                writeActivity("Xóa nhiệm vụ BCH", { task: name, owner: x.officer_name, id: x.id });
                showToast("success", "Đã xóa nhiệm vụ", `Đã xóa nhiệm vụ "${name}".`);
            } catch (e) {
                console.error(e);
                showToast("error", "Không thể xóa nhiệm vụ", e.message || "Vui lòng thử lại.", 6000);
            }
        }
    });
}

const BCH_STORAGE_BUCKET = "task-files";












let BCH_MONTH = new Date().getMonth() + 1, BCH_QUARTER = null, BCH_NODL = false, BCH_PAGE = 1, BCH_PAGE_SIZE = 20, BCH_DL_Q = "", BCH_DL_DATE = null;
function bchSyncMonthStrip() {
    try { document.querySelectorAll("#bchMonthStrip button").forEach(b => b.classList.toggle("active", (b.dataset.month && String(b.dataset.month) === String(BCH_MONTH || "")) || (b.dataset.quarter && String(b.dataset.quarter) === String(BCH_QUARTER || "")) || (b.dataset.nodl && !!BCH_NODL) ? true : false)); } catch (e) {}
}



function bchHeaderDeadlineFilter(v) { BCH_DL_Q = bchFold(v || ""); applyBCHFilters(); }
function bchHeaderDeadlineDate(v) {
    const s = String(v || "").trim();
    BCH_DL_DATE = null; BCH_DL_Q = "";
    if (!s) { applyBCHFilters(); return; }
    const d = bchDeadlineDate(s);
    if (d) BCH_DL_DATE = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    else BCH_DL_Q = bchFold(s);
    applyBCHFilters();
}
function bchPickDeadline() {
    const p = document.getElementById("bchFDeadlinePicker");
    if (!p) return;
    try { p.showPicker(); } catch (e) { p.focus(); p.click(); }
}
function bchPickerDeadline(v) {
    const t = document.getElementById("bchFDeadline");
    if (!v) { if (t) t.value = ""; BCH_DL_DATE = null; BCH_DL_Q = ""; applyBCHFilters(); return; }
    const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (t && m) t.value = `${m[3]}/${m[2]}/${m[1]}`;
    bchHeaderDeadlineDate(t ? t.value : v);
}
function bchSetPageSize(v) { BCH_PAGE_SIZE = Math.max(5, Number(v) || 20); BCH_PAGE = 1; renderBCHTable(BCH_FILTERED); }
function bchGotoPage(p) {
    const total = Math.max(1, Math.ceil((BCH_FILTERED.length || 0) / BCH_PAGE_SIZE));
    BCH_PAGE = Math.min(total, Math.max(1, Number(p) || 1));
    renderBCHTable(BCH_FILTERED);
}
function bchRemainingText(x) {
    if (bchCompletedDate(x.completed_date)) return { t: "Đã hoàn thành", cls: "done" };
    const d = bchDeadlineDate(x.deadline); if (!d) return { t: "—", cls: "" };
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - today) / 86400000);
    if (days > 0) return { t: `${days} ngày`, cls: "" };
    if (days === 0) return { t: "Hết hạn hôm nay", cls: "today" };
    return { t: `${days} ngày`, cls: "late" };
}
function renderBCHLeaderList() {
    const box = document.getElementById("bchLeaderList"); if (!box) return;
    const q = bchFold(document.getElementById("bchLeaderSearch")?.value || "");
    const counts = {};
    BCH_TASKS.forEach(x => { const n = String(x.officer_name || "Chưa phân công").trim() || "Chưa phân công"; counts[n] = (counts[n] || 0) + 1; });
    const names = [...new Set([...(BCH_OFFICERS || []).map(o => String(o.name || "").trim()).filter(Boolean), ...Object.keys(counts)])];
    const cur = document.getElementById("bchOfficerFilter")?.value || "";
    box.innerHTML = names.filter(n => !q || bchFold(n).includes(q)).map(n => {
        const c = counts[n] || 0;
        return `<div class="bch-leader-item${cur === n ? " active" : ""}" onclick="document.getElementById('bchOfficerFilter').value=${JSON.stringify(n).replace(/"/g, "&quot;")};document.getElementById('bchFLeader').value=${JSON.stringify(n).replace(/"/g, "&quot;")};applyBCHFilters();renderBCHLeaderList()"><div><div class="n">${esc(n)}</div><div class="u">${esc(((BCH_OFFICERS || []).find(o => String(o.name || "").trim() === n)?.title) || "")}</div></div><span class="cnt">${c}</span></div>`;
    }).join("") || `<div class="bch-empty">Không có cán bộ.</div>`;
}
function renderBCHTable(rows) {
    const body = document.getElementById("bchTableBody"), empty = document.getElementById("bchEmpty");
    if (!body) return;
    const total = rows.length, pages = Math.max(1, Math.ceil(total / BCH_PAGE_SIZE));
    BCH_PAGE = Math.min(pages, Math.max(1, BCH_PAGE || 1));
    const slice = rows.slice((BCH_PAGE - 1) * BCH_PAGE_SIZE, BCH_PAGE * BCH_PAGE_SIZE);
    body.innerHTML = slice.map((x, i) => {
        const idx = (BCH_PAGE - 1) * BCH_PAGE_SIZE + i + 1;
        const result = [x.product, x.result].map(v => String(v || "").trim()).find(v => v && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(bchFold(v))) || "—";
        const hasFile = !!(String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim());
        const rem = bchRemainingText(x);
        const canEdit = !CURRENT_USER || CURRENT_USER.role === "admin" || CURRENT_USER.scope === "data_entry" || (typeof canNGNEditTask === "function" && canNGNEditTask(x));
        return `<tr class="bch-task-row" onclick="openBCHTaskEdit(${x.id})">
                    <td class="c-stt">${idx}</td>
                    <td class="c-task"><div class="bch-task-text task-tip" data-full="${esc(x.task_name)}">${esc(x.task_name)}${hasFile ? " 📎" : ""}</div></td>
                    <td class="c-officer"><div class="bch-officer-name">👤 ${esc(demoMaskName(x.officer_name) || "Chưa phân công")}</div></td>
                    <td class="c-deadline"><div class="bch-deadline">${esc(bchDispDate(x.deadline))}</div></td>
                    <td class="c-remaining"><span class="bch-remaining ${rem.cls}">${esc(rem.t)}</span></td>
                    <td class="c-status"><span class="bch-badge ${x.statusKey}">${bchStatusLabel(x.statusKey)}</span></td>
                    <td class="c-actions" onclick="event.stopPropagation()">${canEdit ? `<button class="edit-btn" onclick="openBCHTaskEdit(${x.id})">Sửa</button>` : `<span class="locked-text">Xem</span>`}${CURRENT_USER && (CURRENT_USER?.role === "admin" || (typeof isNGNUser === "function" && isNGNUser(CURRENT_USER))) && x.statusKey === "overdue" ? `<button class="extend-btn compact-extend" onclick="event.stopPropagation();openHomeExtend('bch',${JSON.stringify(String(x.id))})">Gia hạn</button>` : ""}</td>
                </tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    const shown = document.getElementById("bchShownCount"); if (shown) shown.textContent = total;
    const info = document.getElementById("bchPagInfo"); if (info) info.textContent = `Tổng ${total} bản ghi`;
    const btns = document.getElementById("bchPagBtns");
    if (btns) {
        let nums = [];
        for (let p = 1; p <= pages; p++) { if (p === 1 || p === pages || Math.abs(p - BCH_PAGE) <= 1) nums.push(p); }
        btns.innerHTML = `<button onclick="bchGotoPage(${BCH_PAGE - 1})" ${BCH_PAGE <= 1 ? "disabled" : ""}>‹</button>` +
            nums.map(p => `<button class="${p === BCH_PAGE ? "active" : ""}" onclick="bchGotoPage(${p})">${p}</button>`).join("") +
            `<button onclick="bchGotoPage(${BCH_PAGE + 1})" ${BCH_PAGE >= pages ? "disabled" : ""}>›</button>`;
    }
}







// ===== V45: WORKSPACE 3 TT/BTV (clone logic BCH, tách bảng riêng) =====
// ===== V17: NHIỆM VỤ TT, BTV ĐU GIAO / public.tt_btv_officers + public.tt_btv_tasks =====
const TTBTV_OFFICERS_API = `${SUPABASE_URL}/rest/v1/tt_btv_officers?select=id,name,title,unit,note&order=id.asc`;
const TTBTV_TASKS_API = `${SUPABASE_URL}/rest/v1/tt_btv_tasks?select=id,officer_name,ubnd_leader,task_name,product,amount,ubnd_source,deadline,result,updated_at,created_at,note,phat_sinh,role,completed_date,status,staff_note,admin_note,attachment_path,attachment_name,attachment_type,attachment_size,attachment_approved,attachment_approved_at,attachment_approved_by,source_sheet,source_row,source_doc,source_group,unit_name,specialist_name&order=id.asc`;
let TTBTV_OFFICERS = [];
let TTBTV_TASKS = [];
let TTBTV_FILTERED = [];
let TTBTV_LOADED = false;
let TTBTV_MONTH = new Date().getMonth() + 1, TTBTV_PAGE = 1, TTBTV_PAGE_SIZE = 20, TTBTV_DL_Q = "", TTBTV_DL_DATE = null, TTBTV_SRC_Q = "";
























function renderTTBTVKPIs() {
    const all = (typeof ttbtvScopeRows === "function") ? ttbtvScopeRows() : TTBTV_TASKS;
    const counts = { processing: 0, done: 0, overdue: 0 };
    all.forEach(x => { const g = ttbtvStatusGroup(x.statusKey); counts[g] = (counts[g] || 0) + 1; });
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v };
    set("ttbtvOfficerCount", TTBTV_OFFICERS.filter(o => ttbtvFold(o.name) !== "vp admin").length);
    set("ttbtvTotalCount", all.length);
    set("ttbtvProcessingCount", counts.processing || 0);
    set("ttbtvDoneCount", counts.done || 0);
    set("ttbtvOverdueCount", counts.overdue || 0);
    set("ttbtvShownCount", TTBTV_FILTERED.length);
    try {
        const total = all.length || 0;
        const done = counts.done || 0, proc = counts.processing || 0, over = counts.overdue || 0;
        const pct = n => total ? Math.round(n * 100 / total) : 0;
        const g = { processing: 0, done: 0, overdue: 0 };
        TTBTV_TASKS.forEach(x => { const k = ttbtvStatusGroup(x.statusKey); g[k] = (g[k] || 0) + 1; });
        set("ttbtvSumTotal", `${TTBTV_TASKS.length} nhiệm vụ`);
        set("ttbtvSumDone", `${g.done || 0} hoàn thành`);
        set("ttbtvSumProcessing", `${g.processing || 0} đang thực hiện`);
        set("ttbtvSumOverdue", `${g.overdue || 0} quá hạn`);
        const bd = document.getElementById("ttbtvRateDoneBar"); if (bd) bd.style.width = pct(done) + "%";
        const bp = document.getElementById("ttbtvRateProcessingBar"); if (bp) bp.style.width = pct(proc) + "%";
        const bo = document.getElementById("ttbtvRateOverdueBar"); if (bo) bo.style.width = pct(over) + "%";
        set("ttbtvRateDoneCount", done); set("ttbtvRateProcessingCount", proc); set("ttbtvRateOverdueCount", over);
        set("ttbtvRateDoneLabel", `Hoàn thành ${pct(done)}% (${done}/${total})`);
        set("ttbtvRateProcessingLabel", `Chưa HT trong hạn ${pct(proc)}% (${proc}/${total})`);
        set("ttbtvRateOverdueLabel", `Chưa HT quá hạn ${pct(over)}% (${over}/${total})`);
        const today = new Date(); today.setHours(0, 0, 0, 0);
        let dueToday = 0, withFile = 0;
        all.forEach(x => {
            if (String(x.attachment_path || "").trim() || String(x.attachment_name || "").trim()) withFile++;
            const d = ttbtvDeadlineDate(x.deadline);
            if (d && !ttbtvCompletedDate(x.completed_date)) {
                const dd = new Date(d.getFullYear(), d.getMonth(), d.getDate());
                if (dd.getTime() === today.getTime()) dueToday++;
            }
        });
        set("ttbtvDueTodayCount", dueToday);
        set("ttbtvFileCount", withFile);
        if (typeof renderTTBTVLeaderList === "function") renderTTBTVLeaderList();
        try { document.querySelectorAll("#ttbtvMonthStrip button").forEach(b => b.classList.toggle("active", String(b.dataset.month || "") === String(TTBTV_MONTH || ""))); } catch (e2) {}
    } catch (e) {}
}

const TTBTV_CHARTS = {};

function renderTTBTVCharts() {
    if (!TTBTV_TASKS.length) {
        ["ttbtvChart1", "ttbtvChart2", "ttbtvChart3", "ttbtvChart4"].forEach(id => { if (TTBTV_CHARTS[id]) { TTBTV_CHARTS[id].destroy(); delete TTBTV_CHARTS[id]; } });
        return;
    }
    const rows = TTBTV_FILTERED.length || ["all"].includes(document.getElementById("ttbtvStatusFilter")?.value || "all") ? TTBTV_FILTERED : TTBTV_TASKS;
    const useRows = (document.getElementById("ttbtvSearch")?.value || document.getElementById("ttbtvOfficerFilter")?.value || (document.getElementById("ttbtvStatusFilter")?.value || "all") !== "all") ? TTBTV_FILTERED : TTBTV_TASKS;

    // 1. Status
    const sm = { processing: 0, done: 0, overdue: 0, regular: 0 }; useRows.forEach(x => { const g = ttbtvStatusGroup(ttbtvStatusFor(x)); sm[g] = (sm[g] || 0) + 1; });
    const sk = ["processing", "done", "overdue", "regular"].filter(k => sm[k]);
    ttbtvRenderChart("ttbtvChart1", sk.map(ttbtvStatusLabel), sk.map(k => sm[k]), sk.map(k => ({ processing: "#56B4E9", done: "#009E73", overdue: "#D55E00", regular: "#a855f7" })[k]), "ttbtvLegend1", "status");

    // 2. Officer title
    const om = ttbtvOfficerMap(), tm = {};
    useRows.forEach(x => { const title = (x.role || x.unit_name) || "Chưa rõ cơ quan chủ trì"; tm[title] = (tm[title] || 0) + 1 });
    const titles = Object.entries(tm).sort((a, b) => b[1] - a[1]);
    const palette = ["#8b5cf6", "#3b82f6", "#009E73", "#f59e0b", "#ec4899", "#56B4E9", "#64748b", "#0ea5e9", "#D55E00", "#14b8a6", "#a855f7", "#eab308"].slice(0, titles.length);
    ttbtvRenderChart("ttbtvChart2", titles.map(x => x[0]), titles.map(x => x[1]), palette, "ttbtvLegend2", "title");

    // 3. Deadline
    const dm = { overdue: 0, soon7: 0, done: 0 };
    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    useRows.forEach(x => {
        const g = ttbtvStatusGroup(ttbtvStatusFor(x));
        if (g === "done") { dm.done++; return }
        if (g === "regular") return;
        const due = ttbtvDeadlineDate(x.deadline);
        if (!due) { dm.none++; return }
        const days = Math.round((due - today) / 86400000);
        if (days < 0) dm.overdue++; else if (days <= 3) dm.soon++; else dm.safe++;
    });
    const dk = ["overdue", "soon", "safe", "done", "none"].filter(k => dm[k]);
    const dn = { overdue: "Quá hạn", soon: "≤ 3 ngày", safe: "Còn hạn", done: "Hoàn thành", none: "Chưa rõ hạn" };
    const dc = { overdue: "#D55E00", soon: "#f59e0b", safe: "#009E73", done: "#3b82f6", none: "#94a3b8" };
    ttbtvRenderChart("ttbtvChart3", dk.map(k => dn[k]), dk.map(k => dm[k]), dk.map(k => dc[k]), "ttbtvLegend3", "deadline");

    // 4. Number of tasks by officer (Top 8)
    const cm = {}; useRows.forEach(x => cm[x.officer_name || "Chưa phân công"] = (cm[x.officer_name || "Chưa phân công"] || 0) + 1);
    const top = Object.entries(cm).sort((a, b) => b[1] - a[1]).slice(0, 8);
    ttbtvRenderChart("ttbtvChart4", top.map(x => x[0]), top.map(x => x[1]), ["#2563eb", "#56B4E9", "#8b5cf6", "#009E73", "#f59e0b", "#ec4899", "#64748b", "#0ea5e9"].slice(0, top.length), "ttbtvLegend4", "officer");
    renderWorkspacePerformance("ttbtvPerformanceChart", "ttbtvPerformanceLegend", useRows, x => x.officer_name || x.owner, x => ttbtvStatusGroup(ttbtvStatusFor(x)), TTBTV_CHARTS, (owner, statusKey) => { let rows = useRows.filter(x => String(x.officer_name || x.owner || "") === String(owner)); if (statusKey) rows = rows.filter(x => ttbtvStatusGroup(ttbtvStatusFor(x)) === statusKey); const labelMap = { done: "Hoàn thành", processing: "Đang triển khai", overdue: "Quá hạn", regular: "Thường xuyên" }; const suffix = statusKey ? ` · ${labelMap[statusKey] || statusKey}` : ""; renderTTBTVDrill(rows, `Hiệu suất nhiệm vụ - ${owner}${suffix}`, "📊"); });
}
function drillTTBTVChart(kind, label) {
    if (kind === "status") {
        const key = label === "Hoàn thành" ? "done" : label === "Quá hạn" ? "overdue" : label === "Thường xuyên" ? "regular" : "processing";
        openTTBTVStatusPopup(key); return;
    }
    if (kind === "officer") {
        const o = document.getElementById("ttbtvOfficerFilter"); if (o) o.value = label; applyTTBTVFilters(); return;
    }
    if (kind === "title") {
        const om = ttbtvOfficerMap();
        TTBTV_FILTERED = TTBTV_TASKS.filter(x => ((x.role || x.unit_name) || "Chưa rõ cơ quan chủ trì") === label);
        renderTTBTVTable(TTBTV_FILTERED); return;
    }
    if (kind === "deadline") {
        const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        TTBTV_FILTERED = TTBTV_TASKS.filter(x => {
            const st = ttbtvStatusFor(x), due = ttbtvDeadlineDate(x.deadline);
            if (label === "Hoàn thành") return ttbtvStatusGroup(st) === "done";
            if (label === "Chưa rõ hạn") return ttbtvStatusGroup(st) !== "done" && !due;
            if (!due || ttbtvStatusGroup(st) === "done") return false;
            const days = Math.round((due - today) / 86400000);
            if (label === "Quá hạn") return days < 0;
            if (label === "≤ 3 ngày") return days >= 0 && days <= 3;
            return days > 3;
        });
        renderTTBTVTable(TTBTV_FILTERED); return;
    }
}




let TTBTV_EDIT_ID = null;
let TTBTV_DRILL_MODE = "all";








let TTBTV_DRILL_STATE = { ids: [], title: "Nhiệm vụ TT, BTV ĐU giao", icon: "🏛️" };



function resetTTBTVDrillFilters() {
    ["ttbtvDrillRoleFilter", "ttbtvDrillOfficerFilter", "ttbtvDrillSearch"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
    onTTBTVDrillFilterChange();
}

// ===== V49: THÊM NHIỆM VỤ TRỰC TIẾP VÀO public.tt_btv_tasks =====
function renderTTBTVAddTaskRow() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || CURRENT_USER.role === "department" || CURRENT_USER.scope === "action100" || !!CURRENT_USER.isNGN || (CURRENT_USER.role === "staff" && ["ttbtv", "data_entry"].includes(CURRENT_USER.scope)))) return "";
    return `<tr id="ttbtvAddTaskRow" class="add-task-row"><td colspan="9">
                <div class="add-task-shell">
                  <div class="add-task-title"><span>➕ Thêm nhiệm vụ TT/BTV</span><span style="font-size:11.8px;color:#64748b;font-weight:600">Ghi trực tiếp vào tt_btv_tasks</span></div>
                  <div class="add-task-grid">
                     <div class="field"><label>Lãnh đạo phụ trách</label><select id="ttbtvAddOfficer" onchange="ttbtvHandleOfficerOther(this)">${[...new Set(TTBTV_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))].map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("")}<option value="__other__">Khác (Nhập tên)</option></select></div>
                    <div class="field span2"><label>Nhiệm vụ</label><textarea id="ttbtvAddTaskName" placeholder="Nhập nội dung nhiệm vụ..."></textarea></div>
                     <div class="field"><label>Cơ quan chủ trì</label><select id="ttbtvAddRole" onchange="ttbtvHandleRoleOther(this)"><option value="">Chọn cơ quan</option>${["Văn phòng Đảng uỷ", "Ban Xây dựng Đảng", "UBKT Đảng uỷ", "MTTQ", "HĐND xã", "Ban Kinh tế", "Ban văn hoá", "UBND xã", "Văn phòng HĐND&UBND", "Phòng Kinh tế, hạ tầng", "Phòng Văn hoá - xã hội", "Phòng Nông nghiệp và Môi trường", "Trung tâm PV HCC", "Trung tâm DVTH", "Ban QLDA đầu tư XD", "Công an xã", "Quân sự xã"].map(r => `<option value="${esc(r)}">${esc(r)}</option>`).join("")}<option value="__other__">Khác (Nhập tên)</option></select></div>
                    <div class="field"><label>Chuyên viên phụ trách</label><input id="ttbtvAddSpecialist" placeholder="Nhập chuyên viên phụ trách"></div>
                     <div class="field"><label>Nguồn giao <span style="color:#dc2626">*</span></label><select id="ttbtvAddSource" onchange="ttbtvHandleSourceOther(this)">${(() => { const list=getTTBTVSourceList(); const opts=['<option value="">Chọn nguồn giao</option>'].concat(list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`)); opts.push('<option value="__other__">Khác (nhập văn bản)</option>'); return opts.join(''); })()}</select></div>
                      <div class="field"><label>Nguồn giao của UBND <span style="color:#dc2626">*</span></label><input id="ttbtvAddUBNDSource" value="Chưa rõ"></div>
                    <div class="field"><label>Hạn hoàn thành <span style="color:#dc2626">*</span></label><input id="ttbtvAddDeadline" type="date" required class="date-ddmmyyyy" oninput="refreshTTBTVAddStatus()" lang="vi"></div>
                    <div class="field"><label>Ngày hoàn thành</label><input id="ttbtvAddCompleted" type="date" class="date-ddmmyyyy" oninput="refreshTTBTVAddStatus()" lang="vi"></div>
                     <div class="field"><label>Trạng thái <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="ttbtvAddStatus" class="auto-status-field" value="Đang triển khai" readonly></div>
                     ${CURRENT_USER?.role==="admin" ? `<div class="field"><label>🔁 Thường xuyên</label><label style="display:flex;align-items:center;gap:8px;font-weight:600"><input type="checkbox" id="ttbtvAddRegular" onchange="refreshTTBTVAddStatus()"> Thường xuyên (bỏ qua hạn/ngày)</label></div>` : ``}
                     <div class="field span2"><label>Kết quả thực hiện</label><textarea id="ttbtvAddResult" placeholder="Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp..." oninput="refreshTTBTVAddStatus()"></textarea></div>
                    <div class="field"><label>Tệp kết quả</label><input id="ttbtvAddAttachment" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx" onchange="refreshTTBTVAddStatus()"></div>
                    <div class="field span3"><label>👤 Ghi chú cán bộ</label><textarea id="ttbtvAddStaffNote" placeholder="Ghi chú bổ sung (nếu có)"></textarea></div>
                    <div class="field add-task-actions"><button id="ttbtvAddBtn" class="add-task-btn" type="button" onclick="stageNewTTBTVTask()">＋ Thêm nhiệm vụ</button></div>
                  </div>
                  <div class="add-task-help">Nhiệm vụ được lưu thẳng lên Supabase. Trạng thái tự tính theo Hạn hoàn thành + Ngày hoàn thành + Kết quả/tệp.</div>
                </div>
            </td></tr>`;
}







let PENDING_TTBTV_TASK = null;




function renderTTBTVDrill(rows, title, icon, openModal = true) {
    if (openModal) { TTBTV_DRILL_STATE = { ids: rows.map(x => String(x.id)), title: title || "Nhiệm vụ TT, BTV ĐU giao", icon: icon || "🏛️" }; const sel = document.getElementById("ttbtvDrillOrder"); if (sel) sel.value = "newest"; }
    const _isPerfPopup = String(title || TTBTV_DRILL_STATE.title || "").includes("Hiệu suất nhiệm vụ -");
    const _roleSel = document.getElementById("ttbtvDrillRoleFilter"), _offSel = document.getElementById("ttbtvDrillOfficerFilter");
    if (_roleSel) { _roleSel.style.display = _isPerfPopup ? "none" : ""; if (_isPerfPopup) _roleSel.value = ""; }
    if (_offSel) { _offSel.style.display = _isPerfPopup ? "none" : ""; if (_isPerfPopup) _offSel.value = ""; }
    TTBTVDrillPopulateFilters();
    const roleF = document.getElementById("ttbtvDrillRoleFilter")?.value || "";
    const offF = document.getElementById("ttbtvDrillOfficerFilter")?.value || "";
    const q = ttbtvFold(document.getElementById("ttbtvDrillSearch")?.value || "");
    if (roleF || offF || q) rows = rows.filter(x => {
        const roleMatch = !roleF || (x.role || x.unit_name || "Chưa rõ cơ quan chủ trì") === roleF;
        const offMatch = !offF || x.officer_name === offF;
        const qMatch = !q || ttbtvFold([x.officer_name, x.task_name, x.role, x.unit_name, x.specialist_name, x.product, x.amount, x.source_doc, x.note, x.result, x.staff_note, x.admin_note].join(" ")).includes(q);
        return roleMatch && offMatch && qMatch;
    });
    rows = applyTTBTVDrillOrder(rows);
    const body = document.getElementById("ttbtvDrillBody"), empty = document.getElementById("ttbtvDrillEmpty");
    const omap = ttbtvOfficerMap();
    document.getElementById("ttbtvDrillTitle").textContent = `${icon || "🏛️"} ${title || "Nhiệm vụ TT, BTV ĐU giao"}`;
    document.getElementById("ttbtvDrillCount").textContent = rows.length;
    body.innerHTML = rows.map((x, i) => {
        const o = omap.get(ttbtvFold(x.officer_name)) || {};
        const can = ttbtvCanEdit(x);
        const rem = ttbtvRemainingText(x);
        return `<tr class="bch-drill-row" onclick="openTTBTVTaskEdit(${x.id})">
                  <td>${i + 1}</td>
                  <td>${esc(x.task_name || "—")}</td>
                  <td><b>${esc(x.officer_name || "—")}</b></td>
                  <td>${esc(x.role || x.unit_name || "—")}</td>
                  <td>${esc(ttbtvDateDisplay(x.deadline, "—"))}</td>
                  <td><span class="bch-remaining ${rem.cls}">${esc(rem.t)}</span></td>
                  <td><span class="bch-badge ${x.statusKey}">${ttbtvStatusLabel(x.statusKey)}</span></td>
                  <td>${esc(x.product || "—")}</td>
                  <td><div class="task-tip ttbtv-drill-result-text" data-full="${esc(x.staff_note || x.result || "Chưa có")}">${esc(x.staff_note || x.result || "Chưa có")}</div></td>
                  <td>${can ? `<button class="edit-btn" onclick="event.stopPropagation();openTTBTVTaskEdit(${x.id})">✏️ Sửa</button>` : `<span class="locked-text">🔒 Xem</span>`}</td>
                </tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    appendTTBTVAddTaskRow();
    if (typeof setupTTBTVDateFields === 'function') setupTTBTVDateFields();
    if (openModal) smoothOpenModal("ttbtvDrillModal");
}

function closeTTBTVDrill() { smoothCloseModal("ttbtvDrillModal"); }









function renderTTBTVCurrentAttachment(x) {
    const el = document.getElementById("ttbtvCurrentAttachment"); if (!el) return;
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        el.innerHTML = '<span class="admin-note-empty">Chưa có tệp đính kèm</span>'; return;
    }
    const approved = x.attachment_approved === true;
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        el.innerHTML = approved
            ? '<span class="approval-pill approved">✅ Tệp đã được Admin phê duyệt</span>'
            : '<span class="approval-pill pending">⏳ Tệp đã gửi · đang chờ Admin phê duyệt</span>';
        return;
    }
    el.innerHTML = `<span class="file-pill">📄 ${esc(x.attachment_name || "Tệp sản phẩm")}</span>
                ${approved ? '<span class="approval-pill approved">✅ Đã duyệt</span>' : '<span class="approval-pill pending">⏳ Chờ duyệt</span>'}
                ${x.attachment_path ? `<button type="button" class="file-link-btn" onclick="openTTBTVAttachment(${x.id},true)">👁 Xem tệp</button>` : `<span class="admin-note-empty">Chỉ lưu tên file</span>`}
                ${!approved ? `<button type="button" class="approve-file-btn" onclick="approveTTBTVAttachment(${x.id})">✓ Phê duyệt</button>` : ""}
                <button type="button" class="file-delete-btn" onclick="deleteTTBTVAttachment(${x.id})">🗑 Xóa tệp</button>`;
}






const TTBTV_STORAGE_BUCKET = "tt-btv-files";































const TTBTV_AGENCY_TREE = [
    { name: "Văn phòng Đảng uỷ" },
    { name: "Ban Xây dựng Đảng" },
    { name: "UBKT Đảng uỷ" },
    { name: "MTTQ" },
    { name: "HĐND xã", children: ["Ban Kinh tế", "Ban văn hoá"] },
    { name: "UBND xã", children: ["Văn phòng HĐND&UBND", "Phòng Kinh tế, hạ tầng", "Phòng Văn hoá - xã hội", "Phòng Nông nghiệp và Môi trường", "Trung tâm PV HCC", "Trung tâm DVTH", "Ban QLDA đầu tư XD"] },
    { name: "Công an xã" },
    { name: "Quân sự xã" },
    { name: "Chưa rõ cơ quan chủ trì", label: "Chưa rõ cơ quan" }
];

function renderTTBTVLeaderList() {
    const box = document.getElementById("ttbtvLeaderList"); if (!box) return;
    const q = ttbtvFold(document.getElementById("ttbtvLeaderSearch")?.value || "");
    const counts = {};
    const canon = {};
    TTBTV_AGENCY_TREE.forEach(t => { canon[ttbtvFold(t.name)] = t.name; (t.children || []).forEach(c => { canon[ttbtvFold(c)] = c; }); });
    TTBTV_TASKS.forEach(x => {
        const raw = String(x.role || x.unit_name || "").trim();
        const key = raw ? (canon[ttbtvFold(raw)] || raw) : "Chưa rõ cơ quan chủ trì";
        counts[key] = (counts[key] || 0) + 1;
    });
    const cur = document.getElementById("ttbtvAgencyFilter")?.value || "";
    const match = n => !q || ttbtvFold(n).includes(q);
    const getDisplayCount = (name) => {
        const entry = TTBTV_AGENCY_TREE.find(t => ttbtvFold(t.name) === ttbtvFold(name));
        if (entry && entry.children && entry.children.length) {
            let sum = 0; entry.children.forEach(ch => { sum += counts[ch] || 0; });
            // Tổng của nhóm = tổng các cơ quan con (nếu có nhiệm vụ trực tiếp mang tên nhóm thì cộng thêm)
            if (counts[name]) sum += counts[name];
            return sum;
        }
        return counts[name] || 0;
    };
    const row = (n, cls, label) => {
        const c = getDisplayCount(n);
        const isUBND = ttbtvFold(n) === "ubnd xa";
        const extra = isUBND ? " ubnd" : "";
        return `<div class="bch-leader-item${cls ? " " + cls : ""}${extra}${cur === n ? " active" : ""}" onclick="ttbtvPickAgency(${JSON.stringify(n).replace(/"/g, "&quot;")})"><div><div class="n">${esc(label || n)}</div></div><span class="cnt">${c}</span></div>`;
    };
    const known = new Set();
    TTBTV_AGENCY_TREE.forEach(t => { known.add(t.name); (t.children || []).forEach(c => known.add(c)); });
    let html = "";
    TTBTV_AGENCY_TREE.forEach(t => {
        const kids = (t.children || []).filter(c => match(t.name) || match(c));
        if (!match(t.name) && !kids.length) return;
        html += row(t.name, (t.children || []).length ? "group" : "", t.label);
        kids.forEach(c => { html += row(c, "sub"); });
    });
    Object.keys(counts).filter(n => !known.has(n) && match(n)).sort((a, b) => a.localeCompare(b, "vi")).forEach(n => { html += row(n, ""); });
    box.innerHTML = html || `<div class="bch-empty">Không có cơ quan.</div>`;
}
function renderTTBTVTable(rows) {
    const body = document.getElementById("ttbtvTableBody"), empty = document.getElementById("ttbtvEmpty");
    if (!body) return;
    const groups = new Map();
    rows.forEach(x => { const key = String(x.amount || x.source_doc || x.ubnd_source || "Chưa có nguồn giao").trim(); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(x); });
    const sortedGroups = [...groups.entries()].sort((a,b)=>{ const da=ttbtvDocDate(a[0]), db=ttbtvDocDate(b[0]); if(da&&db) return da-db; if(da&&!db) return -1; if(!da&&db) return 1; return String(a[0]).localeCompare(String(b[0]),'vi'); });
    let stt = 0;
    body.innerHTML = sortedGroups.map(([source, items]) => {
        const gid = `ttbtv-source-${++stt}`;
        const departments = [...new Set(items.map(x => x.role || x.unit_name).filter(Boolean))].join(", ") || "Chưa rõ";
        const leaders = [...new Set(items.map(x => ttbtvTaskLeader(x)).filter(v => v && v !== "—"))].join(", ") || "—";
        const statusCounts = { done: 0, processing: 0, overdue: 0, regular: 0 };
        items.forEach(x => { const key = ttbtvStatusGroup(x.statusKey || ttbtvStatusFor(x)); if (statusCounts[key] !== undefined) statusCounts[key]++; });
        const statusSummary = `<div class="ttbtv-status-summary">${[
            ["done", "Hoàn thành", statusCounts.done],
            ["processing", "Đang triển khai", statusCounts.processing],
            ["overdue", "Quá hạn", statusCounts.overdue],
            ["regular", "Thường xuyên", statusCounts.regular]
        ].filter(([, , n]) => n > 0).map(([cls, label, n]) => `<span class="${cls}">${label} (${n})</span>`).join("")}</div>`;
        const detail = items.map((x, i) => {
            const result = ttbtvFold(x.result) && !["chua dien", "chua cap nhat", "khong", "---", "--", "-", "null"].includes(ttbtvFold(x.result)) ? x.result : "Chưa điền";
            const taskTitle = `${i + 1}. ${x.task_name || "Chưa nhập nhiệm vụ"}`;
            return `<div class="ttbtv-source-task" onclick="openTTBTVTaskEdit(${x.id})"><div class="ttbtv-task-main"><b class="ttbtv-task-title task-tip" data-full="${esc(demoMaskText(taskTitle))}">${esc(demoMaskText(taskTitle))}</b><span class="bch-badge ${x.statusKey}">${ttbtvStatusLabel(x.statusKey)}</span></div><div class="ttbtv-task-meta"><span>🏢 ${esc(x.role || x.unit_name || "Chưa rõ cơ quan chủ trì")}</span><span>👤 ${esc(demoMaskName(x.officer_name) || "Chưa phân công")}</span><span>🏛️ UBND: ${esc(demoMaskName(x.ubnd_leader) || "—")}</span><span>📅 Hạn: ${esc(ttbtvDateDisplay(x.deadline, "Chưa có"))}</span><span>✅ HT: ${esc(ttbtvDateDisplay(x.completed_date, "Chưa nhập"))}</span><span>📦 ${esc(demoMaskText(result))}</span></div></div>`;
        }).join("");
        return `<tr class="ttbtv-source-row" onclick="if(!event.target.closest('button'))ttbtvToggleSourceGroup('${gid}',this.querySelector('.ttbtv-source-toggle'))"><td class="c-stt">${stt}</td><td class="c-amount"><b>${esc(demoMaskText(source))}</b>${items[0]?.ubnd_source ? `<small class="ttbtv-ubnd-source">UBND: ${esc(demoMaskText(items[0].ubnd_source))}</small>` : ""}</td><td class="c-task"><button class="ttbtv-source-toggle" aria-label="Mở rộng" onclick="event.stopPropagation();ttbtvToggleSourceGroup('${gid}',this)"><svg class="ttbtv-icon-plus" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></button><b>${items.length} nhiệm vụ</b>${statusSummary}</td><td class="c-officer">${esc(demoMaskText(leaders))}</td><td class="c-title">${esc(departments)}</td></tr><tr id="${gid}" class="ttbtv-source-detail" style="display:none"><td colspan="5"><div class="ttbtv-source-task-list">${detail}</div></td></tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    const shown = document.getElementById("ttbtvShownCount"); if (shown) shown.textContent = rows.length;
}









// ===== V50: WORKSPACE NHIỆM VỤ TỈNH GIAO =====
// ===== V45: WORKSPACE 3 Tỉnh giao (clone logic BCH, tách bảng riêng) =====
// ===== V17: NHIỆM VỤ TT, BTV ĐU GIAO / public.province_officers + public.province_tasks =====
const PROV_OFFICERS_API = `${SUPABASE_URL}/rest/v1/province_officers?select=id,name,title,unit,note&order=id.asc`;
const PROV_TASKS_API = `${SUPABASE_URL}/rest/v1/province_tasks?select=id,officer_name,task_name,product,amount,deadline,result,updated_at,created_at,note,phat_sinh,role,completed_date,status,staff_note,admin_note,attachment_path,attachment_name,attachment_type,attachment_size,attachment_approved,attachment_approved_at,attachment_approved_by,source_sheet,source_row,source_doc,source_group,unit_name,specialist_name,source_form,issuing_authority,implementation_detail,overdue_reason,source_status,progress,van_ban_tinh,van_ban_xa&order=id.asc`;
let PROV_OFFICERS = [];
let PROV_TASKS = [];
let PROV_FILTERED = [];
let PROV_LOADED = false;
let PROV_MONTH = null;





















function getProvinceTreeStats() {
    // Bỏ cây thư mục: KPI/chart luôn tính từ bảng province_tasks
    return null;
}
function renderPROVKPIs() {
    const treeStats = getProvinceTreeStats();
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v };
    // Dùng chung cho KPI cũ và mới (đẹp như TT/BTV) — progress & rate phải khớp bộ lọc + tháng
    let total = 0, done = 0, processing = 0, overdue = 0, shown = 0, officerCount = 0;
    let allForRate = null;
    // Lấy scope đã lọc (PROV_FILTERED) để khớp 100% với bảng và chart
    const filtered = Array.isArray(PROV_FILTERED) ? PROV_FILTERED : (treeStats ? (getPROVTreeRows(null)||[]) : PROV_TASKS);
    // Tính cho progress card (phải khớp bộ lọc)
    {
        const fc = { processing:0, done:0, overdue:0 };
        filtered.forEach(x=>{ const k=provinceStatusGroup(x.statusKey || provinceStatusFor(x)); fc[k]=(fc[k]||0)+1; });
        if (treeStats) {
            set("provinceOfficerCount", treeStats.officerCount);
            set("provinceShownCount", filtered.length);
            // officerCount giữ nguyên, còn lại lấy từ filtered để khớp lọc
            total = filtered.length; done = fc.done; processing = fc.processing; overdue = fc.overdue; shown = filtered.length; officerCount = treeStats.officerCount;
            set("provinceTotalCount", total);
            set("provinceProcessingCount", processing);
            set("provinceDoneCount", done);
            set("provinceOverdueCount", overdue);
        } else {
            set("provinceOfficerCount", PROV_OFFICERS.filter(o => provinceFold(o.name) !== "vp admin").length);
            set("provinceShownCount", filtered.length);
            total = filtered.length; done = fc.done; processing = fc.processing; overdue = fc.overdue; shown = filtered.length; officerCount = PROV_OFFICERS.filter(o => provinceFold(o.name) !== "vp admin").length;
            set("provinceTotalCount", total);
            set("provinceProcessingCount", processing);
            set("provinceDoneCount", done);
            set("provinceOverdueCount", overdue);
        }
        allForRate = filtered;
    }
    // KPI đẹp như TT/BTV: summary pills + rate bars + progress
    try {
        // Summary pills: luôn tổng toàn workspace (không lọc tháng) như BCH/TTBTV
        const gAll = { processing: 0, done: 0, overdue: 0 };
        const srcForSum = treeStats ? (getPROVTreeRows(null) || PROV_TASKS) : PROV_TASKS;
        srcForSum.forEach(x => { const k = provinceStatusGroup(x.statusKey || provinceStatusFor(x)); gAll[k]=(gAll[k]||0)+1; });
        set("provinceSumTotal", `${srcForSum.length} nhiệm vụ`);
        set("provinceSumDone", `${gAll.done||0} hoàn thành`);
        set("provinceSumProcessing", `${gAll.processing||0} đang thực hiện`);
        set("provinceSumOverdue", `${gAll.overdue||0} quá hạn`);
        // Rate bars: theo phạm vi đã lọc (allForRate) hoặc treeStats scope
        let rateRows = allForRate;
        if (!rateRows) rateRows = treeStats ? (getPROVTreeRows(null)||PROV_TASKS) : PROV_TASKS;
        // nếu đang lọc tháng, rateRows đã lọc; nếu không, dùng rateRows như trên
        // Tính lại counts cho rateRows nếu cần
        let rcDone=done, rcProc=processing, rcOver=overdue;
        if (PROV_MONTH && rateRows !== null) {
            const rc = { processing:0, done:0, overdue:0 };
            rateRows.forEach(x=>{ const k=provinceStatusGroup(x.statusKey||provinceStatusFor(x)); rc[k]=(rc[k]||0)+1; });
            rcDone=rc.done; rcProc=rc.processing; rcOver=rc.overdue;
            total = rateRows.length;
        }
        const pct = n => total ? Math.round(n*100/total) : 0;
        const bd=document.getElementById("provinceRateDoneBar"); if(bd) bd.style.width=pct(rcDone)+"%";
        const bp=document.getElementById("provinceRateProcessingBar"); if(bp) bp.style.width=pct(rcProc)+"%";
        const bo=document.getElementById("provinceRateOverdueBar"); if(bo) bo.style.width=pct(rcOver)+"%";
        set("provinceRateDoneCount", rcDone); set("provinceRateProcessingCount", rcProc); set("provinceRateOverdueCount", rcOver);
        set("provinceRateDoneLabel", `Hoàn thành ${pct(rcDone)}% (${rcDone}/${total})`);
        set("provinceRateProcessingLabel", `Chưa HT trong hạn ${pct(rcProc)}% (${rcProc}/${total})`);
        set("provinceRateOverdueLabel", `Chưa HT quá hạn ${pct(rcOver)}% (${rcOver}/${total})`);
        // Due today & file count
        const today=new Date(); today.setHours(0,0,0,0);
        let dueToday=0, withFile=0;
        const srcForExtra = rateRows || srcForSum;
        srcForExtra.forEach(x=>{
            if(String(x.attachment_path||"").trim()||String(x.attachment_name||"").trim()) withFile++;
            const d=provinceDeadlineDate(x.deadline);
            if(d && !provinceCompletedDate(x.completed_date)){
                const dd=new Date(d.getFullYear(), d.getMonth(), d.getDate());
                if(dd.getTime()===today.getTime()) dueToday++;
            }
        });
        set("provinceDueTodayCount", dueToday);
        set("provinceFileCount", withFile);
        // Cập nhật active tháng
        try{ document.querySelectorAll("#provinceMonthStrip button").forEach(b=> b.classList.toggle("active", String(b.dataset.month||"")===String(PROV_MONTH||""))); }catch(e2){}
    } catch(e) {}
}


const PROV_CHARTS = {};

function renderPROVCharts() {
    let treeBase = null;
    try { treeBase = getPROVTreeRows(null); } catch (e) {}
    const base = (treeBase && treeBase.length) ? treeBase : PROV_TASKS;
    if (!base.length) {
        ["provinceChart1", "provinceChart2", "provinceChart3", "provinceChart4"].forEach(id => { if (PROV_CHARTS[id]) { PROV_CHARTS[id].destroy(); delete PROV_CHARTS[id]; } });
        return;
    }
    const timeFilterActive = (document.getElementById("provinceTimeFilter")?.value || "all") !== "all";
    const rows = (PROV_FILTERED.length || timeFilterActive || (typeof PROV_MONTH!=="undefined" && PROV_MONTH) || ["all"].includes(document.getElementById("provinceStatusFilter")?.value || "all")) ? PROV_FILTERED : base;
    const useRows = (document.getElementById("provinceSearch")?.value || document.getElementById("provinceOfficerFilter")?.value || (document.getElementById("provinceStatusFilter")?.value || "all") !== "all" || timeFilterActive || (typeof PROV_MONTH!=="undefined" && PROV_MONTH)) ? PROV_FILTERED : base;

    // 1. Status
    const sm = { processing: 0, done: 0, overdue: 0 }; useRows.forEach(x => { const g = provinceStatusGroup(provinceStatusFor(x)); sm[g] = (sm[g] || 0) + 1; });
    const sk = ["processing", "done", "overdue"].filter(k => sm[k]);
    provinceRenderChart("provinceChart1", sk.map(provinceStatusLabel), sk.map(k => sm[k]), sk.map(k => ({ processing: "#56B4E9", done: "#009E73", overdue: "#D55E00" })[k]), "provinceLegend1", "status");

    // 2. Theo văn bản có số lượng nhiệm vụ con.
    const tm = {};
    const isFiltered = useRows !== base;
    const tree2 = document.getElementById('provincePlanTree');
    if (tree2 && tree2.children.length && !isFiltered) {
        [...tree2.querySelectorAll('.pp-task')].forEach(t => {
            if (t.style.display === 'none') return;
            const docs = [...t.querySelectorAll('.pp-docs-tinh div[contenteditable], .pp-docs-xa div[contenteditable]')].map(d=>String(d.textContent||d.innerText||'').trim()).filter(Boolean);
            const cnt = t.querySelectorAll('.pp-agency').length || 1;
            if(!docs.length){
                tm['Không có văn bản'] = (tm['Không có văn bản']||0)+cnt;
            } else {
                const keys = docs.map(d=>{ try{ return (typeof ppShortDoc==='function'?ppShortDoc(d):d.slice(0,40)).trim()||d.slice(0,40);}catch(e){return d.slice(0,40);} }).filter(Boolean);
                const uniq=[...new Set(keys)];
                uniq.forEach(k=>{ tm[k]=(tm[k]||0)+cnt; });
            }
        });
    } else {
        useRows.forEach(x => {
            const isTreeRow = !!x._isTree;
            const rawDocs=isTreeRow ? [...String(x.source_doc||'').split('\n'), ...String(x.source_group||'').split('\n')].map(s=>s.trim()).filter(Boolean) : [...String(x.van_ban_tinh||'').split('\n'), ...String(x.van_ban_xa||'').split('\n')].map(s=>s.trim()).filter(Boolean);
            const cnt = isTreeRow ? ((x._taskEl ? x._taskEl.querySelectorAll('.pp-agency').length : 0) || 1) : ((x.blocks && Array.isArray(x.blocks.agencies) ? x.blocks.agencies.length : (x.agencies?x.agencies.length:1))||1);
            if(!rawDocs.length){ tm['Không có văn bản']=(tm['Không có văn bản']||0)+cnt; }
            else {
                const keys=rawDocs.map(d=>{ try{return (typeof ppShortDoc==='function'?ppShortDoc(d):d.slice(0,40)).trim()||d.slice(0,40);}catch(e){return d.slice(0,40);} }).filter(Boolean);
                const uniq=[...new Set(keys)];
                uniq.forEach(k=>{ tm[k]=(tm[k]||0)+cnt; });
            }
        });
    }
    const titles = Object.entries(tm).sort((a, b) => b[1] - a[1]).slice(0, 7);
    const palette = ["#8b5cf6", "#3b82f6", "#009E73", "#f59e0b", "#ec4899", "#56B4E9", "#64748b"];
    provinceRenderChart("provinceChart2", titles.map(x => x[0]), titles.map(x => x[1]), palette.slice(0, titles.length), "provinceLegend2", "document");

    // 3. Deadline — đếm theo từng người trong cây thư mục để khớp dữ liệu cây (khi không lọc thì dùng DOM, khi lọc thì dùng useRows)
    const dm = { overdue: 0, soon: 0, safe: 0, none: 0, done: 0 };
    const isFilteredDeadline = useRows !== base;
    let deadlineCats = [];
    if (!isFilteredDeadline) { try { deadlineCats = buildPROVDeadlineCategories(); } catch (e) {} }
    if (deadlineCats.length) {
        deadlineCats.forEach(x => { if (x.category === 'overdue' || x.category === 'soon7' || x.category === 'done') dm[x.category]++; });
    } else {
        const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        useRows.forEach(x => {
            if (provinceStatusGroup(provinceStatusFor(x)) === "done") { dm.done++; return }
            const due = provinceDeadlineDate(x.deadline);
            if (!due) return;
            const days = Math.round((due - today) / 86400000);
            if (days < 0) dm.overdue++; else if (days <= 7) dm.soon7++;
        });
    }
    const dk = ["overdue", "soon7", "done"];
    const dn = { overdue: "Quá hạn", soon7: "Sắp đến hạn trong 7 ngày", done: "Hoàn thành" };
    const dc = { overdue: "#D55E00", soon7: "#f59e0b", done: "#3b82f6" };
    provinceRenderChart("provinceChart3", dk.map(k => dn[k]), dk.map(k => dm[k]), dk.map(k => dc[k]), "provinceLegend3", "deadline");

    // 4. Số nhiệm vụ theo từng cơ quan trong cây (khi lọc thì dùng useRows để khớp bộ lọc)
    const cm = {};
    const isFilteredAgency = useRows !== base;
    const tree4 = document.getElementById('provincePlanTree');
    if (tree4 && tree4.children.length && !isFilteredAgency) {
        [...tree4.querySelectorAll('.pp-task')].forEach(t => {
            if (t.style.display === 'none') return;
            [...t.querySelectorAll('.pp-agency')].forEach(ag => {
                const agency = provinceAgencyLabel(ag.querySelector('[data-k=agencyOther]')?.value || ag.querySelector('[data-k=agency]')?.value || '');
                if (agency) cm[agency] = (cm[agency] || 0) + 1;
            });
        });
    } else {
        useRows.forEach(x => {
            const names = x._isTree ? String(x.unit_name||'').split(',').map(s=>provinceAgencyLabel(s)).filter(Boolean) : String(x.unit_name || '').split(',').map(s => provinceAgencyLabel(s)).filter(Boolean);
            names.forEach(a => { if(a) cm[a] = (cm[a] || 0) + 1; });
        });
    }
    const top = Object.entries(cm).sort((a, b) => b[1] - a[1]).slice(0, 8);
    provinceRenderChart("provinceChart4", top.map(x => x[0]), top.map(x => x[1]), ["#2563eb", "#56B4E9", "#8b5cf6", "#009E73", "#f59e0b", "#ec4899", "#64748b", "#0ea5e9"].slice(0, top.length), "provinceLegend4", "officer");
    // Hiệu suất Top 10 theo từng cơ quan trong cây, gồm cả chủ trì và phối hợp.
    let provPerfRows = useRows, provPerfOwner = x => x.unit_name || x.role || "Chưa rõ cơ quan", provPerfStatus = x => x.statusKey || provinceStatusGroup(provinceStatusFor(x));
    try {
        const exp = buildPROVPerfAgencies();
        if (exp.length) { provPerfRows = exp; provPerfOwner = x => x.agency_name; provPerfStatus = x => x.statusKey; }
    } catch (e) {}
    renderWorkspacePerformance("provincePerformanceChart", "provincePerformanceLegend", provPerfRows, provPerfOwner, provPerfStatus, PROV_CHARTS, (owner, statusKey) => {
        let exp = [];
        try { exp = buildPROVPerfAgencies(); } catch (e) {}
        if (exp.length) {
            const idxSet = new Set(exp.filter(e => e.agency_name === owner && (!statusKey || e.statusKey === statusKey)).map(e => e._treeIdx));
            const treeRows = getPROVTreeRows(null) || [];
            const labelMap = { done: "Hoàn thành", processing: "Đang triển khai", overdue: "Quá hạn" };
            const suffix = statusKey ? ` · ${labelMap[statusKey] || statusKey}` : "";
            renderPROVDrill(treeRows.filter(r => idxSet.has(r._treeIdx)), `Hiệu suất cơ quan - ${owner}${suffix}`, "📊");
            return;
        }
        const rows = useRows.filter(x => String(x.unit_name || x.role || "") === String(owner)); renderPROVDrill(rows, `Hiệu suất cơ quan - ${owner}`, "📊");
    });
}



function drillPROVChart(kind, label) {
    if (kind === "status") {
        const key = label === "Hoàn thành" ? "done" : label === "Quá hạn" ? "overdue" : "processing";
        openPROVStatusPopup(key); return;
    }
    if (kind === "officer") {
        const wanted = provinceFold(label);
        const src = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : (getPROVTreeRows(null) || PROV_TASKS);
        // Nếu đang có filter active thì src đã là PROV_FILTERED đã lọc, chỉ cần lọc thêm theo cơ quan
        const isFilteredSrc = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length && src === PROV_FILTERED;
        if (isFilteredSrc || (getPROVTreeRows(null) || []).length) {
            renderPROVDrill(src.filter(r => {
                const agencies = String(r.unit_name || '').split(',').map(s => provinceFold(provinceAgencyLabel(s))).filter(Boolean);
                return agencies.some(a => a === wanted || a.includes(wanted) || wanted.includes(a));
            }), `Số nhiệm vụ - ${label}`, "👤");
            return;
        }
        const o = document.getElementById("provinceOfficerFilter"); if (o) o.value = label; applyPROVFilters(); return;
    }
    if (kind === "document") {
        const wanted = provinceFold(label);
        const src = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : (getPROVTreeRows(null) || PROV_TASKS);
        // Nếu src đã là PROV_FILTERED đã lọc, chỉ lọc thêm theo văn bản
        if (Array.isArray(PROV_FILTERED) && PROV_FILTERED.length) {
            const rows = src.filter(x => {
                const raws = x._isTree ? [...String(x.source_doc||'').split('\n'), ...String(x.source_group||'').split('\n')].map(s=>s.trim()).filter(Boolean) : [...String(x.van_ban_tinh||'').split('\n'), ...String(x.van_ban_xa||'').split('\n')].map(s=>s.trim()).filter(Boolean);
                if(!raws.length) return label==='Không có văn bản';
                return raws.some(d=>{ try{ const k=provinceFold(typeof ppShortDoc==='function'?ppShortDoc(d):d); return k===wanted || k.includes(wanted) || wanted.includes(k);}catch(e){return provinceFold(d)===wanted;}});
            });
            renderPROVDrill(rows, `Theo văn bản - ${label}`, "📄");
            return;
        }
        const tree = document.getElementById('provincePlanTree');
        if (tree && tree.children.length) {
            const idxSet = new Set();
            [...tree.querySelectorAll('.pp-task')].forEach((t, ti) => {
                if (t.style.display === 'none') return;
                const docs=[...t.querySelectorAll('.pp-docs-tinh div[contenteditable], .pp-docs-xa div[contenteditable]')].map(d=>String(d.textContent||d.innerText||'').trim()).filter(Boolean);
                const keys=docs.map(d=>{ try{return provinceFold(typeof ppShortDoc==='function'?ppShortDoc(d):d);}catch(e){return provinceFold(d);} });
                if(label==='Không có văn bản' && !docs.length) idxSet.add(ti);
                else if(keys.some(k=>k===wanted || k.includes(wanted) || wanted.includes(k))) idxSet.add(ti);
            });
            const treeRows = getPROVTreeRows(null) || [];
            renderPROVDrill(treeRows.filter(r => idxSet.has(r._treeIdx)), `Theo văn bản - ${label}`, "📄");
            return;
        }
        let base = PROV_TASKS;
        try { const tr = getPROVTreeRows(null); if (tr) base = tr; } catch (e) {}
        PROV_FILTERED = base.filter(x => {
            const raws=[...String(x.van_ban_tinh||'').split('\n'), ...String(x.van_ban_xa||'').split('\n')].map(s=>s.trim()).filter(Boolean);
            if(!raws.length) return label==='Không có văn bản';
            return raws.some(d=>{ try{return provinceFold(typeof ppShortDoc==='function'?ppShortDoc(d):d)===wanted;}catch(e){return provinceFold(d)===wanted;}});
        });
        renderPROVTable(PROV_FILTERED); return;
    }
    if (kind === "leader") {
        const wanted = provinceFold(label);
        const srcFiltered = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : null;
        if (srcFiltered) {
            const rows = srcFiltered.filter(x => {
                const hay = provinceFold([x.officer_name, x.office_leader, x.leader, x.role, x.unit_name].filter(Boolean).join(" "));
                return hay === wanted || hay.includes(wanted) || wanted.includes(hay);
            });
            renderPROVDrill(rows, `Theo tên lãnh đạo cơ quan - ${label}`, "👤");
            return;
        }
        const tree = document.getElementById('provincePlanTree');
        if (tree && tree.children.length) {
            const idxSet = new Set();
            [...tree.querySelectorAll('.pp-task')].forEach((t, ti) => {
                if (t.style.display === 'none') return;
                const match = [...t.querySelectorAll('.pp-leader-row [data-k=name]')].some(el => provinceFold(el.value || '') === wanted);
                if (match) idxSet.add(ti);
            });
            const treeRows = getPROVTreeRows(null) || [];
            renderPROVDrill(treeRows.filter(r => idxSet.has(r._treeIdx)), `Theo tên lãnh đạo cơ quan - ${label}`, "👤");
            return;
        }
        let base = PROV_TASKS;
        try { const tr = getPROVTreeRows(null); if (tr) base = tr; } catch (e) {}
        PROV_FILTERED = base.filter(x => provinceFold(x.office_leader || x.leader || x.role || '') === wanted);
        renderPROVTable(PROV_FILTERED); return;
    }
    if (kind === "title") {
        const om = provinceOfficerMap();
        let base = PROV_TASKS;
        try { const tr = getPROVTreeRows(null); if (tr) base = tr; } catch (e) {}
        PROV_FILTERED = base.filter(x => ((x.role || x.unit_name) || "Chưa rõ cơ quan chủ trì") === label);
        renderPROVTable(PROV_FILTERED); return;
    }
    if (kind === "deadline") {
        const srcFiltered = Array.isArray(PROV_FILTERED) && PROV_FILTERED.length ? PROV_FILTERED : null;
        if (srcFiltered) {
            const now2 = new Date(), today2 = new Date(now2.getFullYear(), now2.getMonth(), now2.getDate());
            const rows = srcFiltered.filter(x => {
                const st = provinceStatusFor(x), due = provinceDeadlineDate(x.deadline);
                if (label === "Hoàn thành") return provinceStatusGroup(st) === "done";
                if (label === "Sắp đến hạn trong 7 ngày") return provinceStatusGroup(st) !== "done" && due && Math.round((due - today2) / 86400000) >= 0 && Math.round((due - today2) / 86400000) <= 7;
                if (!due || provinceStatusGroup(st) === "done") return false;
                const days = Math.round((due - today2) / 86400000);
                if (label === "Quá hạn") return days < 0;
                if (label === "Sắp đến hạn trong 7 ngày") return days >= 0 && days <= 7;
                return days > 3;
            });
            renderPROVDrill(rows, `Thời hạn xử lý - ${label}`, "⏰");
            return;
        }
        const catMap = { "Hoàn thành": ["done"], "Quá hạn": ["overdue"], "Sắp đến hạn trong 7 ngày": ["soon7"] };
        const catsWanted = catMap[label] || [];
        let cats = [];
        try { cats = buildPROVDeadlineCategories(); } catch (e) {}
        if (catsWanted.length && cats.length) {
            const idxSet = new Set(cats.filter(x => catsWanted.includes(x.category)).map(x => x._treeIdx));
            const treeRows = getPROVTreeRows(null) || [];
            renderPROVDrill(treeRows.filter(r => idxSet.has(r._treeIdx)), `Thời hạn xử lý - ${label}`, "⏰");
            return;
        }
        const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        let base = PROV_TASKS;
        try { const tr = getPROVTreeRows(null); if (tr) base = tr; } catch (e) {}
        PROV_FILTERED = base.filter(x => {
            const st = provinceStatusFor(x), due = provinceDeadlineDate(x.deadline);
            if (label === "Hoàn thành") return provinceStatusGroup(st) === "done";
            if (label === "Sắp đến hạn trong 7 ngày") return provinceStatusGroup(st) !== "done" && due && Math.round((due - today) / 86400000) >= 0 && Math.round((due - today) / 86400000) <= 7;
            if (!due || provinceStatusGroup(st) === "done") return false;
            const days = Math.round((due - today) / 86400000);
            if (label === "Quá hạn") return days < 0;
            if (label === "Sắp đến hạn trong 7 ngày") return days >= 0 && days <= 7;
            return days > 3;
        });
        renderPROVTable(PROV_FILTERED); return;
    }
}




let PROV_EDIT_ID = null;
let PROV_TREE_EDIT_IDX = null;
let PROV_DRILL_MODE = "all";









let PROV_DRILL_STATE = { ids: [], title: "Nhiệm vụ Tỉnh giao", icon: "🏢" };



function resetPROVDrillFilters() { const q=document.getElementById("provinceDrillContentFilter"); if(q) q.value=""; const tm=document.getElementById("provinceDrillTimeFilter"); if(tm) tm.value=""; const st=document.getElementById("provinceDrillStatusFilter"); if(st) st.value="all"; const ord=document.getElementById("provinceDrillOrder"); if(ord) ord.value="newest"; onPROVDrillFilterChange(); }

// ===== V49: THÊM NHIỆM VỤ TRỰC TIẾP VÀO public.province_tasks =====
function renderPROVAddTaskRow() {
    if (!CURRENT_USER || !(CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && ["province", "data_entry"].includes(CURRENT_USER.scope)))) return "";
    return `<tr id="provinceAddTaskRow" class="add-task-row"><td colspan="11">
                <div class="add-task-shell">
                  <div class="add-task-title"><span>➕ Thêm nhiệm vụ Tỉnh giao</span><span style="font-size:11.8px;color:#64748b;font-weight:600">Ghi trực tiếp vào province_tasks</span></div>
                  <div class="add-task-grid">
                    <div class="field span2"><label>Nhiệm vụ tỉnh giao <span style="color:#dc2626">*</span></label><textarea id="provinceAddTaskName" placeholder="Nhập nội dung nhiệm vụ..."></textarea></div>
                    <div class="field"><label>Văn bản tỉnh</label><input id="provinceAddSourceForm" placeholder="Ví dụ: Công văn / Kế hoạch / Quyết định..."></div>
                    <div class="field"><label>Văn bản xã</label><input id="provinceAddIssuingAuthority" placeholder="Ví dụ: UBND tỉnh / Chủ tịch UBND..."></div>
                    <div class="field"><label>Cơ quan (đơn vị tham mưu)</label><input id="provinceAddUnit" placeholder="Ví dụ: UBND xã / Ban XDĐ..."></div>
                    <div class="field"><label>Lãnh đạo (UBND)</label>${CURRENT_USER.role === "admin"
            ? `<select id="provinceAddOfficer">${[...new Set(PROV_OFFICERS.map(o => String(o.name || "").trim()).filter(Boolean))].map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join("")}</select>`
            : `<input id="provinceAddOfficer" value="${CURRENT_USER.scope === "data_entry" ? "" : esc(CURRENT_USER.name)}" ${CURRENT_USER.scope === "data_entry" ? "placeholder=\"Nhập lãnh đạo phụ trách\"" : "readonly"}>`}</div>
                    <div class="field"><label>Lãnh đạo phòng chuyên môn</label><input id="provinceAddRole" placeholder="Ví dụ: Trưởng phòng / Phó phòng..."></div>
                    <div class="field"><label>Chuyên viên</label><input id="provinceAddSpecialist" placeholder="Nhập chuyên viên phụ trách"></div>
                    <div class="field"><label>Hạn hoàn thành <span style="color:#dc2626">*</span></label><input id="provinceAddDeadline" type="date" required data-ds-date="1" class="date-ddmmyyyy" oninput="dateMask(this);refreshPROVAddStatus()" placeholder="dd/mm/yyyy" lang="vi"></div>
                    <div class="field"><label>Ngày hoàn thành</label><input id="provinceAddCompleted" type="date" data-ds-date="1" class="date-ddmmyyyy" oninput="dateMask(this);refreshPROVAddStatus()" placeholder="dd/mm/yyyy" lang="vi"></div>
                    <div class="field"><label>Thời gian còn lại <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="provinceAddRemaining" class="auto-status-field" value="—" readonly></div>
                    <div class="field"><label>Tiến độ</label><input id="provinceAddProgress" placeholder="Ví dụ: 50% / đang triển khai" oninput="refreshPROVAddStatus()"></div>
                    <div class="field"><label>Trạng thái <span style="font-size:11px;color:#64748b">(tự động)</span></label><input id="provinceAddStatus" class="auto-status-field" value="Đang triển khai" readonly></div>
                    <div class="field span2"><label>Sản phẩm</label><textarea id="provinceAddProduct" placeholder="Nêu rõ kết quả được minh chứng cụ thể bằng văn bản, số liệu, hoặc chủ trương giải pháp..." oninput="refreshPROVAddStatus()"></textarea></div>
                    <div class="field"><label>Ghi chú</label><textarea id="provinceAddStaffNote" placeholder="Ghi chú bổ sung (nếu có)"></textarea></div>
                    <div class="field"><label>Ghi chú của Admin</label><textarea id="provinceAddAdminNote" placeholder="Ghi chú từ Admin (chỉ Admin)"></textarea></div>
                    <div class="field add-task-actions"><button id="provinceAddBtn" class="add-task-btn" type="button" onclick="stageNewPROVTask()">＋ Thêm nhiệm vụ</button></div>
                  </div>
                  <div class="add-task-help">Nhiệm vụ được lưu thẳng lên Supabase. Trạng thái tự tính theo Hạn hoàn thành + Ngày hoàn thành + Kết quả/tệp.</div>
                </div>
            </td></tr>`;
}



let PENDING_PROV_TASK = null;



function renderPROVDrill(rows, title, icon, openModal = true) {
    if (openModal) { PROV_DRILL_STATE = { ids: rows.map(x => String(x.id)), title: title || "Nhiệm vụ Tỉnh giao", icon: icon || "🏢" }; const sel = document.getElementById("provinceDrillOrder"); if (sel) sel.value = "newest"; const q=document.getElementById("provinceDrillContentFilter"); if(q) q.value=""; const tm=document.getElementById("provinceDrillTimeFilter"); if(tm) tm.value=""; const st=document.getElementById("provinceDrillStatusFilter"); if(st) st.value="all"; }
    rows = applyPROVDrillOrder(rows);
    const body = document.getElementById("provinceDrillBody"), empty = document.getElementById("provinceDrillEmpty");
    const omap = provinceOfficerMap();
    document.getElementById("provinceDrillTitle").textContent = `${icon || "🏢"} ${title || "Nhiệm vụ Tỉnh giao"}`;
    document.getElementById("provinceDrillCount").textContent = rows.length;
    const jsArg = v => `'${String(v ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
    body.innerHTML = rows.map((x, i) => {
        if (x._isTree) {
            const remaining = provinceRemainingText({ deadline: x.deadline, completed_date: x.completed_date });
            return `<tr class="bch-drill-row" onclick="openPROVTaskEdit(${jsArg(x.id)})">
                      <td class="c-stt">${i + 1}</td>
                      <td class="c-task"><div class="prov-task-text task-tip" data-full="${esc(x.task_name || "")}">${esc(x.task_name || "—")}</div></td>
                      <td class="c-unit">${esc(x.unit_name || "—")}</td>
                      <td class="c-officer"><b>${esc((typeof provinceTaskLeader === "function" ? provinceTaskLeader(x) : x.officer_name) || "—")}</b></td>
                      <td class="c-deadline">${esc(x.deadline || "—")}</td>
                      <td class="c-completed">${esc(x.completed_date || "—")}</td>
                      <td class="c-remaining">${esc(remaining)}</td>
                      <td class="c-progress">${esc(x.progress || "—")}</td>
                      <td class="c-status">${provinceBadgeStatus(x)}</td>
                      <td class="c-result">${esc(x.product || "—")}</td>
                      <td><button class="edit-btn" onclick="event.stopPropagation(); openPROVTaskEdit(${jsArg(x.id)})">✏️ Cập nhật</button></td>
                    </tr>`;
        }
        const can = provinceCanEdit(x) || CURRENT_USER?.scope === "data_entry";
        const remaining = provinceRemainingText(x);
        return `<tr class="bch-drill-row" onclick="openPROVTaskEdit(${jsArg(x.id)})">
                  <td class="c-stt">${i + 1}</td>
                  <td class="c-task"><div class="prov-task-text task-tip" data-full="${esc(x.task_name || "")}">${esc(x.task_name || "—")}</div></td>
                  <td class="c-unit">${esc(x.unit_name || "—")}</td>
                  <td class="c-officer"><b>${esc((typeof provinceTaskLeader === "function" ? provinceTaskLeader(x) : x.officer_name) || "—")}</b></td>
                  <td class="c-deadline">${esc(x.deadline || "—")}</td>
                  <td class="c-completed">${esc(x.completed_date || "—")}</td>
                  <td class="c-remaining">${esc(remaining)}</td>
                  <td class="c-progress">${esc(x.progress || "—")}</td>
                  <td class="c-status">${provinceBadgeStatus(x)}</td>
                  <td class="c-result">${esc(x.product || "—")}</td>
                  <td>${can ? `<button class="edit-btn" onclick="event.stopPropagation();openPROVTaskEdit(${jsArg(x.id)})">✏️ Cập nhật</button>` : `<span class="locked-text">🔒 Xem</span>`}${CURRENT_USER?.role === "admin" && provinceStatusFor(x) === "overdue" ? `<button class="extend-btn" onclick="event.stopPropagation();openHomeExtend('province',${jsArg(x.id)})">📅 Gia hạn</button><button class="edit-btn" onclick="event.stopPropagation();sendWorkspaceDeadlineNotice('province',${jsArg(x.id)})">📧 Gửi TB</button>` : ""}</td>
                </tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    if (openModal) smoothOpenModal("provinceDrillModal");
}

function closePROVDrill() { smoothCloseModal("provinceDrillModal"); }











function renderPROVCurrentAttachment(x) {
    const el = document.getElementById("provinceCurrentAttachment"); if (!el) return;
    if (!x || (!x.attachment_path && !x.attachment_name)) {
        el.innerHTML = '<span class="admin-note-empty">Chưa có tệp đính kèm</span>'; return;
    }
    const approved = x.attachment_approved === true;
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    el.innerHTML = `<span class="file-pill">📄 ${esc(x.attachment_name || "Tệp sản phẩm")}</span>
                ${approved ? '<span class="approval-pill approved">✅ Đã duyệt</span>' : '<span class="approval-pill pending">⏳ Chờ duyệt</span>'}
                ${isAdmin && x.attachment_path ? `<button type="button" class="file-link-btn" onclick="openPROVAttachment(${x.id},true)">👁 Xem tệp</button>` : `<span class="admin-note-empty">Chỉ lưu tên file</span>`}
                ${isAdmin && !approved ? `<button type="button" class="approve-file-btn" onclick="approvePROVAttachment(${x.id})">✓ Phê duyệt</button>` : ""}
                ${isAdmin ? `<button type="button" class="file-delete-btn" onclick="deletePROVAttachment(${x.id})">🗑 Xóa tệp</button>` : ""}`;
}







const PROV_STORAGE_BUCKET = "province-task-files";













function renderPROVTable(rows) {
    const body = document.getElementById("provinceTableBody"), empty = document.getElementById("provinceEmpty");
    if (!body) return;
    const selectedAgency = document.getElementById('provinceOfficerFilter')?.value || '';
    const jsArg = value => `'${String(value ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
    const statusLabel = { done: "Hoàn thành", processing: "Đang triển khai", overdue: "Quá hạn" };
    body.innerHTML = rows.map((x, i) => {
        const key = x.statusKey || provinceStatusFor(x);
        const canEd = !x._isTree && (typeof canEditPROVTask === "function" ? canEditPROVTask(x) : true);
        const editBtn = canEd ? `<button class="prov-row-btn" title="Sửa" onclick="event.stopPropagation();openPROVTaskEdit(${jsArg(x.id)})">✏</button>` : "";
        const delBtn = canEd ? `<button class="prov-row-btn danger" title="Xóa" onclick="event.stopPropagation();deletePROVTaskById(${jsArg(x.id)})">🗑</button>` : "";
        const click = `openPROVTaskDetail(${jsArg(x.id)})`;
        const taskName = esc(x.task_name || "Chưa nhập nhiệm vụ");
        const unit = esc(x.unit_name || "Chưa rõ");
        const leader = esc((typeof provinceTaskLeader === "function" ? provinceTaskLeader(x) : x.officer_name) || "Chưa phân công");
        const deadline = esc(x.deadline || "—");
        const badge = (typeof provinceFilteredBadgeStatus === "function" ? provinceFilteredBadgeStatus(x, selectedAgency) : `<span class="bch-badge ${key}">${statusLabel[key] || ""}</span>`);
        return `<tr class="prov-flat-row" onclick="${click}" title="Bấm để xem chi tiết"><td class="c-stt">${i + 1}</td><td class="c-task"><span class="task-tip" data-full="${taskName}">${taskName}</span></td><td class="c-unit">${unit}</td><td class="c-officer">${leader}</td><td class="c-deadline">${deadline}</td><td class="c-status">${badge}</td><td class="c-act" onclick="event.stopPropagation()"><span class="prov-row-actions">${editBtn}${delBtn}</span></td></tr>`;
    }).join("");
    if (empty) empty.style.display = rows.length ? "none" : "block";
    const shown = document.getElementById("provinceShownCount"); if (shown) shown.textContent = rows.length;
    try{ if(typeof renderProvinceAgencyList==="function") renderProvinceAgencyList(); }catch(e){}
}

// Mat duy nhat o header NGUON GIAO / Nhiem vu cu the (popup): tu thu sidebar + mo full inline, khong bung nhanh
function provShowFullTask(btn){
    try{ if(!document.body.classList.contains("sb-collapsed")) document.getElementById("sbToggle")?.click(); }catch(e){}
    try{
        const body = (btn && btn.closest) ? btn.closest("table")?.querySelector("tbody") : null;
        if(!body) return;
        body.classList.toggle("prov-full");
        btn.classList.toggle("on", body.classList.contains("prov-full"));
    }catch(e){}
}

function renderProvinceAgencyList(){
    const box=document.getElementById("provinceLeaderList"); if(!box) return;
    const q=provinceFold(document.getElementById("provinceLeaderSearch")?.value||"");
    const counts={}; const canon={};
    // Lấy danh sách cơ quan từ cây và từ PROV_TASKS
    try{
        const treeRows=getPROVTreeRows(null);
        if(treeRows && treeRows.length){
            treeRows.forEach(x=>{
                const raw=String(x.unit_name||"").trim();
                const key=raw||"Chưa rõ cơ quan";
                counts[key]=(counts[key]||0)+1;
                canon[provinceFold(key)]=key;
            });
        } else {
            PROV_TASKS.forEach(x=>{
                const raw=String(x.unit_name||x.role||"").trim();
                const key=raw||"Chưa rõ cơ quan";
                counts[key]=(counts[key]||0)+1;
                canon[provinceFold(key)]=key;
            });
        }
    }catch(e){
        PROV_TASKS.forEach(x=>{
            const raw=String(x.unit_name||x.role||"").trim();
            const key=raw||"Chưa rõ cơ quan";
            counts[key]=(counts[key]||0)+1;
        });
    }
    const cur=document.getElementById("provinceOfficerFilter")?.value||"";
    const match=n=>!q||provinceFold(n).includes(q);
    const row=(n,cls)=>{
        const c=counts[n]||0;
        const active=cur===n?" active":"";
        return `<div class="bch-leader-item${cls?" "+cls:""}${active}" onclick="provincePickAgency(${JSON.stringify(n).replace(/"/g,"&quot;")})"><div><div class="n">${esc(n)}</div></div><span class="cnt">${c}</span></div>`;
    };
    const allAgencies=Object.keys(counts).sort((a,b)=>a.localeCompare(b,"vi"));
    let html="";
    // Hiển thị tất cả cơ quan, không phân nhóm cha-con như TT/BTV
    allAgencies.filter(n=>match(n)).forEach(n=>{
        const isUnknown=n==="Chưa rõ cơ quan";
        html+=row(n, isUnknown?"":"");
    });
    box.innerHTML=html||`<div class="bch-empty">Không có cơ quan.</div>`;
}
function getProvinceVanBanList(type){
    const set=new Set();
    try{
        const rows=getPROVTreeRows(null)||[];
        rows.forEach(r=>{
            const v=String(type==='tinh' ? (r.source_doc||"") : (r.source_group||"")).trim();
            if(v) v.split('\n').forEach(s=>{ const t=s.trim(); if(t) set.add(t); });
        });
    }catch(e){}
    try{
        PROV_TASKS.forEach(x=>{
            const v=String(type==='tinh' ? (x.source_doc||x.van_ban_tinh||"") : (x.source_group||x.van_ban_xa||"")).trim();
            if(v) v.split('\n').forEach(s=>{ const t=s.trim(); if(t) set.add(t); });
        });
    }catch(e){}
    return [...set].sort((a,b)=>a.localeCompare(b,"vi"));
}
function populateProvinceVanBanSelects(tinhVal, xaVal){
    const tinhSel=document.getElementById("provinceEditVanBanTinh");
    const xaSel=document.getElementById("provinceEditVanBanXa");
    if(tinhSel){
        // Textbox: gan truc tiep, khong dung dropdown
        if(tinhSel.tagName==="INPUT"){
            tinhSel.value=String(tinhVal||"");
            const inp=document.getElementById("provinceEditVanBanTinhOther"); if(inp){ inp.style.display="none"; inp.value=""; }
        } else {
        const list=getProvinceVanBanList('tinh');
        const cur=String(tinhVal||"").trim();
        if(cur && !list.includes(cur)) list.unshift(cur);
        tinhSel.innerHTML='<option value="">Chọn văn bản tỉnh</option>'+list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('')+'<option value="__other__">Khác (nhập văn bản)</option>';
        tinhSel.value=list.includes(cur)?cur:(cur?"__other__":"");
        handleProvinceVanBanOther(tinhSel,'tinh');
        if(tinhSel.value==="__other__"){ const inp=document.getElementById("provinceEditVanBanTinhOther"); if(inp) inp.value=cur; }
        }
    }
    if(xaSel){
        if(xaSel.tagName==="INPUT"){
            xaSel.value=String(xaVal||"");
            const inp=document.getElementById("provinceEditVanBanXaOther"); if(inp){ inp.style.display="none"; inp.value=""; }
        } else {
        const list=getProvinceVanBanList('xa');
        const cur=String(xaVal||"").trim();
        if(cur && !list.includes(cur)) list.unshift(cur);
        xaSel.innerHTML='<option value="">Chọn văn bản xã</option>'+list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('')+'<option value="__other__">Khác (nhập văn bản xã)</option>';
        xaSel.value=list.includes(cur)?cur:(cur?"__other__":"");
        handleProvinceVanBanOther(xaSel,'xa');
        if(xaSel.value==="__other__"){ const inp=document.getElementById("provinceEditVanBanXaOther"); if(inp) inp.value=cur; }
        }
    }
}
function handleProvinceVanBanOther(sel, type){
    if(sel && sel.tagName==="INPUT") return; // textbox: khong can xu ly Other
    const otherId=type==='tinh'?"provinceEditVanBanTinhOther":"provinceEditVanBanXaOther";
    const inp=document.getElementById(otherId);
    if(!inp) return;
    const isAdmin = CURRENT_USER && CURRENT_USER.role==="admin";
    if(type==='tinh' && isAdmin){
        if(sel.value==="__other__"){
            inp.style.display=""; inp.placeholder="Nhập văn bản tỉnh khác..."; inp.readOnly=false;
            try{ inp.oninput=()=>{inp.dataset.userEdited="1";}; inp.focus(); }catch(e){}
        } else if(sel.value){
            // Admin chọn có sẵn -> cho sửa ngay trong textarea, đồng bộ 100% với select sau khi chọn
            inp.style.display=""; inp.readOnly=false;
            inp.placeholder="Chỉnh sửa văn bản tỉnh (Admin có thể sửa sau khi chọn)...";
            inp.oninput=()=>{inp.dataset.userEdited="1";};
            inp.value=sel.value;
        } else {
            inp.style.display="none"; inp.value=""; try{ delete inp.dataset.userEdited; }catch(e){}
        }
        return;
    }
    if(sel.value==="__other__"){ inp.style.display=""; try{ inp.focus(); }catch(e){} }
    else { inp.style.display="none"; inp.value=""; }
}
function getProvinceVanBanTinhEffective(){
    const sel=document.getElementById("provinceEditVanBanTinh");
    const inp=document.getElementById("provinceEditVanBanTinhOther");
    if(sel && sel.tagName==="INPUT") return (sel?.value||"").trim();
    let v=(sel?.value||"").trim();
    let ov=(inp?.value||"").trim();
    const isAdmin = CURRENT_USER && CURRENT_USER.role==="admin";
    if(v==="__other__") return ov;
    if(isAdmin && inp && inp.style.display!=="none" && ov) return ov;
    return v;
}
function getProvinceVanBanXaEffective(){
    const sel=document.getElementById("provinceEditVanBanXa");
    const inp=document.getElementById("provinceEditVanBanXaOther");
    let v=(sel?.value||"").trim();
    let ov=(inp?.value||"").trim();
    if(v==="__other__") return ov;
    return v;
}







function setSidebarSubmenuState(submenu, open) {
    if (!submenu || !submenu.classList.contains("sidebar-submenu")) return;
    // Luôn dùng đúng chiều cao nội dung thực tế để animation không bị khựng.
    if (open) {
        submenu.classList.add("open");
        submenu.style.maxHeight = submenu.scrollHeight + "px";
    } else {
        // Chốt chiều cao hiện tại trước khi thu để browser có điểm bắt đầu animation.
        submenu.style.maxHeight = submenu.scrollHeight + "px";
        requestAnimationFrame(() => {
            submenu.classList.remove("open");
            submenu.style.maxHeight = "0px";
        });
    }
}

function toggleSubmenu(el) {
    if (!el) return;
    if (el.id !== "officeSidebarItem") document.getElementById("officeWorkspace")?.classList.remove("open");
    if (el.id !== "bchSidebarItem") document.getElementById("bchWorkspace")?.classList.remove("open");
    if (el.id !== "ttbtvSidebarItem") document.getElementById("ttbtvWorkspace")?.classList.remove("open");
    if (el.id !== "provinceSidebarItem") document.getElementById("provinceWorkspace")?.classList.remove("open");
    document.getElementById("nqWorkspace")?.classList.remove("open");
    const submenu = el.nextElementSibling;
    if (submenu && submenu.classList.contains("sidebar-submenu")) {
        const willOpen = !submenu.classList.contains("open");
        el.classList.toggle("collapsed", !willOpen);
        setSidebarSubmenuState(submenu, willOpen);
    }
}



// V62: BCH / Tỉnh giao / TT-BTV có thể thu-mở submenu giống Văn phòng.
// Lần bấm đầu mở workspace + submenu; các lần bấm tiếp chỉ thu/mở submenu,
// không đóng workspace đang làm việc.
function toggleWorkspaceSidebar(el, scope) {
    if (!el) return;
    const cfg = {
        bch: { workspaceId: "bchWorkspace", open: openBCHWorkspace },
        province: { workspaceId: "provinceWorkspace", open: openPROVWorkspace },
        ttbtv: { workspaceId: "ttbtvWorkspace", open: openTTBTVWorkspace }
    }[scope];
    if (!cfg) return;

    const ws = document.getElementById(cfg.workspaceId);
    const workspaceIsOpen = !!ws?.classList.contains("open");
    if (!workspaceIsOpen) {
        cfg.open(el);
        return;
    }
    toggleSubmenu(el);
}

function syncSidebarSubmenuHeights() {
    document.querySelectorAll(".sidebar-submenu").forEach(submenu => {
        submenu.style.maxHeight = submenu.classList.contains("open") ? submenu.scrollHeight + "px" : "0px";
    });
}
window.addEventListener("resize", () => requestAnimationFrame(syncSidebarSubmenuHeights));

function hardRefreshHome() {
    const ids=["officeWorkspace","bchWorkspace","ttbtvWorkspace","provinceWorkspace","action100Workspace","mttqKpiWorkspace","vpubWorkspace","bchWorkspace","nqWorkspace"];
    ids.forEach(id=>document.getElementById(id)?.classList.remove("open"));
    document.querySelectorAll(".sidebar-item").forEach(x=>x.classList.remove("active"));
    const home=[...document.querySelectorAll(".sidebar-item")].find(x=>x.textContent.includes("Trang chủ")); if(home) home.classList.add("active");
    document.querySelectorAll(".sidebar-submenu").forEach(sm=>{sm.classList.remove("open"); sm.style.maxHeight="";});
    document.querySelectorAll(".sidebar-item .toggle-icon").forEach(ic=>ic.textContent="›");
    window.scrollTo({top:0,behavior:"smooth"});
    try{render();}catch(e){}
    try{ localStorage.setItem("vp_last_ws","home"); }catch(e){}
}
function vpSaveLastWs(id){ try{ localStorage.setItem("vp_last_ws", id); if(id==="action100Workspace") localStorage.setItem("vp_last_ws_mode", (typeof ACTION100_MODE!=="undefined"?ACTION100_MODE:"action100")); }catch(e){} }
function vpRestoreLastWs(){ try{ const id=localStorage.getItem("vp_last_ws"); if(!id||id==="home") return; const map={ officeWorkspace: ()=>openOfficeWorkspace(document.getElementById("officeSidebarItem")), bchWorkspace: ()=>openBCHWorkspace(document.getElementById("bchSidebarItem")), ttbtvWorkspace: ()=>openTTBTVWorkspace(document.getElementById("ttbtvSidebarItem")), provinceWorkspace: ()=>openPROVWorkspace(document.getElementById("provinceSidebarItem")), action100Workspace: ()=>{ const mode=localStorage.getItem("vp_last_ws_mode"); if(mode==="vpub") openVPUBWorkspace(document.getElementById("vpubSidebarItem")); else openAction100Workspace(document.getElementById("action100SidebarItem")); }, vpubWorkspace: ()=>openVPUBWorkspace(document.getElementById("vpubSidebarItem")), nqWorkspace: ()=>openNqWorkspace(document.getElementById("nqTwSidebarItem"), "ALL"), mttqKpiWorkspace: ()=>openMTTQKPIWorkspace(document.getElementById("mttqKpiSidebarItem")) }; if(map[id]) setTimeout(()=>{ try{ map[id](); }catch(e){} }, 300); }catch(e){} }

function navigateTo(page) {
    if (page === "trang-chu") { hardRefreshHome(); return; }
}

// Thu gọn sidebar: tách icon khỏi nhãn để chế độ thu gọn chỉ hiện icon (hover vẫn đủ nội dung qua title)
function sbWrapLabels() {
    document.querySelectorAll(".sidebar-item, #notifBtn").forEach(el => {
        if (el.querySelector(".si-ico")) return;
        let host = null, node = null;
        for (const n of el.childNodes) { if (n.nodeType === 3 && n.textContent.trim()) { host = el; node = n; break; } }
        if (!node) {
            const s = el.querySelector(":scope > span:not(.toggle-icon)");
            if (s) for (const n of s.childNodes) { if (n.nodeType === 3 && n.textContent.trim()) { host = s; node = n; break; } }
        }
        if (!node) return;
        const m = node.textContent.match(/^([^\p{L}\p{N}]+)([\s\S]*)$/u);
        if (!m) return;
        const ico = document.createElement("span"); ico.className = "si-ico"; ico.textContent = m[1].replace(/\s+$/, "");
        const SB_ICON_FIX = { officeSidebarItem: "🗂️", bchSidebarItem: "🚩", provinceSidebarItem: "📍", ttbtvSidebarItem: "📌" };
        if (SB_ICON_FIX[el.id]) ico.textContent = SB_ICON_FIX[el.id];
        const rest = m[2].replace(/^\s+/, "");
        if (el.id === "notifBtn") { node.textContent = rest; host.insertBefore(ico, node); }
        else {
            const txt = document.createElement("span"); txt.className = "si-txt"; txt.textContent = rest;
            const frag = document.createDocumentFragment(); frag.appendChild(ico); frag.appendChild(txt);
            host.replaceChild(frag, node);
        }
        if (rest.trim() && !el.getAttribute("title")) el.setAttribute("title", rest.trim().replace(/\s+/g, " "));
    });
}
function toggleSidebar() {
    const c = document.body.classList.toggle("sb-collapsed");
    try { localStorage.setItem("vp_sb_collapsed", c ? "1" : "0"); } catch (e) {}
    const b = document.getElementById("sbToggle"); if (b) b.textContent = c ? "»" : "« Thu gọn";
    try { if (typeof syncSidebarSubmenuHeights === "function") requestAnimationFrame(syncSidebarSubmenuHeights); } catch (e) {}
}
function sbInitCollapse() {
    try { sbWrapLabels(); } catch (e) {}
    let c = false;
    try { c = localStorage.getItem("vp_sb_collapsed") === "1"; } catch (e) {}
    if (c) { document.body.classList.add("sb-collapsed"); const b = document.getElementById("sbToggle"); if (b) b.textContent = "»"; }
}
// legacy.js nạp động sau main.js nên DOMContentLoaded có thể đã chạy xong
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", sbInitCollapse);
else sbInitCollapse();

function exportCSV() {
    if (filtered.length === 0) { showToast("info", "Không có dữ liệu để xuất", "Hãy thay đổi bộ lọc rồi thử lại."); return; }
    const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
    const headers = ["STT", "Nhiệm vụ", "Cán bộ", "Vai trò", "Hạn", "Trạng thái", "Sản phẩm", "Ghi chú cán bộ", "Ghi chú Admin", "Tệp đính kèm"];
    const rows = filtered.map((x, i) => [i + 1, x.task, x.owner, x.role, x.due, x.status, x.product || "Không", x.staff_note || "", x.admin_note || "", isAdmin ? (x.attachment_path ? (x.attachment_approved ? (x.attachment_name || "") : "Chờ duyệt") : "") : (x.attachment_approved ? "Đã duyệt" : (x.attachment_path ? "Chờ duyệt" : ""))]);
    const csv = [headers, ...rows].map(r => r.map(c => `"${String(vpSafeCell(c)).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "tasks_" + new Date().toISOString().slice(0, 10) + ".csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
function exportToExcel(opts) {
    const filename = (opts.filename || "export").replace(/[\\/:*?"<>|]/g, "_");
    const sheetName = (opts.sheetName || "Sheet1").slice(0, 31);
    const headers = opts.headers || [];
    const rows = opts.rows || [];
    const finalName = filename.endsWith(".xlsx") ? filename : filename + ".xlsx";
    try {
        if (window.XLSX && XLSX.utils && typeof XLSX.utils.aoa_to_sheet === "function") {
            const ws = XLSX.utils.aoa_to_sheet(vpSafeSheet([headers, ...rows]));
            const colWidths = headers.map((h, i) => {
                let max = String(h || "").length;
                for (const r of rows) { const l = String(r[i] ?? "").length; if (l > max) max = l; }
                return { wch: Math.min(Math.max(max + 2, 10), 50) };
            });
            ws["!cols"] = colWidths;
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, sheetName);
            XLSX.writeFile(wb, finalName);
            try { showToast("success", "Đã xuất Excel", `Xuất ${rows.length} dòng — ${finalName}`); } catch (e) {}
            return true;
        }
    } catch (e) { console.warn("XLSX export fail, fallback CSV", e); }
    const esc = v => `"${String(vpSafeCell(v ?? "")).replace(/"/g, '""')}"`;
    const csv = "\uFEFF" + [headers, ...rows].map(r => r.map(esc).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = finalName.replace(/\.xlsx$/i, ".csv");
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    try { showToast("success", "Đã xuất CSV (fallback)", `Xuất ${rows.length} dòng`); } catch (e) {}
    return true;
}
function exportToExcelMulti(filename, sheets){
    const finalName = String(filename||"export").replace(/[\\/:*?"<>|]/g,"_"); const outName = finalName.endsWith(".xlsx")? finalName : finalName+".xlsx";
    try{
        if(window.XLSX && XLSX.utils && typeof XLSX.utils.aoa_to_sheet==="function"){
            const wb = XLSX.utils.book_new();
            sheets.forEach(s=>{
                const headers=s.headers||[]; const rows=s.rows||[]; const sheetName=String(s.sheetName||"Sheet1").slice(0,31).replace(/[\\\/\?\*\[\]]/g,"_") || "Sheet1";
                const ws = XLSX.utils.aoa_to_sheet(vpSafeSheet([headers, ...rows]));
                const colWidths=headers.map((h,i)=>{ let max=String(h||"").length; for(const r of rows){ const l=String(r[i]??"").length; if(l>max) max=l; } return {wch: Math.min(Math.max(max+2,10),50)}; });
                ws["!cols"]=colWidths;
                XLSX.utils.book_append_sheet(wb, ws, sheetName);
            });
            XLSX.writeFile(wb, outName);
            try{ showToast("success","Đã xuất Excel",`Xuất ${sheets.length} sheet — ${outName}`);}catch(e){}
            return true;
        }
    }catch(e){ console.warn("XLSX multi fail",e); }
    // fallback: gộp tất cả sheet thành 1 CSV với phân tách
    const esc2=v=>`"${String(vpSafeCell(v??"")).replace(/"/g,'""')}"`;
    let csv="\uFEFF";
    sheets.forEach(s=>{
        csv+=`"${s.sheetName}"\r\n` + [s.headers, ...s.rows].map(r=>r.map(esc2).join(",")).join("\r\n") + "\r\n\r\n";
    });
    const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}); const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=outName.replace(/\.xlsx$/i,".csv"); document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
    try{ showToast("success","Đã xuất CSV (fallback multi)",`Xuất ${sheets.length} sheet`);}catch(e){}
    return true;
}
let EXPORT_SELECT_STATE = { ws: null, people: [] };
function getExportPeople(ws) {
    const w = String(ws||"").toLowerCase(); const target=(w==="action100"&&typeof ACTION100_MODE!=="undefined"&&ACTION100_MODE==="vpub")?"vpub":w;
    let names=[];
    try{
        if(target==="office"){ const src=(typeof DATA!=="undefined"?DATA:[]); names=[...new Set(src.map(x=>String(x.owner||x.officer_name||"").trim()).filter(Boolean))]; }
        else if(target==="bch"){ const src=(typeof BCH_TASKS!=="undefined"?BCH_TASKS:[]); names=[...new Set(src.map(x=>String(x.officer_name||"").trim()).filter(Boolean))]; }
        else if(target==="ttbtv"){ const src=(typeof TTBTV_TASKS!=="undefined"?TTBTV_TASKS:[]); names=[...new Set(src.map(x=>String(x.officer_name||"").trim()).filter(Boolean))]; }
        else if(target==="province"){ const src=(typeof PROV_TASKS!=="undefined"?PROV_TASKS:[]); names=[...new Set(src.map(x=>String(x.officer_name||x.officer||"").trim()).filter(Boolean))]; }
        else if(target==="action100"){ const src=(typeof ACTION100_TASKS!=="undefined"?ACTION100_TASKS:[]); names=[...new Set(src.map(x=>String(x.commune_leader||x.officer_name||"").trim()).filter(Boolean))]; }
        else if(target==="vpub"){ const src=(typeof ACTION100_TASKS!=="undefined"?ACTION100_TASKS:[]); names=[...new Set(src.map(x=>String(x.unit||x.office_leader||x.leader||"").trim()).filter(Boolean))]; }
        else if(target==="mttq"){ const src=(typeof MTTQ_KPI_TASKS!=="undefined"?MTTQ_KPI_TASKS:[]); names=[...new Set(src.map(x=>String((typeof mttqKpiPersonName==="function"?mttqKpiPersonName(x):x.person||"").trim()).filter(Boolean)))]; }
    }catch(e){}
    return names.sort((a,b)=>a.localeCompare(b,'vi'));
}
function openExportSelectModal(ws){
    const w=String(ws||"").toLowerCase(); const target=(w==="action100"&&typeof ACTION100_MODE!=="undefined"&&ACTION100_MODE==="vpub")?"vpub":w;
    const people=getExportPeople(target);
    EXPORT_SELECT_STATE={ws:target, people};
    document.getElementById('exportSelectTitle').textContent=`📤 Xuất Excel — ${target.toUpperCase()}`;
    document.getElementById('exportSelectSubtitle').textContent= people.length? `Chọn 1 hoặc nhiều người (${people.length} người)` : 'Chưa có dữ liệu người trong workspace';
    const list=document.getElementById('exportSelectList'); const search=document.getElementById('exportSelectSearch'); if(search) search.value="";
    const render=(filter="")=>{
        const q=String(filter||"").toLowerCase().trim();
        const shown= q? people.filter(n=>String(n).toLowerCase().includes(q)) : people;
        list.innerHTML= shown.length? shown.map(n=>`<label style="display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer"><input type="checkbox" value="${String(n).replace(/"/g,'&quot;')}" checked style="width:16px;height:16px"> <span style="flex:1">${esc(n)}</span></label>`).join("") : '<div style="padding:12px;color:#94a3b8;text-align:center">Không có người phù hợp</div>';
        document.getElementById('exportSelectCount').textContent= shown.length? `Đã chọn ${shown.length}/${people.length} người` : '';
        [...list.querySelectorAll('input[type="checkbox"]')].forEach(cb=>cb.addEventListener('change',()=>{ const c=[...list.querySelectorAll('input:checked')].length; document.getElementById('exportSelectCount').textContent=`Đã chọn ${c}/${people.length} người`; }));
    };
    render();
    window.filterExportSelectList=()=>render(document.getElementById('exportSelectSearch')?.value||"");
    window.toggleExportSelectAll=(on)=>{ [...list.querySelectorAll('input[type="checkbox"]')].forEach(cb=>cb.checked=on); const c=[...list.querySelectorAll('input:checked')].length; document.getElementById('exportSelectCount').textContent=`Đã chọn ${c}/${people.length} người`; };
    smoothOpenModal('exportSelectModal');
}
function closeExportSelectModal(){ smoothCloseModal('exportSelectModal'); }
function confirmExportSelect(){
    const list=document.getElementById('exportSelectList'); const selected=[...list.querySelectorAll('input:checked')].map(cb=>cb.value);
    if(!selected.length) return showToast('error','Chưa chọn người','Vui lòng chọn ít nhất 1 người để xuất.');
    const ws=EXPORT_SELECT_STATE.ws; closeExportSelectModal(); setTimeout(()=>exportWorkspaceExcelDo(ws, selected), 120);
}
function exportWorkspaceExcelDo(ws, selectedPeople){
    const w = String(ws || "").toLowerCase();
    const target = (w === "action100" && typeof ACTION100_MODE !== "undefined" && ACTION100_MODE === "vpub") ? "vpub" : w;
    const dateTag = new Date().toISOString().slice(0, 10);
    const fmt = v => { if (!v) return ""; try { if (typeof formatDate === "function" && /^\d{4}-\d{2}-\d{2}/.test(String(v))) return formatDate(v); } catch (e) {} return String(v); };
    const dmn = v => { try{ return (typeof demoMaskName==='function' ? demoMaskName(v) : v); }catch(e){ return v; } };
    const dmt = v => { try{ return (typeof demoMaskText==='function' ? demoMaskText(v) : v); }catch(e){ return v; } };
    const matchPeople=(name)=>{ if(!selectedPeople||!selectedPeople.length) return true; const n=String(name||"").trim(); return selectedPeople.some(s=> String(s).trim()===n); };
    try {
        if (target === "office") {
            let src = (typeof filtered !== "undefined" && filtered && filtered.length) ? filtered : (typeof DATA !== "undefined" ? DATA : []);
            src = src.filter(x=> matchPeople(x.owner||x.officer_name));
            if (!src.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const isAdmin = CURRENT_USER && CURRENT_USER.role === "admin";
            const headers = ["STT", "Nhiệm vụ", "Cán bộ", "Vai trò", "Hạn", "Ngày hoàn thành", "Trạng thái", "Sản phẩm", "Ghi chú cán bộ", "Ghi chú Admin", "Tệp đính kèm"];
            const rows = src.map((x, i) => [i + 1, dmt(x.task || x.task_name || ""), dmn(x.owner || x.officer_name || ""), x.role || x.unit_name || "", fmt(x.due || x.deadline || x.deadline_date || ""), fmt(x.completed_date || x.completed || ""), x.status || x.statusKey || "", dmt(x.product || "Không"), dmt(x.staff_note || ""), dmt(x.admin_note || ""), isAdmin ? (x.attachment_path ? (x.attachment_approved ? (x.attachment_name || "Đã duyệt") : "Chờ duyệt") : "") : (x.attachment_approved ? "Đã duyệt" : (x.attachment_path ? "Chờ duyệt" : ""))]);
            return exportToExcel({ filename: `VP_DangUy_${dateTag}.xlsx`, sheetName: "VP Dang uy", headers, rows });
        }
        if (target === "bch") {
            const all = (typeof BCH_TASKS !== "undefined" ? BCH_TASKS : []);
            let src = (typeof BCH_FILTERED !== "undefined" && BCH_FILTERED && (BCH_FILTERED.length || document.getElementById("bchSearch")?.value || document.getElementById("bchStatusFilter")?.value !== "all")) ? BCH_FILTERED : all;
            src = src.filter(x=> matchPeople(x.officer_name));
            if (!src.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const omap = (typeof bchOfficerMap === "function" ? bchOfficerMap() : new Map());
            const headers = ["STT", "Nhiệm vụ cụ thể", "Cán bộ", "Chức vụ", "Chuyên viên", "Nguồn giao", "Hạn hoàn thành", "Ngày hoàn thành", "Kết quả", "Trạng thái"];
            const sheets = selectedPeople.map(p=>{
                const personRows = src.filter(x=> String(x.officer_name||"").trim() === String(p).trim());
                const rows = personRows.map((x, i) => {
                    const o = omap.get(typeof bchFold === "function" ? bchFold(x.officer_name) : String(x.officer_name || "").toLowerCase()) || {};
                    const st = (typeof bchStatusLabel === "function" ? bchStatusLabel(x.statusKey) : x.statusKey || "");
                    const result = [x.product, x.result].map(v => String(v || "").trim()).find(v => v) || "Chưa điền";
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), o.title || "", dmn(x.specialist_name || ""), x.source_doc || x.amount || "", fmt(x.deadline || ""), fmt(x.completed_date || ""), dmt(result), st];
                });
                const sheetName = String(p||"Chưa rõ").slice(0,31).replace(/[\\\/\?\*\[\]\:]/g,"_");
                return { sheetName, headers, rows };
            }).filter(s=> s.rows.length);
            if (!sheets.length) {
                const rows = src.map((x, i) => {
                    const o = omap.get(typeof bchFold === "function" ? bchFold(x.officer_name) : String(x.officer_name || "").toLowerCase()) || {};
                    const st = (typeof bchStatusLabel === "function" ? bchStatusLabel(x.statusKey) : x.statusKey || "");
                    const result = [x.product, x.result].map(v => String(v || "").trim()).find(v => v) || "Chưa điền";
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), o.title || "", dmn(x.specialist_name || ""), x.source_doc || x.amount || "", fmt(x.deadline || ""), fmt(x.completed_date || ""), dmt(result), st];
                });
                return exportToExcel({ filename: `BCH_DangBo_${dateTag}.xlsx`, sheetName: "BCH", headers, rows });
            }
            return exportToExcelMulti(`BCH_DangBo_${dateTag}.xlsx`, sheets);
        }
        if (target === "ttbtv") {
            const all = (typeof TTBTV_TASKS !== "undefined" ? TTBTV_TASKS : []);
            const src = (typeof TTBTV_FILTERED !== "undefined" && TTBTV_FILTERED ? TTBTV_FILTERED : all);
            let use = src.length ? src : all;
            use = use.filter(x=> matchPeople(x.officer_name));
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ", "Lãnh đạo phụ trách", "Cơ quan chủ trì", "Lãnh đạo UBND", "Chuyên viên", "Hạn hoàn thành", "Ngày hoàn thành", "Số ngày còn lại", "Trạng thái", "Kết quả", "Nguồn giao"];
            const sheets = selectedPeople.map(p=>{
                const personRows = use.filter(x=> String(x.officer_name||"").trim() === String(p).trim());
                const rows = personRows.map((x, i) => {
                    const st = (typeof ttbtvStatusLabel === "function" ? ttbtvStatusLabel(x.statusKey) : x.statusKey || "");
                    let remain = "";
                    try { const s = (typeof ttbtvStatusGroup === "function" ? ttbtvStatusGroup(x.statusKey) : ""); if (["done"].includes(s)) remain = "Đã hoàn thành"; else { const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"; } } catch (e) { remain = ""; }
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), x.role || x.unit_name || "", dmn(x.officer_name || ""), dmn(x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || x.staff_note || ""), x.amount || x.source_doc || ""];
                });
                const sheetName = String(p||"Chưa rõ").slice(0,31).replace(/[\\\/\?\*\[\]\:]/g,"_");
                return { sheetName, headers, rows };
            }).filter(s=> s.rows.length);
            if (!sheets.length) {
                const rows = use.map((x, i) => {
                    const st = (typeof ttbtvStatusLabel === "function" ? ttbtvStatusLabel(x.statusKey) : x.statusKey || "");
                    let remain = "";
                    try { const s = (typeof ttbtvStatusGroup === "function" ? ttbtvStatusGroup(x.statusKey) : ""); if (["done"].includes(s)) remain = "Đã hoàn thành"; else { const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"; } } catch (e) { remain = ""; }
                    return [i + 1, dmt(x.task_name || ""), dmn(x.officer_name || ""), x.role || x.unit_name || "", dmn(x.officer_name || ""), dmn(x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || x.staff_note || ""), x.amount || x.source_doc || ""];
                });
                return exportToExcel({ filename: `TT_BTV_${dateTag}.xlsx`, sheetName: "TT BTV", headers, rows });
            }
            return exportToExcelMulti(`TT_BTV_${dateTag}.xlsx`, sheets);
        }
        if (target === "province") {
            let use = [];
            try { if (typeof PROV_FILTERED !== "undefined" && PROV_FILTERED && PROV_FILTERED.length) use = PROV_FILTERED; } catch (e) {}
            if (!use.length) { try { const tr = (typeof getPROVTreeRows === "function" ? getPROVTreeRows(null) : null); if (tr && tr.length) use = tr; } catch (e) {} }
            if (!use.length && typeof PROV_TASKS !== "undefined" && PROV_TASKS.length) use = PROV_TASKS;
            use = use.filter(x=> matchPeople(x.officer_name || x.officer));
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ cụ thể", "Cơ quan (đơn vị tham mưu)", "Lãnh đạo UBND", "Hạn hoàn thành", "Ngày hoàn thành", "Thời gian còn lại", "Tiến độ", "Trạng thái", "Sản phẩm", "Nguồn giao", "Văn bản tỉnh", "Văn bản xã"];
            const rows = use.map((x, i) => {
                const st = (typeof provinceStatusLabel === "function" && x.statusKey ? provinceStatusLabel(x.statusKey) : (x.statusKey || x.status || ""));
                let remain = x.remaining || "";
                try { if (!remain && x.deadline) { const d = (typeof provinceParseDate === "function" ? provinceParseDate(x.deadline) : (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null)); if (d) { const diff = Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000); remain = diff >= 0 ? `${diff} ngày` : `Quá ${Math.abs(diff)} ngày`; } } } catch (e) {}
                return [i + 1, dmt(x.task_name || x.nhiem_vu || ""), x.unit_name || x.role || x.agency || "", dmn(x.officer_name || x.officer || ""), fmt(x.deadline || ""), fmt(x.completed_date || x.completed || ""), remain, x.progress || "", typeof provinceBadgeStatus === "function" ? provinceBadgeStatus(x) : st, dmt(x.product || x.result || ""), x.amount || x.source_doc || "", x.van_ban_tinh || x.source || "", x.van_ban_xa || ""];
            });
            return exportToExcel({ filename: `TinhGiao_${dateTag}.xlsx`, sheetName: "Tinh giao", headers, rows });
        }
        if (target === "action100") {
            const all = (typeof ACTION100_TASKS !== "undefined" ? ACTION100_TASKS : []);
            let use = all;
            try {
                const q = (typeof provinceFold === "function" ? provinceFold(document.getElementById("action100Search")?.value || "") : String(document.getElementById("action100Search")?.value || "").toLowerCase());
                const filter = document.getElementById("action100Status")?.value || "all";
                const timeMode = document.getElementById("action100TimeFilter")?.value || "all";
                const agency = document.getElementById("action100Agency")?.value || "all";
                use = all.filter(x => {
                    const s = (typeof action100Status === "function" ? action100Status(x) : "");
                    const matchesFilter = filter === "all" || s === filter || (filter === "done" && ["early", "ontime", "latedone"].includes(s));
                    if (!matchesFilter) return false;
                    if (timeMode !== "all") { const d = (typeof getCreationDate === "function" ? getCreationDate(x) : null); if (d && typeof isDateInTimeRange === "function" && !isDateInTimeRange(d, timeMode)) return false; }
                    if (agency !== "all") {
                        const norm = v => String(v || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/Đ/g, "D").replace(/đ/g, "d").toLowerCase().trim();
                        const ag = norm(agency); const av = norm(x.commune_leader); const bv = norm(x.unit_name); if (ag !== av && ag !== bv) return false;
                    }
                    if (!q) return true;
                    const label = (typeof provinceFold === "function" ? provinceFold(typeof action100Label === "function" ? action100Label(s) : s) : "");
                    const hay = (typeof provinceFold === "function" ? provinceFold(`${x.task_name || ""} ${x.officer_name || ""} ${x.commune_leader || ""} ${x.unit_name || ""} ${x.product || ""}`) : "");
                    return hay.includes(q) || label.includes(q);
                });
                if (!document.getElementById("action100Search")?.value && filter === "all" && timeMode === "all" && agency === "all") use = all;
                else if (!use.length && !q && filter === "all") use = all;
            } catch (e) {}
            use = use.filter(x=> { const n=String(x.commune_leader||x.officer_name||"").trim(); return selectedPeople.some(s=> String(s).trim()===n) || (!n && selectedPeople.length===0); }); if(!selectedPeople.length) use=all.filter(x=>true);
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nhiệm vụ", "Cơ quan phụ trách", "Cơ quan phối hợp", "Lãnh đạo cơ quan phụ trách", "Lãnh đạo xã", "Chuyên viên", "Hạn hoàn thành", "Ngày hoàn thành", "Số ngày còn lại", "Trạng thái", "Sản phẩm", "Ghi chú"];
            const rows = use.map((x, i) => {
                const st = (typeof action100Label === "function" ? action100Label(typeof action100Status === "function" ? action100Status(x) : "") : "");
                let remain = "";
                try { const done = ["early", "ontime", "latedone"].includes(typeof action100Status === "function" ? action100Status(x) : ""); const d = (typeof action100ParseDate === "function" ? action100ParseDate(x.deadline) : null); remain = done ? "Đã hoàn thành" : (d ? `${Math.ceil((d.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ngày` : "-"); } catch (e) {}
                return [i + 1, dmt(x.task_name || ""), x.commune_leader || "", x.unit_name || "", dmn(x.office_leader || ""), dmn(x.xa_leader || ""), dmn(x.officer_name || x.specialist_name || ""), fmt(x.deadline || ""), fmt(x.completed_date || ""), remain, st, dmt(x.product || x.result || ""), dmt(x.admin_note || x.staff_note || "")];
            });
            return exportToExcel({ filename: `KH100_${dateTag}.xlsx`, sheetName: "KH100", headers, rows });
        }
        if (target === "vpub") {
            const all = (typeof ACTION100_TASKS !== "undefined" ? ACTION100_TASKS : []);
            let use = all;
            try {
                const q = (typeof provinceFold === "function" ? provinceFold(document.getElementById("action100Search")?.value || "") : String(document.getElementById("action100Search")?.value || "").toLowerCase());
                const filter = document.getElementById("action100Status")?.value || "all";
                use = all.filter(x => {
                    const s = (typeof action100Status === "function" ? action100Status(x) : "");
                    const matchesFilter = filter === "all" || s === filter || (filter === "done" && ["early", "ontime", "latedone"].includes(s));
                    if (!matchesFilter) return false;
                    if (!q) return true;
                    const hay = (typeof provinceFold === "function" ? provinceFold(`${x.task_name || ""} ${x.unit || ""} ${x.field || ""} ${x.leader || ""} ${x.office_leader || ""}`) : "");
                    return hay.includes(q);
                });
                if (!document.getElementById("action100Search")?.value && filter === "all") use = all;
            } catch (e) {}
            use = use.filter(x=>{ const cands=[x.unit, x.office_leader, x.leader].map(v=>String(v||"").trim()).filter(Boolean); return cands.some(c=> selectedPeople.includes(c)); });
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Nguồn giao", "Nội dung nhiệm vụ", "Cơ quan phụ trách", "Cơ quan phối hợp", "Lãnh đạo xã", "Lãnh đạo CQ phụ trách", "Ngày bắt đầu", "Thời hạn", "Kết quả tuần", "Khó khăn", "Đề xuất", "Trạng thái", "Ghi chú"];
            const rows = use.map((x, i) => {
                const st = (typeof action100Label === "function" ? action100Label(typeof action100Status === "function" ? action100Status(x) : "") : "");
                return [i + 1, dmt(x.source || ""), dmt(x.task_name || ""), x.unit || "", x.field || "", dmn(x.leader || ""), dmn(x.office_leader || ""), fmt(x.start_date || ""), fmt(x.deadline || ""), dmt(x.weekly_result || x.product || ""), dmt(x.difficulties || ""), dmt(x.proposal || ""), st, dmt(x.note || x.admin_note || "")];
            });
            return exportToExcel({ filename: `VPUB_${dateTag}.xlsx`, sheetName: "VPUB", headers, rows });
        }
        if (target === "mttq") {
            const scoped = (typeof mttqKpiScopedTasks === "function" ? mttqKpiScopedTasks() : (typeof MTTQ_KPI_TASKS !== "undefined" ? MTTQ_KPI_TASKS : []));
            const q = (typeof mttqKpiFold === "function" ? mttqKpiFold(document.getElementById("mttqKpiSearch")?.value) : "");
            const statusFilter = document.getElementById("mttqKpiStatusFilter")?.value || "all";
            let use = scoped.filter(x => { const status = (typeof mttqKpiStatusKey === "function" ? mttqKpiStatusKey(x) : ""); if (statusFilter !== "all" && status !== statusFilter && !(statusFilter === "done" && typeof mttqKpiIsDone === "function" && mttqKpiIsDone(x))) return false; if (!q) return true; const hay = (typeof mttqKpiFold === "function" ? mttqKpiFold(`${typeof mttqKpiPersonName === "function" ? mttqKpiPersonName(x) : ""} ${x.task_name} ${x.assigner} ${x.product} ${x.outcome}`) : ""); return hay.includes(q); });
            if (!use.length && !q && statusFilter === "all") use = scoped;
            use = use.filter(x=>{ const n=String((typeof mttqKpiPersonName==="function"?mttqKpiPersonName(x):"").trim()); return selectedPeople.includes(n); });
            if (!use.length) return showToast("info", "Không có dữ liệu", "Không có nhiệm vụ cho người đã chọn.");
            const headers = ["STT", "Cán bộ", "Nhiệm vụ", "Người giao", "Hạn", "Kết quả", "Số lần sai sót", "Cấp độ", "Hệ số", "Điểm quy đổi", "Trục KPI", "Sản phẩm", "Ghi chú", "Trạng thái", "Tháng", "Năm"];
            const rows = use.map((x, i) => [i + 1, dmn((typeof mttqKpiPersonName === "function" ? mttqKpiPersonName(x) : "")), dmt(x.task_name || ""), dmn(x.assigner || ""), (typeof mttqKpiDateDisplay === "function" ? mttqKpiDateDisplay(x.deadline) : fmt(x.deadline || "")), x.outcome || "Chưa hoàn thành", x.quality_errors ?? 0, x.level ?? "", x.conversion_factor ?? "", (typeof mttqKpiScore === "function" ? mttqKpiScore(x).toFixed(2) : ""), x.kpi_axis || "", dmt(x.product || ""), dmt(x.note || ""), (typeof mttqKpiStatusLabel === "function" ? mttqKpiStatusLabel(typeof mttqKpiStatusKey === "function" ? mttqKpiStatusKey(x) : "") : ""), x.task_month || "", x.task_year || ""]);
            return exportToExcel({ filename: `KPI_MTTQ_${dateTag}.xlsx`, sheetName: "KPI MTTQ", headers, rows });
        }
        return showToast("error", "Không hỗ trợ", `Workspace ${ws} chưa có cấu hình xuất Excel.`);
    } catch (e) { console.error("exportWorkspaceExcel fail", e); try { showToast("error", "Xuất Excel lỗi", e.message); } catch (err) {} }
}
function exportWorkspaceExcel(ws){
    const w=String(ws||"").toLowerCase(); const target=(w==="action100"&&typeof ACTION100_MODE!=="undefined"&&ACTION100_MODE==="vpub")?"vpub":w;
    const people=getExportPeople(target);
    if(!people.length) return showToast("info","Không có dữ liệu","Workspace chưa có người để chọn.");
    openExportSelectModal(ws);
}
window.exportWorkspaceExcel=exportWorkspaceExcel; window.exportWorkspaceExcelDo=exportWorkspaceExcelDo; window.openExportSelectModal=openExportSelectModal; window.closeExportSelectModal=closeExportSelectModal; window.confirmExportSelect=confirmExportSelect;

// V61: đồng bộ Inter cho Chart.js và chiều cao submenu ngay trước khi khởi tạo giao diện.
if (window.Chart) {
    Chart.defaults.font.family = "Inter, Arial, sans-serif";
    Chart.defaults.font.size = 12.5;
}
if (document.readyState === 'complete') { if (typeof syncSidebarSubmenuHeights === "function") syncSidebarSubmenuHeights(); } else { window.addEventListener("load", () => { if (typeof syncSidebarSubmenuHeights === "function") syncSidebarSubmenuHeights(); }); }

// Load data on init - chạy cả khi script được inject động sau sự kiện load
if (document.readyState === 'complete') { initAuth(); } else { window.addEventListener("load", initAuth); }
// Fallback DOMContentLoaded nếu load đã lỡ
document.addEventListener('DOMContentLoaded', function(){ if(!CURRENT_USER && (safeLSGet("vp_demo_token","")||(()=>{try{return sessionStorage.getItem("vp_demo_token")||"";}catch(e){return "";}})())) initAuth(); });
// Sidebar thu gọn/mở rộng



(function () {
    const CLOSE_MS = 220;

    window.smoothOpenModal = function (modalOrId) {
        const modal = typeof modalOrId === 'string'
            ? document.getElementById(modalOrId)
            : modalOrId;
        if (!modal) return;
        // Tooltip hover z-index cao đè lên modal khiến bấm vào textbox không ăn → ẩn hết khi mở modal.
        try { document.querySelectorAll('.task-tip-popup.show').forEach(t => t.classList.remove('show')); } catch (_) {}
        modal.classList.remove('closing');
        requestAnimationFrame(() => modal.classList.add('open'));
    };

    window.smoothCloseModal = function (modalOrId, afterClose) {
        const modal = typeof modalOrId === 'string'
            ? document.getElementById(modalOrId)
            : modalOrId;
        if (!modal || !modal.classList.contains('open')) {
            if (typeof afterClose === 'function') afterClose();
            return;
        }
        modal.classList.add('closing');
        setTimeout(() => {
            modal.classList.remove('open', 'closing');
            if (typeof afterClose === 'function') afterClose();
        }, CLOSE_MS);
    };

    // Escape closes the foremost open application modal.
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        const edit = document.getElementById('editModal');
        const confirmAdd = document.getElementById('addConfirmModal');
        const drill = document.getElementById('drillModal');
        const backup = document.getElementById('backupModal');
        const confirmDelete = document.getElementById('deleteTaskConfirmModal');
        if (backup && backup.classList.contains('open')) {
            e.preventDefault();
            smoothCloseModal(backup);
        } else if (confirmAdd && confirmAdd.classList.contains('open')) {
            e.preventDefault();
            if (typeof window.cancelAddTaskConfirm === 'function') window.cancelAddTaskConfirm();
        } else if (confirmDelete && confirmDelete.classList.contains('open')) {
            e.preventDefault();
            if (typeof window.closeDeleteTaskConfirm === 'function') window.closeDeleteTaskConfirm();
        } else if (edit && edit.classList.contains('open')) {
            e.preventDefault();
            if (typeof window.closeEditTask === 'function') window.closeEditTask();
        } else if (drill && drill.classList.contains('open')) {
            e.preventDefault();
            smoothCloseModal(drill);
        }
    });

    // Click backdrop để đóng đã TẮT cho tất cả popup (theo yêu cầu) - chỉ ESC hoặc nút Đóng mới đóng
    // giữ handler rỗng để tránh click nhầm mất dữ liệu đang gõ
    ['drillModal', 'editModal', 'addConfirmModal', 'extendModal', 'deleteTaskConfirmModal', 'provinceConfirmModal'].forEach(id => {
        const modal = document.getElementById(id);
        if (!modal) return;
        // backdrop mousedown không đóng, chỉ ngăn lan tỏa
        modal.addEventListener('mousedown', (e) => {
            if (e.target !== modal) return;
            e.preventDefault();
        });
    });
})();


// V34: làm mới popup Văn phòng theo đúng tập nhiệm vụ đang mở và bộ lọc hiện tại.
window.refreshActiveDrillPopup = function () {
    const modal = document.getElementById("drillModal");
    if (!modal || !modal.classList.contains("open")) return;
    const st = OFFICE_DRILL_STATE;
    const map = new Map(DATA.map(v => [String(v.id), v]));
    const rows = st.ids.map(id => map.get(String(id))).filter(Boolean);
    renderOfficeDrillRows(rows, st.title, st.icon, false);
};


// ===== V51: CLICK VÙNG NỀN ĐỂ ĐÓNG POPUP =====
// ĐÃ TẮT backdrop-close cho TẤT CẢ popup (Văn phòng, BCH, Tỉnh giao, TT/BTV...) theo yêu cầu
// Chỉ ESC hoặc nút Đóng mới đóng, tránh mất dữ liệu đang gõ
(function enableBackdropCloseV51() {
    const closeMap = {
        // backdrop click disabled - giữ map rỗng để không gắn listener tự đóng
    };
    Object.entries(closeMap).forEach(([id, closer]) => {
        const modal = document.getElementById(id);
        if (!modal || modal.dataset.backdropCloseV51 === "1") return;
        modal.dataset.backdropCloseV51 = "1";
        modal.addEventListener("click", function (e) {
            if (e.target !== modal) return;
            e.preventDefault();
        });
    });
    // gắn chặn mousedown mặc định cho tất cả modal để backdrop click không đóng
    const allModals = ["drillModal","editModal","extendModal","addConfirmModal","provinceConfirmModal","bchDrillModal","bchEditModal","bchDetailModal","provinceDrillModal","provinceEditModal","provinceDetailModal","backupModal","ttbtvDrillModal","ttbtvEditModal","ttbtvDetailModal","action100EditModal","mttqKpiEditModal","homeDrillModal","statsDrillModal","dailyWarnModal","backupModal"];
    allModals.forEach(id=>{
        const m=document.getElementById(id);
        if(!m || m.dataset.backdropDisabled==="1") return;
        m.dataset.backdropDisabled="1";
        m.addEventListener("click", e=>{ if(e.target===m) e.preventDefault(); });
        m.addEventListener("mousedown", e=>{ if(e.target===m) e.preventDefault(); });
    });
})();

// Fix focus toàn cục: không để backdrop/tooltip/event cha cướp pointer khỏi ô nhập.
(function protectEditableFocus() {
    const selector = 'input, textarea, select, [contenteditable="true"]';
    const keepInput = (e) => {
        const el = e.target?.closest?.(selector);
        if (!el) return;
        el.style.pointerEvents = 'auto';
        e.stopPropagation();
    };
    document.addEventListener('pointerdown', keepInput, true);
    document.addEventListener('mousedown', keepInput, true);
})();

function focusFirstEditable(modalId){
    const modal=document.getElementById(modalId);
    if(!modal) return;
    setTimeout(()=>{
        if(!modal.classList.contains('open')) return;
        // Fix mất focus: user đã bấm vào ô nào trong modal thì giữ nguyên, không giật về ô đầu.
        const ae=document.activeElement;
        if(ae && modal.contains(ae) && ae.matches('input, textarea, select, [contenteditable="true"]')) return;
        const sel='input:not([readonly]):not([disabled]):not([type="hidden"]), textarea:not([readonly]):not([disabled]), select:not([disabled]), [contenteditable="true"]';
        const els=modal.querySelectorAll(sel);
        for(const el of els){
            if(el.offsetParent===null) continue;
            if(el.readOnly || el.disabled) continue;
            // ensure pointer-events for focus, không bôi đen để tránh mất text cũ
            el.style.pointerEvents='auto';
            try{
                el.focus({preventScroll:true});
                if(el.setSelectionRange && el.type!=='date' && el.type!=='select-one' && typeof el.value==='string'){
                    const len=el.value.length;
                    try{ el.setSelectionRange(len,len); }catch(_){}
                } else if(el.isContentEditable){
                    try{
                        const range=document.createRange(); range.selectNodeContents(el); range.collapse(false);
                        const sel=window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
                    }catch(_){}
                }
            }catch(e){ try{el.focus();}catch(_){} }
            break;
        }
    },280);
}
window.focusFirstEditable=focusFirstEditable;
// Fix mất focus khi click vào ô nhập liệu trong các dialog (BCH, TTBTV, Tỉnh, KH100/VPUB, VP)
['bchEditModal','ttbtvEditModal','provinceEditModal','action100EditModal','mttqKpiEditModal','editModal','bchDrillModal','ttbtvDrillModal','provinceDrillModal'].forEach(id=>{
    const m=document.getElementById(id);
    if(!m) return;
    const stop=(e)=>{ if(e.target.closest('input, textarea, select, [contenteditable="true"]')) e.stopPropagation(); };
    m.addEventListener('click', stop);
    m.addEventListener('mousedown', stop);
    m.addEventListener('pointerdown', stop);
});


window.DATA = DATA;
window.drillOfficeKPI = drillOfficeKPI;
window.openOfficeWorkspace = openOfficeWorkspace;

// ===== ACTION 100 DAYS =====
let ACTION100_TASKS_API = `${SUPABASE_URL}/rest/v1/action_100_days_tasks?select=*&order=id.asc`;
const ACTION100_OFFICERS_API = `${SUPABASE_URL}/rest/v1/action_100_days_officers?select=id,name,title,unit,note,created_at&order=id.asc`;
let ACTION100_TASKS = [], ACTION100_OFFICERS = [], ACTION100_MODE = 'action100';
let KH100_TASKS_CACHE = [], VPUB_TASKS_CACHE = [];
let PENDING_ACTION100_ADD_TASK = null;
const VPUB_AGENCY_LIST = ['Văn hóa - Xã hội', 'Kinh tế, Hạ tầng', 'Nông nghiệp và Môi trường', 'Trung tâm Phục vụ Hành chính công', 'Trung tâm Dịch vụ tổng hợp', 'Ban Quản lý dự án ĐTXD', 'Công an xã', 'Ban Chỉ huy quân sự xã', 'Văn phòng HĐND và UBND'];
const VPUB_LEADER_LIST = ['Hoàng Minh Chung', 'Đoàn Ngọc Cường', 'Lê Chí Công', 'Trần Trung Hiếu', 'Trần Anh Tráng', 'Lê Trường Thịnh', 'Nguyễn Giang Nam', 'Đinh Mạnh Cường', 'Lưu Quang Lợi', 'Chu Chính Sơn'];
const VPUB_XA_LEADER_LIST = ['Chu Chính Sơn', 'Đinh Mạnh Cường', 'Lưu Quang Lợi'];
function fillSelect(el, opts, cur) { if (!el) return; const list = opts.slice(); if (cur && !list.includes(cur)) list.push(cur); el.innerHTML = list.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('') + `<option value="__other__">Khác (nhập tên)</option>`; el.value = cur; el.dataset.prev = cur; }








let VPUB_DRILL_STATE = { ids: [], title: "Nhiệm vụ VPUB", icon: "📋" };



function resetVPUBDrillFilters() { const q = document.getElementById("vpubDrillContentFilter"); if (q) q.value = ""; const tm = document.getElementById("vpubDrillTimeFilter"); if (tm) tm.value = ""; const ag = document.getElementById("vpubDrillAgencyFilter"); if (ag) ag.value = ""; const st = document.getElementById("vpubDrillStatusFilter"); if (st) st.value = "all"; const ord = document.getElementById("vpubDrillOrder"); if (ord) ord.value = "newest"; onVPUBDrillFilterChange(); }
function renderVPUBDrill(rows, title, icon, openModal = true) {
    if (openModal) {
        VPUB_DRILL_STATE = { ids: rows.map(x => String(x.id)), title: title || "Nhiệm vụ VPUB", icon: icon || "📋" };
        const ord = document.getElementById("vpubDrillOrder"); if (ord) ord.value = "newest";
        const q = document.getElementById("vpubDrillContentFilter"); if (q) q.value = "";
        const tm = document.getElementById("vpubDrillTimeFilter"); if (tm) tm.value = "";
        const st = document.getElementById("vpubDrillStatusFilter"); if (st) st.value = "all";
        const ag = document.getElementById("vpubDrillAgencyFilter");
        if (ag) {
            const prev = ag.value || "";
            const set = new Set((rows || []).map(x => String(x.unit || "").trim()).filter(Boolean));
            const opts = ['<option value="">Tất cả cơ quan</option>'].concat([...set].sort((a, b) => a.localeCompare(b, 'vi')).map(v => `<option value="${esc(v)}">${esc(v)}</option>`));
            ag.innerHTML = opts.join('');
            ag.value = [...set].includes(prev) ? prev : "";
        }
    }
    rows = applyVPUBDrillOrder(rows);
    document.getElementById('vpubDrillTitle').textContent = `${icon || "📋"} ${title || "Nhiệm vụ VPUB"}`;
    document.getElementById('vpubDrillCount').textContent = rows.length;
    document.getElementById('vpubDrillBody').innerHTML = rows.map((x, i) => {
        const s = action100Status(x); const badgeCls = s === 'overdue' ? 'vpub-overdue' : s;
        return `<tr class="bch-task-row" onclick="closeVPUBDrill();openAction100TaskEdit(${x.id})"><td>${i + 1}</td><td><div class="bch-task-text task-tip" data-full="${esc(x.task_name || '')}">${esc(x.task_name || '-')}</div></td><td>${esc(x.unit || '-')}</td><td>${esc(x.office_leader || x.leader || '-')}</td><td>${esc(x.deadline ? formatDate(x.deadline) : '-')}</td><td><span class="bch-badge ${badgeCls}">${esc(action100Label(s, true))}</span></td></tr>`;
    }).join('');
    document.getElementById('vpubDrillEmpty').style.display = rows.length ? 'none' : 'block';
    if (openModal) smoothOpenModal('vpubDrillModal');
}
function openVPUBDrill(status, element) {
    document.querySelectorAll('#action100Workspace .bch-kpi').forEach(kpi => kpi.classList.remove('selected'));
    if (element) element.classList.add('selected');
    const meta = { all: ['📋', 'Tất cả nhiệm vụ VPUB'], processing: ['🔵', 'Nhiệm vụ VPUB đang triển khai'], done: ['✅', 'Nhiệm vụ VPUB hoàn thành'], overdue: ['⏰', 'Nhiệm vụ VPUB NV đang xử lý'] }[status] || ['📋', 'Nhiệm vụ VPUB'];
    const rows = sortNewestFirst((ACTION100_TASKS || []).filter(x => { const s = action100Status(x); return status === 'all' || s === status || (status === 'done' && ['early', 'ontime', 'latedone'].includes(s)); }));
    renderVPUBDrill(rows, meta[1], meta[0], true);
}
function closeVPUBDrill() { smoothCloseModal('vpubDrillModal'); }
function populateAction100AgencyFilter(){
    const sel=document.getElementById('action100Agency'); if(!sel) return;
    const prev=sel.value||'all';
    const set=new Set();
    (ACTION100_TASKS||[]).forEach(x=>{
        const a=(ACTION100_MODE==='vpub'? x.unit : x.commune_leader)||'';
        const b=(ACTION100_MODE==='vpub'? '' : x.unit_name)||'';
        const av=String(a).trim(); if(av) set.add(av);
        const bv=String(b).trim(); if(bv) set.add(bv);
    });
    const opts=['<option value="all">Tất cả cơ quan</option>'].concat([...set].sort((a,b)=>a.localeCompare(b,'vi')).map(v=>`<option value="${esc(v)}">${esc(v)}</option>`));
    sel.innerHTML=opts.join('');
    if([...set].includes(prev) || prev==='all') sel.value=prev; else sel.value='all';
}

function renderAction100Table() {
    const rawQ = document.getElementById('action100Search')?.value || '', q = (typeof provinceFold === 'function' ? provinceFold(rawQ) : String(rawQ || '').toLowerCase().trim()), filter = document.getElementById('action100Status')?.value || 'all', timeMode = document.getElementById('action100TimeFilter')?.value || 'all', agency = document.getElementById('action100Agency')?.value || 'all';
    const rows = ACTION100_TASKS.filter(x => {
        const s = action100Status(x);
        const matchesFilter = filter === 'all' || s === filter || (filter === 'done' && ['early', 'ontime', 'latedone'].includes(s));
        if (!matchesFilter) return false;
        if (timeMode !== 'all') { const d = getCreationDate(x); if (d && !isDateInTimeRange(d, timeMode)) return false; }
        if (agency !== 'all') {
            const norm = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase().trim();
            const ag = norm(agency);
            const av = ACTION100_MODE === 'vpub' ? norm(x.unit) : norm(x.commune_leader);
            const bv = ACTION100_MODE === 'vpub' ? '' : norm(x.unit_name);
            if (ag !== av && ag !== bv) return false;
        }
        if (!q) return true;
        const label = typeof provinceFold === 'function' ? provinceFold(action100Label(s)) : String(action100Label(s) || '').toLowerCase();
        const hay = (typeof provinceFold === 'function' ? provinceFold(`${x.task_name||''} ${x.officer_name||''} ${x.specialist_name||''} ${x.commune_leader||''} ${x.office_leader||''} ${x.unit_name||''} ${x.unit||''} ${x.field||''} ${x.leader||''} ${x.source||''} ${x.ubnd_source||''} ${x.role||''} ${x.amount||''} ${x.product||''} ${x.result||''} ${x.staff_note||''} ${x.admin_note||''} ${x.weekly_result||''} ${x.note||''} ${x.difficulties||''} ${x.proposal||''} ${x.deadline||''} ${x.completed_date||''} ${label}`) : `${x.officer_name} ${x.task_name} ${x.role} ${x.specialist_name} ${x.commune_leader} ${x.office_leader} ${x.unit_name} ${x.amount}`.toLowerCase());
        return hay.includes(q);
    });
    const counts = { all: ACTION100_TASKS.length, processing: 0, early: 0, ontime: 0, latedone: 0, overdue: 0, regular: 0, planned: 0 };
    ACTION100_TASKS.forEach(x => { const k = action100Status(x); if (counts[k] !== undefined) counts[k]++; });
    ['Total', 'Processing', 'Done', 'Overdue'].forEach((n, i) => { const el = document.getElementById(`action100${n}`); if (el) el.textContent = [counts.all, counts.processing, counts.early + counts.ontime + counts.latedone, counts.overdue][i]; });
    syncAction100Head();
    const body = document.getElementById('action100TableBody'), empty = document.getElementById('action100Empty'); if (!body) return;
    if (ACTION100_MODE === 'vpub') { body.innerHTML = vpubSourceGroupsHtml(rows); if (empty) empty.style.display = rows.length ? 'none' : 'block'; return; }
    body.innerHTML = rows.map((x, i) => {
        const st = action100Status(x), done = ['early', 'ontime', 'latedone'].includes(st);
        const due = done ? null : action100ParseDate(x.deadline);
        const remain = done ? '\u0110\u00e3 ho\u00e0n th\u00e0nh' : (due ? `${Math.ceil((due.getTime() - new Date().setHours(0, 0, 0, 0)) / 86400000)} ng\u00e0y` : '-');
        const canEdit = typeof canEditAction100Task === 'function' ? canEditAction100Task(x) : true;
        const actions = canEdit ? `<div class="action100-row-actions"><button type="button" class="bch-btn bch-btn-edit" onclick="event.stopPropagation();openAction100TaskEdit(${x.id})">✏️ Sửa</button></div>` : '';
        return `<tr class="bch-task-row" onclick="openAction100TaskEdit(${x.id})"><td>${i + 1}</td><td><div class="bch-task-text task-tip" data-full="${esc(demoMaskText(x.task_name) || '')}">${esc(demoMaskText(x.task_name) || '-')}</div></td><td>${esc(ACTION100_MODE === 'vpub' ? x.unit : (x.commune_leader || '-'))}</td><td>${esc(ACTION100_MODE === 'vpub' ? (x.field || '-') : (x.unit_name || '-'))}</td><td><b>${esc(demoMaskName(ACTION100_MODE === 'vpub' ? (x.office_leader || '-') : x.office_leader || '-'))}</b></td><td>${esc(x.deadline || '-')}</td><td>${esc(remain)}</td><td><span class="bch-badge ${st}">${esc(action100Label(st))}</span></td><td>${actions}</td></tr>`;
    }).join('');
    if (empty) empty.style.display = rows.length ? 'none' : 'block';
}



function renderAction100AddBox() {
    const box = document.getElementById('action100AddBox'); if (!box) return; if (ACTION100_MODE === 'vpub') { renderVPUBAddBox(box); return; } if (box.dataset.ready) return; box.dataset.ready = '1';
    if (!CURRENT_USER || (CURRENT_USER.role !== 'admin' && CURRENT_USER.role !== 'staff')) return;
    if (ACTION100_MODE === 'vpub') return renderVPUBAddBox(box);
    box.innerHTML = `<div class="action100-add-panel"><div class="add-task-title"><span>Th&#234;m nhi&#7879;m v&#7909; KH h&#224;nh &#273;&#7897;ng 100 ng&#224;y</span></div><div class="bch-edit-grid"><div class="wide"><label>T&#234;n nhi&#7879;m v&#7909;</label><textarea id="action100TaskName"></textarea></div><div><label>Cơ quan phụ trách</label><input id="action100CommuneLeader"></div><div><label>Lãnh đạo xã phụ trách</label><input id="action100XaLeader"></div><div><label>Lãnh đạo cơ quan phụ trách</label><input id="action100OfficeLeader"></div><div><label>Cơ quan phối hợp</label><input id="action100CoordAgency" placeholder="Cơ quan phối hợp"></div><div><label>Chuyên viên phụ trách</label><input id="action100Officer" type="text"></div><div><label>H&#7841;n ho&#224;n th&#224;nh</label><input id="action100Deadline" type="date" data-ds-date="1" oninput="dateMask(this);refreshAction100AddMeta()" placeholder="dd/mm/yyyy" onchange="refreshAction100AddMeta()"></div><div><label>Ng&#224;y ho&#224;n th&#224;nh</label><input id="action100Completed" type="date" data-ds-date="1" oninput="dateMask(this);refreshAction100AddMeta()" placeholder="dd/mm/yyyy" onchange="refreshAction100AddMeta()"></div><div><label>Tr&#7841;ng th&#225;i</label><input id="action100StatusField" class="auto-status-field" readonly></div><div><label>S&#7889; ng&#224;y c&#242;n l&#7841;i</label><input id="action100Remaining" readonly></div><div class="wide"><label>S&#7843;n ph&#7849;m</label><textarea id="action100Product"></textarea></div><div class="wide"><label>Ghi ch&#250; / K&#7871;t qu&#7843; c&#7911;a c&#225;n b&#7897;</label><textarea id="action100Result"></textarea></div><div class="wide"><label>Ghi ch&#250; ADMIN</label><textarea id="action100AdminNote"></textarea></div><div class="wide add-task-actions"><button class="bch-btn primary" onclick="prepareAction100AddTask()">L&#432;u nhi&#7879;m v&#7909;</button></div></div></div>`;
}

function renderVPUBAddBox(box) {
    if (box) box.innerHTML = '';
}
function setupVPUBDateFields() {
    if (ACTION100_MODE !== 'vpub') return;
    const field = document.getElementById('vpubField');
    if (field) {
        const currentField = field.value;
        const label = field.previousElementSibling; if (label) label.textContent = 'Cơ quan phối hợp';
        if (field.tagName !== 'SELECT') {
            const select = document.createElement('select'); select.id = 'vpubField'; field.replaceWith(select);
        }
        const select = document.getElementById('vpubField'); select.innerHTML = '<option value="">Chọn cơ quan phối hợp</option>' + VPUB_AGENCY_LIST.map(o => `<option>${o}</option>`).join('') + '<option value="__other__">Khác (nhập tên)</option>'; if (currentField) select.value = currentField; select.onchange = () => ttbtvHandleRoleOther(select);
    }
    ['vpubStartDate', 'vpubDeadline', 'action100EditDue', 'action100EditCompleted'].forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        el.type = 'text'; el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric'; el.oninput = () => dateMask(el);
        if (typeof vpubWrapDateInput === 'function') vpubWrapDateInput(el);
    });
}









 function openAction100Workspace(el) {
    ACTION100_MODE = 'action100'; ACTION100_TASKS_API = `${SUPABASE_URL}/rest/v1/action_100_days_tasks?select=*&order=id.asc`;
    ['officeWorkspace', 'bchWorkspace', 'ttbtvWorkspace', 'provinceWorkspace', 'mttqKpiWorkspace', 'nqWorkspace'].forEach(id => document.getElementById(id)?.classList.remove('open'));
    const ws = document.getElementById('action100Workspace'); if (!ws) return; ws.classList.add('open');
    document.querySelectorAll('.sidebar-item').forEach(x => x.classList.remove('active')); (el || document.getElementById('action100SidebarItem'))?.classList.add('active'); syncAction100OverdueLabel(); loadAction100Data(false); syncVPUBQuickAddBtn();
    try{ vpSaveLastWs("action100Workspace"); }catch(e){}
}
function openOtherWorkspace(kind, el) {
    if (typeof event !== 'undefined' && event) { try { event.stopPropagation(); } catch (e) {} }
    if (kind === 'mttq') { if (!canAccessMTTQKPI()) return showToast('error', 'Không có quyền', 'Chỉ Admin và cán bộ MTTQ được truy cập workspace này.'); openMTTQKPIWorkspace(el); }
    else { if (CURRENT_USER?.role === 'department' && !['vpub','action100'].includes(CURRENT_USER.scope)) return showToast('error', 'Không có quyền', 'Token này chỉ được xem KH hành động 100 ngày.'); openVPUBWorkspace(el); }
    document.querySelectorAll('.sidebar-item').forEach(x => x.classList.remove('active'));
    const parent = document.getElementById('othersSidebarItem'); if (parent) parent.classList.add('active');
}













// ===== KPI MTTQ =====
let MTTQ_KPI_PEOPLE = [], MTTQ_KPI_CATALOG = [], MTTQ_KPI_TASKS = [], MTTQ_KPI_EDIT_ID = null, MTTQ_KPI_CHART = null;
const MTTQ_KPI_PEOPLE_API = `${SUPABASE_URL}/rest/v1/mttq_kpi_people`;
const MTTQ_KPI_CATALOG_API = `${SUPABASE_URL}/rest/v1/mttq_kpi_catalog`;
const MTTQ_KPI_TASKS_API = `${SUPABASE_URL}/rest/v1/mttq_kpi_tasks`;















function populateMTTQKPIFilters() {
    const person = document.getElementById('mttqKpiPersonFilter'), month = document.getElementById('mttqKpiMonthFilter'), year = document.getElementById('mttqKpiYearFilter'), editPerson = document.getElementById('mttqKpiPerson');
    if (person) { const old = person.value; person.innerHTML = '<option value="all">Tất cả cán bộ</option>' + MTTQ_KPI_PEOPLE.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join(''); person.value = MTTQ_KPI_PEOPLE.some(p => String(p.id) === old) ? old : 'all'; }
    if (editPerson) { const old = editPerson.value; editPerson.innerHTML = MTTQ_KPI_PEOPLE.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join(''); if (old) editPerson.value = old; }
    const fill = (el, label, values) => { if (!el) return; const old = el.value; el.innerHTML = `<option value="all">${label}</option>` + values.map(v => `<option value="${v}">${v}</option>`).join(''); el.value = values.map(String).includes(old) ? old : 'all'; };
    fill(month, 'Tất cả tháng', [...new Set(MTTQ_KPI_TASKS.map(x => Number(x.task_month)).filter(Boolean))].sort((a, b) => a - b));
    fill(year, 'Tất cả năm', [...new Set(MTTQ_KPI_TASKS.map(x => Number(x.task_year)).filter(Boolean))].sort((a, b) => b - a));
    const list = document.getElementById('mttqTaskCatalogList'); if (list) list.innerHTML = MTTQ_KPI_CATALOG.map(x => `<option value="${esc(x.task_name || '')}"></option>`).join('');
}

function renderMTTQKPITable() {
    const scoped = mttqKpiScopedTasks(), q = mttqKpiFold(document.getElementById('mttqKpiSearch')?.value), statusFilter = document.getElementById('mttqKpiStatusFilter')?.value || 'all';
    const rows = scoped.filter(x => { const status = mttqKpiStatusKey(x); if (statusFilter !== 'all' && status !== statusFilter && !(statusFilter === 'done' && mttqKpiIsDone(x))) return false; if (!q) return true; return mttqKpiFold(`${mttqKpiPersonName(x)} ${x.task_name} ${x.assigner} ${x.product} ${x.outcome}`).includes(q); });
    const total = document.getElementById('mttqKpiTotal'), done = document.getElementById('mttqKpiDone'), processing = document.getElementById('mttqKpiProcessing'), overdue = document.getElementById('mttqKpiOverdue'), score = document.getElementById('mttqKpiScore');
    if (total) total.textContent = scoped.length; if (done) done.textContent = scoped.filter(mttqKpiIsDone).length; if (processing) processing.textContent = scoped.filter(x => mttqKpiStatusKey(x) === 'processing').length; if (overdue) overdue.textContent = scoped.filter(x => mttqKpiStatusKey(x) === 'overdue').length; if (score) score.textContent = scoped.reduce((sum, x) => sum + mttqKpiScore(x), 0).toFixed(2);
    const body = document.getElementById('mttqKpiTableBody'), empty = document.getElementById('mttqKpiEmpty'), count = document.getElementById('mttqKpiShownCount'); if (!body) return; if (count) count.textContent = rows.length;
    const soon3 = document.getElementById('mttqKpiSoon3'), soon7 = document.getElementById('mttqKpiSoon7'); if (soon3) soon3.textContent = scoped.filter(x => mttqKpiUpcoming(x, 3)).length; if (soon7) soon7.textContent = scoped.filter(x => mttqKpiUpcoming(x, 7)).length;
    body.innerHTML = rows.map((x, i) => { const key = mttqKpiStatusKey(x), actions = mttqKpiCanEditTask(x) ? `<button class="bch-btn bch-btn-edit" onclick="event.stopPropagation();openMTTQKPIEdit('${x.id}')">✏️ Sửa</button><button class="bch-btn" onclick="event.stopPropagation();deleteMTTQKPITask('${x.id}')">Xóa</button>` : '<span class="mttq-readonly-label">Chỉ xem</span>'; return `<tr class="bch-task-row" onclick="openMTTQKPIDrillById('${x.id}')"><td>${i + 1}</td><td><b>${esc(demoMaskName(mttqKpiPersonName(x)))}</b></td><td><div class="bch-task-text task-tip" data-full="${esc(demoMaskText(x.task_name) || '')}">${esc(demoMaskText(x.task_name) || '-')}</div></td><td>${esc(demoMaskName(x.assigner) || '-')}</td><td>${esc(mttqKpiDateDisplay(x.deadline) || '-')}</td><td>${esc(x.outcome || 'Chưa hoàn thành')}</td><td><b>${mttqKpiScore(x).toFixed(2)}</b></td><td><span class="bch-badge ${key === 'processing' ? 'processing' : key === 'overdue' || key === 'failed' ? 'overdue' : 'done'}">${esc(mttqKpiStatusLabel(key))}</span></td><td>${actions}</td></tr>`; }).join(''); if (empty) empty.style.display = rows.length ? 'none' : 'block'; renderMTTQKPIChart();
}
function renderMTTQKPIChart() {
    const canvas = document.getElementById('mttqKpiPerformanceChart'); if (MTTQ_KPI_CHART) { MTTQ_KPI_CHART.destroy(); MTTQ_KPI_CHART = null; } if (!canvas || !window.Chart) return;
    const scoped = mttqKpiScopedTasks(), defs = [{ key: 'done', label: 'Hoàn thành', color: '#009E73' }, { key: 'processing', label: 'Đang thực hiện', color: '#56B4E9' }, { key: 'overdue', label: 'Quá hạn', color: '#D55E00' }, { key: 'failed', label: 'Không hoàn thành', color: '#f59e0b' }], people = MTTQ_KPI_PEOPLE.filter(p => scoped.some(x => String(x.person_id) === String(p.id)));
    if (!people.length) return;
    const values = key => people.map(p => scoped.filter(x => String(x.person_id) === String(p.id) && (key === 'done' ? mttqKpiIsDone(x) : mttqKpiStatusKey(x) === key)).length);
    MTTQ_KPI_CHART = new Chart(canvas.getContext('2d'), { type: 'bar', data: { labels: people.map(p => DEMO_MODE ? demoMaskName(p.name) : p.name), datasets: defs.map(d => ({ label: d.label, data: values(d.key), backgroundColor: d.color, borderRadius: 4, borderSkipped: false })) }, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true, beginAtZero: true, ticks: { precision: 0 }, grid: { display: true } }, y: { stacked: true, ticks: { autoSkip: false } } }, plugins: { legend: { position: 'top' }, tooltip: { callbacks: { title: items => items[0] ? (DEMO_MODE ? demoMaskName(people[items[0].dataIndex]?.name) : people[items[0].dataIndex]?.name) : '' } } }, onClick: (event, elements) => { if (!elements.length) return; const el = elements[0], person = people[el.index], def = defs[el.datasetIndex]; if (!person || !def) return; showMTTQKPIDrill(scoped.filter(x => String(x.person_id) === String(person.id) && (def.key === 'done' ? mttqKpiIsDone(x) : mttqKpiStatusKey(x) === def.key)), `${DEMO_MODE ? demoMaskName(person.name) : person.name} · ${def.label}`); } } });
}
function showMTTQKPIDrill(rows, title = 'Chi tiết KPI MTTQ') {
    const titleEl = document.getElementById('mttqKpiDrillTitle'), count = document.getElementById('mttqKpiDrillCount'), body = document.getElementById('mttqKpiDrillBody'), empty = document.getElementById('mttqKpiDrillEmpty'); if (!body) return;
    if (titleEl) titleEl.textContent = title; if (count) count.textContent = rows.length; const list = [...rows].sort((a, b) => (mttqKpiParseDate(a.deadline) || new Date(8640000000000000)) - (mttqKpiParseDate(b.deadline) || new Date(8640000000000000)));
    body.innerHTML = list.map((x, i) => { const key = mttqKpiStatusKey(x), action = mttqKpiCanEditTask(x) ? `<button class="bch-btn bch-btn-edit" onclick="event.stopPropagation();closeMTTQKPIDrill();openMTTQKPIEdit('${x.id}')">✏️ Sửa</button>` : '<span class="mttq-readonly-label">Chỉ xem</span>'; return `<tr class="mttq-drill-row"><td>${i + 1}</td><td>${esc(demoMaskName(mttqKpiPersonName(x)))}</td><td><div class="task-tip" data-full="${esc(demoMaskText(x.task_name) || '')}">${esc(demoMaskText(x.task_name) || '-')}</div></td><td>${esc(mttqKpiDateDisplay(x.deadline) || '-')}</td><td>${esc(x.outcome || 'Chưa hoàn thành')}</td><td><b>${mttqKpiScore(x).toFixed(2)}</b></td><td><span class="bch-badge ${key === 'processing' ? 'processing' : key === 'overdue' || key === 'failed' ? 'overdue' : 'done'}">${esc(mttqKpiStatusLabel(key))}</span></td><td>${action}</td></tr>`; }).join(''); if (empty) empty.style.display = list.length ? 'none' : 'block'; smoothOpenModal('mttqKpiDrillModal');
}
function openMTTQKPIDrill(mode) { const scoped = mttqKpiScopedTasks(), rows = mode === 'soon3' ? scoped.filter(x => mttqKpiUpcoming(x, 3)) : mode === 'soon7' ? scoped.filter(x => mttqKpiUpcoming(x, 7)) : scoped; showMTTQKPIDrill(rows, mode === 'soon3' ? 'Nhiệm vụ sắp đến hạn trong 3 ngày' : mode === 'soon7' ? 'Nhiệm vụ sắp đến hạn trong 7 ngày' : 'Chi tiết KPI MTTQ'); }
function openMTTQKPIDrillById(id) { const task = MTTQ_KPI_TASKS.find(x => String(x.id) === String(id)); if (task) showMTTQKPIDrill([task], `Chi tiết · ${mttqKpiPersonName(task)}`); }
function closeMTTQKPIDrill() { smoothCloseModal('mttqKpiDrillModal'); }








// ===== CẢNH BÁO NHIỆM VỤ QUÁ HẠN / SẮP ĐẾN HẠN HÀNG NGÀY =====
let DAILY_OVERDUE_TASKS = [];
let DAILY_SOON_TASKS = [];
async function refreshDailyWarnTasks() {
    DAILY_OVERDUE_TASKS = [];
    DAILY_SOON_TASKS = [];
    if (!CURRENT_USER) return false;
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const soonEnd = new Date(todayStart);
    soonEnd.setDate(soonEnd.getDate() + 7);

    function isCompleted(x, source) {
        if (source === "office") return x.status === "Hoàn thành trước hạn" || x.status === "Hoàn thành đúng hạn" || x.status === "Hoàn thành quá hạn";
        if (source === "a100" || source === "vpub") { const s = action100Status(x); return ["early", "ontime", "latedone"].includes(s); }
        return ["early", "ontime", "latedone", "done"].includes(x.statusKey || "");
    }
    function isOverdue(x, source) {
        if (isCompleted(x, source)) return false;
        if (source === "office") { const d = parseDate(x.due); return d && d < todayStart; }
        if (source === "a100" || source === "vpub") return action100Status(x) === "overdue";
        return (x.statusKey || "") === "overdue";
    }
    function isSoon(x, source) {
        if (isCompleted(x, source)) return false;
        let d;
        if (source === "office") d = parseDate(x.due);
        else if (source === "a100" || source === "vpub") d = action100ParseDate(x.deadline);
        else d = parseDate(x.deadline || x.due || "");
        return d && d >= todayStart && d <= soonEnd;
    }
    function pushTask(arr, ws, x) {
        arr.push({ workspace: ws, id: x.id, task_name: x.task_name || x.task || "", owner: x.owner || x.officer_name || "", deadline: x.deadline || x.due || x.deadline_date || "", status: x.status || x.statusKey || "", source: ws });
    }
    function isOwnedByToken(x, source){
        if(!CURRENT_USER) return false;
        if(CURRENT_USER.role==="admin") return true;
        const name=String(CURRENT_USER.name||"").trim(); if(!name) return false;
        const norm0=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim(); const u0=norm0(name);
        if(source==="office"){ const o=norm0(String(x.owner||"")); return o===u0||o.includes(u0)||u0.includes(o); }
        if(source==="bch"||source==="ttbtv"||source==="province"){ const o=norm0(String(x.officer_name||x.officer||"")); return o===u0||o.includes(u0)||u0.includes(o); }
        if(source==="a100"){
            try{ if(typeof canEditAction100Task==="function" && canEditAction100Task(x)) return true; }catch(e){}
            const norm=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim(); const u=norm(name);
            const vals=[x.commune_leader,x.unit_name]; return vals.some(v=>{const s=norm(v); return s && (s===u||s.includes(u)||u.includes(s));});
        }
        if(source==="vpub"){
            const norm2=s=>String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim(); const u=norm2(name);
            const vals=[x.unit,x.field,x.leader]; return vals.some(v=>{const s=norm2(v); return s && (s===u||s.includes(u)||u.includes(s));}) || String(x.leader||"").trim()===name;
        }
        return false;
    }

    if (typeof DATA !== "undefined" && DATA.length) {
        DATA.forEach(x => { if(!isOwnedByToken(x,"office")) return; if (isOverdue(x, "office")) pushTask(DAILY_OVERDUE_TASKS, "Văn phòng", x); else if (isSoon(x, "office")) pushTask(DAILY_SOON_TASKS, "Văn phòng", x); });
    }
    if (typeof BCH_TASKS !== "undefined" && BCH_TASKS.length) {
        BCH_TASKS.forEach(x => { if(!isOwnedByToken(x,"bch")) return; if (isOverdue(x, "bch")) pushTask(DAILY_OVERDUE_TASKS, "BCH", x); else if (isSoon(x, "bch")) pushTask(DAILY_SOON_TASKS, "BCH", x); });
    }
    if (typeof TTBTV_TASKS !== "undefined" && TTBTV_TASKS.length) {
        TTBTV_TASKS.forEach(x => { if(!isOwnedByToken(x,"ttbtv")) return; if (isOverdue(x, "ttbtv")) pushTask(DAILY_OVERDUE_TASKS, "TT/BTV", x); else if (isSoon(x, "ttbtv")) pushTask(DAILY_SOON_TASKS, "TT/BTV", x); });
    }
    if (typeof PROV_TASKS !== "undefined" && PROV_TASKS.length) {
        PROV_TASKS.forEach(x => { if(!isOwnedByToken(x,"province")) return; if (isOverdue(x, "province")) pushTask(DAILY_OVERDUE_TASKS, "Tỉnh giao", x); else if (isSoon(x, "province")) pushTask(DAILY_SOON_TASKS, "Tỉnh giao", x); });
    }

    const headers = { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` };
    const soonEndStr = soonEnd.toISOString().slice(0, 10);
    try {
        const [a100, vpub] = await Promise.all([
            fetch(`${SUPABASE_URL}/rest/v1/action_100_days_tasks?select=*&deadline=lt.${soonEndStr}`, { headers }).then(r => r.ok ? r.json() : []).catch(() => []),
            fetch(`${SUPABASE_URL}/rest/v1/vpub_tasks?select=*&deadline=lt.${soonEndStr}`, { headers }).then(r => r.ok ? r.json() : []).catch(() => [])
        ]);
        (a100 || []).forEach(x => { if(!isOwnedByToken(x,"a100")) return; if (isOverdue(x, "a100")) pushTask(DAILY_OVERDUE_TASKS, "KH 100 ngày", x); else if (isSoon(x, "a100")) pushTask(DAILY_SOON_TASKS, "KH 100 ngày", x); });
        (vpub || []).forEach(x => { if(!isOwnedByToken(x,"vpub")) return; if (isOverdue(x, "vpub")) pushTask(DAILY_OVERDUE_TASKS, "VPUB", x); else if (isSoon(x, "vpub")) pushTask(DAILY_SOON_TASKS, "VPUB", x); });
    } catch { }
    return !!(DAILY_OVERDUE_TASKS.length || DAILY_SOON_TASKS.length);
}

function checkDailyOverdueAlert() {
    if (!CURRENT_USER) return;
    const canWarn3 = CURRENT_USER && (CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.scope === "office"));
    if (!canWarn3) return;
    const today = new Date().toISOString().slice(0, 10);
    const lastAlert = localStorage.getItem("last_overdue_alert_date");
    if (lastAlert === today) return;
    refreshDailyWarnTasks().then(has => {
        if (has) {
            const parts = [];
            if (DAILY_OVERDUE_TASKS.length) parts.push(`⏰ Quá hạn: ${DAILY_OVERDUE_TASKS.length}`);
            if (DAILY_SOON_TASKS.length) parts.push(`⏳ Sắp đến hạn: ${DAILY_SOON_TASKS.length}`);
            const summary = parts.join(" | ");
            showToast("warning", "Nhiệm vụ cần xử lý", summary, 10000, { onClick: openDailyWarnModal });
            writeActivity("Cảnh báo nhiệm vụ hàng ngày", { date: today, overdue: DAILY_OVERDUE_TASKS.length, soon: DAILY_SOON_TASKS.length });
        }
        localStorage.setItem("last_overdue_alert_date", today);
    });
}

async function openDailyWarnModal() {
    await refreshDailyWarnTasks();
    const soon = DAILY_SOON_TASKS.map(x => ({ ...x, type: "soon" }));
    if (!soon.length) { showToast("info", "Không có nhiệm vụ", "Hiện tại không có nhiệm vụ sắp đến hạn trong 7 ngày."); return; }
    const wsOrder = { "Văn phòng": 0, "BCH": 1, "TT/BTV": 2, "Tỉnh giao": 3, "KH 100 ngày": 4, "VPUB": 5 };
    soon.sort((a, b) => (wsOrder[a.workspace] ?? 9) - (wsOrder[b.workspace] ?? 9));
    const isAdmin = CURRENT_USER?.role === "admin";
    const sendBtn = document.getElementById("dailyWarnSendBtn");
    const stopBtn = document.getElementById("dailyWarnStopBtn");
    if (sendBtn) sendBtn.style.display = isAdmin ? "" : "none";
    if (stopBtn) stopBtn.style.display = "none";
    const summary = document.getElementById("dailyWarnSummary");
    if (summary) summary.textContent = `${soon.length} nhiệm vụ sắp đến hạn trong 7 ngày`;
    const wrap = document.getElementById("dailyWarnTableWrap");
    if (!wrap) return;
    const savedEmail = localStorage.getItem("user_email") || "";
    wrap.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:13.5px">
                <thead><tr style="background:#f8fafc;border-bottom:2px solid #e2e8f0">
                    <th style="padding:8px 10px;text-align:left;width:50px;white-space:nowrap">STT</th>
                    <th style="padding:8px 10px;text-align:left;width:109px">Workspace</th>
                    <th style="padding:8px 10px;text-align:left">Nhiệm vụ</th>
                    <th style="padding:8px 10px;text-align:left;width:110px">Phụ trách</th>
                    <th style="padding:8px 10px;text-align:left;width:125px">Hạn</th>
                    ${isAdmin ? `<th style="padding:8px 10px;text-align:left;width:198px">Email nhận TB</th>` : ""}
                </tr></thead>
                <tbody>${soon.map((x, i) => `<tr style="border-bottom:1px solid #f1f5f9;background:#fffbeb">
                    <td style="padding:7px 10px">${i + 1}</td>
                    <td style="padding:7px 10px"><span style="background:#e0e7ff;color:#3730a3;padding:2px 7px;border-radius:4px;font-size:12px;font-weight:600">${esc(x.workspace)}</span></td>
                    <td style="padding:7px 10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:320px" title="${esc(x.task_name)}">${esc(x.task_name.length > 60 ? x.task_name.slice(0, 60) + "…" : x.task_name)}</td>
                    <td style="padding:7px 10px">${esc(x.owner)}</td>
                    <td style="padding:7px 10px;color:#d97706;font-weight:600">${esc(formatDate(x.deadline).replaceAll('/','-'))}</td>
                    ${isAdmin ? `<td style="padding:6px 8px"><input type="email" class="daily-warn-email-input" data-index="${i}" value="${esc(savedEmail)}" placeholder="email_cua_dong_chi@gmail.com" style="width:100%;padding:5px 8px;border:1px solid #e2e8f0;border-radius:5px;font-size:12.5px"></td>` : ""}
                </tr>`).join("")}</tbody></table>`;
    smoothOpenModal("dailyWarnModal");
}

let DAILY_WARN_STOPPED = false;
function stopDailyWarnEmails() {
    DAILY_WARN_STOPPED = true;
    const sendBtn = document.getElementById("dailyWarnSendBtn");
    const stopBtn = document.getElementById("dailyWarnStopBtn");
    if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = "📧 Gửi tất cả"; }
    if (stopBtn) stopBtn.style.display = "none";
    showToast("info", "Đã dừng gửi", "Quá trình gửi email đã được dừng lại.");
}
async function sendDailyWarnEmails() {
    const inputs = document.querySelectorAll(".daily-warn-email-input");
    if (!inputs.length) { showToast("info", "Không có nhiệm vụ", "Danh sách trống."); return; }
    const tasksWithEmail = [];
    inputs.forEach((inp, i) => {
        const email = (inp.value || "").trim();
        if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && DAILY_SOON_TASKS[i]) {
            tasksWithEmail.push({ ...DAILY_SOON_TASKS[i], to_email: email });
        }
    });
    if (!tasksWithEmail.length) { showToast("error", "Thiếu email", "Vui lòng nhập ít nhất 1 email hợp lệ."); return; }
    const sendBtn = document.getElementById("dailyWarnSendBtn");
    const stopBtn = document.getElementById("dailyWarnStopBtn");
    const oldText = sendBtn?.textContent;
    DAILY_WARN_STOPPED = false;
    if (sendBtn) sendBtn.disabled = true;
    if (stopBtn) stopBtn.style.display = "inline-flex";
    let sent = 0, failed = 0, stopped = false;
    for (let i = 0; i < tasksWithEmail.length; i++) {
        if (DAILY_WARN_STOPPED) { stopped = true; break; }
        const x = tasksWithEmail[i];
        if (sendBtn) sendBtn.textContent = `Đang gửi ${i + 1}/${tasksWithEmail.length}…`;
        try {
            const body = { to_email: x.to_email, task_name: x.task_name, owner: x.owner, deadline: x.deadline, admin_note: "Nhiệm vụ sắp đến hạn trong 3 ngày" };
            const r = await fetch(`${SUPABASE_URL}/functions/v1/send-email`, { method: "POST", headers: { "Content-Type": "application/json", "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` }, body: JSON.stringify(body) });
            if (r.ok) sent++; else failed++;
        } catch { failed++; }
        if (i < tasksWithEmail.length - 1) await new Promise(r => setTimeout(r, 1200));
    }
    if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = oldText; }
    if (stopBtn) stopBtn.style.display = "none";
    writeActivity("Gửi thông báo email hàng loạt", { sent, failed, total: tasksWithEmail.length, stopped });
    if (stopped) { showToast("warning", "Đã dừng gửi", `Đã gửi ${sent} · Lỗi ${failed}`, 5000); return; }
    showToast(failed ? "warning" : "success", "Hoàn tất gửi email", `Thành công: ${sent} · Lỗi: ${failed}`, 5000);
}

const PROVINCE_PLAN_API = `${SUPABASE_URL}/rest/v1/province_plan_blocks?select=*&order=stt.asc`;
function ppParseDate(s) { const t = String(s || '').trim(); const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) { const d = new Date(+iso[1], +iso[2] - 1, +iso[3]); return isNaN(d) ? null : d; } const p = t.split('/'); if (p.length !== 3) return null; if (!/^\d{4}$/.test(String(p[2]).trim())) return null; const y=+p[2], m=+p[1], day=+p[0]; if(m<1||m>12||day<1||day>31) return null; const d = new Date(y, m - 1, day); if(d.getFullYear()!==y||d.getMonth()!==m-1||d.getDate()!==day) return null; return isNaN(d) ? null : d; }
function ppDateInputVal(v) { const t = String(v || '').trim(); if (!t) return ''; const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`; const m = t.match(/(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/); if (m) return `${m[3]}-${String(m[2]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`; return ''; }
function ppDateDisplayVal(v) { const d = ppParseDate(v); return d ? `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` : ''; }
function ppDispDate(v) { const t = String(v || '').trim(); if (!t) return ''; const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})/); if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`; return t; }


















window.ppAddDoc = function (btn, kind) { if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được thêm văn bản.'); const list = btn.parentElement.nextElementSibling; if (list) list.insertAdjacentHTML('beforeend', ppDocItem()); };
window.ppRemoveDoc = function (btn) { if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được xóa văn bản.'); const row = btn.parentElement; if (row.parentElement.children.length > 1) row.remove(); };
window.ppAddAgency = function (btn) { const task0 = btn.closest('.pp-task'); const wrap = task0 ? task0.querySelector('.pp-agencies') : btn.previousElementSibling; if (!wrap) return; const isFirst = wrap.querySelectorAll('.pp-agency').length === 0; wrap.insertAdjacentHTML('beforeend', ppAgencyBlock(isFirst)); ppNormalizeDateInputs(); const task = btn.closest('.pp-task'); if (task) { ppRefreshAgencyTitles(task); try{ ppBuildTaskTitle(task, task.querySelector('.pp-stt')?.textContent); }catch(e){} } };
window.ppAddPCM = function (btn) {
    const ag = btn.closest('.pp-agency');
    if (!ppIsAdmin() && !ppScope100CanEditAgency(ag)) return showToast('error','Không có quyền','Chỉ cơ quan phụ trách/phối hợp được thêm LĐ PCM.');
    const list = btn.previousElementSibling; if(list && list.style.display==='none') list.style.display=''; list.insertAdjacentHTML('beforeend', ppPCMBlock()); ppNormalizeDateInputs();
};
window.ppTogglePCMList = function(btn){
    const ag = btn.closest('.pp-agency');
    if (!ppIsAdmin() && !ppScope100CanEditAgency(ag) && !btn.previousElementSibling?.children.length) {
        // cho phép mở trống nhưng không tự thêm dòng nếu không có quyền
    }
    const list = btn.previousElementSibling; if(!list) return; const hidden = list.style.display==='none' || !list.style.display && !list.children.length;
    if(hidden || list.style.display==='none'){
        if(!list.children.length && (ppIsAdmin() || ppScope100CanEditAgency(ag))) list.insertAdjacentHTML('beforeend', ppPCMBlock());
        list.style.display=''; btn.textContent='− Thu gọn PCM';
    } else { list.style.display='none'; btn.textContent='+ LĐ PCM'; }
};
window.ppToggleAgencyType = function (sel) { const task = sel.closest('.pp-task'); if (task) ppRefreshAgencyTitles(task); };
window.ppToggleAgency = function (btn) { const ag = btn.closest('.pp-agency'); if (!ag) return; const content = ag.querySelector('.pp-agency-content'); if (!content) return; const hidden = content.style.display === 'none'; content.style.display = hidden ? '' : 'none'; btn.textContent = hidden ? 'Thu gọn' : 'Mở rộng'; btn.classList.toggle('open', hidden); try{ const task=ag.closest('.pp-task'); if(task) ppRefreshAgencyTitles(task); }catch(e){} };
window.ppToggleAgencyGroup = function(btn){ const ag=btn.closest('.pp-agency'); if(!ag) return; const grp=ag.querySelector('.pp-agency-group'); if(!grp) return; const hidden=grp.style.display==='none'; grp.style.display=hidden?'':'none'; btn.textContent=hidden?'Ẩn cơ quan':'Hiện cơ quan'; try{ ppUpdateAll(); }catch(e){} };

window.ppHandleAgencyOtherChange = async function (sel) {
    if (!sel) return;
    if (sel.value !== '__other__') { sel.dataset.prev = sel.value; try { ppSyncAgencyLeader(sel); } catch (e) {} return; }
    const prev = sel.dataset.prev || '';
    const isPerson = sel.getAttribute('data-k') === 'name';
    const title = isPerson ? 'Nhập tên cán bộ' : 'Nhập tên cơ quan khác';
    const placeholder = isPerson ? 'Nhập tên cán bộ...' : 'Nhập tên cơ quan khác...';
    const message = isPerson ? 'Vui lòng nhập tên cán bộ không có trong danh sách' : 'Vui lòng nhập tên cơ quan không có trong danh sách';
    const icon = isPerson ? '👤' : '🏢';
    const bodyHtml = `<div style="margin-top:4px"><input id="customAgencyInput" type="text" placeholder="${placeholder}" maxlength="80" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none;transition:border-color .15s,box-shadow .15s" onfocus="this.style.borderColor='#10b981';this.style.boxShadow='0 0 0 3px rgba(16,185,129,.14)'" onblur="this.style.borderColor='#cbd5e1';this.style.boxShadow='none'" /></div><div style="font-size:11px;color:#94a3b8;margin-top:6px">Nhấn <b>Thêm</b> để lưu vào danh sách • Enter để xác nhận</div>`;
    setTimeout(() => { const inp = document.getElementById('customAgencyInput'); if (inp) { inp.focus(); try{ const len=inp.value.length; inp.setSelectionRange(len,len);}catch(_){} inp.addEventListener('keydown', function _h(e) { if (e.key === 'Enter') { e.preventDefault(); document.getElementById('provinceConfirmOkBtn')?.click(); } }); } }, 120);
    const ok = await provinceConfirm({ icon, title, message, bodyHtml, confirmText: 'Thêm', cancelText: 'Hủy', confirmClass: 'btn-primary' });
    const inp2 = document.getElementById('customAgencyInput');
    const custom = inp2 ? inp2.value.trim() : '';
    if (ok && custom) {
        let exists = [...sel.options].some(o => o.value === custom);
        if (!exists) {
            const opt = document.createElement('option');
            opt.value = custom;
            opt.textContent = custom;
            const otherOpt = [...sel.options].find(o => o.value === '__other__');
            if (otherOpt) sel.insertBefore(opt, otherOpt); else sel.appendChild(opt);
        }
        sel.value = custom;
        sel.dataset.prev = custom;
    } else {
        if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
        else if (sel.options.length) sel.selectedIndex = 0;
        if (sel.value === '__other__') sel.selectedIndex = 0;
    }
    try { ppSyncAgencyLeader(sel); } catch (e) {}
};

window.ppDeleteTask = async function (btn) {
    if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được xóa.');
    const task = btn.closest('.pp-task'); if (!task) return;
    const title = (task.querySelector('[data-k=nhiemvu]')?.innerText.trim() || task.querySelector('[data-k=agencyTask]')?.value.trim() || '');
    const stt = task.querySelector('.pp-stt')?.textContent || '';
    const name = title ? title.slice(0, 60) : `Nhiệm vụ ${stt}`;
    const ok = await provinceConfirm({ icon: '🗑️', title: 'Xác nhận xóa nhiệm vụ', message: `Bạn có muốn xóa nhiệm vụ ${stt ? '#' + stt : ''} "${name}"?`, bodyHtml: `<div style="font-size:12px;color:#64748b;background:#fff7f7;border:1px solid #fecdd3;border-radius:8px;padding:8px 10px">Sẽ xóa khỏi giao diện — bấm <b>Xác nhận lưu Supabase</b> để xóa vĩnh viễn trên DB.</div>`, confirmText: 'Xóa', cancelText: 'Hủy', confirmClass: 'btn-danger' });
    if (!ok) return;
    const id = task.dataset.id;
    if (id) {
        fetch(`${SUPABASE_URL}/rest/v1/province_plan_blocks?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE', headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }).catch(() => { });
    }
    task.remove(); ppUpdateSTT(); ppUpdateAll(); try { applyProvincePlanTreeFilter(); } catch (e) { }
    showToast('success', 'Đã xóa', `Đã xóa ${name}`);
    try { writeActivity('Tỉnh giao - Xóa nhiệm vụ', { stt, title: name }); } catch (e) { }
};
window.ppRemoveAgency = async function (btn) {
    if (!ppIsAdmin()) return showToast('error', 'Không có quyền', 'Chỉ Admin được xóa cơ quan.');
    const ag = btn.closest('.pp-agency'); const task = btn.closest('.pp-task'); if (!ag) return;
    const label = ag.querySelector('[data-k=agencyTypeLabel]')?.textContent || 'Cơ quan';
    const name = ag.querySelector('[data-k=agencyOther]')?.value.trim() || '';
    const ok = await provinceConfirm({ icon: '🏢', title: 'Xác nhận xóa cơ quan', message: `Bạn có muốn xóa ${label}${name ? ' "' + name.slice(0, 40) + '"' : ''} khỏi nhiệm vụ này?`, confirmText: 'Xóa', cancelText: 'Hủy', confirmClass: 'btn-danger' });
    if (!ok) return;
    ag.remove(); if (task) { ppRefreshAgencyTitles(task); ppUpdateSTT(); ppUpdateAll(); }
};
window.ppToggleTask = function (btn) {
    const task = btn.closest('.pp-task'); const body = task.querySelector('.pp-task-body'); const hid = body.style.display === 'none';
    const header = task.firstElementChild;
    const oldTop = header ? header.getBoundingClientRect().top : 0;
    if (hid) {
        document.querySelectorAll('#provincePlanTree .pp-task').forEach(other => {
            if (other === task) return;
            const ob = other.querySelector('.pp-task-body'); if (!ob || ob.style.display === 'none') return;
            ob.style.display = 'none';
            const obBtn = other.querySelector('button[onclick="ppToggleTask(this)"]'); if (obBtn) obBtn.textContent = '▶';
            const osum = other.querySelector('.pp-summary'); if (osum) osum.style.display = 'none';
            try { ppTaskHeaderStatus(other); } catch (e) { }
        });
        const portal = document.getElementById('ppFixedTip'); if (portal) { portal.style.display = 'none'; portal.style.opacity = '0'; portal.style.visibility = 'hidden'; }
    }
    body.style.display = hid ? '' : 'none'; btn.textContent = hid ? '▼' : '▶';
    if (hid && header) {
        const newTop = header.getBoundingClientRect().top;
        const delta = newTop - oldTop;
        if (delta !== 0) window.scrollBy({ top: delta, behavior: 'auto' });
    }
    const titleEl = task.querySelector('.pp-task-title'); const sttEl = task.querySelector('.pp-stt'); const stt = sttEl ? sttEl.textContent : '';     const b2 = ppBuildTaskTitle(task, stt); if (titleEl) { if (!titleEl.dataset.orig) titleEl.dataset.orig = titleEl.innerHTML; titleEl.textContent = b2.disp; titleEl.removeAttribute('title'); }
    ppTaskHeaderStatus(task); ppSyncTaskRoleUI(task);
    let sum = task.querySelector('.pp-summary'); if (!hid) {
        const nh = task.querySelector('[data-k=nhiemvu]')?.innerText.trim() || task.querySelector('[data-k=agencyTask]')?.value.trim() || 'Chưa nhập'; const mo = task.querySelector('[data-k=mota]')?.innerText.trim() || ''; const agsEls = [...task.querySelectorAll('.pp-agency')]; const ags = agsEls.length; const deadlines = [...task.querySelectorAll('.pp-person [data-k=deadline]')].map(i => i.value.trim()).filter(Boolean); const han = ppDispDate(deadlines[0] || ''); if (!sum) { sum = document.createElement('div'); sum.className = 'pp-summary'; task.insertBefore(sum, body); }
        const vbTinhRaw = [...task.querySelectorAll('.pp-docs-tinh div[contenteditable="true"], .pp-docs-tinh div[contenteditable="false"]')].map(d => (d.textContent || d.innerText || '').trim()).filter(Boolean).join(', ');
        const vbXaRaw = [...task.querySelectorAll('.pp-docs-xa div[contenteditable="true"], .pp-docs-xa div[contenteditable="false"]')].map(d => (d.textContent || d.innerText || '').trim()).filter(Boolean).join(', ');
        const vbTinh = ppShortDoc(vbTinhRaw);
        const vbXa = ppShortDoc(vbXaRaw);
        let extra = '';
        if (vbTinh || vbXa) { extra = `<br><span style="color:#64748b;font-size:11px">` + (vbTinh ? `Tỉnh: ${esc(vbTinh)}` : '') + (vbTinh && vbXa ? ' | ' : '') + (vbXa ? `Xã: ${esc(vbXa)}` : '') + `</span>`; }
        const brief = esc(nh.slice(0, 60) + (nh.length > 60 ? '…' : '')) + (mo ? ' — ' + esc(mo.slice(0, 40)) : '') + ` — ${ags} cơ quan` + (han ? ` — Hạn: ${han}` : '') + extra;
        // tooltip full data
        const fullNh = esc(nh);
        const fullMo = mo ? esc(mo) : '';
        const chuTri = agsEls[0]?.querySelector('[data-k=agencyOther]')?.value.trim() || agsEls[0]?.querySelector('[data-k=agencyTask]')?.value.trim() || '—';
        const phoihopList = agsEls.slice(1).map(a => (a.querySelector('[data-k=agencyOther]')?.value.trim() || a.querySelector('[data-k=agencyTask]')?.value.trim() || '').trim()).filter(Boolean);
        const phoihop = phoihopList.length ? esc(phoihopList.join(', ')) : '<span style="color:#94a3b8">—</span>';
        const vbTinhFull = vbTinhRaw ? esc(ppShortDoc(vbTinhRaw)) : '<span style="color:#94a3b8">—</span>';
        const vbXaFull = vbXaRaw ? esc(ppShortDoc(vbXaRaw)) : '<span style="color:#94a3b8">—</span>';
        // Hạn & tiến độ: collect per person
        const persons = [...task.querySelectorAll('.pp-person')];
        const hanTiendo = persons.length ? persons.map(r => { const n = r.querySelector('[data-k=name]')?.value.trim() || ''; const dl = ppDispDate(r.querySelector('[data-k=deadline]')?.value.trim() || '') || '—'; const prog = r.querySelector('[data-k=progress]')?.value.trim() || '—'; const label = r.querySelector('span')?.innerText.trim() || ''; return `${n ? esc(n) + ' ' : ''}<span style="color:#6366f1">${esc(dl)}</span> · <span style="color:#059669">${esc(prog)}</span> <span style="color:#94a3b8;font-size:11px">(${esc(label)})</span>`; }).slice(0, 4).join('<br>') + (persons.length > 4 ? `<div style="color:#94a3b8;font-size:11px;margin-top:4px">+${persons.length - 4} người khác…</div>` : '') : '<span style="color:#94a3b8">—</span>';
        const tip = `<div class="pp-summary-tip" role="tooltip"><div class="pp-tip-head">📋 Nhiệm vụ</div><div class="pp-tip-row"><span class="pp-tip-label">Nhiệm vụ chính</span><span class="pp-tip-val">${fullNh}${fullMo ? '<br><span style="color:#64748b;font-size:12px">' + fullMo + '</span>' : ''}</span></div><div class="pp-tip-row"><span class="pp-tip-label">Cơ quan</span><span class="pp-tip-val"><span style="display:inline-flex;align-items:center;gap:6px"><span style="background:#dbeafe;color:#1e40af;padding:2px 10px;border-radius:999px;font-size:11px;font-weight:700;border:1px solid #93c5fd;white-space:nowrap;flex:0 0 auto;min-width:64px;text-align:center;justify-content:center;display:inline-flex;align-items:center">Chủ trì</span>${esc(chuTri.slice(0, 60))}</span>${phoihopList.length ? '<br><span style="display:inline-flex;align-items:center;gap:6px;margin-top:6px"><span style="background:#ffedd5;color:#9a3412;padding:2px 10px;border-radius:999px;font-size:11px;font-weight:700;border:1px solid #fed7aa;white-space:nowrap;flex:0 0 auto;min-width:68px;text-align:center;justify-content:center;display:inline-flex;align-items:center">Phối hợp</span>' + phoihop + '</span>' : ''}</span></div><div class="pp-tip-row two"><span class="pp-tip-cell"><span class="pp-tip-label">Văn bản tỉnh</span><span class="pp-tip-val">${vbTinhFull}</span></span><span class="pp-tip-cell"><span class="pp-tip-label">Văn bản xã</span><span class="pp-tip-val">${vbXaFull}</span></span></div><div class="pp-tip-row"><span class="pp-tip-label">Hạn hoàn thành — Tiến độ</span><span class="pp-tip-val" style="line-height:1.6">${hanTiendo}</span></div></div>`;
        sum.innerHTML = `<span class="pp-summary-text">${brief}</span>` + tip;
        sum.style.display = '';
        ppTaskHeaderStatus(task); ppSyncTaskRoleUI(task);
        // portal tooltip fixed to avoid clipping at viewport edge / workspace overflow
        if (!sum._tipBound) {
            sum._tipBound = true;
            const show = () => {
                const tip = sum.querySelector('.pp-summary-tip'); if (!tip) return;
                let portal = document.getElementById('ppFixedTip');
                if (!portal) {
                    portal = document.createElement('div');
                    portal.id = 'ppFixedTip';
                    portal.style.cssText = 'position:fixed;z-index:99999;display:none;max-width:520px;pointer-events:none';
                    document.body.appendChild(portal);
                    // keep portal alive when hovering it (for long content)
                    portal.addEventListener('mouseenter', () => { portal._hover = true; });
                    portal.addEventListener('mouseleave', () => {
                        portal._hover = false;
                        // hide after short delay if not hovering summary
                        setTimeout(() => {
                            const s = sum; // closure sum of last show, but we need global check
                            if (!portal._hover && !portal._sumHover) hide();
                        }, 120);
                    });
                    portal.addEventListener('wheel', (e) => { e.stopPropagation(); }, { passive: false });
                }
                portal.innerHTML = tip.innerHTML;
                portal.className = tip.className;
                // detect long content
                const isLong = (tip.innerText || '').length > 400 || tip.scrollHeight > 260 || portal.scrollHeight > 260;
                const pe = isLong ? 'auto' : 'none';
                portal.style.cssText = 'position:fixed;z-index:99999;display:block;opacity:0;visibility:hidden;pointer-events:' + pe + ';max-width:min(520px,92vw);max-height:min(72vh,560px);overflow:auto;overscroll-behavior:contain';
                // measure
                const r = sum.getBoundingClientRect();
                let th = portal.offsetHeight, tw = portal.offsetWidth;
                const vh = window.innerHeight, vw = window.innerWidth;
                const maxH = Math.min(560, vh - 16);
                if (th > maxH) { portal.style.maxHeight = maxH + 'px'; portal.style.overflow = 'auto'; th = maxH; }
                let top = r.bottom + 10, left = r.left;
                const needFlip = top + th + 8 > vh;
                if (needFlip) {
                    const topFlip = r.top - th - 10;
                    if (topFlip >= 8) top = topFlip;
                    else {
                        top = Math.max(8, vh - th - 8);
                        portal.style.maxHeight = (vh - 16) + 'px';
                        portal.style.overflow = 'auto';
                    }
                }
                if (left + tw > vw - 12) left = vw - tw - 12;
                if (left < 8) left = 8;
                portal.style.left = left + 'px';
                portal.style.top = top + 'px';
                portal.style.opacity = '1';
                portal.style.visibility = 'visible';
                portal.style.display = 'block';
                portal.style.pointerEvents = pe;
                portal._isLong = isLong;
                portal._sumHover = true;
                sum._portal = portal;
                // store current sum rect for distance check
                portal._sumRect = r;
            };
            const hide = () => {
                const p = document.getElementById('ppFixedTip');
                if (!p) return;
                if (p._isLong && p._hover) return; // keep when hovering tooltip
                // check distance: only hide when mouse far from both
                p.style.display = 'none'; p.style.opacity = '0'; p.style.visibility = 'hidden'; p._sumHover = false;
            };
            sum._show = show; sum._hide = hide;
            const hideFar = (e) => {
                const p = document.getElementById('ppFixedTip');
                if (!p || p.style.display === 'none') return;
                if (p._isLong && p._hover) return;
                const r = sum.getBoundingClientRect();
                const pr = p.getBoundingClientRect();
                const x = e.clientX, y = e.clientY;
                const nearSum = x >= r.left - 40 && x <= r.right + 40 && y >= r.top - 20 && y <= r.bottom + 20;
                const nearTip = x >= pr.left - 60 && x <= pr.right + 60 && y >= pr.top - 60 && y <= pr.bottom + 60;
                if (!nearSum && !nearTip) {
                    hide();
                }
            };
            // chỉ mắt mới hiện tooltip, sum không tự hiện
            sum.addEventListener('mouseenter', () => { });
            sum.addEventListener('mouseleave', () => { });
            sum.addEventListener('mousemove', () => { });
            if (!window._ppTooltipGlobalBound) {
                window._ppTooltipGlobalBound = true; document.addEventListener('mousemove', (e) => {
                    const p = document.getElementById('ppFixedTip'); if (!p || p.style.display === 'none') return;
                    if (p._isLong && p._hover) return;
                    const r = p._sumRect; if (!r) return;
                    const pr = p.getBoundingClientRect(); const x = e.clientX, y = e.clientY;
                    const nearSum = x >= r.left - 40 && x <= r.right + 40 && y >= r.top - 20 && y <= r.bottom + 20;
                    const nearTip = x >= pr.left - 60 && x <= pr.right + 60 && y >= pr.top - 60 && y <= pr.bottom + 60;
                    if (!nearSum && !nearTip) { p.style.display = 'none'; p.style.opacity = '0'; p.style.visibility = 'hidden'; p._sumHover = false; }
                });
            }
        }
    } else if (sum) sum.style.display = 'none';
    ppSyncTaskRoleUI(task);
};




function ppNormalizeDateInputs() { document.querySelectorAll('#provincePlanTree input.date-ddmmyyyy').forEach(el => { const raw = el.value || ''; if (el.type !== 'text') el.type = 'text'; if (raw) { const isIso = /^\d{4}-\d{2}-\d{2}/.test(raw); const isFullDMY = /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(raw.trim()); if(isIso||isFullDMY){ const fmt = ppDateDisplayVal(raw); if (fmt && fmt !== raw) el.value = fmt; } } el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric'; if(!el._ppBound){ el._ppBound=true; el.addEventListener('input', () => { dateMask(el); try{ ppUpdateAll(); }catch(e){} }); el.addEventListener('blur', () => { const v=(el.value||'').trim(); if(!v) return; const d=ppParseDate(v); if(d){ const fmt=ppDateDisplayVal(v); if(fmt) el.value=fmt; } }); } }); }
window.ppOpenDatePicker = function (btn) {
    const wrap = btn ? btn.parentElement : null;
    const inp = wrap ? wrap.querySelector('input.date-ddmmyyyy') : null;
    if (!inp || inp.disabled || inp.readOnly) return;
    if (document.getElementById('ppCalPop') && ppCalState && ppCalState.inp === inp) { ppCloseCal(); return; }
    let sel = ppParseDate((inp.value || '').trim());
    if (!sel) { const t = new Date(); sel = new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
    ppCalState = { inp: inp, btn: btn, y: sel.getFullYear(), m: sel.getMonth(), selDate: ppParseDate((inp.value || '').trim()) };
    ppRenderCal();
};
let ppCalState = null;
function vpubWrapDateInput(el) {
    if (!el || el.dataset.calWrapped) return;
    el.dataset.calWrapped = '1';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:100%;box-sizing:border-box';
    el.parentElement.insertBefore(wrap, el);
    wrap.appendChild(el);
    el.style.paddingRight = '26px';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pp-date-btn'; b.title = 'Chọn ngày'; b.textContent = '📅';
    b.style.cssText = 'position:absolute;right:2px;top:50%;transform:translateY(-50%);border:none;background:transparent;cursor:pointer;font-size:14px;line-height:1;padding:2px 4px';
    b.onclick = function () { vpubOpenDatePicker(b); };
    wrap.appendChild(b);
}
window.vpubOpenDatePicker = function (btn) {
    const wrap = btn ? btn.parentElement : null;
    const inp = wrap ? wrap.querySelector('input') : null;
    if (!inp || inp.disabled || inp.readOnly) return;
    if (document.getElementById('ppCalPop') && ppCalState && ppCalState.inp === inp) { ppCloseCal(); return; }
    let sel = ppParseDate((inp.value || '').trim());
    if (!sel) { const t = new Date(); sel = new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
    ppCalState = { inp: inp, btn: btn, y: sel.getFullYear(), m: sel.getMonth(), selDate: ppParseDate((inp.value || '').trim()),
        onPick: function (val, ref) {
            ref.value = val;
            if (ref.id === 'action100EditDue' || ref.id === 'action100EditCompleted') { try { if (typeof refreshAction100EditMeta === 'function') refreshAction100EditMeta(); } catch (e) {} }
            try { ref.focus({ preventScroll: true }); } catch (_) {}
        } };
    ppRenderCal();
};

window.ttbtvOpenDatePicker = function (btn) {
    const wrap = btn ? btn.parentElement : null;
    const inp = wrap ? wrap.querySelector('input') : null;
    if (!inp || inp.disabled || inp.readOnly) return;
    if (document.getElementById('ppCalPop') && ppCalState && ppCalState.inp === inp) { ppCloseCal(); return; }
    let sel = ppParseDate((inp.value || '').trim());
    if (!sel) { const t = new Date(); sel = new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
    ppCalState = { inp: inp, btn: btn, y: sel.getFullYear(), m: sel.getMonth(), selDate: ppParseDate((inp.value || '').trim()),
        onPick: function (val, ref) {
            ref.value = val;
            try {
                const _id = ref.id || "";
                if (_id === 'ttbtvAddDeadline' || _id === 'ttbtvAddCompleted') { if (typeof refreshTTBTVAddStatus === 'function') refreshTTBTVAddStatus(); }
                else if (_id.indexOf('ttbtvRole') === 0 || _id.indexOf('ttbtvNew') === 0) { if (typeof refreshTTBTVNewStatus === 'function') refreshTTBTVNewStatus(); }
                else if (typeof refreshTTBTVAutoStatus === 'function') refreshTTBTVAutoStatus();
            } catch (e) {}
            try { ref.focus({ preventScroll: true }); } catch (_) {}
        } };
    ppRenderCal();
};



function setupTTBTVDateFields() {
    const map = { ttbtvAddDeadline: 'add', ttbtvAddCompleted: 'add', ttbtvNewDeadline: 'new', ttbtvNewCompleted: 'new', ttbtvEditDue: 'edit', ttbtvEditCompleted: 'edit', ttbtvRoleUBNDDue: 'new', ttbtvRoleUBNDDone: 'new', ttbtvRolePhongDue: 'new', ttbtvRolePhongDone: 'new', ttbtvRoleCVDue: 'new', ttbtvRoleCVDone: 'new', ttbtvEditRoleUBNDDue: 'edit', ttbtvEditRoleUBNDDone: 'edit', ttbtvEditRolePhongDue: 'edit', ttbtvEditRolePhongDone: 'edit', ttbtvEditRoleCVDue: 'edit', ttbtvEditRoleCVDone: 'edit' };
    Object.keys(map).forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        if (el.type !== 'text') el.type = 'text';
        el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric';
        el.oninput = () => { dateMask(el); try { if (id === 'ttbtvRoleUBNDDone' || id === 'ttbtvRolePhongDone') { try { ttbtvSyncMainDatesFromLeader('new'); } catch(e){} } else if (id === 'ttbtvEditRoleUBNDDone' || id === 'ttbtvEditRolePhongDone') { try { ttbtvSyncMainDatesFromLeader('edit'); } catch(e){} } if (map[id] === 'add') refreshTTBTVAddStatus(); else if (map[id] === 'new') refreshTTBTVNewStatus(); else refreshTTBTVAutoStatus(); } catch (e) {} };
        if (typeof ttbtvWrapDateInput === 'function') ttbtvWrapDateInput(el);
    });
}
function bchWrapDateInput(el) {
    if (!el || el.dataset.calWrapped) return;
    el.dataset.calWrapped = '1';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:100%;box-sizing:border-box';
    el.parentElement.insertBefore(wrap, el);
    wrap.appendChild(el);
    el.style.paddingRight = '26px';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pp-date-btn'; b.title = 'Chọn ngày'; b.textContent = '📅';
    b.style.cssText = 'position:absolute;right:2px;top:50%;transform:translateY(-50%);border:1px solid #cbd5e1;background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);border-radius:6px;cursor:pointer;font-size:13px;line-height:1;padding:3px 5px;box-shadow:0 1px 2px rgba(15,23,42,.08)';
    b.onmouseover = function(){ this.style.background='#e0f2fe'; this.style.borderColor='#7dd3fc'; };
    b.onmouseout = function(){ this.style.background='linear-gradient(180deg,#fff 0%,#f8fafc 100%)'; this.style.borderColor='#cbd5e1'; };
    b.onclick = function () { bchOpenDatePicker(b); };
    wrap.appendChild(b);
}
window.bchOpenDatePicker = function (btn) {
    const wrap = btn ? btn.parentElement : null;
    const inp = wrap ? wrap.querySelector('input') : null;
    if (!inp || inp.disabled || inp.readOnly) return;
    if (document.getElementById('ppCalPop') && ppCalState && ppCalState.inp === inp) { ppCloseCal(); return; }
    let sel = parseDate((inp.value || '').trim()) || bchDeadlineDate((inp.value || '').trim());
    if (!sel) { const t = new Date(); sel = new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
    ppCalState = { inp: inp, btn: btn, y: sel.getFullYear(), m: sel.getMonth(), selDate: parseDate((inp.value || '').trim()) || bchDeadlineDate((inp.value || '').trim()),
        onPick: function (val, ref) {
            ref.value = val;
            try {
                if (ref.id === 'bchAddDeadline' || ref.id === 'bchAddCompleted') { if (typeof refreshBCHAddStatus === 'function') refreshBCHAddStatus(); }
                else if (ref.id === 'bchNewDeadline' || ref.id === 'bchNewCompleted') { if (typeof refreshBCHNewStatus === 'function') refreshBCHNewStatus(); }
                else if (typeof refreshBCHAutoStatus === 'function') refreshBCHAutoStatus();
            } catch (e) {}
            try { ref.focus({ preventScroll: true }); } catch (_) {}
        } };
    ppRenderCal();
};
function bchDateDisplay(v, fallback) { const s = String(v ?? '').trim(); if (!s) return fallback; return /^\d{4}-\d{2}-\d{2}/.test(s) ? formatDate(s) : s; }
function setupBCHDateFields() {
    const map = { bchAddDeadline: 'add', bchAddCompleted: 'add', bchNewDeadline: 'new', bchNewCompleted: 'new', bchEditDue: 'edit', bchEditCompleted: 'edit' };
    Object.keys(map).forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        if (el.type !== 'text') el.type = 'text';
        el.placeholder = 'dd/mm/yyyy'; el.inputMode = 'numeric';
        el.oninput = () => { dateMask(el); try { if (map[id] === 'add') refreshBCHAddStatus(); else if (map[id] === 'new') refreshBCHNewStatus(); else refreshBCHAutoStatus(); } catch (e) {} };
        if (typeof bchWrapDateInput === 'function') bchWrapDateInput(el);
    });
}
document.addEventListener('DOMContentLoaded', function(){ try{ setupBCHDateFields(); }catch(e){} });



;



window.ppEditTask = function (btn) {
    const t = btn.closest('.pp-task'); const body = t.querySelector('.pp-task-body'); body.style.display = ''; // mở
    if (!ppCanEditProvinceTask(t)) return showToast('error', 'Không có quyền', 'Chỉ Admin hoặc cơ quan phụ trách/phối hợp được sửa Tỉnh giao.');
    if (ppIsAdmin()) { t.querySelectorAll('[contenteditable]').forEach(e => e.setAttribute('contenteditable', 'true')); t.querySelectorAll('input, textarea, select').forEach(e => { e.readOnly = false; e.disabled = false; }); }
    else { t.querySelectorAll('.pp-agency').forEach(ag=>{ const canAG=ppScope100CanEditAgency(ag); ag.querySelectorAll('.pp-person').forEach(row=>{ if(canAG){ const nameEl=row.querySelector('[data-k=name]'), finishEl=row.querySelector('[data-k=finish]'), productEl=row.querySelector('[data-k=product]'), progressEl=row.querySelector('[data-k=progress]'), reasonEl=row.querySelector('[data-k=reason]'); [nameEl, finishEl, productEl, progressEl, reasonEl].forEach(el=>{ if(el){ el.readOnly=false; el.disabled=false; } }); const deadlineEl=row.querySelector('[data-k=deadline]'); if(deadlineEl){ deadlineEl.readOnly=true; deadlineEl.disabled=true; } } else { row.querySelectorAll('input, textarea, select').forEach(el=>{ el.readOnly=true; el.disabled=true; }); } }); }); }
    showToast('info', 'Chế độ sửa', 'Bạn đang sửa nhiệm vụ này, nhớ Xác nhận lưu.'); ppSyncTaskRoleUI(t);
};
function ppNorm(s){ return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase().trim(); }
function ppInitials(s){ const n=ppNorm(s); if(!n.includes(' ') && n.length<=6 && /^[a-z0-9]+$/.test(n)) return n; return n.split(/[^a-z0-9]+/).filter(Boolean).map(w=>w[0]).join(''); }
// Tỉnh giao: token được sửa nếu tên của mình xuất hiện trong cây (vd: Lãnh đạo Trần Văn Hùng -> CB-MAUA-***)
function applyProvincePlanTreeFilter() {
    const q = provinceFold(document.getElementById('provinceSearch')?.value || '');
    const agency = provinceFold(document.getElementById('provinceOfficerFilter')?.value || '');
    const status = document.getElementById('provinceStatusFilter')?.value || 'all';
    const timeMode = document.getElementById('provinceTimeFilter')?.value || 'all';
    const tree = document.getElementById('provincePlanTree'); if (!tree) return;
    const statusMap = { processing: 'doing', done: 'done', overdue: 'overdue' };
    const needKey = statusMap[status] || status;
    tree.querySelectorAll('.pp-task').forEach(task => {
        let show = true;
        if (q) {
            const txt = provinceFold([
                task.querySelector('[data-k=nhiemvu]')?.innerText || '',
                task.querySelector('[data-k=mota]')?.innerText || '',
                ...[...task.querySelectorAll('.pp-docs-tinh div[contenteditable]')].map(d => d.innerText),
                ...[...task.querySelectorAll('.pp-docs-xa div[contenteditable]')].map(d => d.innerText),
                ...[...task.querySelectorAll('[data-k=agencyOther]')].map(i => i.value),
                ...[...task.querySelectorAll('[data-k=agencyTask]')].map(i => i.value),
                ...[...task.querySelectorAll('.pp-person [data-k=name]')].map(i => i.value),
                ...[...task.querySelectorAll('.pp-person [data-k=product]')].map(i => i.value),
                ...[...task.querySelectorAll('.pp-person [data-k=progress]')].map(i => i.value),
                ...[...task.querySelectorAll('.pp-person [data-k=reason]')].map(i => i.value)
            ].join(' '));
            if (!txt.includes(q)) show = false;
        }
        if (show && agency) {
            const agencies = [...task.querySelectorAll('.pp-agency')].map(ag => provinceFold(ag.querySelector('[data-k=agencyOther]')?.value || ag.querySelector('[data-k=agency]')?.value || '')).filter(Boolean);
            if (!agencies.some(a => a === agency || a.includes(agency))) show = false;
        }
        if (show && status !== 'all') {
            const key = task.dataset.statusKey || 'doing';
            if (key !== needKey) show = false;
        }
        if (show && timeMode !== 'all') {
            const raw = task.dataset.createdAt || "";
            const d = raw ? new Date(raw) : null;
            if (d && !isNaN(d) && !isDateInTimeRange(d, timeMode)) show = false;
        }
        if (show && typeof PROV_MONTH !== "undefined" && PROV_MONTH) {
            const hasMonth = [...task.querySelectorAll('.pp-person [data-k=deadline]')].some(inp => {
                try{ const dd = ppParseDate(inp.value || ''); return dd && (dd.getMonth()+1)===PROV_MONTH; }catch(e){ return false; }
            });
            // nếu task chưa có deadline nào thì ẩn khi đang lọc tháng
            if (!hasMonth) show = false;
        }
        task.style.display = show ? '' : 'none';
    });
    try { renderPROVKPIs(); } catch (e) { }
}





window.toggleProvinceOldList = function () {
    const card = document.getElementById('provinceOldCard');
    const btn = document.getElementById('provinceToggleOldBtn');
    if (!card) return;
    const isHidden = window.getComputedStyle(card).display === 'none';
    if (isHidden) { card.style.removeProperty('display'); } else { card.style.setProperty('display', 'none', 'important'); }
    if (btn) btn.textContent = isHidden ? '👁 Ẩn danh sách cũ' : '👁 Hiện danh sách cũ';
    try { localStorage.setItem('provinceOldListHidden', isHidden ? '0' : '1'); } catch { }
}
function initProvinceOldToggle() {
    try {
        const h = localStorage.getItem('provinceOldListHidden');
        const c = document.getElementById('provinceOldCard');
        const b = document.getElementById('provinceToggleOldBtn');
        if (!c || !b) return false;
        b.removeAttribute('onclick');
        if (h === '1') { c.style.setProperty('display', 'none', 'important'); b.textContent = '👁 Hiện danh sách cũ'; }
        else { c.style.removeProperty('display'); b.textContent = '👁 Ẩn danh sách cũ'; }
        if (!b._bound) {
            b._bound = true;
            b.addEventListener('click', (e) => { e.preventDefault(); window.toggleProvinceOldList(); });
        }
        return true;
    } catch (e) { console.warn('toggle init', e); return false; }
}
if (document.readyState === 'loading') { window.addEventListener('DOMContentLoaded', initProvinceOldToggle); } else { initProvinceOldToggle(); }
setTimeout(initProvinceOldToggle, 900);








let PROVINCE_CONFIRM_RESOLVE = null;
function openProvinceConfirm({ icon = '💾', title = 'Xác nhận', message = '', bodyHtml = '', confirmText = 'Xác nhận', cancelText = 'Hủy', confirmClass = 'btn-primary' } = {}) {
    const m = document.getElementById('provinceConfirmModal'); if (!m) return;
    const ic = document.getElementById('provinceConfirmIcon'); if (ic) ic.textContent = icon;
    const ti = document.getElementById('provinceConfirmTitle'); if (ti) ti.textContent = title;
    const me = document.getElementById('provinceConfirmMessage'); if (me) me.textContent = message;
    const body = document.getElementById('provinceConfirmBody'); if (body) { if (bodyHtml) { body.innerHTML = bodyHtml; body.style.display = ''; } else { body.innerHTML = ''; body.style.display = 'none'; } }
    const ok = document.getElementById('provinceConfirmOkBtn'); if (ok) { ok.textContent = confirmText; ok.className = confirmClass; }
    const ca = document.getElementById('provinceConfirmCancelBtn'); if (ca) ca.textContent = cancelText;
    smoothOpenModal('provinceConfirmModal');
}
function closeProvinceConfirm(ok) {
    smoothCloseModal('provinceConfirmModal');
    if (PROVINCE_CONFIRM_RESOLVE) { const fn = PROVINCE_CONFIRM_RESOLVE; PROVINCE_CONFIRM_RESOLVE = null; fn(!!ok); }
}

setTimeout(() => { const tree = document.getElementById('provincePlanTree'); if (tree) { provincePlanLoad(); tree.addEventListener('input', debounce(ppUpdateAll,150)); tree.addEventListener('change', debounce(ppUpdateAll,150)); tree.addEventListener('paste', ppPastePlain); tree.addEventListener('click', (e) => { if (e.target.closest('input, textarea, [contenteditable="true"]')) e.stopPropagation(); }); } const pc = document.getElementById('provinceConfirmModal'); if (pc) { pc.addEventListener('click', (e) => { if (e.target === pc) closeProvinceConfirm(false); }); } }, 800);
// Debounce tìm kiếm giữ hiệu ứng đẹp, không block gõ
(function(){
  const setup=()=>{
    const si=document.getElementById('searchInput');
    if(si && !si.dataset.debounced){
      si.dataset.debounced='1';
      si.removeAttribute('onkeyup');
      si.addEventListener('input', debounce(()=>{ try{applyFilters();}catch(e){} },280));
    }
    const oqf=document.getElementById('officeOfficerNameFilter');
    if(oqf && !oqf.dataset.debounced){
      oqf.dataset.debounced='1';
      oqf.removeAttribute('oninput');
      oqf.addEventListener('input', debounce(()=>{ try{applyFilters();}catch(e){} },280));
    }
    const ops=document.getElementById('officePerformanceSearch');
    if(ops && !ops.dataset.debounced){
      ops.dataset.debounced='1';
      ops.removeAttribute('oninput');
      ops.addEventListener('input', debounce(()=>{ try{renderOfficeCharts();}catch(e){} },220));
    }
  };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', setup); else setup();
  setTimeout(setup, 900);
})();

// ===== SET ROLE (Admin only) - Per-workspace permissions override =====
const SET_ROLE_STORAGE_KEY = "vp_token_multiscope";
const SET_ROLE_WORKSPACES = [
    { id: "office", label: "VP" },
    { id: "bch", label: "BCH" },
    { id: "ttbtv", label: "TT/BTV" },
    { id: "province", label: "Tỉnh" },
    { id: "action100", label: "KH100" },
    { id: "vpub", label: "VPUB" }
];
const SET_ROLE_ACTIONS = [
    { id: "v", label: "Xem", icon: "👁" },
    { id: "a", label: "Thêm", icon: "➕" },
    { id: "e", label: "Sửa", icon: "✏️" },
    { id: "d", label: "Xóa", icon: "🗑" }
];

let SERVER_OVERRIDES_CACHE = null;







let SET_ROLE_TOKENS = [];








window.openSetRoleModal = openSetRoleModal;
window.closeSetRoleModal = closeSetRoleModal;
window.loadSetRoleTokens = loadSetRoleTokens;
window.renderSetRoleTable = renderSetRoleTable;
window.saveSetRole = saveSetRole;
window.clearSetRoleOverrides = clearSetRoleOverrides;
window.userHasExtraScope = userHasExtraScope;
window.applyTokenMultiScope = applyTokenMultiScope;
window.userCan = userCan;
window.computeDefaultPerms = computeDefaultPerms;
window.getEffectivePerms = getEffectivePerms;

// ===== NQ TW (Theo doi Nghi quyet Trung uong, Supabase table nq_tw) =====
const NQ_TW_API = `${SUPABASE_URL}/rest/v1/nq_tw?select=*&order=id.asc`;
let NQ_TW_LIST = [], NQ_TW_EDIT_ID = null;
// Only admin token can add/edit/delete nghi quyet
function canEditNqTw() { return typeof CURRENT_USER !== "undefined" && CURRENT_USER && CURRENT_USER.role === "admin"; }
function nqTwHeaders(json) {
    const h = { "apikey": SUPABASE_KEY, "Authorization": `Bearer ${SUPABASE_KEY}` };
    if (json) h["Content-Type"] = "application/json";
    return h;
}
// NQ dashboard: one workspace, 3 caps (TW/TINH/XA share table nq_tw)
let NQ_CAP_FILTER = "ALL";
let NQ_VIEW_ALL = false;
function toggleNqViewAll() { NQ_VIEW_ALL = !NQ_VIEW_ALL; renderNqDashboard(); }
function applyNqViewMode() {
    const isAll = NQ_CAP_FILTER === "ALL";
    const show = (sel, v) => document.querySelectorAll(sel).forEach(e => { e.style.display = v ? "" : "none"; });
    show("#nqWorkspace .nq-cap-btn", isAll); // tab cap chi hien o Tong quan
    show("#nqWorkspace .nq-caps", isAll); // the cap chi hien o Tong quan
    show("#nqWorkspace .nq-grid", !isAll);
    show("#nqPersonChartWrap,#nqBtvChartWrap", isAll); // person + BTV chart chi hien o Tong quan
    show("#nqLeadRow", isAll); // 3 nut lanh dao chi hien o Tong quan
}
function openNqWorkspace(el, cap) {
    ['officeWorkspace', 'bchWorkspace', 'ttbtvWorkspace', 'provinceWorkspace', 'action100Workspace', 'mttqKpiWorkspace', 'vpubWorkspace'].forEach(id => document.getElementById(id)?.classList.remove('open'));
    document.querySelectorAll(".sidebar-item").forEach(x => x.classList.remove("active"));
    (el || document.getElementById("nqTwSidebarItem"))?.classList.add("active");
    document.getElementById("nqWorkspace")?.classList.add("open");
    NQ_CAP_FILTER = cap || "ALL";
    document.querySelectorAll(".nq-cap-btn,.nq-cap-card").forEach(b => b.classList.toggle("selected", b.dataset.cap === NQ_CAP_FILTER));
    applyNqViewMode();
    loadNqDashboard();
    try { vpSaveLastWs("nqWorkspace"); } catch (e) {}
}
function filterNqByCap(cap, btn) {
    NQ_CAP_FILTER = cap || "ALL";
    document.querySelectorAll(".nq-cap-btn,.nq-cap-card").forEach(b => b.classList.toggle("selected", b.dataset.cap === NQ_CAP_FILTER));
    if (!document.getElementById("nqWorkspace")?.classList.contains("open")) return;
    renderNqDashboard();
}
const NQ_STATUS_LABEL = { doing: "Đang triển khai", done: "Hoàn thành", late: "Chậm tiến độ", none: "Chưa phân công" };
let NQ_CHART_DONUT = null, NQ_CHART_LINE = null;
function renderNqCharts() {
    if (typeof Chart === "undefined") return;
    const scope = NQ_CAP_FILTER === "ALL" ? NQ_TW_LIST : NQ_TW_LIST.filter(x => (x.cap || "TW") === NQ_CAP_FILTER);
    const stOf = x => x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none");
    const dTitle = document.getElementById("nqDonutTitle"), lTitle = document.getElementById("nqLineTitle");
    let dLabels, dData, dColors, lLabels, lData;
    if (NQ_CAP_FILTER === "ALL") {
        const n = k => scope.filter(x => (x.cap || "TW") === k).length;
        dLabels = ["Trung ương", "Tỉnh ủy", "Đảng ủy xã"]; dData = [n("TW"), n("TINH"), n("XA")]; dColors = ["#EA580C", "#3b82f6", "#009E73"];
        if (dTitle) dTitle.textContent = "Tiến độ thực hiện theo cấp ban hành";
        const avg = k => { const a = scope.filter(x => (x.cap || "TW") === k); return a.length ? Math.round(a.reduce((s, x) => s + Number(x.tien_do || 0), 0) / a.length) : 0; };
        lLabels = ["Trung ương", "Tỉnh ủy", "Đảng ủy xã"]; lData = [avg("TW"), avg("TINH"), avg("XA")];
        if (lTitle) lTitle.textContent = "Tiến độ trung bình theo cấp (%)";
    } else {
        const cs = ["doing", "done", "late", "none"];
        dLabels = cs.map(s => NQ_STATUS_LABEL[s]); dData = cs.map(s => scope.filter(x => stOf(x) === s).length);
        dColors = ["#009E73", "#8b5cf6", "#f59e0b", "#94a3b8"];
        const capName = NQ_CAP_LABEL[NQ_CAP_FILTER] || NQ_CAP_FILTER;
        if (dTitle) dTitle.textContent = "Cơ cấu trạng thái — " + capName;
        const b = [0, 0, 0, 0, 0];
        scope.forEach(x => { const t = Number(x.tien_do || 0); b[t >= 100 ? 4 : t >= 80 ? 3 : t >= 50 ? 2 : t > 0 ? 1 : 0]++; });
        lLabels = ["0%", "1-49%", "50-79%", "80-99%", "100%"]; lData = b;
        if (lTitle) lTitle.textContent = "Phân bố tiến độ — " + capName;
    }
    const dc = document.getElementById("nqDonutChart"), lc = document.getElementById("nqLineChart");
    if (!dc || !lc) return;
    if (NQ_CHART_DONUT) NQ_CHART_DONUT.destroy();
    if (NQ_CHART_LINE) NQ_CHART_LINE.destroy();
    NQ_CHART_DONUT = new Chart(dc.getContext("2d"), { type: "doughnut", data: { labels: dLabels, datasets: [{ data: dData, backgroundColor: dColors }] }, options: { responsive: true, maintainAspectRatio: false, onHover: (event, elements) => { event.native.target.style.cursor = elements.length ? "pointer" : "default"; }, onClick: (event, elements) => { if (!elements.length) return; showNqDonutDrill(elements[0].index); }, plugins: { legend: { position: "right" }, nqSlicePct: { display: true } } } });
    const yOpt = NQ_CAP_FILTER === "ALL" ? { beginAtZero: true, max: 100 } : { beginAtZero: true, ticks: { precision: 0 } };
    NQ_CHART_LINE = new Chart(lc.getContext("2d"), { type: "line", data: { labels: lLabels, datasets: [{ data: lData, borderColor: "#16a34a", backgroundColor: "rgba(22,163,74,.12)", fill: true, tension: .3 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: yOpt } } });
    // Person charts: render all (show/hide based on cap filter)
    if (NQ_CAP_FILTER === "ALL") { renderNqPersonChart(); renderNqBtvChart(); }
}
function showNqDonutDrill(idx) {
    // Donut o Tong quan (ALL): lat cat = cap TW/TINH/XA; khi loc cap: lat cat = trang thai
    const stOf = x => x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none");
    let rows, title;
    if (NQ_CAP_FILTER === "ALL") {
        const cap = ["TW", "TINH", "XA"][idx];
        if (!cap) return;
        rows = NQ_TW_LIST.filter(x => (x.cap || "TW") === cap);
        title = (NQ_CAP_LABEL[cap] || cap) + " — " + rows.length + " nghị quyết";
    } else {
        const st = ["doing", "done", "late", "none"][idx];
        if (!st) return;
        rows = NQ_TW_LIST.filter(x => (x.cap || "TW") === NQ_CAP_FILTER && stOf(x) === st);
        title = NQ_STATUS_LABEL[st] + " (" + (NQ_CAP_LABEL[NQ_CAP_FILTER] || NQ_CAP_FILTER) + ") — " + rows.length + " nghị quyết";
    }
    // Tai dung popup nqKpiModal (layout + CSS clamp + click-to-edit co san)
    document.getElementById("nqKpiTitle").textContent = title;
    document.getElementById("nqKpiCount").textContent = rows.length;
    const body = document.getElementById("nqKpiBody"), empty = document.getElementById("nqKpiEmpty");
    if (!rows.length) { body.innerHTML = ""; empty.style.display = ""; }
    else {
        empty.style.display = "none";
        const _nqAdmin = canEditNqTw();
        body.innerHTML = rows.map((x, i) => {
            const s = stOf(x);
            return `<tr class="nq-row"${_nqAdmin ? ` onclick="openNqTwEdit(${x.id})"` : ``}><td>${i + 1}</td>
            <td><div class="nq-name"><b>${esc(x.name)}</b></div><div class="nq-sub1">${esc(x.co_quan || "")}</div></td>
            <td><span class="nq-badge" title="${NQ_CAP_LABEL[x.cap || "TW"]}">${NQ_CAP_SHORT[x.cap || "TW"]}</span></td>
            <td><div class="nq-person">${esc(x.thuong_truc || "")}</div></td>
            <td><b>${Number(x.tien_do || 0)}%</b></td>
            <td><span class="nq-badge ${s}">${NQ_STATUS_LABEL[s]}</span></td></tr>`;
        }).join("");
    }
    document.getElementById("nqKpiModal")?.classList.add("open");
}
let NQ_CHART_PERSON = null, NQ_CHART_BTV = null;
function renderNqPersonChart() {
    const host = document.getElementById("nqPersonChart");
    if (!host || typeof Chart === "undefined") return;
    if (NQ_CHART_PERSON) NQ_CHART_PERSON.destroy();
    const by = {};
    NQ_TW_LIST.forEach(x => {
        const k = (x.thuong_truc || "Chưa phân công").trim() || "Chưa phân công";
        const g = (by[k] = by[k] || { TW: 0, TINH: 0, XA: 0 });
        g[(x.cap || "TW")]++;
    });
    const entries = Object.entries(by).sort((a, b) => (b[1].TW + b[1].TINH + b[1].XA) - (a[1].TW + a[1].TINH + a[1].XA)).slice(0, 10);
    const labels = entries.map(([k]) => k.length > 30 ? k.slice(0, 30) + "…" : k);
    NQ_CHART_PERSON = new Chart(host.getContext("2d"), {
        type: "bar",
        data: {
            labels,
            datasets: [
                { label: "Trung ương", data: entries.map(([, g]) => g.TW), backgroundColor: "#EA580C" },
                { label: "Tỉnh ủy", data: entries.map(([, g]) => g.TINH), backgroundColor: "#3b82f6" },
                { label: "Đảng ủy xã", data: entries.map(([, g]) => g.XA), backgroundColor: "#009E73" }
            ]
        },
        options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            onHover: (event, elements) => { event.native.target.style.cursor = elements.length ? "pointer" : "default"; },
            onClick: (event, elements, chart) => {
                if (!elements.length) return;
                const idx = elements[0].index; // dataIndex = person index trong top-10 da sort
                const dsIdx = elements[0].datasetIndex; // datasetIndex: 0=TW, 1=TINH, 2=XA
                const capMap = ["TW", "TINH", "XA"];
                const personName = entries[idx] && entries[idx][0];
                if (!personName) return;
                const cap = dsIdx != null ? capMap[dsIdx] : null;
                showNqPersonDrill(personName, cap);
            },
            plugins: { legend: { position: "top" }, nqBarTotal: { display: true } },
            scales: {
                x: { stacked: true, beginAtZero: true, title: { display: true, text: "Số nghị quyết" } },
                y: { stacked: true }
            }
        }
    });
}

function renderNqBtvChart() {
    const host = document.getElementById("nqBtvChart");
    if (!host || typeof Chart === "undefined") return;
    if (NQ_CHART_BTV) NQ_CHART_BTV.destroy();
    const by = {};
    NQ_TW_LIST.forEach(x => {
        const k = ((x.uv_thuong_vu || "").trim()) || "Chưa phân công";
        const g = (by[k] = by[k] || { TW: 0, TINH: 0, XA: 0 });
        g[(x.cap || "TW")]++;
    });
    // Hien DU moi UVBTV co trong data (khong cat top 10) — "Chua phan cong" giu lai de thay viec chua giao
    const entries = Object.entries(by).sort((a, b) => (b[1].TW + b[1].TINH + b[1].XA) - (a[1].TW + a[1].TINH + a[1].XA));
    const labels = entries.map(([k]) => k.length > 30 ? k.slice(0, 30) + "…" : k);
    NQ_CHART_BTV = new Chart(host.getContext("2d"), {
        type: "bar",
        data: {
            labels,
            datasets: [
                { label: "Trung ương", data: entries.map(([, g]) => g.TW), backgroundColor: "#EA580C" },
                { label: "Tỉnh ủy", data: entries.map(([, g]) => g.TINH), backgroundColor: "#3b82f6" },
                { label: "Đảng ủy xã", data: entries.map(([, g]) => g.XA), backgroundColor: "#009E73" }
            ]
        },
        options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            onHover: (event, elements) => { event.native.target.style.cursor = elements.length ? "pointer" : "default"; },
            onClick: (event, elements, chart) => {
                if (!elements.length) return;
                const idx = elements[0].index; // dataIndex trong top-10 da sort
                const dsIdx = elements[0].datasetIndex; // datasetIndex: 0=TW, 1=TINH, 2=XA
                const capMap = ["TW", "TINH", "XA"];
                const personName = entries[idx] && entries[idx][0];
                if (!personName) return;
                const cap = dsIdx != null ? capMap[dsIdx] : null;
                showNqPersonDrill(personName, cap, "uv_thuong_vu");
            },
            plugins: { legend: { position: "top" }, nqBarTotal: { display: true } },
            scales: {
                x: { stacked: true, beginAtZero: true, title: { display: true, text: "Số nghị quyết" } },
                y: { stacked: true }
            }
        }
    });
}

function showNqPersonDrill(personName, cap, field) {
    // field: "thuong_truc" (mac dinh) hoac "uv_thuong_vu" (chart Ban Thuong vu)
    field = field === "uv_thuong_vu" ? "uv_thuong_vu" : "thuong_truc";
    const isBtv = field === "uv_thuong_vu";
    // Filter NQ_TW_LIST by person name (and optionally cap)
    const capFilter = cap ? (x => (x.cap || "TW") === cap) : () => true;
    const rows = NQ_TW_LIST.filter(x => {
        const name = ((x[field] || "").trim()) || "Chưa phân công";
        return name === personName && capFilter(x);
    });
    const capText = cap ? ` · ${NQ_CAP_LABEL[cap] || cap}` : "";
    document.getElementById("nqPersonDrillTitle").textContent = (isBtv ? "Ban Thường vụ: " : "Người phụ trách: ") + personName + capText;
    document.getElementById("nqPersonDrillWhoHead").textContent = isBtv ? "BTV phụ trách" : "TTĐU phụ trách";
    document.getElementById("nqPersonDrillCount").textContent = rows.length;
    const body = document.getElementById("nqPersonDrillBody"), empty = document.getElementById("nqPersonDrillEmpty");
    if (!rows.length) { body.innerHTML = ""; empty.style.display = ""; }
    else {
        empty.style.display = "none";
        const _nqAdmin = canEditNqTw();
        body.innerHTML = rows.map((x, i) => {
            const s = x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none");
            return `<tr class="nq-row"${_nqAdmin ? ` onclick="openNqTwEdit(${x.id})"` : ``}><td>${i + 1}</td>
                <td><div class="nq-name"><b>${esc(x.name)}</b></div><div class="nq-sub1">${esc(x.co_quan || "")}</div></td>
                <td><span class="nq-badge" title="${NQ_CAP_LABEL[x.cap || "TW"]}">${NQ_CAP_SHORT[x.cap || "TW"]}</span></td>
                <td><div class="nq-person">${esc(x[field] || "")}</div></td>
                <td><b>${Number(x.tien_do || 0)}%</b></td>
                <td><span class="nq-badge ${s}">${NQ_STATUS_LABEL[s]}</span></td></tr>`;
        }).join("");
    }
    // Reuse smoothOpenModal if available, fallback to manual open
    try {
        if (typeof smoothOpenModal === "function") smoothOpenModal("nqPersonDrillModal");
        else document.getElementById("nqPersonDrillModal")?.classList.add("open");
    } catch (_) {
        document.getElementById("nqPersonDrillModal")?.classList.add("open");
    }
}

function closeNqPersonDrill() {
    try {
        if (typeof smoothCloseModal === "function") smoothCloseModal("nqPersonDrillModal");
        else document.getElementById("nqPersonDrillModal")?.classList.remove("open");
    } catch (_) {
        document.getElementById("nqPersonDrillModal")?.classList.remove("open");
    }
}
function syncNqKpiSelected() {
    const st = document.getElementById("nqStatusFilter")?.value || "all";
    document.querySelectorAll(".nq-kpi").forEach(k => k.classList.toggle("selected", k.dataset.st === st));
}
function filterNqByStatus(st, el) {
    const sel = document.getElementById("nqStatusFilter");
    if (sel) sel.value = st || "all";
    syncNqKpiSelected();
    renderNqDashboard();
}
function onNqStatusSelect() { syncNqKpiSelected(); renderNqDashboard(); }
function openNqKpiModal(st) {
    st = st || "all";
    const scope = NQ_CAP_FILTER === "ALL" ? NQ_TW_LIST : NQ_TW_LIST.filter(x => (x.cap || "TW") === NQ_CAP_FILTER);
    const stOf = x => x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none");
    const rows = st === "all" ? scope : scope.filter(x => stOf(x) === st);
    const capSuffix = NQ_CAP_FILTER === "ALL" ? "" : " (" + (NQ_CAP_LABEL[NQ_CAP_FILTER] || NQ_CAP_FILTER) + ")";
    document.getElementById("nqKpiTitle").textContent = (st === "all" ? "Tổng số nghị quyết" : NQ_STATUS_LABEL[st]) + " — " + rows.length + " nghị quyết" + capSuffix;
    document.getElementById("nqKpiCount").textContent = rows.length;
    const body = document.getElementById("nqKpiBody"), empty = document.getElementById("nqKpiEmpty");
    if (!rows.length) { body.innerHTML = ""; empty.style.display = ""; }
    else {
        empty.style.display = "none";
        const _nqAdmin = canEditNqTw();
        body.innerHTML = rows.map((x, i) => {
            const s = stOf(x);
            return `<tr class="nq-row"${_nqAdmin ? ` onclick="openNqTwEdit(${x.id})"` : ``}><td>${i + 1}</td>
            <td><div class="nq-name"><b>${esc(x.name)}</b></div><div class="nq-sub1">${esc(x.co_quan || "")}</div></td>
            <td><span class="nq-badge" title="${NQ_CAP_LABEL[x.cap || "TW"]}">${NQ_CAP_SHORT[x.cap || "TW"]}</span></td>
            <td><div class="nq-person">${esc(x.thuong_truc || "")}</div></td>
            <td><b>${Number(x.tien_do || 0)}%</b></td>
            <td><span class="nq-badge ${s}">${NQ_STATUS_LABEL[s]}</span></td></tr>`;
        }).join("");
    }
    document.getElementById("nqKpiModal")?.classList.add("open");
}
function closeNqKpiModal() { document.getElementById("nqKpiModal")?.classList.remove("open"); }
const NQ_CAP_LABEL = { TW: "Trung ương", TINH: "Tỉnh ủy", XA: "Đảng ủy xã" };
const NQ_CAP_SHORT = { TW: "TW", TINH: "Tỉnh", XA: "Xã" };
async function loadNqDashboard(silent) {
    try {
        const r = await fetch(NQ_TW_API, { headers: nqTwHeaders() });
        if (!r.ok) throw new Error("HTTP " + r.status);
        NQ_TW_LIST = await r.json();
        const t = document.getElementById("nqSyncText");
        if (t) t.textContent = "Cập nhật lần cuối: " + new Date().toLocaleString("vi-VN");
    } catch (e) {
        console.warn("loadNq fail", e);
        if (!silent) showToast("error", "Không tải được nghị quyết", "Kiểm tra đã chạy SQL tạo bảng nq_tw chưa.");
        NQ_TW_LIST = [];
    }
    renderNqDashboard();
}
function nqFiltered() {
    const kw = (document.getElementById("nqSearch")?.value || "").toLowerCase();
    const st = document.getElementById("nqStatusFilter")?.value || "all";
    return NQ_TW_LIST.filter(x => {
        if (NQ_CAP_FILTER !== "ALL" && (x.cap || "TW") !== NQ_CAP_FILTER) return false;
        if (st !== "all" && (x.trang_thai || "doing") !== st) return false;
        if (kw && !((x.name || "") + " " + (x.thuong_truc || "") + " " + (x.co_quan || "")).toLowerCase().includes(kw)) return false;
        return true;
    });
}
function renderNqDashboard() {
    if (!document.getElementById("nqWorkspace")) return;
    syncNqKpiSelected();
    const list = NQ_TW_LIST;
    const stOf = x => x.trang_thai || ((x.co_quan || "").trim() ? "doing" : "none");
    // KPI cards follow cap scope (ALL = all 3 caps)
    const scope = NQ_CAP_FILTER === "ALL" ? list : list.filter(x => (x.cap || "TW") === NQ_CAP_FILTER);
    // KPI cards (toan bo, khong loc cap)
    const c = s => scope.filter(x => stOf(x) === s).length;
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set("nqKpiTotal", scope.length); set("nqKpiDoing", c("doing")); set("nqKpiDone", c("done")); set("nqKpiLate", c("late")); set("nqKpiNone", c("none"));
    // Pct + bars on stat cards
    const pct = n => scope.length ? Math.round(n / scope.length * 100) : 0;
    const pDoing = pct(c("doing")), pDone = pct(c("done")), pLate = pct(c("late")), pNone = pct(c("none"));
    const setText = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    const setW = (id, v) => { const el = document.getElementById(id); if (el) el.style.width = v + "%"; };
    setText("nqSubTotal", scope.length + " nghị quyết"); setText("nqSubDoing", pDoing + "% tổng số"); setW("nqBarDoing", pDoing);
    setText("nqSubDone", pDone + "% tổng số"); setW("nqBarDone", pDone);
    setText("nqSubLate", pLate + "% tổng số"); setW("nqBarLate", pLate);
    setText("nqSubNone", pNone + "% tổng số"); setW("nqBarNone", pNone);
    // Cap mini cards
    set("nqCapTw", list.filter(x => (x.cap || "TW") === "TW").length);
    set("nqCapTinh", list.filter(x => (x.cap || "TW") === "TINH").length);
    set("nqCapXa", list.filter(x => (x.cap || "TW") === "XA").length);
    // View mode: ALL = KPI + charts + person stats (no caps/tabs/list); cap = full UI
    applyNqViewMode();
    const isAll = NQ_CAP_FILTER === "ALL";
    // Cap rows
    const caps = ["TW", "TINH", "XA"];
    document.getElementById("nqCapRows").innerHTML = caps.map(k => {
        const n = list.filter(x => (x.cap || "TW") === k).length;
        const pct = list.length ? Math.round(n / list.length * 100) : 0;
        return `<div class="nq-cap-row"><span>${k === "TW" ? "📕" : k === "TINH" ? "📘" : "📗"} ${NQ_CAP_LABEL[k]}</span><div class="nq-bar"><span style="width:${pct}%"></span></div><b>${n} (${pct}%)</b></div>`;
    }).join("");
    // Main table (max 10 rows, toggle view all)
    const rows = nqFiltered();
    const shown = NQ_VIEW_ALL ? rows : rows.slice(0, 10);
    set("nqShownCount", rows.length);
    const viewBtn = document.getElementById("nqViewAllBtn");
    if (viewBtn) {
        viewBtn.style.display = rows.length > 10 ? "" : "none";
        viewBtn.textContent = NQ_VIEW_ALL ? "← Thu gọn" : `Xem tất cả (${rows.length}) →`;
    }
    const body = document.getElementById("nqMainBody"), empty = document.getElementById("nqEmpty");
    const _nqAdmin = canEditNqTw();
    try { document.querySelectorAll("#nqWorkspace .bch-actions button").forEach(b => { if ((b.getAttribute("onclick") || "").includes("openNqTwEdit")) b.style.display = _nqAdmin ? "" : "none"; }); } catch (e) {}
    if (!shown.length) { body.innerHTML = ""; empty.style.display = ""; }
    else {
        empty.style.display = "none";
        body.innerHTML = shown.map((x, i) => {
            const td = Number(x.tien_do || 0), st = stOf(x);
            const barColor = td >= 80 ? "#16a34a" : td >= 50 ? "#16a34a" : td >= 30 ? "#f59e0b" : "#D55E00";
            return `<tr class="nq-row"${_nqAdmin ? ` onclick="openNqTwEdit(${x.id})"` : ``}><td>${i + 1}</td>
            <td><div class="nq-name"><b>${esc(x.name)}</b></div><div class="nq-sub1">${esc(x.co_quan || "")}</div></td>
            <td><span class="nq-badge">${NQ_CAP_LABEL[x.cap || "TW"]}</span></td>
            <td>${esc(x.ngay_ban_hanh || "")}</td>
            <td>${esc(x.thuong_truc || "")}</td>
            <td>${esc(x.uv_thuong_vu || "")}</td>
            <td>
                <b>${td}%</b>
                ${x.so_chi_tieu > 0 ? `<span style="font-size:12px;color:#64748b">(${x.so_chi_tieu_dan_da || 0}/${x.so_chi_tieu})</span>` : ''}
                <div class="nq-bar"><span style="width:${td}%;background:${barColor}"></span></div>
            </td>
            <td><span class="nq-badge ${st}">${NQ_STATUS_LABEL[st]}</span></td>
            <td>${_nqAdmin ? `<button class="bch-btn" onclick="event.stopPropagation();openNqTwEdit(${x.id})">✏️</button>
            <button class="bch-btn" onclick="event.stopPropagation();deleteNqTw(${x.id})">🗑</button>` : `<span class="locked-text">🔒 Xem</span>`}</td></tr>`;
        }).join("");
    }
    // Alerts: late hoac tien do < 60
    const alerts = list.filter(x => stOf(x) === "late" || Number(x.tien_do || 0) < 60).slice(0, 5);
    document.getElementById("nqAlertList").innerHTML = alerts.length ? alerts.map(x =>
        `<div class="nq-alert"><b>${esc(x.name)}</b><br>Chủ trì: ${esc(x.co_quan || "—")} | Phụ trách: ${esc(x.thuong_truc || "—")}<br>Tiến độ: ${Number(x.tien_do || 0)}%</div>`
    ).join("") : `<div style="font-size:13px;color:#64748b">Không có nhiệm vụ cần quan tâm.</div>`;
    renderNqCharts();
}
function openNqTwEdit(id) {
    if (!canEditNqTw()) { showToast("error", "Không có quyền", "Chỉ token admin được thêm/sửa nghị quyết."); return; }
    NQ_TW_EDIT_ID = id ?? null;
    const x = id ? NQ_TW_LIST.find(v => String(v.id) === String(id)) : null;
    document.getElementById("nqTwEditTitle").textContent = x ? "✏️ Sửa Nghị quyết" : "➕ Thêm Nghị quyết";
    document.getElementById("nqTwCap").value = x?.cap || (NQ_CAP_FILTER === "ALL" ? "TW" : NQ_CAP_FILTER);
    document.getElementById("nqTwName").value = x?.name || "";
    document.getElementById("nqTwNgayBh").value = x?.ngay_ban_hanh || "";
    document.getElementById("nqTwTtrucc").value = x?.thuong_truc || "";
    document.getElementById("nqTwUvTv").value = x?.uv_thuong_vu || "";
    document.getElementById("nqTwUvBch").value = x?.uv_bch || "";
    document.getElementById("nqTwCoquan").value = x?.co_quan || "";
    document.getElementById("nqTwTrangThai").value = x?.trang_thai || "doing";
    document.getElementById("nqTwSoChiTieu").value = x?.so_chi_tieu ?? 0;
    document.getElementById("nqTwSoChiTieuDanDa").value = x?.so_chi_tieu_dan_da ?? 0;
    // Tính tiến độ realtime từ chỉ tiêu
    calcNqTienDo();
    document.getElementById("nqTwEditModal")?.classList.add("open");
}
// Tính tiến độ realtime từ chỉ tiêu (readonly field)
function calcNqTienDo() {
    const soChiTieu = Math.max(0, Number(document.getElementById("nqTwSoChiTieu").value || 0));
    const soChiTieuDanDa = Math.max(0, Number(document.getElementById("nqTwSoChiTieuDanDa").value || 0));
    const tienDo = soChiTieu > 0 ? Math.round((soChiTieuDanDa / soChiTieu) * 100) : 0;
    document.getElementById("nqTwTienDo").value = tienDo;
}
function closeNqTwEdit() { document.getElementById("nqTwEditModal")?.classList.remove("open"); }
async function saveNqTwEdit() {
    if (!canEditNqTw()) { showToast("error", "Không có quyền", "Chỉ token admin được thêm/sửa nghị quyết."); return; }
    const soChiTieu = Math.max(0, Number(document.getElementById("nqTwSoChiTieu").value || 0));
    const soChiTieuDanDa = Math.max(0, Number(document.getElementById("nqTwSoChiTieuDanDa").value || 0));
    // Luôn tính tiến độ từ chỉ tiêu (không cho nhập thủ công)
    const tienDo = soChiTieu > 0 ? Math.round((soChiTieuDanDa / soChiTieu) * 100) : 0;
    const payload = {
        cap: document.getElementById("nqTwCap").value,
        name: document.getElementById("nqTwName").value.trim(),
        ngay_ban_hanh: document.getElementById("nqTwNgayBh").value.trim(),
        thuong_truc: document.getElementById("nqTwTtrucc").value.trim(),
        uv_thuong_vu: document.getElementById("nqTwUvTv").value.trim(),
        uv_bch: document.getElementById("nqTwUvBch").value.trim(),
        co_quan: document.getElementById("nqTwCoquan").value.trim(),
        tien_do: tienDo,
        so_chi_tieu: soChiTieu,
        so_chi_tieu_dan_da: soChiTieuDanDa,
        trang_thai: document.getElementById("nqTwTrangThai").value
    };
    if (!payload.name) return showToast("error", "Thiếu tên", "Nhập Tên Nghị quyết trước khi lưu.");
    try {
        const r = NQ_TW_EDIT_ID
            ? await fetch(`${SUPABASE_URL}/rest/v1/nq_tw?id=eq.${NQ_TW_EDIT_ID}`, { method: "PATCH", headers: nqTwHeaders(true), body: JSON.stringify(payload) })
            : await fetch(`${SUPABASE_URL}/rest/v1/nq_tw`, { method: "POST", headers: nqTwHeaders(true), body: JSON.stringify(payload) });
        if (!r.ok) throw new Error("HTTP " + r.status);
        closeNqTwEdit(); loadNqDashboard(true);
        showToast("success", "Đã lưu", "Cập nhật nghị quyết thành công.");
    } catch (e) { showToast("error", "Lưu thất bại", String(e.message || e)); }
}
async function deleteNqTw(id) {
    if (!canEditNqTw()) { showToast("error", "Không có quyền", "Chỉ token admin được xóa nghị quyết."); return; }
    if (!confirm("Xóa nghị quyết này?")) return;
    try {
        const r = await fetch(`${SUPABASE_URL}/rest/v1/nq_tw?id=eq.${id}`, { method: "DELETE", headers: nqTwHeaders() });
        if (!r.ok) throw new Error("HTTP " + r.status);
        loadNqDashboard(true);
    } catch (e) { showToast("error", "Xóa thất bại", String(e.message || e)); }
}
window.openNqWorkspace = openNqWorkspace;
window.filterNqByCap = filterNqByCap;
window.filterNqByStatus = filterNqByStatus;
window.toggleNqViewAll = toggleNqViewAll;
window.onNqStatusSelect = onNqStatusSelect;
window.openNqKpiModal = openNqKpiModal;
window.closeNqKpiModal = closeNqKpiModal;
window.loadNqDashboard = loadNqDashboard;
window.renderNqDashboard = renderNqDashboard;
window.applyNqViewMode = applyNqViewMode;
window.renderNqCharts = renderNqCharts;
window.openNqTwEdit = openNqTwEdit;
window.closeNqTwEdit = closeNqTwEdit;
window.saveNqTwEdit = saveNqTwEdit;
window.deleteNqTw = deleteNqTw;

