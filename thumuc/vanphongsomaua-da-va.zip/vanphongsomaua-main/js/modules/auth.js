/* js/modules/auth.js — tach tu js/legacy.js (nhom 1 Auth/Token/Phan quyen).
 * Classic script (window globals), load SAU utils, TRUOC legacy.js.
 * Giu lai legacy.js: isOwnedByToken@10527 (nested trong refreshDailyWarnTasks).
 * Ranges goc: 13-13, 14-14, 15-27, 205-212, 213-213, 519-522, 524-530, 532-532, 533-533, 535-541, 543-632, 633-633, 634-634, 635-641, 643-687, 689-720, 722-768, 770-791, 793-850, 863-868, 1999-2005, 3582-3589, 3590-3594, 3595-3604, 3605-3613, 3614-3626, 3627-3633, 4523-4531, 5083-5100, 5101-5129, 5923-5954, 6322-6342, 6343-6347, 6348-6362, 6363-6370, 6371-6383, 6384-6398, 6413-6435, 7932-7937, 8155-8157, 8158-8169, 8170-8184, 8185-8194, 8214-8230, 8231-8255, 8256-8272, 10134-10159, 11378-11378, 11381-11381, 11382-11394, 11396-11403, 11404-11414, 11415-11425, 11426-11439, 11440-11440, 11441-11454, 11455-11575, 11576-11591, 12021-12034, 12035-12043, 12045-12048, 12049-12060, 12062-12062, 12063-12067, 12068-12073, 12074-12076, 12078-12094, 12096-12104, 12106-12143, 12145-12157, 12161-12170, 12171-12171, 12172-12184, 12186-12189, 12191-12236, 12238-12283, 12285-12309, 12311-12330, 12332-12344
 */

function _obfToken(t){ try{ return btoa(String(t).split('').reverse().join('')); }catch(e){ return String(t); } }

function _deobfToken(s){ try{ return atob(String(s)).split('').reverse().join(''); }catch(e){ return String(s); } }

function _readStoredToken(){
  try{
    let v = localStorage.getItem("_vp_t");
    if(v) return _deobfToken(v);
    v = localStorage.getItem("vp_demo_token");
    if(v) return String(v);
    try{ v = sessionStorage.getItem("_vp_t"); if(v) return _deobfToken(v); }catch(_){}
    try{ v = sessionStorage.getItem("vp_demo_token"); if(v) return String(v); }catch(_){}
    const c = readCache("_vp_t"); if(c) return _deobfToken(String(c));
    const c2 = readCache("vp_demo_token"); if(c2) return typeof c2==="string"?c2:(c2.token||"");
  }catch(_){}
  return "";
}

function getBchViewTier(user) {
    if (user && user.bchTier) return user.bchTier;
    const u = user || CURRENT_USER;
    if (u && (u.role === "admin" || u.scope === "all")) return "full";
    if (u && u.scope === "bch" && ["Hà Đức Anh","Phạm Xuân Sơn","Chu Chính Sơn"].includes(String(u.name||"").trim())) return "full";
    if (u && u.scope === "bch") return "broad";
    return "";
}

function isBchPrivilegedViewer(user) { const tier = getBchViewTier(user); return tier === "full" || tier === "broad"; }

function userScopeLabel(user) {
    if (!user || user.role === "admin") return "ADMIN · Toàn quyền";
    return ({ office: "Văn phòng", bch: "BCH", ttbtv: "TT/BTV", province: "Tỉnh giao" })[user.scope] ? `${user.name} · ${{ office: "Văn phòng", bch: "BCH", ttbtv: "TT/BTV", province: "Tỉnh giao" }[user.scope]}` : user.name;
}

function userRoleLabel(user) {
    if (!user) return "";
    if (user.role === "admin") return "Admin · Toàn quyền";
    if (user.mttqAdmin) return "Admin KPI MTTQ";
    if (user.scope === "data_entry") return "Cán bộ nhập liệu";
    return ({ office: "Cán bộ Văn phòng", bch: "Cán bộ BCH", ttbtv: "Cán bộ TT/BTV", province: "Cán bộ Tỉnh giao", mttq: "Cán bộ MTTQ" })[user.scope] || user.role || "";
}

function canAccessMTTQKPI(user = CURRENT_USER) { return !!user && (user.role === "admin" || (user.role === "staff" && user.scope === "mttq")); }

function isMTTQAdmin(user = CURRENT_USER) { return !!user && (user.role === "admin" || (user.scope === "mttq" && user.mttqAdmin === true)); }

function canAccessOfficeData(user) {
    if (!user) return false;
    if (user.role === "admin") return true;
    if (user.role === "staff" && user.scope === "office") return true;
    if (getBchViewTier(user) === "full") return true;
    return false;
}

function syncUserWorkspaceVisibility(user) {
    document.querySelectorAll(".sidebar-menu .sidebar-section").forEach(section => { section.style.display = ""; });
    if (user?.scope === "data_entry") {
        document.querySelectorAll(".sidebar-menu .sidebar-section").forEach(section => { section.style.display = ""; });
        ["officeSidebarItem", "bchSidebarItem", "bchSubmenu", "mttqKpiSidebarItem"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = "none"; });
        const officeItem = document.getElementById("officeSidebarItem");
        const officeSub = officeItem ? officeItem.nextElementSibling : null;
        if (officeSub && officeSub.classList.contains("sidebar-submenu")) officeSub.style.display = "none";
        document.querySelectorAll(".sidebar-menu .sidebar-section").forEach(section => {
            const t = section.querySelector(".sidebar-section-title");
            if (t && ["Tiện ích", "Báo cáo"].includes(t.textContent.trim())) section.style.display = "none";
        });
        const vpubOnly = document.getElementById("vpubSidebarItem"); if (vpubOnly) vpubOnly.style.display = "";
        const othersSub = document.getElementById("othersSubmenu");
        if (othersSub && typeof setSidebarSubmenuState === "function") setSidebarSubmenuState(othersSub, true);
        // CV được phép xem TT/BTV
        try{ const tt=document.getElementById("ttbtvSidebarItem"); if(tt) tt.style.display=""; const sub=document.getElementById("ttbtvSubmenu"); if(sub) sub.style.display=""; }catch(e){}
        syncVPUBQuickAddBtn();
        return;
    }
    const isMttq = user?.role === "staff" && user?.scope === "mttq";
    if (isMttq) {
        document.querySelectorAll(".sidebar-menu .sidebar-section").forEach(section => {
            section.style.display = ["homeSidebarSection", "othersSidebarSection"].includes(section.id) ? "" : "none";
        });
        const vpubOnly = document.getElementById("vpubSidebarItem"); if (vpubOnly) vpubOnly.style.display = "none";
        const mttqOnly = document.getElementById("mttqKpiSidebarItem"); if (mttqOnly) mttqOnly.style.display = "";
        return;
    }
    const mttqItem = document.getElementById("mttqKpiSidebarItem"); if (mttqItem) mttqItem.style.display = canAccessMTTQKPI(user) ? "" : "none";
    const departmentOnly = user?.role === "department" && (user.scope === "action100" || user.scope === "vpub") || user?.scope === "data_entry";
    const mayOffice = canAccessOfficeData(user);
    const isBch = user?.role === "staff" && user?.scope === "bch";
    if (isBch) {
        const tier = getBchViewTier(user);
        if (tier === "full") {
            ["bchSidebarItem", "bchSubmenu", "provinceSidebarItem", "provinceSubmenu", "ttbtvSidebarItem", "ttbtvSubmenu", "officeSidebarItem", "officeSubmenu", "vpubSidebarItem", "action100SidebarItem"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = ""; });
        } else if (tier === "broad") {
            ["bchSidebarItem", "bchSubmenu", "provinceSidebarItem", "provinceSubmenu", "ttbtvSidebarItem", "ttbtvSubmenu", "action100SidebarItem"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = ""; });
            ["officeSidebarItem", "officeSubmenu", "vpubSidebarItem"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = "none"; });
        } else {
            ["bchSidebarItem", "bchSubmenu"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = ""; });
            ["provinceSidebarItem", "provinceSubmenu", "ttbtvSidebarItem", "ttbtvSubmenu", "officeSidebarItem", "officeSubmenu", "vpubSidebarItem", "action100SidebarItem"].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.display = "none";
            });
            return;
        }
        // full/broad: handle office/vpub visibility and continue to canAdd logic without early return
        const vpubItemBroad = document.getElementById("vpubSidebarItem");
        if (vpubItemBroad) vpubItemBroad.style.display = tier === "full" ? "" : "none";
        ["officeSidebarItem", "officeSubmenu"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = mayOffice ? "" : "none"; });
    } else {
        ["bchSidebarItem", "provinceSidebarItem", "ttbtvSidebarItem", "bchSubmenu", "provinceSubmenu", "ttbtvSubmenu"].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = "";
        });
        ["officeSidebarItem", "officeSubmenu"].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = mayOffice ? "" : "none";
        });
        const vpubItem = document.getElementById("vpubSidebarItem");
        if (vpubItem) vpubItem.style.display = user?.role === "department" && !["vpub","action100"].includes(user.scope) ? "none" : "";
    }
    const canAddBCH = user?.role === "admin" || (user?.role === "staff" && user?.scope === "bch") || isNGNUser(user);
    const canAddTTBTV = user?.role === "admin" || user?.role === "department" || user.scope === "action100" || (user?.role === "staff" && ["ttbtv", "data_entry"].includes(user?.scope)) || !!user?.isNGN;
    const canAddPROV = user?.role === "admin" || (user?.role === "staff" && ["province", "data_entry"].includes(user?.scope));
    const canAddOffice = canAccessOfficeData(user);
    const addPerm = { bchQuickAddBtn: canAddBCH, ttbtvQuickAddBtn: canAddTTBTV, provinceQuickAddBtn: canAddPROV, officeQuickAddBtn: canAddOffice };
    ["bchQuickAddBtn", "ttbtvQuickAddBtn", "provinceQuickAddBtn", "officeQuickAddBtn"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = addPerm[id] ? "inline-flex" : "none";
    });
    const vpubIt = document.getElementById("vpubSidebarItem"), mttqIt = document.getElementById("mttqKpiSidebarItem");
    const anyOtherVisible = (vpubIt && vpubIt.style.display !== "none") || (mttqIt && mttqIt.style.display !== "none");
    ["othersSidebarItem", "othersSubmenu", "othersSidebarSection"].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = anyOtherVisible ? "" : "none"; });
    // đảm bảo 20 token TT/BTV luôn thấy mục TT/BTV
    try{ if(TTBTV_ALLOWED_TOKENS.has(user?._rawToken)){ const tt=document.getElementById("ttbtvSidebarItem"); if(tt) tt.style.display=""; const sub=document.getElementById("ttbtvSubmenu"); if(sub) sub.style.display=""; } }catch(e){}
    syncVPUBQuickAddBtn();
    try {
        const extras = Array.isArray(user && user._extraScopes) ? user._extraScopes : [];
        const scopeToMenu = { office: ["officeSidebarItem"], bch: ["bchSidebarItem"], ttbtv: ["ttbtvSidebarItem"], province: ["provinceSidebarItem"], action100: ["action100SidebarItem"], vpub: ["vpubSidebarItem"] };
        extras.forEach(s => {
            const ids = scopeToMenu[s];
            if (!ids) return;
            if (!userCan(user, "view", s)) return;
            ids.forEach(id => { const el = document.getElementById(id); if (el && el.style.display === "none") el.style.display = ""; });
        });
    } catch (e) {}
}

function canAddVPUBTask(u = CURRENT_USER) { return !!u && !(u.role === "department" && !["vpub","action100"].includes(u.scope)); }

function syncVPUBQuickAddBtn() { const el = document.getElementById("vpubQuickAddBtn"); if (el) el.style.display = (ACTION100_MODE === "vpub" && canAddVPUBTask()) ? "" : "none"; }

function syncAction100OverdueLabel() {
    const isVpub = typeof ACTION100_MODE !== 'undefined' && ACTION100_MODE === 'vpub';
    const el = document.getElementById('action100OverdueLabel');
    if (el) el.textContent = isVpub ? 'NV đang xử lý' : 'Quá hạn';
    const opt = document.querySelector('#action100Status option[value="overdue"]');
    if (opt) opt.textContent = isVpub ? '⏰ NV đang xử lý' : '⏰ Quá hạn (chưa xong)';
}

function setLoggedInUser(user, tokenToRemember = "") {
    if (tokenToRemember) user._rawToken = tokenToRemember;
    else if (!user._rawToken) user._rawToken = _readStoredToken() || "";
    try { applyTokenMultiScope(user, user._rawToken); } catch (e) {}
    CURRENT_USER = user;
    syncUserWorkspaceVisibility(user);
    safeLSSet("vp_demo_user", JSON.stringify(user));
    try{ sessionStorage.setItem("vp_demo_user", JSON.stringify(user)); }catch(e){}
    if (tokenToRemember) {
        const obf = _obfToken(tokenToRemember);
        safeLSSet("_vp_t", obf);
        try{ sessionStorage.setItem("_vp_t", obf); }catch(e){}
        // xóa key plain cũ nếu còn để giảm lộ
        try{ localStorage.removeItem("vp_demo_token"); }catch(_){}
        try{ sessionStorage.removeItem("vp_demo_token"); }catch(_){}
    }
    document.getElementById("authGate").classList.add("hidden");
    document.getElementById("userChip").style.display = "inline-flex";
    document.getElementById("logoutBtn").style.display = "inline-flex";
    const _lb2=document.getElementById("logoutBtn2"); if(_lb2) _lb2.style.display="inline-flex";
    document.getElementById("userChipName").textContent = demoMaskName(user.name) || "Chưa đăng nhập";
    document.getElementById("userChipRole").textContent = userRoleLabel(user);
    const logItem = document.getElementById("activityLogSidebarItem");
    if (logItem) logItem.style.display = user.role === "admin" ? "flex" : "none";
    const backupItem = document.getElementById("backupSidebarItem");
    if (backupItem) backupItem.style.display = user.role === "admin" ? "flex" : "none";
    const warnItem = document.getElementById("warnSidebarItem");
    if (warnItem) {
        const isOfficeStaff = user.role === "staff" && user.scope === "office";
        warnItem.style.display = (user.role === "admin" || isOfficeStaff) ? "flex" : "none";
    }
    const setRoleItem = document.getElementById("setRoleSidebarItem");
    if (setRoleItem) setRoleItem.style.display = user.role === "admin" ? "flex" : "none";
    const notifBtn = document.getElementById("notifBtn");
    if (notifBtn) notifBtn.style.display = "";
    const loginKey = `activity_login_${user.id}`;
    if (sessionStorage.getItem(loginKey) !== "1") {
        sessionStorage.setItem(loginKey, "1");
        writeActivity("Đăng nhập");
    }
    // V48: tải đủ 3 workspace để dashboard dùng chung số liệu.
    refreshAllData();
    setTimeout(() => { try { if (typeof ppRenderViewMode === 'function') ppRenderViewMode(); if (typeof ppSyncAllProvinceRoleUI === 'function') ppSyncAllProvinceRoleUI(); } catch (e) { } }, 700);
    setTimeout(() => { try{ if(typeof vpRestoreLastWs==="function") vpRestoreLastWs(); }catch(e){} }, 900);
}

async function loginWithToken() {
    const input = document.getElementById("tokenInput");
    const token = input.value.trim();
    const err = document.getElementById("authError");
    const btn = document.querySelector(".auth-login-btn");
    err.textContent = "";
    if (!token) { err.textContent = "Vui lòng nhập token truy cập."; input.focus(); return; }
    // Token thật đã chuyển lên Supabase 4 bảng, xác thực duy nhất qua /api/admin (SERVICE_ROLE_KEY)
    // Giữ fallback demo theo yêu cầu - làm mờ plain string để giảm grep
    try {
        if (btn) { btn.disabled = true; btn.textContent = "⏳ Đang kiểm tra..."; }
        const loginRes = await fetch('/api/admin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'login', token: token })
        });
        const loggedUser = await loginRes.json().catch(() => ({}));
        if (loginRes.ok && loggedUser && loggedUser.role) {
            setLoggedInUser(loggedUser, token);
            input.value = "";
            return;
        }
        err.textContent = loggedUser.error || "Token không hợp lệ hoặc chưa được cấp quyền.";
        input.select();
    } catch (e) {
        void e;
        err.textContent = "Không thể kết nối máy chủ xác thực. Vui lòng thử lại.";
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "🔐 Đăng nhập"; }
    }
}

function setAuthStatus(t) { try{ const el = document.getElementById("authStatusLine"); if(el) el.textContent = t; }catch(e){} }

function logoutUser() {
    try{ localStorage.removeItem("vp_demo_user"); }catch(e){}
    try{ localStorage.removeItem("vp_demo_token"); }catch(e){}
    try{ localStorage.removeItem("_vp_t"); }catch(e){}
    try{ sessionStorage.removeItem("vp_demo_user"); }catch(e){}
    try{ sessionStorage.removeItem("vp_demo_token"); }catch(e){}
    try{ sessionStorage.removeItem("_vp_t"); }catch(e){}
    try{ localStorage.removeItem("vp_last_ws"); }catch(e){}
    try{ localStorage.removeItem("vp_last_ws_mode"); }catch(e){}
    CURRENT_USER = null;
    DATA = []; filtered = []; BCH_TASKS = []; TTBTV_TASKS = []; PROV_TASKS = []; BCH_LOADED = false; TTBTV_LOADED = false; PROV_LOADED = false;
    document.getElementById("mttqKpiWorkspace")?.classList.remove("open");
    document.getElementById("userChip").style.display = "none";
    document.getElementById("logoutBtn").style.display = "none";
    const _lb2b=document.getElementById("logoutBtn2"); if(_lb2b) _lb2b.style.display="inline-flex";
    document.getElementById("authGate").classList.remove("hidden");
    document.getElementById("tokenInput").value = "";
    document.getElementById("authError").textContent = "";
    setAuthStatus("Xin chào");
    const warnItemOut = document.getElementById("warnSidebarItem"); if (warnItemOut) warnItemOut.style.display = "none";
    const notifBtnOut = document.getElementById("notifBtn"); if (notifBtnOut) notifBtnOut.style.display = "none";
    setTimeout(() => document.getElementById("tokenInput").focus(), 50);
}

async function initAuth() {
    try{
    let rememberedToken = _readStoredToken() || "";
    if(!rememberedToken){ try{ rememberedToken = localStorage.getItem("vp_demo_token") || ""; }catch(e){} }
    if(!rememberedToken){ const c=readCache("vp_demo_token"); if(c) rememberedToken = typeof c==="string"?c:(c.token||""); }
    if (rememberedToken) {
        setAuthStatus("Đang tải… xin đợi");
        // Luôn xác thực lại với máy chủ. Chỉ dùng bộ nhớ đệm khi KHÔNG kết nối được (mất mạng).
        // Nếu máy chủ trả lời token không hợp lệ (đã thu hồi/sai) thì đăng xuất, không dùng cache.
        let unreachable = false;
        try {
            const r = await fetch('/api/admin', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'login', token: rememberedToken}) });
            const fresh = await r.json().catch(()=>null);
            if (r.ok && fresh && fresh.role) { setLoggedInUser(fresh, rememberedToken); return; }
        } catch (e) { unreachable = true; }
        if (unreachable) {
            try {
                const raw = safeLSGet("vp_demo_user","") || sessionStorage.getItem("vp_demo_user") || "";
                const cu = raw ? JSON.parse(raw) : null;
                if (cu && cu.id && cu.role) { cu._rawToken = rememberedToken; setLoggedInUser(cu, rememberedToken); return; }
            } catch(_) {}
        }
        try{ localStorage.removeItem("vp_demo_token"); }catch(e){}
        try{ localStorage.removeItem("_vp_t"); }catch(e){}
        try{ sessionStorage.removeItem("vp_demo_token"); }catch(e){}
        try{ sessionStorage.removeItem("_vp_t"); }catch(e){}
        try{ localStorage.removeItem("vp_demo_user"); }catch(e){}
        try{ sessionStorage.removeItem("vp_demo_user"); }catch(e){}
    }
    }catch(e){ void e; }
    setAuthStatus("Xin chào");
    document.getElementById("authGate").classList.remove("hidden");
    setTimeout(() => { try{ document.getElementById("tokenInput").focus(); }catch(e){} }, 100);
}

function canEditTask(x) {
    if (!CURRENT_USER) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return false;
    return CURRENT_USER.role === "admin" || (CURRENT_USER.role === "staff" && CURRENT_USER.name === x.owner);
}

function syncWorkspaceExtendButton(id, source, task) {
    const btn = document.getElementById(id);
    if (!btn) return;
    const due = source === "bch" ? bchDeadlineDate(task.deadline) : source === "ttbtv" ? ttbtvDeadlineDate(task.deadline) : provinceDeadlineDate(task.deadline);
    const overdue = source === "bch" ? bchStatusFor(task) === "overdue" : source === "ttbtv" ? ttbtvStatusFor(task) === "overdue" : provinceStatusFor(task) === "overdue";
    btn.style.display = CURRENT_USER?.role === "admin" && overdue && due ? "inline-flex" : "none";
}

function officeRoleCanonical(raw) {
    const s = officeFold(String(raw || ""));
    if (!s) return "";
    if (s === "ct" || s === "chu tri") return "Chủ trì";
    if (s === "ph" || s === "phoi hop" || s === "phoi_hop" || s === "phoihop") return "Phối hợp";
    if (s === "td") return "TĐ";
    return String(raw || "").trim();
}

function officeRoleDisplay(raw) {
    const c = officeRoleCanonical(raw);
    if (c === "Chủ trì" || c === "Phối hợp" || c === "TĐ") return c;
    return String(raw || "").trim() || "—";
}

function officeChartRole(raw) {
    const s = officeFold(String(raw || ""));
    if (s === "ct" || s === "chu tri") return "Chủ trì";
    if (s === "ph" || s === "phoi hop" || s === "phoi_hop" || s === "phoihop") return "Phối hợp";
    if (s === "td") return "TĐ";
    if (!s) return "Khác";
    const c = officeRoleCanonical(raw);
    if (c === "Chủ trì" || c === "Phối hợp" || c === "TĐ") return c;
    return "Khác";
}

function officeRoleOptionsHtml(selected) {
    const can = officeRoleCanonical(selected);
    const isOther = selected && can !== "Chủ trì" && can !== "Phối hợp" && String(selected).trim() !== "";
    let html = '<option value="">Chọn vai trò...</option>';
    html += `<option value="Chủ trì"${can === "Chủ trì" ? " selected" : ""}>Chủ trì</option>`;
    html += `<option value="Phối hợp"${can === "Phối hợp" ? " selected" : ""}>Phối hợp</option>`;
    html += `<option value="__other__"${isOther ? " selected" : ""}>Khác</option>`;
    return html;
}

function handleOfficeRoleOther(sel) {
    if (!sel) return;
    const otherId = sel.id + "Other";
    const other = document.getElementById(otherId);
    if (!other) return;
    if (sel.value === "__other__") {
        other.style.display = "";
        other.focus();
    } else {
        other.style.display = "none";
        other.value = "";
    }
}

function getOfficeRoleValue(selectId) {
    const sel = document.getElementById(selectId);
    const other = document.getElementById(selectId + "Other");
    if (!sel) return "";
    if (sel.value === "__other__") return (other?.value || "").trim();
    return (sel.value || "").trim();
}

function canEditBCHTask(x) {
    if (!CURRENT_USER) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return false;
    if (CURRENT_USER.role === "admin") return true;
    if (CURRENT_USER.name && String(CURRENT_USER.name).trim() === String(x.officer_name||"").trim()) return true;
    if (isNGNUser(CURRENT_USER)) return true;
    return false;
}

function ttbtvRoleMemberKey(r) {
    // Trạng thái từng thành viên trong Group vai trò: có Ngày HT + Kết quả mới tính Hoàn thành.
    const due = ttbtvDeadlineDate(r?.due);
    const done = ttbtvCompletedDate(r?.done);
    if (done && ttbtvHasResult(r?.result)) {
        if (due) {
            const a = new Date(done.getFullYear(), done.getMonth(), done.getDate()).getTime();
            const b = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
            if (a < b) return "early";
            if (a === b) return "ontime";
            return "latedone";
        }
        return "ontime";
    }
    const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (due && due < today) return "overdue";
    return "processing";
}

function ttbtvGroupKeyFromRoles(roles, mainDue, mainCompleted, agencyRole) {
    // Chỉ Hoàn thành khi LÃNH ĐẠO bắt buộc xong: LĐ phòng luôn cần; thêm LĐ UBND khi Cơ quan=UBND xã.
    // CV tham mưu được thiếu (trống thì bỏ qua, có dữ liệu thì cũng phải xong).
    const active = (roles || []).filter(r => r && (r.name || r.due || r.done || r.result || r.reason));
    if (!active.length) return null;
    const byTitle = {};
    active.forEach(r => { if (r && r.title && !byTitle[r.title]) byTitle[r.title] = r; });
    const isDone = t => byTitle[t] && ["early", "ontime", "latedone"].includes(ttbtvRoleMemberKey(byTitle[t]));
    const notDone = () => {
        const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if (mainDue && mainDue < today) return "overdue";
        return "processing";
    };
    const required = ttbtvIsUBND(agencyRole) ? ["Lãnh đạo UBND", "Lãnh đạo phòng"] : ["Lãnh đạo phòng"];
    if (!required.every(isDone)) return notDone();
    const cv = byTitle["CV tham mưu"];
    if (cv && (cv.name || cv.due || cv.done || cv.result) && !isDone("CV tham mưu")) return notDone();
    if (mainCompleted) {
        if (mainDue) {
            const a = new Date(mainCompleted.getFullYear(), mainCompleted.getMonth(), mainCompleted.getDate()).getTime();
            const b = new Date(mainDue.getFullYear(), mainDue.getMonth(), mainDue.getDate()).getTime();
            if (a < b) return "early";
            if (a === b) return "ontime";
            return "latedone";
        }
        return "ontime";
    }
    return "ontime";
}

function canEditTTBTVTask(x) {
    if (!CURRENT_USER || !x) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return true;
    if (CURRENT_USER.role === "admin") return true;
    try{ if (typeof userCan==='function' && userCan(CURRENT_USER,"edit","ttbtv")) return true; }catch(e){}
    if (CURRENT_USER.role === "staff" && String(CURRENT_USER.name||"").trim() === String(x.officer_name||"").trim()) return true;
    // cơ quan token: nếu tên cơ quan khớp với Cơ quan chủ trì (role/unit_name) thì được sửa
    try{
        const _nmV = String(CURRENT_USER.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase();
        const _isVpdu = CURRENT_USER.scope==='office' && (_nmV.includes('van phong dang uy') || _nmV.replace(/[^a-z0-9]/g,'').includes('vpdu'));
        const isAgencyToken = (typeof TTBTV_ALLOWED_TOKENS !== 'undefined' && TTBTV_ALLOWED_TOKENS.has(CURRENT_USER._rawToken)) || CURRENT_USER.role === 'department' || CURRENT_USER.scope === 'action100' || _isVpdu;
        if(isAgencyToken){
            const norm = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase().trim();
            const nm = norm(CURRENT_USER.name);
            if(nm){
                const base = nm.replace(/^cb\s+/,'').replace(/^cq\s+/,'').trim();
                const agencyVals = [x.role, x.unit_name].map(norm).filter(Boolean);
                for(const a of agencyVals){
                    if(!a) continue;
                    if(a===nm || a.includes(nm) || nm.includes(a)) return true;
                    if(base && (a.includes(base) || base.includes(a))) return true;
                    // alias viết tắt: Ban Xây dựng Đảng <-> BANXDD
                    const initials = s => norm(s).split(/[^a-z0-9]+/).filter(Boolean).map(w=>w[0]).join('');
                    const ni = initials(nm), ai = initials(a);
                    if(ni && ai && (ni===ai || ai.includes(ni) || ni.includes(ai))) return true;
                }
            }
        }
    }catch(e){}
    return false;
}

async function ttbtvHandleRoleOther(sel, type = "agency") {
    if (!sel) return;
    if (sel.value !== "__other__") { sel.dataset.prev = sel.value; if (sel.id === "ttbtvNewRole" || sel.id === "ttbtvEditRole") { try { ttbtvSyncRoleGroup(sel, sel.id === "ttbtvEditRole" ? "ttbtvEditRoleUBNDRow" : "ttbtvRoleUBNDRow"); } catch (e) {} } return; }
    const prev = sel.dataset.prev || "";
    const isLeader = type === "leader" || sel.id === "vpubLeader";
    const bodyHtml = `<div style="margin-top:4px"><input id="customTTBTVRoleInput" type="text" placeholder="${isLeader ? "Nhập tên lãnh đạo phụ trách..." : "Nhập tên cơ quan chủ trì..."}" maxlength="120" style="width:100%;padding:12px 14px;border:1.5px solid #cbd5e1;border-radius:10px;font-size:14px;background:#fff;outline:none"></div>`;
    setTimeout(() => document.getElementById("customTTBTVRoleInput")?.focus(), 120);
    const ok = await provinceConfirm({ icon: isLeader ? "👤" : "🏢", title: isLeader ? "Nhập tên lãnh đạo" : "Nhập cơ quan chủ trì", message: isLeader ? "Vui lòng nhập tên lãnh đạo" : "Vui lòng nhập tên cơ quan chủ trì", bodyHtml, confirmText: "Thêm", cancelText: "Hủy", confirmClass: "btn-primary" });
    const custom = document.getElementById("customTTBTVRoleInput")?.value.trim() || "";
    if (ok && custom) {
        if (![...sel.options].some(o => o.value === custom)) {
            const opt = document.createElement("option"); opt.value = custom; opt.textContent = custom;
            const other = [...sel.options].find(o => o.value === "__other__");
            if (other) sel.insertBefore(opt, other); else sel.appendChild(opt);
        }
        sel.value = custom; sel.dataset.prev = custom;
    } else {
        sel.value = prev || "";
    }
    if (sel.id === "ttbtvNewRole" || sel.id === "ttbtvEditRole") { try { ttbtvSyncRoleGroup(sel, sel.id === "ttbtvEditRole" ? "ttbtvEditRoleUBNDRow" : "ttbtvRoleUBNDRow"); } catch (e) {} }
}

function ttbtvSyncRoleGroup(sel, rowId) {
    const isUBND = ttbtvIsUBND(sel?.value);
    const row = document.getElementById(rowId || "ttbtvRoleUBNDRow");
    if (row) row.style.display = isUBND ? "" : "none";
}

function ttbtvCollectRoleRows() {
    const defs = [
        { title: "Lãnh đạo UBND", nameId: "ttbtvNewUBNDLeader", dueId: "ttbtvRoleUBNDDue", doneId: "ttbtvRoleUBNDDone", resultId: "ttbtvRoleUBNDResult", reasonId: "ttbtvRoleUBNDReason" },
        { title: "Lãnh đạo phòng", nameId: "ttbtvNewOfficer", dueId: "ttbtvRolePhongDue", doneId: "ttbtvRolePhongDone", resultId: "ttbtvRolePhongResult", reasonId: "ttbtvRolePhongReason" },
        { title: "CV tham mưu", nameId: "ttbtvNewSpecialist", dueId: "ttbtvRoleCVDue", doneId: "ttbtvRoleCVDone", resultId: "ttbtvRoleCVResult", reasonId: "ttbtvRoleCVReason" }
    ];
    const isUBND = ttbtvIsUBND(document.getElementById("ttbtvNewRole")?.value);
    return defs.filter(d => d.title !== "Lãnh đạo UBND" || isUBND).map(d => {
        const v = id => (document.getElementById(id)?.value || "").trim();
        const due = v(d.dueId), done = v(d.doneId);
        if (due) requireValidDate(due, `${d.title} - Hạn hoàn thành`, false);
        if (done) requireValidDate(done, `${d.title} - Ngày hoàn thành`, false);
        return { title: d.title, name: v(d.nameId), due, done, result: v(d.resultId), reason: v(d.reasonId) };
    });
}

function ttbtvParseRoleNote(note) {
    try {
        const s = String(note || "").trim();
        if (!s || s[0] !== "{") return null;
        const o = JSON.parse(s);
        return Array.isArray(o.roles) ? o.roles : null;
    } catch (e) { return null; }
}

function ttbtvFillEditRoles(x) {
    const byTitle = {};
    (ttbtvParseRoleNote(x.note) || []).forEach(r => { if (r && r.title) byTitle[r.title] = r; });
    [
        { t: "Lãnh đạo UBND", due: "ttbtvEditRoleUBNDDue", done: "ttbtvEditRoleUBNDDone", result: "ttbtvEditRoleUBNDResult", reason: "ttbtvEditRoleUBNDReason" },
        { t: "Lãnh đạo phòng", due: "ttbtvEditRolePhongDue", done: "ttbtvEditRolePhongDone", result: "ttbtvEditRolePhongResult", reason: "ttbtvEditRolePhongReason" },
        { t: "CV tham mưu", due: "ttbtvEditRoleCVDue", done: "ttbtvEditRoleCVDone", result: "ttbtvEditRoleCVResult", reason: "ttbtvEditRoleCVReason" }
    ].forEach(m => {
        const r = byTitle[m.t] || {};
        const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v || ""; };
        set(m.due, r.due); set(m.done, r.done); set(m.result, r.result); set(m.reason, r.reason);
    });
}

function ttbtvCollectEditRoles() {
    const defs = [
        { title: "Lãnh đạo UBND", dueId: "ttbtvEditRoleUBNDDue", doneId: "ttbtvEditRoleUBNDDone", resultId: "ttbtvEditRoleUBNDResult", reasonId: "ttbtvEditRoleUBNDReason" },
        { title: "Lãnh đạo phòng", dueId: "ttbtvEditRolePhongDue", doneId: "ttbtvEditRolePhongDone", resultId: "ttbtvEditRolePhongResult", reasonId: "ttbtvEditRolePhongReason" },
        { title: "CV tham mưu", dueId: "ttbtvEditRoleCVDue", doneId: "ttbtvEditRoleCVDone", resultId: "ttbtvEditRoleCVResult", reasonId: "ttbtvEditRoleCVReason" }
    ];
    const isUBND = ttbtvIsUBND(document.getElementById("ttbtvEditRole")?.value);
    return defs.filter(d => d.title !== "Lãnh đạo UBND" || isUBND).map(d => {
        const v = id => (document.getElementById(id)?.value || "").trim();
        const due = v(d.dueId), done = v(d.doneId);
        if (due) requireValidDate(due, `${d.title} - Hạn hoàn thành`, false);
        if (done) requireValidDate(done, `${d.title} - Ngày hoàn thành`, false);
        return { title: d.title, due, done, result: v(d.resultId), reason: v(d.reasonId) };
    });
}

function ttbtvRefreshRoleStatuses(mode) {
    // Trạng thái (tự động) của từng người trong group Vai trò.
    try {
        const isNew = mode === "new";
        const pairs = isNew ? [
            ["ttbtvRoleUBNDDue", "ttbtvRoleUBNDDone", "ttbtvRoleUBNDResult", "ttbtvRoleUBNDStatus"],
            ["ttbtvRolePhongDue", "ttbtvRolePhongDone", "ttbtvRolePhongResult", "ttbtvRolePhongStatus"],
            ["ttbtvRoleCVDue", "ttbtvRoleCVDone", "ttbtvRoleCVResult", "ttbtvRoleCVStatus"]
        ] : [
            ["ttbtvEditRoleUBNDDue", "ttbtvEditRoleUBNDDone", "ttbtvEditRoleUBNDResult", "ttbtvEditRoleUBNDStatus"],
            ["ttbtvEditRolePhongDue", "ttbtvEditRolePhongDone", "ttbtvEditRolePhongResult", "ttbtvEditRolePhongStatus"],
            ["ttbtvEditRoleCVDue", "ttbtvEditRoleCVDone", "ttbtvEditRoleCVResult", "ttbtvEditRoleCVStatus"]
        ];
        pairs.forEach(([dueId, doneId, resId, stId]) => {
            const el = document.getElementById(stId); if (!el) return;
            const due = document.getElementById(dueId)?.value || "";
            const done = document.getElementById(doneId)?.value || "";
            const result = document.getElementById(resId)?.value || "";
            if (!String(due).trim() && !String(done).trim() && !ttbtvHasResult(result)) { el.value = "—"; return; }
            el.value = ttbtvStatusLabel(ttbtvRoleMemberKey({ due, done, result }));
        });
    } catch (e) {}
}

function canEditPROVTask(x) {
    if (!CURRENT_USER) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return true; // intentional cross-edit cho CV nhập liệu
    return CURRENT_USER.role === "admin" || provinceUserOwnsTask(x);
}

function provinceParseRoleNote(note){
    try{ const s=String(note||"").trim(); if(!s||s[0]!=="{") return null; const o=JSON.parse(s); return Array.isArray(o.roles)?o.roles:null; }catch(e){ return null; }
}

function provinceFillEditRoles(x){
    const byTitle={}; (provinceParseRoleNote(x.note)||[]).forEach(r=>{ if(r&&r.title) byTitle[r.title]=r; });
    [
        {t:"Lãnh đạo UBND", due:"provinceEditRoleUBNDDue", done:"provinceEditRoleUBNDDone", result:"provinceEditRoleUBNDResult", reason:"provinceEditRoleUBNDReason"},
        {t:"Lãnh đạo phòng", due:"provinceEditRolePhongDue", done:"provinceEditRolePhongDone", result:"provinceEditRolePhongResult", reason:"provinceEditRolePhongReason"},
        {t:"CV tham mưu", due:"provinceEditRoleCVDue", done:"provinceEditRoleCVDone", result:"provinceEditRoleCVResult", reason:"provinceEditRoleCVReason"}
    ].forEach(m=>{
        const r=byTitle[m.t]||{};
        const set=(id,v)=>{ const el=document.getElementById(id); if(el) el.value=v||""; };
        set(m.due, r.due); set(m.done, r.done); set(m.result, r.result); set(m.reason, r.reason);
    });
}

function provinceCollectEditRoles(){
    const defs=[
        {title:"Lãnh đạo UBND", dueId:"provinceEditRoleUBNDDue", doneId:"provinceEditRoleUBNDDone", resultId:"provinceEditRoleUBNDResult", reasonId:"provinceEditRoleUBNDReason"},
        {title:"Lãnh đạo phòng", dueId:"provinceEditRolePhongDue", doneId:"provinceEditRolePhongDone", resultId:"provinceEditRolePhongResult", reasonId:"provinceEditRolePhongReason"},
        {title:"CV tham mưu", dueId:"provinceEditRoleCVDue", doneId:"provinceEditRoleCVDone", resultId:"provinceEditRoleCVResult", reasonId:"provinceEditRoleCVReason"}
    ];
    const isUBND=provinceIsUBND(document.getElementById("provinceEditUnit")?.value);
    return defs.filter(d=> d.title!=="Lãnh đạo UBND" || isUBND).map(d=>{
        const v=id=> (document.getElementById(id)?.value||"").trim();
        const due=v(d.dueId), done=v(d.doneId);
        if(due) requireValidDate(due, `${d.title} - Hạn hoàn thành`, false);
        if(done) requireValidDate(done, `${d.title} - Ngày hoàn thành`, false);
        return {title:d.title, due, done, result:v(d.resultId), reason:v(d.reasonId)};
    });
}

function provinceSyncRoleGroup(sel){
    const isUBND=provinceIsUBND(sel?.value);
    const row=document.getElementById("provinceEditRoleUBNDRow");
    if(row) row.style.display=isUBND?"":"none";
    // Nếu chọn Khác thì mở prompt nhập
    if(sel && sel.value==="__other__"){
        // defer to existing handler if any, but use generic
        setTimeout(()=>provinceHandleUnitOther(sel), 0);
    }
}

function provinceRoleMemberKey(r){
    const due=provinceDeadlineDate(r?.due);
    const done=provinceCompletedDate(r?.done);
    // Có Ngày HT là tự tính hoàn thành (như provinceStatusFor), không bắt buộc Kết quả
    if(done){
        if(due){
            const a=new Date(done.getFullYear(), done.getMonth(), done.getDate()).getTime();
            const b=new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
            if(a<b) return "early"; if(a===b) return "ontime"; return "latedone";
        }
        return "ontime";
    }
    // Chưa có Ngày HT: nếu có Kết quả kèm Hạn quá hạn thì cũng tính quá hạn, không thì đang triển khai
    const now=new Date(), today=new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if(due && due < today) return "overdue";
    return "processing";
}

function provinceGroupKeyFromRoles(roles, mainDue, mainCompleted, agencyRole){
    const active=(roles||[]).filter(r=> r && (r.due||r.done||r.result||r.reason));
    if(!active.length) return null;
    const byTitle={}; active.forEach(r=>{ if(r && r.title && !byTitle[r.title]) byTitle[r.title]=r; });
    const isDone=t=> byTitle[t] && ["early","ontime","latedone"].includes(provinceRoleMemberKey(byTitle[t]));
    const notDone=()=>{
        const now=new Date(), today=new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if(mainDue && mainDue < today) return "overdue";
        return "processing";
    };
    // Yêu cầu lãnh đạo bắt buộc: UBND xã cần LĐ UBND + LĐ phòng, khác chỉ LĐ phòng; CV thiếu vẫn ok nhưng nếu có dữ liệu thì phải xong
    const needUBND=provinceIsUBND(agencyRole);
    const required= needUBND ? ["Lãnh đạo UBND","Lãnh đạo phòng"] : ["Lãnh đạo phòng"];
    const allRequiredDone= required.every(t=> isDone(t));
    if(!allRequiredDone) return notDone();
    // CV tham mưu: nếu trống thì bỏ qua, nếu có dữ liệu thì cũng phải xong
    const cv=byTitle["CV tham mưu"];
    const cvHasData=cv && (cv.due||cv.done||cv.result||cv.reason);
    if(cvHasData && !isDone("CV tham mưu")) return notDone();
    // Tất cả bắt buộc đã xong -> trả về trạng thái chi tiết của LĐ chính (ưu tiên LĐ UBND nếu có)
    const leadTitle= needUBND ? "Lãnh đạo UBND" : "Lãnh đạo phòng";
    const leadKey=provinceRoleMemberKey(byTitle[leadTitle]||{});
    if(["early","ontime","latedone"].includes(leadKey)) return leadKey;
    return "done";
}

function provinceRefreshRoleStatuses(){
    try{
        const pairs=[
            ["provinceEditRoleUBNDDue","provinceEditRoleUBNDDone","provinceEditRoleUBNDResult","provinceEditRoleUBNDStatus"],
            ["provinceEditRolePhongDue","provinceEditRolePhongDone","provinceEditRolePhongResult","provinceEditRolePhongStatus"],
            ["provinceEditRoleCVDue","provinceEditRoleCVDone","provinceEditRoleCVResult","provinceEditRoleCVStatus"]
        ];
        pairs.forEach(([dueId,doneId,resId,stId])=>{
            const el=document.getElementById(stId); if(!el) return;
            const due=document.getElementById(dueId)?.value||"";
            const done=document.getElementById(doneId)?.value||"";
            const result=document.getElementById(resId)?.value||"";
            if(!String(due).trim() && !String(done).trim() && !provinceHasResult(result)){ el.value="—"; return; }
            el.value=provinceStatusLabel(provinceRoleMemberKey({due, done, result}));
        });
    }catch(e){}
}

function canEditAction100Task(x) {
    if (!CURRENT_USER || !x) return false;
    if (canNGNEditTask(x)) return true;
    if (CURRENT_USER.scope === "data_entry") return true;
    if (CURRENT_USER.role === 'admin') return true;
    if (userCan(CURRENT_USER, "edit", ACTION100_MODE === 'vpub' ? "vpub" : "action100")) return true;
    if (CURRENT_USER.scope === 'action100' || (CURRENT_USER.scope === 'office' && (()=>{ const _n=String(CURRENT_USER.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase(); return _n.includes('van phong dang uy')||_n.replace(/[^a-z0-9]/g,'').includes('vpdu'); })())) {
        const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase().trim();
        const initials = s => { const n=norm(s); if(!n.includes(' ') && n.length<=6 && /^[a-z0-9]+$/.test(n)) return n; return n.split(/[^a-z0-9]+/).filter(Boolean).map(w=>w[0]).join(''); };
        const tokenInit = s => { const n=norm(s); return n.includes(' ') ? initials(n) : n.replace(/[^a-z0-9]/g,''); };
        const nmNorm = norm(CURRENT_USER.name);
        if (!nmNorm) return false;
        const baseNm = nmNorm.replace(/^cb\s+/, '').replace(/^cq\s+/, '').trim();
        const nmInit = tokenInit(nmNorm);
        const vals = ACTION100_MODE === 'vpub' ? [x.unit, x.field] : [x.commune_leader, x.unit_name];
        return vals.some(v => { const s = norm(v); if (!s) return false; if (s === nmNorm || s.includes(nmNorm) || nmNorm.includes(s)) return true; if (baseNm && (s.includes(baseNm) || baseNm.includes(s))) return true; const sInit = initials(s); if(nmInit && sInit && (sInit===nmInit || sInit.includes(nmInit) || nmInit.includes(sInit))) return true; return false; });
    }
    if (CURRENT_USER.role === 'staff') {
        return String(CURRENT_USER.name || '').trim() === String(x.officer_name || '').trim();
    }
    if (CURRENT_USER.role === 'department' && CURRENT_USER.scope === 'vpub') {
        const dept = String(CURRENT_USER.name || '').trim().toLowerCase();
        return [x.unit, x.field, x.leader, x.source, x.unit_name, x.role, x.commune_leader, x.office_leader, x.specialist_name, x.officer_name].some(v => { const s = String(v || '').trim().toLowerCase(); return s && (s === dept || s.includes(dept) || dept.includes(s)); });
    }
    return false;
}

function ppIsAdmin() { if (CURRENT_USER?.role === 'admin') return true; try { const t = String(CURRENT_USER?._rawToken || safeLSGet("vp_demo_token","") || sessionStorage.getItem("vp_demo_token") || "").trim();  } catch (e) { } return false; }

function ppTokenInit(s){ const n=ppNorm(s); return n.includes(' ') ? ppInitials(n) : n.replace(/[^a-z0-9]/g,''); }

function ppMatchAgencyByToken(v){
    v = ppNorm(v); if (!v) return false;
    const nm = ppNorm(CURRENT_USER?.name); if (!nm) return false;
    const compact = s => String(s || '').replace(/[^a-z0-9]/g, '');
    // Alias: token VPUB chính là "Văn phòng HĐND & UBND" và "UBND xã"
    if (compact(nm) === 'vpub' && ['vanphonghdndubnd', 'vphdndubnd', 'ubndxa'].includes(compact(v))) return true;
    if (v === nm || v.includes(nm) || nm.includes(v)) return true;
    const base = nm.replace(/^cb\s+/, '').replace(/^cq\s+/, '').trim();
    if (base && (v.includes(base) || base.includes(v))) return true;
    const nmInit = ppTokenInit(nm), vInit = ppInitials(v);
    if (nmInit && vInit && (vInit === nmInit || vInit.includes(nmInit) || nmInit.includes(vInit))) return true;
    return false;
}

function ppIsCurrentUserRow(row){
    if (!row || !CURRENT_USER?.name) return false;
    const me = ppNorm(CURRENT_USER.name); if (!me) return false;
    const el = row.querySelector('[data-k=name]'); if (!el) return false;
    let v = el.tagName === 'SELECT' ? (el.value || '') : (el.value != null ? el.value : (el.textContent || ''));
    v = String(v).trim(); if (!v || v === '__other__') return false;
    return ppNorm(v) === me;
}

function ppCurrentUserInTask(task){
    if (!task || !CURRENT_USER?.name) return false;
    const me = ppNorm(CURRENT_USER.name); if (!me) return false;
    const els = task.querySelectorAll('[data-k=name]');
    for (const el of els) {
        let v = el.tagName === 'SELECT' ? (el.value || '') : (el.value != null ? el.value : (el.textContent || ''));
        v = String(v).trim(); if (!v || v === '__other__') continue;
        if (ppNorm(v) === me) return true;
    }
    return false;
}

function ppCurrentUserInAgency(agEl){
    if (!agEl || !CURRENT_USER?.name) return false;
    const me = ppNorm(CURRENT_USER.name); if (!me) return false;
    const els = agEl.querySelectorAll('[data-k=name]');
    for (const el of els) {
        let v = el.tagName === 'SELECT' ? (el.value || '') : (el.value != null ? el.value : (el.textContent || ''));
        v = String(v).trim(); if (!v || v === '__other__') continue;
        if (ppNorm(v) === me) return true;
    }
    return false;
}

function ppScope100CanEditTask(task){
    if (ppIsAdmin()) return true;
    if (canNGNEditTask(task)) return true;
    if (CURRENT_USER?.scope === 'data_entry') return true; // intentional: CV nhập liệu được sửa mọi agency
    if (ppCurrentUserInTask(task)) return true; // Tỉnh giao: tên mình trong cây -> được sửa
    if (isNGNUser(CURRENT_USER)) {
        const agEls = [...task.querySelectorAll('.pp-agency [data-k=agencyOther]')];
        if (agEls.some(el => String(el.value || el.textContent || '').toLowerCase().includes('ubnd'))) return true;
    }
    try{ if (typeof userCan==='function' && userCan(CURRENT_USER,"edit","province")) return true; }catch(e){}
    if (!task || !['action100', 'vpub'].includes(CURRENT_USER?.scope) && !(CURRENT_USER?.scope==='office' && (()=>{ const _n=String(CURRENT_USER?.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase(); return _n.includes('van phong dang uy')||_n.replace(/[^a-z0-9]/g,'').includes('vpdu'); })())) return false;
    const agEls = [...task.querySelectorAll('.pp-agency [data-k=agencyOther]')];
    return agEls.some(el => ppMatchAgencyByToken(el.value || el.textContent || ''));
}

function ppCanEditProvinceTask(task){ return ppIsAdmin() || ppScope100CanEditTask(task) || ppCurrentUserInTask(task); }

function ppScope100CanEditAgency(agEl){
    if (ppIsAdmin()) return true;
    if (canNGNEditTask(agEl?.closest('.pp-task'))) return true;
    if (CURRENT_USER?.scope === 'data_entry') return true;
    if (ppCurrentUserInAgency(agEl)) return true; // tên mình trong agency đó -> được sửa agency đó
    if (isNGNUser(CURRENT_USER)) {
        const sel = agEl?.querySelector('[data-k=agencyOther]');
        if (String(sel?.value || sel?.textContent || '').toLowerCase().includes('ubnd')) return true;
    }
    try{ if (typeof userCan==='function' && userCan(CURRENT_USER,"edit","province")) return true; }catch(e){}
    if (!agEl || !['action100', 'vpub'].includes(CURRENT_USER?.scope) && !(CURRENT_USER?.scope==='office' && (()=>{ const _n=String(CURRENT_USER?.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/Đ/g,'D').replace(/đ/g,'d').toLowerCase(); return _n.includes('van phong dang uy')||_n.replace(/[^a-z0-9]/g,'').includes('vpdu'); })())) return false;
    const sel = agEl.querySelector('[data-k=agencyOther]');
    return ppMatchAgencyByToken(sel?.value || sel?.textContent || '');
}

function ppSyncTaskRoleUI(task) {
    if (!task) return;
    const isAdmin = ppIsAdmin();
    const isLimited = !isAdmin && (ppScope100CanEditTask(task) || ppCurrentUserInTask(task));
    const canEdit = isAdmin || isLimited;
    const saveBtn = task.querySelector('.pp-save-btn') || task.querySelector('button[onclick="ppSaveOne(this)"]');
    const editBtn = task.querySelector('.pp-edit-btn') || task.querySelector('button[onclick="ppEditTask(this)"]');
    const delBtn = task.querySelector('.pp-delete-btn') || task.querySelector('button[onclick*="ppUpdateSTT"]');
    const agencyBtns = task.querySelectorAll('.pp-agency-remove');
    const pcmBtns = task.querySelectorAll('.pp-pcm-remove');
    const headerBtns = [saveBtn, editBtn, delBtn, ...agencyBtns, ...pcmBtns];
    headerBtns.forEach(b => {
        if (!b) return;
        let enable = canEdit;
        if (isLimited) enable = (b === saveBtn || b === editBtn);
        b.disabled = !enable;
        b.style.opacity = enable ? '' : '0.45';
        b.style.pointerEvents = enable ? '' : 'none';
        b.style.filter = enable ? '' : 'grayscale(0.2)';
        b.title = enable ? '' : (isLimited ? 'Chỉ hiện Lưu/Sửa cho cơ quan phụ trách/phối hợp' : 'Chỉ Admin hoặc cơ quan phụ trách/phối hợp được thao tác');
    });
    task.querySelectorAll('.pp-agency').forEach(ag => {
        const pcmAddBtn = ag.querySelector('button[onclick*="ppAddPCM"], button[onclick*="ppTogglePCMList"]');
        if (pcmAddBtn) {
            const canPCM = isAdmin || ppScope100CanEditAgency(ag);
            pcmAddBtn.disabled = !canPCM;
            pcmAddBtn.style.opacity = canPCM ? '' : '0.45';
            pcmAddBtn.style.pointerEvents = canPCM ? '' : 'none';
            pcmAddBtn.title = canPCM ? '' : 'Chỉ cơ quan phụ trách/phối hợp được thêm LĐ PCM';
        }
    });
    const body = task.querySelector('.pp-task-body');
    const isExpanded = body && body.style.display !== 'none';
    if (isExpanded && !canEdit) {
        task.querySelectorAll('[contenteditable]').forEach(e => e.setAttribute('contenteditable', 'false'));
        task.querySelectorAll('.pp-person input, .pp-person textarea, [data-k=agencyOther], [data-k=agencyTask], [data-k=nhiemvu], [data-k=mota]').forEach(e => { e.readOnly = true; if (e.tagName === 'TEXTAREA' || e.tagName === 'INPUT') e.disabled = true; });
        task.querySelectorAll('.pp-task-body button').forEach(b => {
            if (headerBtns.includes(b)) return;
            b.disabled = true; b.style.opacity = '0.45'; b.style.pointerEvents = 'none';
        });
    } else if (isExpanded && isLimited) {
        task.querySelectorAll('[contenteditable]').forEach(e => e.setAttribute('contenteditable', 'false'));
        task.querySelectorAll('[data-k=agencyOther], [data-k=agencyTask], [data-k=nhiemvu], [data-k=mota], .pp-docs-tinh [contenteditable], .pp-docs-xa [contenteditable]').forEach(e => {
            if (e.hasAttribute('contenteditable')) e.setAttribute('contenteditable','false');
            else { e.readOnly = true; e.disabled = true; }
        });
        task.querySelectorAll('.pp-agency').forEach(ag=>{
            const canAG = ppScope100CanEditAgency(ag) || ppCurrentUserInAgency(ag);
            // Đánh dấu agency sửa được: viền + bóng cam nhạt, không nổi bật
            ag.style.boxShadow = canAG ? '0 0 0 2px rgba(249,115,22,.20)' : '';
            ag.style.borderColor = canAG ? '#fed7aa' : '';
            ag.querySelectorAll('.pp-person').forEach(row=>{
                const nameEl=row.querySelector('[data-k=name]');
                const finishEl=row.querySelector('[data-k=finish]');
                const productEl=row.querySelector('[data-k=product]');
                const progressEl=row.querySelector('[data-k=progress]');
                const reasonEl=row.querySelector('[data-k=reason]');
                const deadlineEl=row.querySelector('[data-k=deadline]');
                const isMyRow = ppIsCurrentUserRow(row);
                const canRow = canAG || isMyRow;
                // Reset label cũ (trước đó làm nổi bật nhãn trái) để tránh nhầm
                const oldLabelEl = row.querySelector('span');
                if (oldLabelEl && oldLabelEl.style.background === 'rgb(34, 197, 94)') {
                    oldLabelEl.style.background = ''; oldLabelEl.style.color = ''; oldLabelEl.style.padding = ''; oldLabelEl.style.borderRadius = ''; oldLabelEl.style.display = '';
                }
                if(canRow){
                    row.style.borderColor = '#fed7aa'; row.style.background = '#f0fdf4';
                    if(isMyRow) row.title = 'Nhiệm vụ của bạn — được phép sửa';
                    // Làm nổi bật nhãn/tiêu đề cho 3 trường token nhập được: Ngày hoàn thành (nhiệm vụ chính), Ngày hoàn thành (cán bộ), Tiến độ (cán bộ)
                    // -> nền xanh lá nhẹ #dcfce7 + chữ đen #000 cho header span (pp-nhiemvu) và cho input finish/progress
                    if (row.classList.contains('pp-nhiemvu')) {
                        const headSpans = row.querySelectorAll(':scope > div:first-child span');
                        headSpans.forEach(sp => {
                            const t = (sp.textContent || '').trim();
                            if (t === 'Ngày hoàn thành' || t === 'Tiến độ') {
                                sp.style.background = '#dcfce7';
                                sp.style.color = '#000';
                                sp.style.padding = '2px 6px';
                                sp.style.borderRadius = '6px';
                                sp.style.fontWeight = '800';
                                sp.style.display = 'inline-block';
                            }
                        });
                    }
                    [nameEl, finishEl, productEl, progressEl, reasonEl].forEach(el=>{ if(!el) return; el.readOnly=false; el.disabled=false; el.style.opacity=''; el.style.pointerEvents=''; });
                    if(deadlineEl){ deadlineEl.readOnly=true; deadlineEl.disabled=true; deadlineEl.style.opacity='0.6'; }
                    // Tên mình thì không cho đổi tên, chỉ sửa finish/product/progress/reason
                    if(isMyRow && nameEl){ nameEl.readOnly=true; nameEl.disabled=true; nameEl.style.opacity='0.65'; }
                    // Chỉ 2 trường Ngày hoàn thành (finish) và Tiến độ (progress) nổi bật: nền xanh lá nhẹ + chữ đen + viền cam nhạt
                    [finishEl, progressEl].forEach(el=>{ if(!el) return; el.style.background='#dcfce7'; el.style.color='#000'; el.style.borderColor='#fed7aa'; el.style.fontWeight='600'; });
                    [nameEl, productEl, reasonEl].forEach(el=>{ if(!el) return; el.style.background=''; el.style.color=''; el.style.borderColor=''; el.style.fontWeight=''; });
                    row.querySelectorAll('button').forEach(b=>{ b.disabled=false; b.style.opacity=''; b.style.pointerEvents=''; });
                    row.querySelectorAll('.pp-date-btn[data-picker-for="deadline"]').forEach(function(b){ b.disabled=true; b.style.opacity='0.45'; b.style.pointerEvents='none'; b.title='Chỉ Admin được sửa Hạn hoàn thành'; });
                } else {
                    // Reset highlight cho header pp-nhiemvu khi không có quyền
                    if (row.classList.contains('pp-nhiemvu')) {
                        const headSpans = row.querySelectorAll(':scope > div:first-child span');
                        headSpans.forEach(sp => { const t=(sp.textContent||'').trim(); if(t==='Ngày hoàn thành'||t==='Tiến độ'){ sp.style.background=''; sp.style.color=''; sp.style.padding=''; sp.style.borderRadius=''; sp.style.fontWeight=''; sp.style.display=''; } });
                    }
                    [finishEl, progressEl].forEach(el=>{ if(!el) return; el.style.background=''; el.style.color=''; el.style.borderColor=''; el.style.fontWeight=''; });
                    row.style.borderColor = (row.querySelector('[data-k=status]')?.textContent === 'quá hạn') ? '#fca5a5' : ''; row.style.background = '';
                    row.querySelectorAll('input, textarea, select').forEach(el=>{ el.readOnly=true; el.disabled=true; el.style.opacity='0.6'; });
                    row.querySelectorAll('button').forEach(b=>{ b.disabled=true; b.style.opacity='0.45'; b.style.pointerEvents='none'; });
                }
            });
        });
        task.querySelectorAll('.pp-task-body > div > button, .pp-agency > div > button').forEach(b=>{
            if (b.textContent.includes('LĐ PCM') || b.textContent.includes('Thu gọn PCM')) return;
            if (headerBtns.includes(b)) return;
            if (b.textContent.includes('+ Nhiệm vụ') || b.textContent.includes('Xóa nhiệm vụ') || b.textContent.includes('Xóa cơ quan')) {
                b.disabled=true; b.style.opacity='0.45'; b.style.pointerEvents='none';
            }
        });
        // Chỉ Admin được thêm/xóa dòng văn bản tỉnh/xã (nội dung VB đã khóa ở trên)
        task.querySelectorAll('.pp-docs-tinh button, .pp-docs-xa button').forEach(b=>{ b.disabled=true; b.style.opacity='0.45'; b.style.pointerEvents='none'; b.title='Chỉ Admin được thêm/xóa văn bản'; });
    } else if (isAdmin) {
        task.querySelectorAll('[contenteditable]').forEach(e=> e.setAttribute('contenteditable','true'));
        task.querySelectorAll('input, textarea, select').forEach(e=>{ e.readOnly=false; e.disabled=false; e.style.opacity=''; e.style.pointerEvents=''; });
        task.querySelectorAll('.pp-task-body button').forEach(b=>{ b.disabled=false; b.style.opacity=''; b.style.pointerEvents=''; });
    }
}

function ppSyncAllProvinceRoleUI() {
    const tree = document.getElementById('provincePlanTree'); if (!tree) return;
    const isAdmin = ppIsAdmin();
    const isLimitedScope = ['action100', 'vpub', 'data_entry'].includes(CURRENT_USER?.scope);
    tree.querySelectorAll('.pp-task').forEach(ppSyncTaskRoleUI);
    if (!isAdmin && !isLimitedScope) {
        tree.querySelectorAll('[contenteditable]').forEach(e => e.setAttribute('contenteditable', 'false'));
        tree.querySelectorAll('input, textarea').forEach(e => { e.readOnly = true; });
    }
    ['provincePlanAddTask', 'provinceMigrateOldToBlocks'].forEach(fn => {
        const b = document.querySelector(`#provincePlanCard button[onclick="${fn}()"]`);
        if (b) { b.disabled = !isAdmin; b.style.opacity = isAdmin ? '' : '0.45'; b.style.pointerEvents = isAdmin ? '' : 'none'; b.title = isAdmin ? '' : 'Chỉ Admin được thao tác'; }
    });
    const confirmBtn = document.getElementById('provincePlanConfirmBtn');
    if (confirmBtn) { confirmBtn.disabled = !isAdmin; confirmBtn.style.opacity = isAdmin ? '' : '0.45'; confirmBtn.style.pointerEvents = isAdmin ? '' : 'none'; confirmBtn.title = isAdmin ? '' : 'Chỉ Admin được thao tác'; }
}

async function fetchServerOverrides() {
    try {
        const r = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'get_role_overrides', token: _apiToken() }) });
        if (!r.ok) return null;
        const j = await r.json();
        if (j && j.overrides && typeof j.overrides === 'object') {
            SERVER_OVERRIDES_CACHE = j.overrides;
            try { localStorage.setItem(SET_ROLE_STORAGE_KEY, JSON.stringify(j.overrides)); } catch (e) {}
            return j.overrides;
        }
        if (j && j.error && String(j.error).includes('role_overrides')) return null;
    } catch (e) {}
    return null;
}

function getTokenMultiScopeMap() {
    if (SERVER_OVERRIDES_CACHE && typeof SERVER_OVERRIDES_CACHE === 'object') return SERVER_OVERRIDES_CACHE;
    try {
        const raw = localStorage.getItem(SET_ROLE_STORAGE_KEY);
        if (!raw) return {};
        const obj = JSON.parse(raw);
        return obj && typeof obj === "object" && !Array.isArray(obj) ? obj : {};
    } catch (e) { return {}; }
}

function setTokenMultiScopeMap(map) {
    try { localStorage.setItem(SET_ROLE_STORAGE_KEY, JSON.stringify(map || {})); } catch (e) {}
    SERVER_OVERRIDES_CACHE = map && typeof map === 'object' ? map : null;
}

async function saveServerOverrides(map) {
    try {
        const r = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'save_role_overrides', token: _apiToken(), overrides: map }) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) return { ok: false, error: j.error || r.statusText };
        return { ok: true };
    } catch (e) { return { ok: false, error: String(e?.message || e) }; }
}

function isNGNUser(user) { return !!user && (!!user.isNGN || String(user.name||"").trim() === "Nguyễn Giang Nam"); }

function isUBNDTaskForNGN(x) {
    if (!x) return false;
    const vals = [x.owner, x.officer_name, x.unit, x.unit_name, x.role, x.commune_leader, x.office_leader, x.field, x.leader, x.source, x.issuing_authority, x.specialist_name, x.title, x.agency];
    return vals.some(v => String(v||"").toLowerCase().includes("ubnd"));
}

function canNGNEditTask(x) {
    if (!isNGNUser(CURRENT_USER)) return false;
    if (!x) return false;
    if (String(CURRENT_USER.name||"").trim() === String(x.officer_name||x.owner||"").trim()) return true;
    return isUBNDTaskForNGN(x);
}

function userHasExtraScope(user, scopeId) {
    return !!user && Array.isArray(user._extraScopes) && user._extraScopes.includes(scopeId);
}

function computeDefaultPerms(role, scope, wsId) {
    const all = { v: true, a: true, e: true, d: true };
    if (role === "admin") return Object.assign({}, all);
    if (role === "staff") {
        if (scope === wsId) return { v: true, a: true, e: true, d: false };
        return { v: false, a: false, e: false, d: false };
    }
    if (role === "department") {
        if (scope === wsId) return { v: true, a: false, e: true, d: false };
        return { v: false, a: false, e: false, d: false };
    }
    if (role === "data_entry" || scope === "data_entry") {
        if (wsId === "ttbtv") return { v: true, a: true, e: true, d: false };
        return { v: false, a: false, e: false, d: false };
    }
    return { v: false, a: false, e: false, d: false };
}

function getEffectivePerms(tokenRow, wsId) {
    const def = computeDefaultPerms(tokenRow.role, tokenRow.scope, wsId);
    const map = getTokenMultiScopeMap();
    const ov = map[tokenRow.token] && map[tokenRow.token][wsId];
    if (!ov || typeof ov !== "object") return def;
    const merged = Object.assign({}, def);
    ["v","a","e","d"].forEach(k => { if (typeof ov[k] === "boolean") merged[k] = ov[k]; });
    return merged;
}

function applyTokenMultiScope(user, token) {
    if (!user || !token) return;
    if (user._perms && typeof user._perms === 'object' && !Array.isArray(user._perms) && Object.keys(user._perms).length) {
        const extraSet0 = new Set(Array.isArray(user._extraScopes) ? user._extraScopes : []);
        Object.keys(user._perms).forEach(wsId => { const p = user._perms[wsId]; if (p && typeof p === 'object' && (p.v || p.a || p.e || p.d)) extraSet0.add(wsId); });
        user._extraScopes = Array.from(extraSet0);
        return;
    }
    const map = getTokenMultiScopeMap();
    const ov = map[token];
    if (!ov || typeof ov !== "object") return;
    if (Array.isArray(ov)) {
        const extraSet = new Set(Array.isArray(user._extraScopes) ? user._extraScopes : []);
        ov.forEach(wsId => extraSet.add(wsId));
        user._extraScopes = Array.from(extraSet);
        const perms = {};
        ov.forEach(wsId => { perms[wsId] = { v: true }; });
        user._perms = perms;
        return;
    }
    const extraSet = new Set(Array.isArray(user._extraScopes) ? user._extraScopes : []);
    const perms = {};
    Object.keys(ov).forEach(wsId => {
        const p = ov[wsId];
        if (!p || typeof p !== "object") return;
        const filtered = {};
        ["v","a","e","d"].forEach(k => { if (typeof p[k] === "boolean") filtered[k] = p[k]; });
        if (!Object.keys(filtered).length) return;
        if (typeof filtered.v !== "boolean" && (filtered.a || filtered.e || filtered.d)) filtered.v = true;
        perms[wsId] = filtered;
        const def = computeDefaultPerms(user.role, user.scope, wsId);
        const effV = typeof filtered.v === "boolean" ? filtered.v : !!def.v;
        if (effV) extraSet.add(wsId);
        else if (typeof filtered.v === "boolean" && !filtered.v) extraSet.delete(wsId);
    });
    user._extraScopes = Array.from(extraSet);
    user._perms = perms;
}

function userCan(user, action, workspaceId) {
    if (!user) return false;
    if (user.role === "admin") return true;
    const actionKey = action === "view" ? "v" : action === "add" ? "a" : action === "edit" ? "e" : action === "delete" ? "d" : null;
    if (!actionKey) return false;
    if (user._perms && user._perms[workspaceId] && typeof user._perms[workspaceId][actionKey] === "boolean") {
        return user._perms[workspaceId][actionKey];
    }
    const def = computeDefaultPerms(user.role, user.scope, workspaceId);
    if (user.scope === workspaceId) return !!def[actionKey];
    if (actionKey === "v" && user._extraScopes && user._extraScopes.includes(workspaceId)) return true;
    return !!def[actionKey] && !!user._extraScopes && user._extraScopes.includes(workspaceId);
}

async function openSetRoleModal() {
    if (!CURRENT_USER || CURRENT_USER.role !== "admin") {
        if (typeof showToast === "function") showToast("error", "Không có quyền", "Chỉ Admin được mở Set role.");
        return;
    }
    const inp = document.getElementById('setRolePasswordInput'); if (inp) inp.value = "";
    const err = document.getElementById('setRolePasswordError'); if (err) err.style.display = "none";
    smoothOpenModal('setRolePasswordModal');
    setTimeout(()=>{ try{ document.getElementById('setRolePasswordInput')?.focus(); }catch(e){} }, 100);
}

function closeSetRolePasswordModal(){ try{ smoothCloseModal('setRolePasswordModal'); }catch(e){ const m=document.getElementById('setRolePasswordModal'); if(m) m.classList.remove('open'); } }

async function confirmSetRolePassword(){
    const val = String(document.getElementById('setRolePasswordInput')?.value||"").trim();
    if (!(await verifyAdminToken(val))) {
        const err=document.getElementById('setRolePasswordError'); if(err) err.style.display="block";
        try{ showToast('error','Sai mật khẩu','Vui lòng kiểm tra lại.'); }catch(e){}
        return;
    }
    closeSetRolePasswordModal();
    const modal = document.getElementById("setRoleModal");
    if (modal) modal.classList.add("open");
    await fetchServerOverrides();
    await loadSetRoleTokens();
}

function closeSetRoleModal() {
    const modal = document.getElementById("setRoleModal");
    if (modal) modal.classList.remove("open");
}

async function loadSetRoleTokens() {
    const status = document.getElementById("setRoleStatus");
    if (status) status.textContent = "Đang tải danh sách token...";
    let tokens = [];
    try {
        const r = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'list_tokens', token: _apiToken() }) });
        const j = await r.json().catch(() => ({}));
        if (r.ok && Array.isArray(j.tokens)) tokens = j.tokens;
        else if (status) status.textContent = j.error || "Không tải được danh sách token.";
    } catch (e) { console.warn("loadSetRoleTokens", e); }
    SET_ROLE_TOKENS = tokens;
    if (status) status.textContent = `Đã tải ${tokens.length} token. Tick workspace bổ sung rồi bấm Lưu.`;
    renderSetRoleTable();
}

function renderSetRoleTable() {
    const tbody = document.getElementById("setRoleBody");
    if (!tbody) return;
    const search = (document.getElementById("setRoleSearch")?.value || "").toLowerCase().trim();
    const srcFilter = document.getElementById("setRoleSourceFilter")?.value || "";
    const map = getTokenMultiScopeMap();
    const rows = SET_ROLE_TOKENS.filter(t => {
        if (srcFilter && t.src !== srcFilter) return false;
        if (!search) return true;
        const hay = [t.token, t.name, t.title, t.unit, t.role, t.scope, t.src].join(" ").toLowerCase();
        return hay.includes(search);
    });
    if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="29" style="text-align:center;padding:24px;color:#94a3b8">Không có token phù hợp.</td></tr>`;
        return;
    }
    tbody.innerHTML = rows.map(t => {
        const override = map[t.token] || {};
        const checks = SET_ROLE_WORKSPACES.map(ws => {
            const def = computeDefaultPerms(t.role, t.scope, ws.id);
            const ovWs = override[ws.id];
            const cells = SET_ROLE_ACTIONS.map(act => {
                const defVal = def[act.id];
                let curVal = defVal;
                if (ovWs && typeof ovWs[act.id] === "boolean") curVal = ovWs[act.id];
                else if (act.id === "v" && ovWs && (ovWs.a || ovWs.e || ovWs.d)) curVal = true;
                const changed = ovWs && typeof ovWs[act.id] === "boolean" && ovWs[act.id] !== defVal;
                const effChanged = changed || (act.id === "v" && !ovWs?.v && ovWs && (ovWs.a || ovWs.e || ovWs.d) && defVal === false && curVal === true);
                const checked = curVal ? "checked" : "";
                const title = `${ws.label} · ${act.label}: ${curVal ? "Có" : "Không"}${effChanged ? " (đã sửa)" : ""}${!effChanged && curVal === defVal && defVal ? " (mặc định)" : ""}`;
                const accent = effChanged ? ' style="accent-color:#f59e0b"' : "";
                return `<td style="text-align:center;padding:4px"><input type="checkbox" data-token="${esc(t.token)}" data-ws="${ws.id}" data-action="${act.id}" data-default="${defVal ? 1 : 0}" ${checked} title="${title}"${accent}></td>`;
            }).join("");
            return cells;
        }).join("");
        const srcLabel = t.src === "admin" ? "Admin (hardcoded)" : t.src;
        return `<tr>
            <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${esc(maskToken(t.token))}</code></td>
            <td><b>${esc(t.name)}</b><div style="font-size:11px;color:#64748b">${esc(t.title || "")}${t.unit ? " · " + esc(t.unit) : ""}</div></td>
            <td><span class="set-role-role role-${esc(t.role)}">${esc(t.role)}</span></td>
            <td>${esc(t.scope)}</td>
            <td style="font-size:11px;color:#475569">${esc(srcLabel)}</td>
            ${checks}
        </tr>`;
    }).join("");
}

function collectSetRoleOverrides() {
    const checks = document.querySelectorAll('#setRoleBody input[type="checkbox"]');
    const map = {};
    checks.forEach(c => {
        const tok = c.getAttribute("data-token");
        const ws = c.getAttribute("data-ws");
        const act = c.getAttribute("data-action");
        const def = c.getAttribute("data-default") === "1";
        if (!tok || !ws || !act) return;
        if (!map[tok]) map[tok] = {};
        if (!map[tok][ws]) map[tok][ws] = {};
        const cur = c.checked;
        if (cur !== def) map[tok][ws][act] = cur;
    });
    Object.keys(map).forEach(tok => {
        Object.keys(map[tok]).forEach(ws => {
            const o = map[tok][ws];
            if ((o.a || o.e || o.d) && typeof o.v !== "boolean") o.v = true;
            const allFalse = !o.v && !o.a && !o.e && !o.d;
            if (allFalse) delete map[tok][ws];
        });
        if (!Object.keys(map[tok]).length) delete map[tok];
    });
    return map;
}

async function saveSetRole() {
    const fromForm = collectSetRoleOverrides();
    const current = getTokenMultiScopeMap();
    const merged = { ...current };
    Object.keys(fromForm).forEach(tok => { merged[tok] = fromForm[tok]; });
    const formTokens = new Set(Object.keys(fromForm));
    SET_ROLE_TOKENS.forEach(t => { if (!formTokens.has(t.token) && merged[t.token]) delete merged[t.token]; });
    setTokenMultiScopeMap(merged);
    let totalPerms = 0;
    Object.values(merged).forEach(t => { Object.values(t).forEach(ws => { totalPerms += Object.values(ws).filter(v => v === true).length; }); });
    if (typeof showToast === "function") showToast("success", "Đã lưu (local)", `${Object.keys(merged).length} token có override (${totalPerms} quyền). Đang đồng bộ server...`);
    try { writeActivity("Set role", { tokens: Object.keys(merged).length, perms: totalPerms }); } catch (e) {}
    const srv = await saveServerOverrides(merged);
    if (srv.ok) {
        if (typeof showToast === "function") showToast("success", "Đã đồng bộ", `Server đã lưu ${Object.keys(merged).length} token. NGN đăng nhập lại ở mọi trình duyệt sẽ có quyền mới.`);
    } else {
        const msg = srv.error && String(srv.error).includes('role_overrides') ? 'Bảng role_overrides chưa tồn tại - hãy chạy SQL tạo bảng (xem supabase_seed_tokens.sql)' : (srv.error || 'không đồng bộ được server');
        if (typeof showToast === "function") showToast("error", "Chỉ lưu local", msg + ' - override chỉ có tác dụng trên trình duyệt này.');
    }
}

async function clearSetRoleOverrides() {
    if (!confirm("Xóa toàn bộ override multi-scope? Token sẽ trở về scope gốc từ bảng officers.")) return;
    setTokenMultiScopeMap({});
    const srv = await saveServerOverrides({});
    if (srv.ok) {
        if (typeof showToast === "function") showToast("success", "Đã xóa", "Đã xóa toàn bộ override trên local và server.");
    } else {
        renderSetRoleTable();
        if (typeof showToast === "function") showToast("success", "Đã xóa local", "Đã xóa local. Server chưa xóa được - " + (srv.error || ''));
        return;
    }
    renderSetRoleTable();
}


// ===== Dùng chung: token hiện tại, che token, xác minh Admin phía máy chủ =====
function _apiToken() {
    return String((typeof CURRENT_USER !== "undefined" && CURRENT_USER && CURRENT_USER._rawToken) || (typeof _readStoredToken === "function" ? _readStoredToken() : "") || "").trim();
}
function maskToken(t) {
    const s = String(t || "");
    return s.length <= 10 ? "••••" : s.slice(0, 8) + "…" + s.slice(-3);
}
async function verifyAdminToken(candidate) {
    const tok = String(candidate || "").trim();
    if (!tok) return false;
    try {
        const r = await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "verify_admin", token: tok }) });
        return r.ok;
    } catch (e) { return false; }
}

// ===== Gắn X-User-Token vào mọi yêu cầu tới Supabase để RLS phía CSDL xác thực quyền =====
(function installSupabaseTokenHeader() {
    if (window.__vpTokenFetch) return;
    window.__vpTokenFetch = true;
    const orig = window.fetch.bind(window);
    window.fetch = function (input, init) {
        try {
            const url = typeof input === "string" ? input : (input && input.url) || "";
            const base = (typeof SUPABASE_URL !== "undefined" && SUPABASE_URL) || (window.SUPABASE_CONFIG && window.SUPABASE_CONFIG.url) || "";
            if (base && url.indexOf(base) === 0) {
                const tok = _apiToken();
                if (tok) {
                    init = init ? Object.assign({}, init) : {};
                    const h = new Headers(init.headers || (typeof input !== "string" && input.headers) || {});
                    if (!h.has("X-User-Token")) h.set("X-User-Token", tok);
                    init.headers = h;
                }
            }
        } catch (e) { /* không chặn yêu cầu nếu gắn header lỗi */ }
        return orig(input, init);
    };
})();
