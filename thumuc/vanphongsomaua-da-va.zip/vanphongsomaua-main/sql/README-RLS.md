# Triển khai bản vá bảo mật — Văn phòng số Mậu A

Làm đúng thứ tự. Mỗi bước có cách kiểm tra; chưa đạt thì chưa sang bước sau.
Nên thử trên một dự án Vercel preview và (nếu được) một dự án Supabase thử nghiệm trước.

## Bước 0 — Sao lưu
- Supabase Dashboard > Database > Backups (hoặc dùng nút "Sao lưu" trong ứng dụng khi còn đăng nhập Admin).
- Cất tệp sao lưu NGOÀI kho mã (tệp này chứa token của cán bộ).

## Bước 1 — Tạo token Admin mới
```bash
openssl rand -hex 24          # ra chuỗi 48 ký tự: đây là token Admin mới
printf '%s' 'CHUỖI-VỪA-TẠO' | sha256sum   # ra mã băm 64 ký tự dùng ở Bước 4
```
Token cũ `ADM-MAUA-adm` coi như đã lộ và không còn dùng được sau khi triển khai mã mới.

## Bước 2 — Cấu hình Vercel và triển khai mã
Vercel > Settings > Environment Variables: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_TOKEN` (xem env.example.txt).
Triển khai thư mục này. Kiểm tra:
1. Đăng nhập bằng token Admin MỚI → vào được. Token `ADM-MAUA-adm` → bị từ chối.
2. Đăng nhập bằng một token cán bộ và một token cơ quan (CQ-*) → vào được, thấy đúng workspace.
3. Mở Set role → hỏi nhập lại token Admin; danh sách token hiển thị dạng che (`CB-MAUA-…xyz`).
Ở bước này RLS Phase 1 vẫn đang chạy nên ứng dụng hoạt động như cũ; client đã bắt đầu gửi header `X-User-Token`.

## Bước 3 — Edge Function
```bash
supabase functions delete secure-write           # không dùng, và có lỗ hổng
supabase secrets set ADMIN_TOKEN='...' MAIL_FROM='Văn phòng số Mậu A <thongbao@miền-đã-xác-minh>' ALLOWED_ORIGINS='https://vanphongsomaua.vercel.app'
supabase functions deploy send-email
```
Kiểm tra: gửi thử một thông báo hạn từ tài khoản Admin → thành công. Gọi thẳng bằng curl không kèm `x-user-token` → 401.

## Bước 4 — RLS Phase 2A (chặn truy cập không có token)
1. Mở `sql/rls-phase2a-token-required.sql`, thay mã băm ở BƯỚC 2 (bỏ `--` đầu dòng), chạy toàn bộ trong SQL Editor.
2. Hard refresh trình duyệt (Ctrl+Shift+R), đăng nhập lại.
Kiểm tra (thay `URL` và `ANON` bằng giá trị trong js/config.js):
```bash
# a) Không token: phải trả về [] (RLS chặn đọc)
curl -s "URL/rest/v1/tasks?select=id&limit=1" -H "apikey: ANON" -H "Authorization: Bearer ANON"
# b) Đọc cột token: phải báo lỗi permission denied
curl -s "URL/rest/v1/officers?select=token&limit=1" -H "apikey: ANON" -H "Authorization: Bearer ANON" -H "X-User-Token: <TOKEN-CÁN-BỘ-HỢP-LỆ>"
# c) Ghi không token: phải bị từ chối
curl -s -X DELETE "URL/rest/v1/tasks?id=eq.-1" -H "apikey: ANON" -H "Authorization: Bearer ANON"
```
Nếu một chức năng bỗng hiện 0 dòng sau bước này: nhiều khả năng có chỗ gọi Supabase mà không đi qua `fetch` toàn cục (ví dụ iframe, tab mới). Cần thêm header `X-User-Token` ở chỗ đó. Cần quay lại ngay: `sql/rls-rollback.sql`, phần B.

## Bước 5 — Thử toàn bộ chức năng bằng tài khoản thật (ít nhất 1 Admin, 1 cán bộ, 1 cơ quan CQ-*)
Xem bảng kiểm thử trong báo cáo kế hoạch. Đặc biệt: thêm/sửa/xóa ở từng workspace, tải tệp đính kèm, xuất Excel/CSV, Set role, Sao lưu/Khôi phục, Gửi email.

## Bước 6 — RLS Phase 2B (siết theo workspace) — sau vài ngày chạy ổn
Chạy `sql/rls-phase2b-scope-strict.sql`. Cán bộ chỉ thêm/sửa được ở workspace của mình (và nơi Set role cấp thêm); xóa chỉ khi được cấp quyền `d`.
Quay về 2A: `sql/rls-rollback.sql`, phần A.

## Bước 7 — Xoay toàn bộ token
Kho mã và lịch sử git từng chứa token, mật khẩu cũ và tệp sao lưu. Sau khi hệ thống ổn: cấp token mới cho toàn bộ cán bộ (cột `token` mỗi bảng), phát lại cho từng người, đồng thời thu hồi token cũ. Dọn lịch sử git (`git filter-repo`) nếu kho có thể bị chia sẻ rộng.

## Còn lại sau các bước trên (rủi ro đã biết)
- Token vẫn lưu ở trình duyệt dạng đảo chuỗi + base64 (che chữ, không phải mã hóa).
- Cán bộ cùng workspace vẫn sửa được nhiệm vụ của nhau ở mức CSDL; chỉ giao diện hạn chế.
- Chống dò token ở `api/admin.js` chỉ là best-effort (bộ nhớ từng instance) — nên bật Vercel Firewall rate limit cho `/api/admin`.
- Chính sách của Supabase Storage (tệp đính kèm) chưa có trong kho mã: cần kiểm tra thủ công trên Dashboard > Storage > Policies.
- `department_tasks`, `mttq_kpi_*`, `nq_tw` mới yêu cầu "token hợp lệ", chưa siết theo workspace.
