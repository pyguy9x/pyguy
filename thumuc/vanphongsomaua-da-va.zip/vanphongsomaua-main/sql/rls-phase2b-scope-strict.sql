-- ==========================================================================
-- RLS PHASE 2B — siết quyền ghi theo từng workspace (khớp computeDefaultPerms + Set role)
-- CHỈ CHẠY SAU KHI Phase 2A đã chạy ổn ít nhất vài ngày và đã kiểm tra bảng test trong README-RLS.md.
--
-- Quy tắc (giống giao diện):
--   admin                       : toàn quyền
--   cán bộ (CB-*) đúng workspace: thêm + sửa, KHÔNG xóa
--   cơ quan (CQ-*) đúng workspace: chỉ sửa
--   CV nhập liệu                : thêm + sửa ở TT/BTV
--   role_overrides (Set role)   : cộng/trừ quyền v/a/e/d theo token, ưu tiên cao nhất
-- Chưa siết (vẫn "token hợp lệ"): department_tasks, mttq_kpi_*, nq_tw — cần xác nhận ai được ghi.
-- Không kiểm soát được ở mức dòng: cán bộ cùng workspace vẫn sửa được nhiệm vụ của nhau.
-- ==========================================================================

create or replace function public.vp_can(p_ws text, p_act text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare
  t text := public.vp_token();
  sc text := public.vp_scope();
  base boolean := false;
  ov text;
begin
  if sc is null then return false; end if;
  if sc = 'admin' then return true; end if;
  if sc = p_ws then
    if t like 'CQ-%' then base := p_act in ('v', 'e');
    else base := p_act in ('v', 'a', 'e');
    end if;
  elsif sc = 'data_entry' and p_ws = 'ttbtv' then
    base := p_act in ('v', 'a', 'e');
  end if;
  select (r.perms -> p_ws ->> p_act) into ov from public.role_overrides r where r.token = t;
  if ov in ('true', 'false') then return ov::boolean; end if;
  return base;
end $$;
grant execute on function public.vp_can(text, text) to anon, authenticated;

drop policy if exists "p2a_tasks_all" on public.tasks;
create policy "p2b_tasks_sel" on public.tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_tasks_ins" on public.tasks for insert to anon, authenticated with check ((select public.vp_can('bch', 'a')));
create policy "p2b_tasks_upd" on public.tasks for update to anon, authenticated using ((select public.vp_can('bch', 'e'))) with check ((select public.vp_can('bch', 'e')));
create policy "p2b_tasks_del" on public.tasks for delete to anon, authenticated using ((select public.vp_can('bch', 'd')));

drop policy if exists "p2a_tt_btv_tasks_all" on public.tt_btv_tasks;
create policy "p2b_tt_btv_tasks_sel" on public.tt_btv_tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_tt_btv_tasks_ins" on public.tt_btv_tasks for insert to anon, authenticated with check ((select public.vp_can('ttbtv', 'a')));
create policy "p2b_tt_btv_tasks_upd" on public.tt_btv_tasks for update to anon, authenticated using ((select public.vp_can('ttbtv', 'e'))) with check ((select public.vp_can('ttbtv', 'e')));
create policy "p2b_tt_btv_tasks_del" on public.tt_btv_tasks for delete to anon, authenticated using ((select public.vp_can('ttbtv', 'd')));

drop policy if exists "p2a_province_tasks_all" on public.province_tasks;
create policy "p2b_province_tasks_sel" on public.province_tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_province_tasks_ins" on public.province_tasks for insert to anon, authenticated with check ((select public.vp_can('province', 'a')));
create policy "p2b_province_tasks_upd" on public.province_tasks for update to anon, authenticated using ((select public.vp_can('province', 'e'))) with check ((select public.vp_can('province', 'e')));
create policy "p2b_province_tasks_del" on public.province_tasks for delete to anon, authenticated using ((select public.vp_can('province', 'd')));

drop policy if exists "p2a_province_plan_blocks_all" on public.province_plan_blocks;
create policy "p2b_province_plan_blocks_sel" on public.province_plan_blocks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_province_plan_blocks_ins" on public.province_plan_blocks for insert to anon, authenticated with check ((select public.vp_can('province', 'a')));
create policy "p2b_province_plan_blocks_upd" on public.province_plan_blocks for update to anon, authenticated using ((select public.vp_can('province', 'e'))) with check ((select public.vp_can('province', 'e')));
create policy "p2b_province_plan_blocks_del" on public.province_plan_blocks for delete to anon, authenticated using ((select public.vp_can('province', 'd')));

drop policy if exists "p2a_action_100_days_tasks_all" on public.action_100_days_tasks;
create policy "p2b_action_100_days_tasks_sel" on public.action_100_days_tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_action_100_days_tasks_ins" on public.action_100_days_tasks for insert to anon, authenticated with check ((select public.vp_can('action100', 'a')));
create policy "p2b_action_100_days_tasks_upd" on public.action_100_days_tasks for update to anon, authenticated using ((select public.vp_can('action100', 'e'))) with check ((select public.vp_can('action100', 'e')));
create policy "p2b_action_100_days_tasks_del" on public.action_100_days_tasks for delete to anon, authenticated using ((select public.vp_can('action100', 'd')));

drop policy if exists "p2a_vpub_tasks_all" on public.vpub_tasks;
create policy "p2b_vpub_tasks_sel" on public.vpub_tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_vpub_tasks_ins" on public.vpub_tasks for insert to anon, authenticated with check ((select public.vp_can('vpub', 'a')));
create policy "p2b_vpub_tasks_upd" on public.vpub_tasks for update to anon, authenticated using ((select public.vp_can('vpub', 'e'))) with check ((select public.vp_can('vpub', 'e')));
create policy "p2b_vpub_tasks_del" on public.vpub_tasks for delete to anon, authenticated using ((select public.vp_can('vpub', 'd')));

drop policy if exists "p2a_office_tasks_all" on public.office_tasks;
create policy "p2b_office_tasks_sel" on public.office_tasks for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2b_office_tasks_ins" on public.office_tasks for insert to anon, authenticated with check ((select public.vp_can('office', 'a')));
create policy "p2b_office_tasks_upd" on public.office_tasks for update to anon, authenticated using ((select public.vp_can('office', 'e'))) with check ((select public.vp_can('office', 'e')));
create policy "p2b_office_tasks_del" on public.office_tasks for delete to anon, authenticated using ((select public.vp_can('office', 'd')));

-- Nhật ký chỉ Admin được đọc (giao diện chỉ Admin xem)
drop policy if exists "p2a_activity_sel" on public.activity_logs;
create policy "p2b_activity_sel" on public.activity_logs for select to anon, authenticated using ((select public.vp_scope()) = 'admin');
