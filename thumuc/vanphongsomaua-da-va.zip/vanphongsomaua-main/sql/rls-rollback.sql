-- ==========================================================================
-- ROLLBACK RLS — chỉ dùng khi sự cố. Đọc kỹ phần nào cần chạy.
-- ==========================================================================

-- ---------- A. Từ Phase 2B quay về Phase 2A (vẫn bắt buộc token hợp lệ) ----------
drop policy if exists "p2b_tasks_sel" on public.tasks;
drop policy if exists "p2b_tasks_ins" on public.tasks;
drop policy if exists "p2b_tasks_upd" on public.tasks;
drop policy if exists "p2b_tasks_del" on public.tasks;
create policy "p2a_tasks_all" on public.tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_tt_btv_tasks_sel" on public.tt_btv_tasks;
drop policy if exists "p2b_tt_btv_tasks_ins" on public.tt_btv_tasks;
drop policy if exists "p2b_tt_btv_tasks_upd" on public.tt_btv_tasks;
drop policy if exists "p2b_tt_btv_tasks_del" on public.tt_btv_tasks;
create policy "p2a_tt_btv_tasks_all" on public.tt_btv_tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_province_tasks_sel" on public.province_tasks;
drop policy if exists "p2b_province_tasks_ins" on public.province_tasks;
drop policy if exists "p2b_province_tasks_upd" on public.province_tasks;
drop policy if exists "p2b_province_tasks_del" on public.province_tasks;
create policy "p2a_province_tasks_all" on public.province_tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_province_plan_blocks_sel" on public.province_plan_blocks;
drop policy if exists "p2b_province_plan_blocks_ins" on public.province_plan_blocks;
drop policy if exists "p2b_province_plan_blocks_upd" on public.province_plan_blocks;
drop policy if exists "p2b_province_plan_blocks_del" on public.province_plan_blocks;
create policy "p2a_province_plan_blocks_all" on public.province_plan_blocks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_action_100_days_tasks_sel" on public.action_100_days_tasks;
drop policy if exists "p2b_action_100_days_tasks_ins" on public.action_100_days_tasks;
drop policy if exists "p2b_action_100_days_tasks_upd" on public.action_100_days_tasks;
drop policy if exists "p2b_action_100_days_tasks_del" on public.action_100_days_tasks;
create policy "p2a_action_100_days_tasks_all" on public.action_100_days_tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_vpub_tasks_sel" on public.vpub_tasks;
drop policy if exists "p2b_vpub_tasks_ins" on public.vpub_tasks;
drop policy if exists "p2b_vpub_tasks_upd" on public.vpub_tasks;
drop policy if exists "p2b_vpub_tasks_del" on public.vpub_tasks;
create policy "p2a_vpub_tasks_all" on public.vpub_tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_office_tasks_sel" on public.office_tasks;
drop policy if exists "p2b_office_tasks_ins" on public.office_tasks;
drop policy if exists "p2b_office_tasks_upd" on public.office_tasks;
drop policy if exists "p2b_office_tasks_del" on public.office_tasks;
create policy "p2a_office_tasks_all" on public.office_tasks for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
drop policy if exists "p2b_activity_sel" on public.activity_logs;
create policy "p2a_activity_sel" on public.activity_logs for select to anon, authenticated using ((select public.vp_scope()) is not null);

-- ---------- B. KHẨN CẤP: về lại Phase 1 (ai có khóa anon cũng ghi được — KHÔNG an toàn) ----------
-- Chỉ chạy nếu ứng dụng không dùng được và cần khôi phục dịch vụ ngay. Sau đó phải xử lý nguyên nhân và chạy lại 2A.
-- do $$
-- declare t text; pol record;
-- begin
--   foreach t in array array['officers','tt_btv_officers','province_officers','office_officers','action_100_days_officers',
--     'tasks','tt_btv_tasks','province_tasks','province_plan_blocks','action_100_days_tasks','vpub_tasks','office_tasks',
--     'department_tasks','mttq_kpi_people','mttq_kpi_catalog','mttq_kpi_tasks','activity_logs'] loop
--     for pol in select policyname from pg_policies where schemaname='public' and tablename=t loop
--       execute format('drop policy %I on public.%I', pol.policyname, t);
--     end loop;
--     execute format('create policy %I on public.%I for select using (true)', 'rls_'||t||'_select', t);
--     execute format('create policy %I on public.%I for all using (auth.role() = ''anon'')', 'rls_'||t||'_anon_write', t);
--     execute format('grant select on public.%I to anon, authenticated', t);
--   end loop;
-- end $$;
