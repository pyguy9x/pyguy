-- ==========================================================================
-- RLS PHASE 2A — Văn phòng số Mậu A
-- Mục tiêu: chấm dứt việc "ai có khóa anon cũng đọc/ghi được".
--   * Mọi đọc/ghi phải kèm header X-User-Token là token hợp lệ.
--   * Cột token của 5 bảng cán bộ không còn đọc được từ trình duyệt.
--   * Bảng cán bộ chỉ Admin được ghi; role_overrides và app_admins chỉ service_role truy cập.
--
-- ĐIỀU KIỆN TRƯỚC KHI CHẠY (xem sql/README-RLS.md):
--   1. Đã triển khai bản mã mới (client gửi X-User-Token) và đăng nhập thử thành công.
--   2. Đã sao lưu CSDL (Dashboard > Database > Backups, hoặc nút Sao lưu trong ứng dụng).
--   3. Chuẩn bị mã băm SHA-256 của token Admin MỚI:   printf '%s' 'TOKEN-ADMIN-MOI' | sha256sum
--      rồi dán vào lệnh INSERT ở BƯỚC 2 (không dán token gốc vào SQL Editor).
-- Chạy trong Supabase Dashboard > SQL Editor. Có thể chạy lại nhiều lần.
-- ==========================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------- BƯỚC 1: bảng quản trị & role_overrides (chỉ service_role) ----------
create table if not exists public.app_admins (
  token_sha256 text primary key,
  note text,
  created_at timestamptz not null default now()
);
create table if not exists public.role_overrides (
  token text primary key,
  perms jsonb not null default '{}'::jsonb,
  updated_by text,
  updated_at timestamptz default now()
);
alter table public.app_admins enable row level security;
alter table public.role_overrides enable row level security;
revoke all on public.app_admins from anon, authenticated;
revoke all on public.role_overrides from anon, authenticated;

-- ---------- BƯỚC 2: đăng ký Admin (thay mã băm rồi bỏ dấu -- ở đầu dòng) ----------
-- insert into public.app_admins (token_sha256, note) values ('<MÃ-BĂM-SHA256-64-KÝ-TỰ>', 'Admin chính')
--   on conflict do nothing;

-- ---------- BƯỚC 3: hàm xác định người gọi ----------
create or replace function public.vp_token()
returns text language plpgsql stable security definer set search_path = public as $$
declare h json;
begin
  begin
    h := current_setting('request.headers', true)::json;
  exception when others then
    return null;
  end;
  return nullif(btrim(coalesce(h->>'x-user-token', '')), '');
end $$;

-- Trả về: 'admin' | 'bch' | 'ttbtv' | 'province' | 'office' | 'action100' | 'vpub' | 'data_entry' | null
-- Quy tắc khớp với api/admin.js (CV nhập liệu -> data_entry; token CQ-* -> vpub/action100).
create or replace function public.vp_scope()
returns text language plpgsql stable security definer set search_path = public, extensions as $$
declare
  t text := public.vp_token();
  v_name text;
  v_scope text;
begin
  if t is null or length(t) > 200 then return null; end if;
  if exists (select 1 from public.app_admins where token_sha256 = encode(extensions.digest(t, 'sha256'), 'hex')) then
    return 'admin';
  end if;
  select o.name, o.s into v_name, v_scope from (
    select name, 'bch'::text as s, 1 as ord from public.officers where token = t
    union all select name, 'ttbtv', 2 from public.tt_btv_officers where token = t
    union all select name, 'province', 3 from public.province_officers where token = t
    union all select name, 'office', 4 from public.office_officers where token = t
    union all select name, 'action100', 5 from public.action_100_days_officers where token = t
  ) o order by o.ord limit 1;
  if v_scope is null then return null; end if;
  if btrim(coalesce(v_name, '')) = 'CV nhập liệu' then return 'data_entry'; end if;
  if t like 'CQ-%' then
    return case when btrim(coalesce(v_name, '')) = 'VPUB' then 'vpub' else 'action100' end;
  end if;
  return v_scope;
end $$;

grant execute on function public.vp_token() to anon, authenticated;
grant execute on function public.vp_scope() to anon, authenticated;

-- ---------- BƯỚC 4: xóa chính sách cũ (Phase 1: "anon được ghi") và bật RLS ----------
do $$
declare t text; pol record;
begin
  foreach t in array array['officers','tt_btv_officers','province_officers','office_officers','action_100_days_officers',
                           'tasks', 'tt_btv_tasks', 'province_tasks', 'province_plan_blocks', 'action_100_days_tasks', 'vpub_tasks', 'office_tasks', 'department_tasks', 'mttq_kpi_people', 'mttq_kpi_catalog', 'mttq_kpi_tasks',
                           'activity_logs','nq_tw'] loop
    if to_regclass('public.' || t) is null then
      raise notice 'Bỏ qua bảng không tồn tại: %', t;
      continue;
    end if;
    execute format('alter table public.%I enable row level security', t);
    for pol in select policyname from pg_policies where schemaname = 'public' and tablename = t loop
      execute format('drop policy %I on public.%I', pol.policyname, t);
    end loop;
  end loop;
end $$;

-- ---------- BƯỚC 5: chính sách mới ----------
create policy "p2a_tasks_all" on public.tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_tt_btv_tasks_all" on public.tt_btv_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_province_tasks_all" on public.province_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_province_plan_blocks_all" on public.province_plan_blocks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_action_100_days_tasks_all" on public.action_100_days_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_vpub_tasks_all" on public.vpub_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_office_tasks_all" on public.office_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_department_tasks_all" on public.department_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_mttq_kpi_people_all" on public.mttq_kpi_people for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_mttq_kpi_catalog_all" on public.mttq_kpi_catalog for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);
create policy "p2a_mttq_kpi_tasks_all" on public.mttq_kpi_tasks for all to anon, authenticated
  using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null);

-- Bảng cán bộ: ai có token hợp lệ được đọc (không gồm cột token); chỉ Admin được ghi
create policy "p2a_officers_sel" on public.officers for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_officers_wr"  on public.officers for all    to anon, authenticated using ((select public.vp_scope()) = 'admin') with check ((select public.vp_scope()) = 'admin');
create policy "p2a_tt_btv_officers_sel" on public.tt_btv_officers for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_tt_btv_officers_wr"  on public.tt_btv_officers for all    to anon, authenticated using ((select public.vp_scope()) = 'admin') with check ((select public.vp_scope()) = 'admin');
create policy "p2a_province_officers_sel" on public.province_officers for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_province_officers_wr"  on public.province_officers for all    to anon, authenticated using ((select public.vp_scope()) = 'admin') with check ((select public.vp_scope()) = 'admin');
create policy "p2a_office_officers_sel" on public.office_officers for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_office_officers_wr"  on public.office_officers for all    to anon, authenticated using ((select public.vp_scope()) = 'admin') with check ((select public.vp_scope()) = 'admin');
create policy "p2a_action_100_days_officers_sel" on public.action_100_days_officers for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_action_100_days_officers_wr"  on public.action_100_days_officers for all    to anon, authenticated using ((select public.vp_scope()) = 'admin') with check ((select public.vp_scope()) = 'admin');

-- Nhật ký: token hợp lệ được đọc/ghi thêm; chỉ Admin được xóa
create policy "p2a_activity_sel" on public.activity_logs for select to anon, authenticated using ((select public.vp_scope()) is not null);
create policy "p2a_activity_ins" on public.activity_logs for insert to anon, authenticated with check ((select public.vp_scope()) is not null);
create policy "p2a_activity_del" on public.activity_logs for delete to anon, authenticated using ((select public.vp_scope()) = 'admin');

-- nq_tw (nếu có)
do $$
begin
  if to_regclass('public.nq_tw') is not null then
    execute 'create policy "p2a_nq_tw_all" on public.nq_tw for all to anon, authenticated using ((select public.vp_scope()) is not null) with check ((select public.vp_scope()) is not null)';
  end if;
end $$;

-- ---------- BƯỚC 6: ẩn cột token khỏi trình duyệt ----------
do $$
declare t text; cols text;
begin
  foreach t in array array['officers','tt_btv_officers','province_officers','office_officers','action_100_days_officers'] loop
    if to_regclass('public.' || t) is null then continue; end if;
    select string_agg(quote_ident(column_name), ', ' order by ordinal_position) into cols
      from information_schema.columns
     where table_schema = 'public' and table_name = t and column_name <> 'token';
    execute format('revoke select on public.%I from anon, authenticated', t);
    execute format('grant select (%s) on public.%I to anon, authenticated', cols, t);
  end loop;
end $$;

-- ---------- BƯỚC 7: kiểm tra ----------
select tablename, rowsecurity from pg_tables
 where schemaname = 'public' and tablename in ('officers','tt_btv_officers','province_officers','office_officers',
   'action_100_days_officers','tasks','office_tasks','role_overrides','app_admins') order by tablename;
